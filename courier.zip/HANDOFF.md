# HANDOFF — Consolidation + Node Layer Session (2026-07-03)

This package is a **drop-in replacement**: `courier/` and `gator/` at the
same paths as the original archive, with the prior session's consolidated
patch merged in and this session's work applied on top. Unzip over the
repo root (or replace it). No migration steps: new DB tables/columns are
created idempotently on next boot; old ledgers gain the `meta` table
automatically; legacy rows with unparseable `config` are repaired or
loudly degraded at the API, never at the client.

Read this file, then the changelog in `courier/README.md` (every item
below has a fuller entry there).

---

## What this session shipped

### 1. Consolidation + quality gate
The prior session's package (daemon mode, systemd deployment, dashboard
cache fix, FTS5 corpus retrieval, energy metering) was merged over the
base archive and reviewed line-by-line. Four fixes from that review:
imports made contiguous in `worker.py`, a dead import removed from
`corpus.py`, a double params-merge in `corpus_search.py` reduced to one
merge point (`_merged`), and the "probes probes" doubled word in the
energy suite title.

### 2. No-hidden-knobs pass (project rule, now enforced)
Every should-be-configurable parameter has an operator surface,
registered in the README's recognized-variables table AND `.env.example`:
`COURIER_WATTS_PER_CORE` (was code-only), `COURIER_ENERGY_SAMPLE_INTERVAL`
(new), `corpus_search` param `max_terms` (was a hidden constant), digestor
flag `--min-chunk-chars` (was a hidden constant), and — found later during
the auth work — `COURIER_TRUST_PROXY`, which existed in the gate's code
but appeared in no documentation. Precedence is uniformly
*explicit argument > environment > default*. Literals that are
deliberately NOT knobs are named module constants with a comment saying
so.

### 3. Node identity + NETWORK tab ("a network of one is still a network")
- **Courier ID**: stable node identity (`courier-<12 hex>`), minted once,
  persisted in the ledger's new `meta` key/value table — survives
  restarts and travels with a DB export. This is the first brick of the
  courier-network protocol: receipts/envelopes will sign as this name.
- **`GET /api/node`**: identity, interface addresses, reach/scheme/auth
  posture, uptime, current + last-completed cycle, lifetime totals
  (cycles · tokens · metered joules), corpus holdings, and an honest
  `peers: 0` block stating the exchange protocol is designed but unbuilt.
- **`GET /api/corpus`**: corpus stats + listing.
- **Dashboard NETWORK tab** renders all of it (copy button on the ID;
  refreshes at the operator-configured SSE cadence — no hidden timer).
- DB additions: `meta` table, `get_meta/set_meta`, `cycle_totals()`
  (energy is `None` when unmetered — absent ≠ free).

### 4. Write-auth posture: configurable, safest-by-default, loud
One pure decision point — `core/security.py::write_posture()` — with four
modes, safest wins on conflict:
`token-required` > `insecure-bypass` > `proxy-trusted` > `local-origin`.
- `COURIER_REQUIRE_TOKEN=1`: bearer token for EVERY write; beats even
  `COURIER_INSECURE=1`. The setting for any proxied/shared/public port.
- `COURIER_TRUST_PROXY=0`: opts a Codespace out of the automatic proxy
  trust it gets from the `CODESPACES` env (previously no off switch).
- Startup prints the posture and a `⚠ AUTH WARNING` when trust is broad;
  the NETWORK tab renders the posture amber (red for the bypass) with the
  hazard note. The hazard, spelled out in README →
  *Security & Networking → Proxies & forwarded ports*: a Codespaces port
  flipped to **Public** forwards anyone with a rewritten local Host.

### 5. Energy surfaced across the UI
History rows show per-cycle joules inline; the expanded view carries the
`412 J (rapl) · 18.1 W avg` line; the history header totals metered
energy with the method mix; the Settings drawer's System section reports
the active instrument and its `.env` knobs. `_build_history()` and the
SSE `system` state now carry the energy fields; the worker's meter
singleton is public (`engine.worker.get_meter`).

### 6. Receipt integrity — three bugs found via operator screenshots
- **Metadata dashes (deeper cause).** `fetchCycleConfig` parsed the
  `config` JSON in the same silent try as the row's ledger facts; any
  failure voided timestamps/energy/params permanently, without a word.
  Now: the fragile parse is isolated (ledger facts banked regardless),
  the endpoint guarantees valid-JSON-or-stated-reason via
  `report.normalize_config_json` (legacy Python-repr rows repaired with
  `ast.literal_eval` — literals only; garbage → `{}` + `config_error`),
  and failures render an amber banner with the reason + RETRY.
- **The 'think' block bug (three cooperating defects).** (a) The prompt
  formatters' `thinking` parameter was "Reserved for future use" —
  ignored — so non-thinking image stages let the model burn ~5 budgeted
  tokens emitting `<think></think>` itself; both formatters now prime
  the assistant turn with the Qwen3 closed-think convention. (b) The
  think-strip was gated on *not truncated*, so truncated receipts showed
  the junk; rules now live in torch-free `engine/textproc.py` (empty
  pairs stripped always; closed blocks stripped when thinking off;
  unclosed left intact; never strip to blank). (c) Token counts were
  `len(text)//4` estimates including scaffolding and the truncation
  banner ("66 tokens" on a 32-token stage); the engine now returns
  `(text, real_count)`, persisted to `cycle_stages.output_tokens`,
  preferred everywhere via `pipeline.stage_token_count` with the estimate
  as legacy fallback.
- **Popout race, second organ.** Stage outputs (model/template/stages/
  images) reached popouts only via SSE; a popout opened early showed
  "No stage outputs available" forever (background-throttled openers
  process no healing pushes; a manual refresh looked like a cache fix).
  Now one server-side builder (`_cycle_result_payload`) guarantees the
  REST endpoint and SSE entry are identical (the REST shape had silently
  omitted `images`), and the client fetches results on demand before
  first paint, retries them in the popout loop, and says
  "stage outputs not loaded yet — fetching" instead of a false verdict.

**Design law established by #6, now binding:** every payload the UI
renders must have an on-demand fetch, a retry path, and a loud absent
state. SSE is an optimization, never the only road to the data.

### 7. Windows + Codespaces runbook
README's deployment section documents the Windows path end to end
(`python start.py` daemon commands, the `python` vs `python3` Store-stub
trap, NSSM vs Task Scheduler, energy falling back to the labeled
estimate on Windows) and warns that the systemd installer cannot work
inside a Codespace container.

---

## Verification protocol (run from repo root)

```bash
# 1. Everything compiles; shell scripts lint (silence = pass)
find . -name '*.py' -exec python3 -m py_compile {} +
bash -n courier/start.sh courier/deploy/install-service.sh

# 2. Five cold probe suites — no torch, no network, ~120 assertions
python3 gator/probe_datagator.py
python3 gator/probe_digestor.py
cd courier
python3 tests/probe_energy.py
python3 tests/probe_node.py        # identity, totals, postures, config repair
python3 tests/probe_textproc.py    # think blocks, truncation, token contract
cd ..

# 3. Dashboard JS parses (write a real temp file — process substitution
#    fails: node --check stats the path, /proc pipe fds don't stat)
python3 -c "
import re, subprocess
sc = re.search(r'<script>(.*)</script>', open('courier/static/dashboard.html').read(), re.S).group(1)
open('/tmp/d.js','w').write(sc)
print('JS OK' if subprocess.run(['node','--check','/tmp/d.js']).returncode==0 else 'JS FAIL')
"
```

Status at handoff: **all of the above green on the field Codespace**
(2026-07-03). Windows equivalents: `python` instead of `python3`, skip
`bash -n`.

### Post-handoff addendum (same session): energy dials → Settings

`watts_per_core` / `energy_sample_interval` moved from env vars into the
persistent config (Settings → System → Energy Metering), live-applied at
boot and on save. The env vars named in §2 above are now IGNORED with a
loud boot warning — one source of truth. Boot log was also standardized
(`[courier] Key: value` grammar, both shell and server voices) and a
foreground start now detects an already-running daemon instead of dying
on a raw bind error.

### Post-handoff addendum (same session): pytest collection fixed

The first `pytest tests/` run on the field box died collecting
test_resilience/test_sd_lossless: `test_globless_cycle.py` installed an
EMPTY fake torch in `sys.modules`, which under pytest's shared interpreter
became everyone's torch and blocked the real library. Fixed with one
canonical `tests/_probe_util.ensure_torch()` (real torch preferred; one
adequate shared stub otherwise); the two pytest-collected files use it,
standalone probes keep their process-local fakes. The fix also exposed
and fixed a real regression from the token-count work (resume path read
`row["output_tokens"]` from dicts lacking the key). `test_resilience`
(38 checks) is cold-capable and passes shared-process + standalone.
Live check #2 (auth banner) was CONFIRMED on the field box the same run.

## Live checks still pending (need torch + a running server)

1. `cd courier && pytest tests/` — rerun after the collection fix above;
   the torch-dependent bodies still need the real environment.
2. Restart the server; the log must show the posture line and, on a
   Codespace, the warning (`Auth: tokenless local writes; proxy trusted
   (CODESPACES detected)` followed by `⚠ AUTH WARNING: …`).
3. Run one **image** cycle with thinking off: expect no `<think>` block
   in the receipt, more of the answer surviving the cap, and the header
   token count agreeing with the truncation banner's limit.
4. Pop a cycle out **cold**: it should paint complete on the first try,
   or show an amber banner naming exactly what it couldn't load.
5. NETWORK tab: Auth row now amber with the hazard note (on a Codespace).

## Open threads (designed, not built)

- **courier-network protocol** — envelope exchange between nodes,
  hash-chained signed receipts, witness countersignatures. The Courier ID
  (identity), `/api/node` (address surface), and the NETWORK tab's Peers
  section (UI socket) are this session's deliberate first bricks.
- **gator `camera_snapshot` adapter** — pairs with the vision pipeline.
- **RAPL soft spot (known, deliberately unfixed):** a counter that becomes
  unreadable mid-cycle coerces to 0 and would trip the wraparound
  correction into a garbage delta. Not realistic (permissions don't change
  mid-run); fix on a future hardening pass with a None-propagating read.
- **Payload-law audit:** configs and results now obey the on-demand-fetch/
  retry/loud-absence law; a short audit of the remaining SSE-borne
  payloads against it is cheap insurance.
- **#29's config trigger** was never caught red-handed; it is now
  survivable and self-reporting — if the amber banner ever names it,
  that's the evidence.

## Notes for the next session

- Probes are the project's conscience: twice this session the cold suites
  caught what `py_compile` structurally cannot (an ImportError at boot; a
  dataclass field-order TypeError). Anything with logic gets a probe in a
  torch-free module — `engine/textproc.py` exists precisely because
  `engine/inference.py` reaches torch through the adapter registry.
- The multimodal no-think priming changes prompts on the image path; the
  probes pin the prompt text, but the first real image cycle is the true
  confirmation (live check #3).
- Popouts self-heal: errors are part of the refresh signature, so an open
  popout repairs itself when a later fetch succeeds.
