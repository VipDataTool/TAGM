# Courier — Gemma 3 Adapter Build Plan

**Status:** Phase A/B implemented (text path); Phase C (vision) specified, not built
**Scope:** A third model family: `core/adapter/gemma3.py`, a dedicated
`engine/gemma3_streamer.py`, registry + dispatch hooks, one additive prompt-encode
hook on the adapter base, and three additive `ModelConfig` fields. LayerStreamer and
HybridStreamer are untouched except the dispatch site — existing families stay
byte-stable (Class I discipline from the performance spec).
**Audience:** Maintainer/engineer extending Courier.

---

## 1. Why Gemma 3

The only family besides Qwen3.5 with a same-tokenizer **multimodal SD ladder**
(4B/12B/27B vision + 1B text draft), directly hedging the Qwen dependence for the
vision workload. Dense, single-tokenizer across sizes, ungated download, commercial
use under the Gemma Terms; Gemma 4 (Apache 2.0, April 2026) inherits most of this
adapter later.

## 2. Architecture facts (grounded in the HF reference, not memory)

| Fact | Value | Engine consequence |
|---|---|---|
| Attention pattern | 5 local : 1 global; `sliding_window_pattern=6`, window **1024** | per-layer mask/KV-slice + `layer_types` |
| RoPE | global layers θ=1M **with linear factor 8**; local layers θ=`rope_local_base_freq`=10k, unscaled | TWO inv_freq sets, selected per layer |
| Attention scale | `query_pre_attn_scalar`⁻⁰·⁵ (decoupled from head_dim; differs on 27B) | scale from config, never head_dim assumed |
| Norms | **sandwich**: input / post_attention / pre_feedforward / post_feedforward, all zero-centered **(1+weight)** RMSNorm | Gemma3Streamer owns forward_layer |
| QK-norm | yes, per-head (1+weight), replaces Gemma 2 softcapping | q_norm/k_norm keys, gemma-variant norm |
| MLP | GeGLU: `gelu_pytorch_tanh(gate) * up` | activation dispatch |
| Embedding | scaled by √hidden_size **at input only**; lm_head tied to *unscaled* embedding | scale applied in forward, not to weights |
| Softcapping | none in Gemma 3 (attn or final) | omit; assert configs agree |
| BOS | required; quality collapses without it | adapter `encode_prompt` hook prepends |
| Tokenizer | Gemini tokenizer, vocab 262,208, shared across all sizes | SD table row |
| eos | `[1, 106]` (`<eos>`, `<end_of_turn>`) | config default |
| Vision (4B+) | SigLIP @896×896, pan-and-scan, 256 soft tokens/image via projector; image spans attend bidirectionally | Phase C |
| Checkpoint prefixes | text-only: `model.layers.*`; composite: `model.language_model.*` (new transformers) or `language_model.model.*` (early checkpoints) | adapter detects at load from the safetensors index |

## 3. Design decisions

1. **Dedicated `Gemma3Streamer(LayerStreamer)`.** LayerStreamer never consults
   `rmsnorm_uses_residual_weight` (the (1+weight) path lives only in
   HybridStreamer), and sandwich norms / GeGLU / dual RoPE / band masks are
   forward-pass structure, not parameters. A subclass overriding `forward()` and
   `forward_layer()` inherits generate/KV/checkpoint/SD-snapshot behavior while
   leaving the base class bit-identical for Qwen3/Llama.
2. **Dispatch by family, before capability flags.** `build_engine` currently
   routes `is_multimodal or has_hybrid_attention → HybridStreamer` — which would
   run Qwen3.5 math on a Gemma. `model_type.startswith("gemma3")` routes first.
3. **Vision parsed but disabled (Phase C).** The adapter stores `vision=None`
   for now, so 4B/12B/27B checkpoints run text-only through the correct
   streamer; SigLIP + projector + bidirectional image masking land as Phase C
   with their own parity gate.
4. **Local layers slice KV, not just mask.** In decode, a local layer attends
   the last `sliding_window` positions — slicing cached K/V is equivalent to the
   band mask and cheaper. Prefill builds a vectorized causal+band mask (no
   Python loop). KV still *stores* full length in v1; window-trimmed KV storage
   is a later memory optimization, noted for the performance spec.
5. **Additive base changes only.** Three optional `ModelConfig` fields
   (`sliding_window`, `query_pre_attn_scalar`, `rope_local_base_freq`, all
   defaulting None) and one adapter hook `encode_prompt(prompt)` whose default
   reproduces today's `tokenizer.encode(prompt, add_special_tokens=False)`
   exactly; `generate()` and `speculative_generate()` call the hook. Existing
   families: byte-identical by construction.

## 4. Phases & gates

**A — 1B text parity (Codespace).** `google/gemma-3-1b-it` through
`scripts/download_model.py` + INT8 quantize. Gate: greedy 64-token decode
byte-identical to `transformers` fp32 greedy on the same prompt (token IDs
compared, three prompts incl. one > 1024 tokens so local windows actually clip).
The >1024 prompt is the test that catches a wrong band mask or a swapped RoPE
set — short prompts cannot.

**B — 4B text parity + SD ladder.** Same gate on `gemma-3-4b-it` text-only;
then draft=1B verifier=4B through `speculative_generate`, greedy: byte-identical
to 4B plain greedy (`test_sd_lossless` discipline). Adds the Gemma row to the
README SD table (vocab 262,208, any smaller → any larger).

**C — vision.** SigLIP tower streaming (reuse the ViT scaffolding from
`engine/vision.py`), pan-and-scan preprocessing, projector, image-span
bidirectional masking, `<start_of_image>` token plumbing. Gate: image caption
parity vs transformers on 3 images, plus the eruption-risk template end-to-end.

**Cold probe (this sandbox, no torch):** `tests/probe_gemma3_adapter.py` —
config parsing (composite + flat), prefix detection from a synthetic safetensors
index (both checkpoint vintages), layer-type derivation (26 layers, pattern 6 →
globals at {5,11,17,23}), key maps for every role, eos/BOS/flags, and the
encode-hook default equivalence.

## 5. Risks

- **Checkpoint-vintage prefix drift** — mitigated by detection, probed for both.
- **27B `query_pre_attn_scalar` ≠ head_dim** — read from config; probe asserts
  the adapter never falls back to head_dim when the field is present.
- **bf16 embedding-scale rounding** — the √hidden multiplier is cast to the
  embedding dtype before use, mirroring the reference, so parity holds in bf16.
- **Gemma has no system role** — templates with a system stage rely on the
  tokenizer's chat template folding; flagged for template docs, not engine code.
- **Parity gate is the confidence.** Everything above is grounded in the
  reference implementation, but "confident" is certified by Phase A's diff on
  real weights, not by this document.
