"""KV cache manager: RAM-first with disk spillover.

Stores per-layer key/value tensors. Keeps as many layers in RAM
as fit within the configured budget. Evicts least-recently-used
layers to disk when RAM is full. Append-only on disk for lower
SSD write amplification. Dirty pages flush only at checkpoint
boundaries.
"""

import os
import time
from collections import OrderedDict
from pathlib import Path
from typing import Optional

import torch


class KVCacheManager:
    """RAM-first KV cache with LRU disk spillover."""

    def __init__(
        self,
        n_layers: int,
        num_kv_heads: int,
        head_dim: int,
        max_ram_layers: int = -1,
        cache_dir: Optional[str | Path] = None,
        dtype: torch.dtype = torch.bfloat16,
    ):
        """
        Args:
            n_layers: Total number of transformer layers
            num_kv_heads: Number of KV attention heads
            head_dim: Dimension per head
            max_ram_layers: Max layers to keep in RAM (-1 = all, no spill)
            cache_dir: Directory for disk spillover files
            dtype: Tensor dtype for cache entries
        """
        self.n_layers = n_layers
        self.num_kv_heads = num_kv_heads
        self.head_dim = head_dim
        self.max_ram_layers = max_ram_layers if max_ram_layers >= 0 else n_layers
        self.dtype = dtype
        self.cache_dir = Path(cache_dir) if cache_dir else None

        # Spill without a destination is silent data loss: write() evicts the
        # LRU layer and _spill_to_disk() no-ops with no cache_dir, so the
        # evicted KV simply vanishes and the next forward pass treats that
        # layer's history as empty — corrupted output, no error. Fail loud at
        # construction instead.
        if self.max_ram_layers < n_layers and self.cache_dir is None:
            raise ValueError(
                f"max_ram_layers={self.max_ram_layers} < n_layers={n_layers} "
                f"requires a cache_dir for disk spillover. Set kv_cache_dir, "
                f"or set max_kv_ram_layers=-1 to keep all KV in RAM."
            )

        if self.cache_dir and self.max_ram_layers < n_layers:
            self.cache_dir.mkdir(parents=True, exist_ok=True)

        # RAM cache: layer_idx → (K, V) tensors
        # OrderedDict for LRU tracking
        self._ram: OrderedDict[int, tuple[torch.Tensor, torch.Tensor]] = OrderedDict()

        # Track which layers are on disk
        self._on_disk: set[int] = set()

        # Stats
        self.ram_hits = 0
        self.disk_hits = 0
        self.disk_writes = 0
        self.disk_bytes_written = 0

    def write(self, layer_idx: int, k: torch.Tensor, v: torch.Tensor) -> None:
        """Store K/V for a layer. RAM if space, spill LRU to disk if not.

        Args:
            layer_idx: Layer index
            k: Key tensor, shape (batch, num_kv_heads, seq_len, head_dim)
            v: Value tensor, same shape as k
        """
        # If already in RAM, update in place
        if layer_idx in self._ram:
            self._ram[layer_idx] = (k, v)
            self._ram.move_to_end(layer_idx)
            return

        # Evict LRU if at capacity
        while len(self._ram) >= self.max_ram_layers and self._ram:
            evict_idx, (ek, ev) = self._ram.popitem(last=False)
            self._spill_to_disk(evict_idx, ek, ev)

        # Store in RAM
        self._ram[layer_idx] = (k, v)
        self._ram.move_to_end(layer_idx)

        # Remove from disk tracking if it was there
        self._on_disk.discard(layer_idx)

    def read(self, layer_idx: int) -> Optional[tuple[torch.Tensor, torch.Tensor]]:
        """Read K/V for a layer. RAM hit or disk load.

        Args:
            layer_idx: Layer index

        Returns:
            (K, V) tuple, or None if not cached
        """
        # RAM hit
        if layer_idx in self._ram:
            self._ram.move_to_end(layer_idx)
            self.ram_hits += 1
            return self._ram[layer_idx]

        # Disk hit
        if layer_idx in self._on_disk:
            k, v = self._load_from_disk(layer_idx)
            self.disk_hits += 1
            # Promote to RAM (may evict another)
            self.write(layer_idx, k, v)
            return k, v

        return None

    def flush(self) -> None:
        """Write all dirty RAM-resident caches to disk (checkpoint).

        After flush, all layers are on disk and in RAM (if they fit).
        """
        if self.cache_dir is None:
            return
        for idx, (k, v) in self._ram.items():
            self._spill_to_disk(idx, k, v, keep_in_ram=True)

    def clear(self) -> None:
        """Remove all cached KV data (new cycle)."""
        self._ram.clear()
        self._on_disk.clear()
        if self.cache_dir and self.cache_dir.exists():
            for f in self.cache_dir.glob("kv_layer_*.pt"):
                f.unlink()

    def truncate(self, length: int) -> None:
        """Roll back every layer's KV to the first ``length`` positions.

        Speculative decoding (multimodel spec §6, Change 2) needs to undo the
        K/V appended for rejected draft tokens after a verify sweep. KV is
        append-only along the sequence axis (dim=2), so a rollback is a slice:
        keep [0, length), drop the rest.

        This is the FULL-ATTENTION half of rollback. For a HybridStreamer the
        recurrent + conv state of the linear-attention layers cannot be sliced
        and must be restored from a snapshot instead — see
        HybridStreamer.snapshot_state()/restore_state(). truncate() alone would
        silently corrupt a hybrid continuation; it is never the whole story
        there.

        Dormant: only the SD verify path calls this. The normal append-only
        decode never invokes it, so default behavior is unchanged.
        """
        if length < 0:
            raise ValueError(f"truncate length must be >= 0, got {length}")
        # RAM layers hold the most recent positions (where speculative tokens
        # were just written); slice them back. Disk-spilled layers hold older
        # positions (< length) and are left untouched.
        for idx, (k, v) in list(self._ram.items()):
            if k.shape[2] > length:
                self._ram[idx] = (k[:, :, :length, :].contiguous(),
                                  v[:, :, :length, :].contiguous())

    def kv_lengths(self) -> dict[int, int]:
        """Per-layer current sequence length — the cheap half of a snapshot."""
        return {idx: k.shape[2] for idx, (k, v) in self._ram.items()}

    def restore(self) -> int:
        """Scan cache_dir for existing KV files and mark them available.

        Used after restart to restore KV cache state from a checkpoint.
        Returns the number of layers found on disk.
        """
        if self.cache_dir is None or not self.cache_dir.exists():
            return 0
        count = 0
        for f in sorted(self.cache_dir.glob("kv_layer_*.pt")):
            idx = int(f.stem.split("_")[-1])
            self._on_disk.add(idx)
            count += 1
        return count

    def seq_len(self) -> int:
        """Current sequence length (from any cached layer)."""
        for k, v in self._ram.values():
            return k.shape[2]
        return 0

    def stats(self) -> dict:
        """Cache statistics."""
        ram_bytes = sum(
            k.nelement() * k.element_size() + v.nelement() * v.element_size()
            for k, v in self._ram.values()
        )
        return {
            "ram_layers": len(self._ram),
            "disk_layers": len(self._on_disk),
            "total_layers": len(self._ram) + len(self._on_disk),
            "ram_bytes": ram_bytes,
            "ram_mb": ram_bytes / (1024 * 1024),
            "ram_hits": self.ram_hits,
            "disk_hits": self.disk_hits,
            "disk_writes": self.disk_writes,
            "disk_bytes_written": self.disk_bytes_written,
            "seq_len": self.seq_len(),
        }

    # ── Internal ─────────────────────────────────────────────

    def _spill_to_disk(self, layer_idx: int, k: torch.Tensor, v: torch.Tensor,
                       keep_in_ram: bool = False) -> None:
        """Write a layer's KV to disk."""
        if self.cache_dir is None:
            return

        path = self.cache_dir / f"kv_layer_{layer_idx:04d}.pt"
        torch.save({"k": k, "v": v}, path)
        self._on_disk.add(layer_idx)
        self.disk_writes += 1
        self.disk_bytes_written += path.stat().st_size

    def _load_from_disk(self, layer_idx: int) -> tuple[torch.Tensor, torch.Tensor]:
        """Read a layer's KV from disk."""
        path = self.cache_dir / f"kv_layer_{layer_idx:04d}.pt"
        data = torch.load(path, map_location="cpu", weights_only=True)
        return data["k"], data["v"]
