"""Energy metering: joules per cycle — the metric the whole design optimizes.

Courier's economics are not tokens/second; they are joules/verdict. A field
node lives on a fixed energy income (solar, battery, eventually RTG), so
every receipt should state what its verdict cost. This module measures that,
using the best instrument the host actually has, in preference order:

  rapl      Intel RAPL package energy counters
            (/sys/class/powercap/intel-rapl:*/energy_uj) — cumulative
            microjoule counters maintained by the CPU itself. Precise,
            no sampling needed; read at start and stop, subtract, handle
            counter wraparound via max_energy_range_uj. Covers CPU+DRAM
            domains (not the whole wall draw) — labeled accordingly.
  battery   /sys/class/power_supply/*/power_now (µW) or
            current_now × voltage_now, integrated by a sampling thread
            (cadence: the 'energy_sample_interval' setting, default 5s).
            Whole-system draw; only meaningful ON BATTERY (on AC many
            batteries report charge flow, not load) — the meter checks
            discharge status and refuses to fake it otherwise.
  estimate  cpu_time_delta × the 'watts_per_core' setting (default
            6 W/core; Settings → System). A model, not a measurement —
            and it says so.

Every reading carries its method so a receipt never launders an estimate
as a measurement: {"joules": 412.3, "avg_watts": 18.1, "method": "rapl",
"seconds": 22.8}. method == "none" when nothing usable exists.

Zero hard dependencies; psutil used opportunistically for the estimate
path. All sysfs roots are constructor parameters so cold probes can point
the meter at synthetic trees.
"""
from __future__ import annotations

import os
import threading
import time
from pathlib import Path

RAPL_ROOT = Path("/sys/class/powercap")
BATTERY_ROOT = Path("/sys/class/power_supply")
# Defaults only. The operator-facing source of truth for both dials is the
# persistent config ("watts_per_core", "energy_sample_interval"), edited in
# Settings → System like every other dial and pushed onto the live meter by
# the server (_apply_live_energy). ONE source — no env vars, no shadow copy.
DEFAULT_WATTS_PER_CORE = 6.0     # conservative mobile-CPU active draw
DEFAULT_SAMPLE_INTERVAL = 5.0    # battery-method sampling cadence, seconds


def _read_int(p: Path):
    try:
        return int(p.read_text().strip())
    except (OSError, ValueError):
        return None


# ── RAPL ─────────────────────────────────────────────────────
class _RaplSource:
    """Top-level intel-rapl package domains (skip subdomains: the package
    counter already contains them; summing both double-counts)."""

    def __init__(self, root: Path = RAPL_ROOT):
        self.domains = []
        try:
            for d in sorted(root.glob("intel-rapl:*")):
                if ":" in d.name.split("intel-rapl:", 1)[1]:
                    continue                      # subdomain like :0:0
                e = d / "energy_uj"
                if _read_int(e) is None:
                    continue                      # unreadable (perms)
                rng = _read_int(d / "max_energy_range_uj") or (2 ** 60)
                self.domains.append((e, rng))
        except OSError:
            pass

    @property
    def available(self) -> bool:
        return bool(self.domains)

    def read_uj(self) -> list[int]:
        return [_read_int(e) or 0 for e, _ in self.domains]

    def delta_j(self, before: list[int], after: list[int]) -> float:
        total = 0
        for ((_, rng), b, a) in zip(self.domains, before, after):
            d = a - b
            if d < 0:                             # counter wrapped
                d += rng
            total += d
        return total / 1e6


# ── Battery ──────────────────────────────────────────────────
class _BatterySource:
    """Instantaneous system draw in watts, valid only while discharging."""

    def __init__(self, root: Path = BATTERY_ROOT):
        self.bat = None
        try:
            for d in sorted(root.glob("*")):
                if (d / "type").exists() and \
                        (d / "type").read_text().strip() == "Battery":
                    self.bat = d
                    break
        except OSError:
            pass

    @property
    def available(self) -> bool:
        return self.bat is not None and self.watts() is not None

    def _discharging(self) -> bool:
        try:
            return (self.bat / "status").read_text().strip().lower() \
                   == "discharging"
        except OSError:
            return False

    def watts(self):
        if self.bat is None or not self._discharging():
            return None
        uw = _read_int(self.bat / "power_now")
        if uw is not None:
            return abs(uw) / 1e6
        ua = _read_int(self.bat / "current_now")
        uv = _read_int(self.bat / "voltage_now")
        if ua is not None and uv is not None:
            return abs(ua) * abs(uv) / 1e12
        return None


# ── Estimate ─────────────────────────────────────────────────
def _cpu_seconds():
    """Process-tree CPU time; falls back to os.times (self only)."""
    try:
        import psutil
        p = psutil.Process()
        t = p.cpu_times()
        total = t.user + t.system
        for c in p.children(recursive=True):
            try:
                ct = c.cpu_times()
                total += ct.user + ct.system
            except psutil.Error:
                pass
        return total
    except Exception:
        t = os.times()
        return t.user + t.system


class _Reading:
    """One in-flight measurement: created by EnergyMeter.start()."""

    def __init__(self, meter: "EnergyMeter"):
        self.meter = meter
        self.t0 = time.monotonic()
        self.method = meter.method
        if self.method == "rapl":
            self._uj0 = meter._rapl.read_uj()
        elif self.method == "battery":
            self._samples: list[float] = []
            self._stop = threading.Event()
            self._thread = threading.Thread(target=self._sample, daemon=True)
            self._thread.start()
        elif self.method == "estimate":
            self._cpu0 = _cpu_seconds()

    def _sample(self):
        while not self._stop.wait(self.meter.sample_interval):
            w = self.meter._battery.watts()
            if w is not None:
                self._samples.append(w)

    def stop(self) -> dict:
        seconds = max(1e-9, time.monotonic() - self.t0)
        joules = None
        method = self.method
        if method == "rapl":
            joules = self.meter._rapl.delta_j(self._uj0,
                                              self.meter._rapl.read_uj())
        elif method == "battery":
            self._stop.set()
            self._thread.join(timeout=2)
            w = self.meter._battery.watts()
            if w is not None:
                self._samples.append(w)
            if self._samples:
                joules = (sum(self._samples) / len(self._samples)) * seconds
            else:
                method = "none"                   # e.g. plugged in mid-cycle
        elif method == "estimate":
            joules = (_cpu_seconds() - self._cpu0) * self.meter.watts_per_core
        if joules is None:
            return {"joules": None, "avg_watts": None,
                    "method": "none", "seconds": round(seconds, 1)}
        return {"joules": round(joules, 1),
                "avg_watts": round(joules / seconds, 2),
                "method": method, "seconds": round(seconds, 1)}


class EnergyMeter:
    """Pick the best available instrument once; hand out readings."""

    def __init__(self, rapl_root: Path = RAPL_ROOT,
                 battery_root: Path = BATTERY_ROOT,
                 watts_per_core: float | None = None,
                 sample_interval: float | None = None,
                 allow_estimate: bool = True):
        self._rapl = _RaplSource(rapl_root)
        self._battery = _BatterySource(battery_root)
        # Explicit argument > default; the server overlays the config
        # values onto the live meter (see module note above).
        self.sample_interval = (sample_interval if sample_interval is not None
                                else DEFAULT_SAMPLE_INTERVAL)
        self.watts_per_core = (watts_per_core if watts_per_core is not None
                               else DEFAULT_WATTS_PER_CORE)
        if self._rapl.available:
            self.method = "rapl"
        elif self._battery.available:
            self.method = "battery"
        elif allow_estimate:
            self.method = "estimate"
        else:
            self.method = "none"

    def start(self) -> _Reading:
        return _Reading(self)

    def describe(self) -> str:
        return {
            "rapl": "RAPL hardware counters (CPU+DRAM domains)",
            "battery": "battery discharge telemetry (whole system)",
            "estimate": f"CPU-time model @ {self.watts_per_core} W/core "
                        f"(tune in Settings → System)",
            "none": "no energy instrumentation available",
        }[self.method]
