"""Channel B — speculative decoding verify/accept loop (multimodel spec §7).

Draft K tokens cheaply with a small resident engine, verify all K in ONE
verifier forward sweep, then accept/correct so the committed output is drawn
from the VERIFIER's distribution at the caller's sampling settings. This is the
standard speculative-decoding algorithm (Leviathan et al. 2023; Chen et al.
2023): it is distribution-preserving by construction.

The sampling regime is NOT chosen here — it is whatever temperature/top_p/top_k/
presence_penalty the caller (and therefore the operator) set, identical to the
plain decode. Two regimes fall out of the one rule:

  * temperature == 0  -> the verifier distribution is a one-hot at its argmax,
    so a draft token is accepted iff it equals the verifier's argmax and the
    correction is the verifier's argmax. The committed stream is exactly the
    verifier's greedy decode: byte-for-byte lossless, deterministically.
  * temperature  > 0  -> modified rejection sampling: accept draft token x with
    probability min(1, p(x)/q(x)); on rejection sample from the normalized
    residual (p - q)+; if all K accept, sample one bonus token from p. The
    committed stream is distributed EXACTLY as the verifier's sampling output at
    those settings. (Distribution-identical, not seed-identical — a particular
    sampled run won't byte-match, because that's not what the method preserves.)

p and q are built with sampler.distribution(), the same transforms the plain
sampler uses, so the verifier distribution here equals what the non-speculative
path would draw from.

Correctness MUST be validated with the real pair on the target rig (spec §9):
greedy off-vs-on must be byte-identical; sampled on must match plain-sampled in
distribution. It cannot be proven without the models. The accept/reject math
itself is checked torch-free in tests/probe_specsample.py.

Both engines are rolled back with snapshot_state()/restore_state() at each block
boundary and re-advanced over exactly the committed tokens — required for
HybridStreamer, whose recurrent/conv state can't be un-stepped by slicing
(spec §6). Verifier and draft are same-family hybrids, so both are snapshotted.
"""
from __future__ import annotations

from typing import Callable, Optional

import torch

from engine.sampler import distribution


def _draw(probs: torch.Tensor) -> int:
    """Draw one token id from a probability vector. A one-hot (greedy) vector
    makes this a deterministic argmax."""
    return int(torch.multinomial(probs, num_samples=1).item())


def speculative_generate(
    verifier,
    draft,
    prompt: str,
    max_new_tokens: int = 100,
    block_k: int = 4,
    temperature: float = 0.0,
    top_p: float = 1.0,
    top_k: int = 0,
    presence_penalty: float = 0.0,
    stop_tokens: Optional[list[int]] = None,
    on_token: Optional[Callable[[int, int], None]] = None,
    on_checkpoint: Optional[Callable[[int, int, int, list], None]] = None,
    cancel_check: Optional[Callable] = None,
) -> list[int]:
    """Speculative decode at the caller's sampling settings. Returns token ids.

    The sampling parameters are passed through unchanged from the caller; they
    are NOT overridden here. temperature == 0 yields lossless greedy; > 0 yields
    distribution-preserving speculative sampling.

    Args:
        verifier: the big engine (source of truth — LayerStreamer or
            HybridStreamer); must expose forward(..., all_positions=...) and
            snapshot_state()/restore_state().
        draft: the small resident engine, same family/tokenizer.
        prompt: input text.
        max_new_tokens: total tokens to generate.
        block_k: draft tokens proposed per verify sweep.
        temperature/top_p/top_k/presence_penalty: sampling settings, identical
            to those the plain decode would use for this call.
        stop_tokens: stop ids (default: verifier eos).
        on_token / on_checkpoint / cancel_check: same callbacks as generate().
    """
    if stop_tokens is None:
        stop_tokens = verifier.config.eos_token_id
    stop = set(stop_tokens or [])
    block_k = max(1, int(block_k))

    verifier.clear_state()
    draft.clear_state()
    verifier._cancel_check = cancel_check

    prompt_ids = verifier.adapter.encode_prompt(prompt)
    base = len(prompt_ids)

    def dist(row, seen):
        return distribution(row, temperature, top_p, top_k,
                            presence_penalty, seen)

    pid = torch.tensor([prompt_ids], dtype=torch.long, device=verifier.device)
    v_logits = verifier.forward(pid, position_offset=0).squeeze(0)  # (vocab,)
    did = torch.tensor([prompt_ids], dtype=torch.long, device=draft.device)
    d_logits = draft.forward(did, position_offset=0).squeeze(0)     # (vocab,)

    generated: list[int] = []
    step = 0

    while len(generated) < max_new_tokens:
        if cancel_check is not None:
            cancel_check()
        pos = base + len(generated)
        remaining = max_new_tokens - len(generated)
        k = min(block_k, remaining)

        # Roll-back point for BOTH engines at the block boundary.
        v_snap = verifier.snapshot_state()
        d_snap = draft.snapshot_state()

        # 1) Draft k tokens by SAMPLING from the draft's own distribution,
        #    keeping each q vector for the accept ratio / residual.
        draft_tokens: list[int] = []
        q_vecs: list[torch.Tensor] = []
        dl = d_logits
        for j in range(k):
            q = dist(dl, generated + draft_tokens)
            q_vecs.append(q)
            dt = _draw(q)
            draft_tokens.append(dt)
            nxt = torch.tensor([[dt]], dtype=torch.long, device=draft.device)
            dl = draft.forward(nxt, position_offset=pos + j).squeeze(0)

        # 2) Verify all k in ONE sweep (all-position logits, spec §6 Change 1).
        vin = torch.tensor([draft_tokens], dtype=torch.long, device=verifier.device)
        block_logits = verifier.forward(
            vin, position_offset=pos, all_positions=True
        )[0]  # (k, vocab)

        # Verifier distribution at slot j: slot 0 from v_logits (computed before
        # the block); slot j>=1 from block_logits[j-1] (conditioned on
        # draft_tokens[:j]). Slot k (the bonus position) is block_logits[k-1].
        def p_at(slot: int, seen: list[int]) -> torch.Tensor:
            row = v_logits if slot == 0 else block_logits[slot - 1]
            return dist(row, seen)

        # 3) Sequential accept/reject — one rule, both regimes.
        accepted = 0
        final_token: Optional[int] = None
        for j in range(k):
            seen = generated + draft_tokens[:j]
            p = p_at(j, seen)
            q = q_vecs[j]
            x = draft_tokens[j]
            qx = float(q[x])
            px = float(p[x])
            ratio = 1.0 if qx <= 0.0 else min(1.0, px / qx)
            if float(torch.rand(())) < ratio:
                accepted += 1
                continue
            # Reject at slot j: draw the correction from the residual (p - q)+.
            resid = torch.clamp(p - q, min=0.0)
            s = resid.sum()
            resid = resid / s if float(s) > 0.0 else p
            final_token = _draw(resid)
            break
        if final_token is None:
            # All k accepted -> one bonus token from the verifier distribution.
            p = p_at(k, generated + draft_tokens)
            final_token = _draw(p)

        committed = (draft_tokens[:accepted] + [final_token])[:remaining]

        # 4) Roll both engines back and re-advance EXACTLY the committed tokens,
        #    so each engine's state matches the committed output precisely.
        verifier.restore_state(v_snap)
        draft.restore_state(d_snap)
        cin = torch.tensor([committed], dtype=torch.long, device=verifier.device)
        v_logits = verifier.forward(cin, position_offset=pos).squeeze(0)
        din = torch.tensor([committed], dtype=torch.long, device=draft.device)
        d_logits = draft.forward(din, position_offset=pos).squeeze(0)

        # 5) Emit, honoring callbacks and stop tokens.
        for t in committed:
            generated.append(t)
            if on_token:
                on_token(t, step)
            if on_checkpoint:
                on_checkpoint(t, step, base + len(generated), generated)
            step += 1
            if t in stop:
                verifier._cancel_check = None
                return generated

    verifier._cancel_check = None
    return generated
