"""Hybrid layer-streaming inference engine.

Extends LayerStreamer to handle Qwen3.5-style architectures:
- Hybrid attention: dispatches each layer to either full_attention
  (standard GQA) or linear_attention (Gated DeltaNet) based on
  the adapter's layer_types configuration
- Vision token insertion: replaces <image> placeholder tokens with
  vision encoder output embeddings
- Multimodal RoPE (mRoPE): 3-component positional encoding for
  temporal, height, and width dimensions

For text-only Qwen3 models, this module is not needed — the base
LayerStreamer handles them. HybridStreamer is used exclusively for
multimodal models like Qwen3.5.

Gated DeltaNet (linear attention) overview:
    - O(n) complexity in sequence length (vs O(n²) for full attention)
    - Uses a recurrent state instead of KV cache
    - Components: QKV projection, output gate (z), delta-rule
      scaling (a, b), causal conv1d for short-range mixing
    - The recurrent state replaces the KV cache for these layers,
      so memory cost is fixed regardless of sequence length
"""

import math
import time
from typing import Optional, Callable

import torch
import torch.nn.functional as F

from core.adapter.base import ModelAdapter
from core.shard_manager import ShardManager
from engine.kv_cache import KVCacheManager
from engine.profiler import PROFILER
from engine.sampler import sample
from engine.streamer import rmsnorm, rotate_half, apply_rope, repeat_kv


def rmsnorm_qwen35(x: torch.Tensor, weight: torch.Tensor, eps: float) -> torch.Tensor:
    """Qwen3.5 RMSNorm: x * rsqrt(mean(x²) + eps) * (1 + weight).

    Unlike standard RMSNorm (which multiplies by weight directly),
    Qwen3.5 initializes weight to ZEROS and multiplies by (1 + weight).
    This is a critical difference — using plain weight gives ~20×
    wrong magnitude since the learned weights are near-zero offsets.
    """
    output = x.float() * torch.rsqrt(x.float().pow(2).mean(-1, keepdim=True) + eps)
    output = output * (1.0 + weight.float())
    return output.type_as(x)


# ── HF reference Gated DeltaNet functions ─────────────────────
# Copied verbatim from transformers/models/qwen3_5/modeling_qwen3_5.py
# (Apache 2.0 license, Copyright 2025 The Qwen Team and HuggingFace Inc.)
# These are the torch fallback implementations used when fla is not installed.

def _l2norm(x: torch.Tensor, dim: int = -1, eps: float = 1e-6) -> torch.Tensor:
    """L2 normalize, matching the FLA library implementation."""
    inv_norm = torch.rsqrt((x * x).sum(dim=dim, keepdim=True) + eps)
    return x * inv_norm


def _torch_recurrent_gated_delta_rule(
    query, key, value, g, beta, initial_state, output_final_state,
    use_qk_l2norm_in_kernel=False,
):
    """Single-step recurrent Gated DeltaNet (for decode or short sequences)."""
    initial_dtype = query.dtype
    if use_qk_l2norm_in_kernel:
        query = _l2norm(query, dim=-1, eps=1e-6)
        key = _l2norm(key, dim=-1, eps=1e-6)
    query, key, value, beta, g = [
        x.transpose(1, 2).contiguous().to(torch.float32)
        for x in (query, key, value, beta, g)
    ]
    batch_size, num_heads, sequence_length, k_head_dim = key.shape
    v_head_dim = value.shape[-1]
    scale = 1 / (query.shape[-1] ** 0.5)
    query = query * scale

    core_attn_out = torch.zeros(
        batch_size, num_heads, sequence_length, v_head_dim,
        dtype=value.dtype, device=value.device,
    )
    last_recurrent_state = (
        torch.zeros(batch_size, num_heads, k_head_dim, v_head_dim,
                     dtype=value.dtype, device=value.device)
        if initial_state is None else initial_state.to(value)
    )

    for i in range(sequence_length):
        q_t = query[:, :, i]
        k_t = key[:, :, i]
        v_t = value[:, :, i]
        g_t = g[:, :, i].exp().unsqueeze(-1).unsqueeze(-1)
        beta_t = beta[:, :, i].unsqueeze(-1)

        last_recurrent_state = last_recurrent_state * g_t
        kv_mem = (last_recurrent_state * k_t.unsqueeze(-1)).sum(dim=-2)
        delta = (v_t - kv_mem) * beta_t
        last_recurrent_state = (
            last_recurrent_state + k_t.unsqueeze(-1) * delta.unsqueeze(-2)
        )
        core_attn_out[:, :, i] = (
            last_recurrent_state * q_t.unsqueeze(-1)
        ).sum(dim=-2)

    if not output_final_state:
        last_recurrent_state = None
    core_attn_out = core_attn_out.transpose(1, 2).contiguous().to(initial_dtype)
    return core_attn_out, last_recurrent_state


def _torch_chunk_gated_delta_rule(
    query, key, value, g, beta,
    chunk_size=64,
    initial_state=None,
    output_final_state=False,
    use_qk_l2norm_in_kernel=False,
    **kwargs,
):
    """Chunked Gated DeltaNet (for prefill / multi-token forward)."""
    initial_dtype = query.dtype
    if use_qk_l2norm_in_kernel:
        query = _l2norm(query, dim=-1, eps=1e-6)
        key = _l2norm(key, dim=-1, eps=1e-6)

    query, key, value, beta, g = [
        x.transpose(1, 2).contiguous().to(torch.float32)
        for x in (query, key, value, beta, g)
    ]
    batch_size, num_heads, sequence_length, k_head_dim = key.shape
    v_head_dim = value.shape[-1]
    pad_size = (chunk_size - sequence_length % chunk_size) % chunk_size
    query = F.pad(query, (0, 0, 0, pad_size))
    key = F.pad(key, (0, 0, 0, pad_size))
    value = F.pad(value, (0, 0, 0, pad_size))
    beta = F.pad(beta, (0, pad_size))
    g = F.pad(g, (0, pad_size))
    total_sequence_length = sequence_length + pad_size

    scale = 1 / (query.shape[-1] ** 0.5)
    query = query * scale
    v_beta = value * beta.unsqueeze(-1)
    k_beta = key * beta.unsqueeze(-1)

    # Reshape to chunks
    query, key, value, k_beta, v_beta = [
        x.reshape(x.shape[0], x.shape[1], -1, chunk_size, x.shape[-1])
        for x in (query, key, value, k_beta, v_beta)
    ]
    g = g.reshape(g.shape[0], g.shape[1], -1, chunk_size)

    mask = torch.triu(
        torch.ones(chunk_size, chunk_size, dtype=torch.bool, device=query.device),
        diagonal=0,
    )
    # Chunk decay
    g = g.cumsum(dim=-1)
    decay_mask = ((g.unsqueeze(-1) - g.unsqueeze(-2)).tril().exp().float()).tril()
    attn = -((k_beta @ key.transpose(-1, -2)) * decay_mask).masked_fill(mask, 0)
    for i in range(1, chunk_size):
        row = attn[..., i, :i].clone()
        sub = attn[..., :i, :i].clone()
        attn[..., i, :i] = row + (row.unsqueeze(-1) * sub).sum(-2)
    attn = attn + torch.eye(chunk_size, dtype=attn.dtype, device=attn.device)

    value = attn @ v_beta
    k_cumdecay = attn @ (k_beta * g.exp().unsqueeze(-1))

    last_recurrent_state = (
        torch.zeros(batch_size, num_heads, k_head_dim, v_head_dim,
                     dtype=value.dtype, device=value.device)
        if initial_state is None else initial_state.to(value)
    )
    core_attn_out = torch.zeros_like(value)
    mask = torch.triu(
        torch.ones(chunk_size, chunk_size, dtype=torch.bool, device=query.device),
        diagonal=1,
    )
    # For each chunk
    for i in range(0, total_sequence_length // chunk_size):
        q_i, k_i, v_i = query[:, :, i], key[:, :, i], value[:, :, i]
        attn = q_i @ k_i.transpose(-1, -2) * decay_mask[:, :, i]
        v_prime = (k_cumdecay[:, :, i]) @ last_recurrent_state
        v_new = v_i - v_prime
        attn_inter = (q_i * g[:, :, i, :, None].exp()) @ last_recurrent_state
        core_attn_out[:, :, i] = attn_inter + attn @ v_new
        last_recurrent_state = (
            last_recurrent_state * g[:, :, i, -1, None, None].exp()
            + (k_i * (g[:, :, i, -1, None] - g[:, :, i]).exp()[..., None]).transpose(-1, -2) @ v_new
        )

    if not output_final_state:
        last_recurrent_state = None
    core_attn_out = core_attn_out.reshape(
        core_attn_out.shape[0], core_attn_out.shape[1], -1, core_attn_out.shape[-1]
    )
    core_attn_out = core_attn_out[:, :, :sequence_length]
    core_attn_out = core_attn_out.transpose(1, 2).contiguous().to(initial_dtype)
    return core_attn_out, last_recurrent_state


class HybridStreamer:
    """Layer-streaming engine for hybrid-attention multimodal models.

    Supports two layer types:
    - full_attention: standard GQA with QK-norm and RoPE (identical
      to LayerStreamer.forward_layer)
    - linear_attention: Gated DeltaNet with recurrent state

    And optionally integrates a VisionEncoder for multimodal input.
    """

    def __init__(
        self,
        shard_manager: ShardManager,
        adapter: ModelAdapter,
        dtype: torch.dtype = torch.bfloat16,
        device: str = "cpu",
        kv_cache_dir: Optional[str] = None,
        max_kv_ram_layers: int = -1,
        layer_delay: float = 0.0,
        brake=None,
    ):
        self.shards = shard_manager
        self.adapter = adapter
        self.config = adapter.config
        self.dtype = dtype
        self.device = device
        self.eps = self.config.rms_norm_eps
        # Inter-layer pacing — fixed floor plus optional dynamic CPU brake.
        # Parity with LayerStreamer: before this, the hybrid path ignored the
        # brake entirely, so throttling was a no-op on Qwen3.5 / multimodal.
        self.layer_delay = layer_delay
        self._brake = brake

        # Precompute RoPE frequencies
        self._inv_freq = self._build_inv_freq()

        # Load persistent weights (embedding + final norm)
        self._embed = self.shards.load_embedding(dtype).to(device)
        # Load final norm at native precision (float32 in Qwen3.5 checkpoints)
        self._final_norm = self.shards.get_tensor(
            self.adapter.final_norm_key()
        ).to(device)

        lm_head_key = self.adapter.lm_head_key()
        self._lm_head = None
        self._stream_lm_head = False
        if lm_head_key is not None and self.shards.has_key(lm_head_key):
            from core.gguf_shard_manager import GGUFShardManager
            if isinstance(self.shards, GGUFShardManager):
                self._stream_lm_head = True
            else:
                lm_head = self.shards.load_lm_head(dtype)
                self._lm_head = lm_head.to(device) if lm_head is not None else None
        elif lm_head_key is not None:
            # The adapter says the model has an untied LM head, but the
            # key wasn't found in the shard index. This is a configuration
            # error that silently falls through to tied-embedding logits,
            # producing garbage output. Fail loud.
            available = [k for k in self.shards.all_keys()
                         if "lm_head" in k or "output" in k.split(".")[-1]]
            raise KeyError(
                f"Untied LM head key '{lm_head_key}' not found in model shards. "
                f"The model has tie_word_embeddings=false, so a separate LM head "
                f"is required. Candidates in shard index: {available or '(none)'}. "
                f"Check that the adapter's lm_head_key() matches the safetensors "
                f"weight map."
            )

        # KV cache — only for full_attention layers
        # Count how many full attention layers exist
        if self.config.layer_types:
            n_full = sum(1 for lt in self.config.layer_types if lt == "full_attention")
        else:
            n_full = self.config.num_hidden_layers

        self.kv_cache = KVCacheManager(
            n_layers=self.config.num_hidden_layers,
            num_kv_heads=self.config.num_key_value_heads,
            head_dim=self.config.head_dim,
            max_ram_layers=max_kv_ram_layers,
            cache_dir=kv_cache_dir,
            dtype=dtype,
        )

        # Recurrent state for linear attention layers
        # Each linear layer maintains a (num_v_heads, k_head_dim, v_head_dim) state
        self._recurrent_state: dict[int, torch.Tensor] = {}
        # Conv1d state buffer for each linear layer
        self._conv_state: dict[int, torch.Tensor] = {}

        # Cancel callback — checked between layers for responsive interruption
        self._cancel_check: Optional[Callable] = None

        # Live layer heartbeat (see LayerStreamer): index of the most recently
        # completed layer in the current forward pass, read by the dashboard
        # Layer bar off the persistent streamer handle.
        self.current_layer = 0

        # Vision encoder (lazy-loaded)
        self._vision_encoder = None

        # Validate linear attention config if hybrid
        if self.config.layer_types:
            for field in ("linear_num_key_heads", "linear_key_head_dim",
                         "linear_num_value_heads", "linear_value_head_dim"):
                val = getattr(self.config, field, None)
                if val is None:
                    raise ValueError(
                        f"Hybrid model missing config field: {field}. "
                        f"Check that the adapter parsed text_config correctly."
                    )

    def _rest_after_layer(self, compute_s: float) -> None:
        """Pace inference between layers: fixed floor plus dynamic brake.

        Identical to LayerStreamer._rest_after_layer — the throttle behaves the
        same on the hybrid (Qwen3.5 / multimodal) path. `time.sleep` releases
        the GIL, yielding the core to the collector. No-op when both are off.
        """
        rest = self.layer_delay
        if self._brake is not None:
            from engine.brake import process_load_frac
            rest = max(rest, self._brake.update(compute_s, process_load_frac()))
        if rest > 0:
            time.sleep(rest)

    @property
    def vision_encoder(self):
        """Lazy-load the vision encoder only when needed."""
        if self._vision_encoder is None and self.adapter.is_multimodal:
            from engine.vision import VisionEncoder
            self._vision_encoder = VisionEncoder(
                self.shards, self.adapter, self.dtype, self.device
            )
        return self._vision_encoder

    def _build_inv_freq(self) -> torch.Tensor:
        """Precompute RoPE inverse frequencies.

        For Qwen3.5 with partial_rotary_factor, only a fraction
        of the head_dim gets RoPE. The rest stays un-rotated.
        """
        head_dim = self.config.head_dim
        factor = self.config.partial_rotary_factor
        if factor is not None:
            rope_dim = int(head_dim * factor)
        else:
            rope_dim = head_dim

        theta = self.config.rope_theta
        inv_freq = 1.0 / (theta ** (
            torch.arange(0, rope_dim, 2, dtype=torch.float32) / rope_dim
        ))
        return inv_freq.to(self.device)

    def _rope_cos_sin(self, positions: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Compute RoPE cos/sin, respecting partial rotary factor.

        Args:
            positions: (1, seq_len) position indices

        Returns:
            cos, sin: each (1, seq_len, rope_dim)
            Note: rope_dim may be < head_dim when partial_rotary_factor < 1.0
        """
        freqs = positions[:, :, None].float() * self._inv_freq[None, None, :]
        emb = torch.cat([freqs, freqs], dim=-1)
        return emb.cos().to(self.dtype), emb.sin().to(self.dtype)

    # ── Full attention layer (same as Qwen3) ──────────────────

    def forward_full_attention(
        self,
        hidden: torch.Tensor,
        layer_idx: int,
        cos: torch.Tensor,
        sin: torch.Tensor,
    ) -> torch.Tensor:
        """Gated attention layer (Qwen3.5 full attention with output gate)."""
        cfg = self.config
        with PROFILER.phase("disk_read"):
            w = self.shards.load_layer(layer_idx, self.dtype)
            w = {k: v.to(self.device) for k, v in w.items()}

            # Preserve native float32 for norm weights (Qwen3.5 stores them as float32)
            key_map = self.adapter.layer_weight_keys(layer_idx)
            for norm_key in ("input_layernorm", "post_attention_layernorm", "q_norm", "k_norm"):
                if norm_key in key_map and self.shards.has_key(key_map[norm_key]):
                    w[norm_key] = self.shards.get_tensor(key_map[norm_key]).to(self.device)

        bsz, seq_len, _ = hidden.shape
        q_dim = cfg.num_attention_heads * cfg.head_dim

        # Pre-attention norm
        residual = hidden
        hidden = rmsnorm_qwen35(hidden, w["input_layernorm"], self.eps)

        # Q projection: output is INTERLEAVED per head as
        # [Q_h0(256), gate_h0(256), Q_h1(256), gate_h1(256), ...]
        # Must reshape to (B, L, num_heads, head_dim*2) then chunk per head.
        q_raw = hidden @ w["q_proj"].T
        if q_raw.shape[-1] == q_dim * 2:
            q_gate = q_raw.view(bsz, seq_len, cfg.num_attention_heads, cfg.head_dim * 2)
            q, attn_gate = q_gate.chunk(2, dim=-1)  # each (B, L, H, head_dim)
            attn_gate = attn_gate.reshape(bsz, seq_len, -1)  # (B, L, q_dim)
        else:
            q = q_raw.view(bsz, seq_len, cfg.num_attention_heads, cfg.head_dim)
            attn_gate = None

        k = (hidden @ w["k_proj"].T).view(bsz, seq_len, cfg.num_key_value_heads, cfg.head_dim)
        v = (hidden @ w["v_proj"].T).view(bsz, seq_len, cfg.num_key_value_heads, cfg.head_dim)

        # QK-LayerNorm
        q = rmsnorm_qwen35(q, w["q_norm"], self.eps)
        k = rmsnorm_qwen35(k, w["k_norm"], self.eps)

        q = q.transpose(1, 2)
        k = k.transpose(1, 2)
        v = v.transpose(1, 2)

        # Partial RoPE
        rope_dim = cos.shape[-1]
        if rope_dim < cfg.head_dim:
            q_rope, q_pass = q[..., :rope_dim], q[..., rope_dim:]
            k_rope, k_pass = k[..., :rope_dim], k[..., rope_dim:]
            q_rope, k_rope = apply_rope(q_rope, k_rope, cos, sin)
            q = torch.cat([q_rope, q_pass], dim=-1)
            k = torch.cat([k_rope, k_pass], dim=-1)
        else:
            q, k = apply_rope(q, k, cos, sin)

        # KV cache
        cached = self.kv_cache.read(layer_idx)
        if cached is not None:
            past_k, past_v = cached
            past_k, past_v = past_k.to(self.device), past_v.to(self.device)
            k = torch.cat([past_k, k], dim=2)
            v = torch.cat([past_v, v], dim=2)
        self.kv_cache.write(layer_idx, k.cpu(), v.cpu())

        # GQA
        gqa_rep = self.adapter.gqa_group_size()
        k_rep = repeat_kv(k, gqa_rep)
        v_rep = repeat_kv(v, gqa_rep)

        # Attention
        scale = cfg.head_dim ** -0.5
        scores = (q @ k_rep.transpose(-1, -2)) * scale

        if seq_len > 1:
            kv_len = k_rep.shape[2]
            causal = torch.full((seq_len, kv_len), float("-inf"),
                               device=self.device, dtype=self.dtype)
            offset = kv_len - seq_len
            for i in range(seq_len):
                causal[i, :offset + i + 1] = 0
            scores = scores + causal[None, None, :, :]

        attn = F.softmax(scores.float(), dim=-1).to(self.dtype)
        out = attn @ v_rep

        # Output projection with gated attention
        out = out.transpose(1, 2).contiguous().reshape(bsz, seq_len, -1)
        if attn_gate is not None:
            out = out * torch.sigmoid(attn_gate)
        out = out @ w["o_proj"].T

        hidden = residual + out

        # Post-attention norm + SwiGLU MLP
        residual = hidden
        hidden = rmsnorm_qwen35(hidden, w["post_attention_layernorm"], self.eps)

        gate = F.silu(hidden @ w["gate_proj"].T)
        up = hidden @ w["up_proj"].T
        hidden = (gate * up) @ w["down_proj"].T

        hidden = residual + hidden
        del w
        return hidden

    # ── Linear attention layer (Gated DeltaNet) ───────────────

    def forward_linear_attention(
        self,
        hidden: torch.Tensor,
        layer_idx: int,
    ) -> torch.Tensor:
        """Gated DeltaNet linear attention layer.

        Implements the recurrent delta-rule attention used in 75% of
        Qwen3.5 layers. Reference: HuggingFace transformers
        Qwen3NextGatedDeltaNet (modeling_qwen3_next.py).

        The recurrence per token:
            decay = exp(-exp(A_log) * softplus(a + dt_bias))
            S = decay * S
            S = S + k * beta * (v - k^T @ S)        # delta-rule write
            o = q^T @ S                               # readout

        Output is gated: RMSNorm(o) * SiLU(z), then projected.
        """
        cfg = self.config
        with PROFILER.phase("disk_read"):
            w = self.shards.load_layer(layer_idx, self.dtype)
            w = {k: v.to(self.device) for k, v in w.items()}

            # Preserve native float32 for precision-sensitive gate parameters.
            # A_log and norm.weight are stored as float32 in the checkpoint;
            # truncating to bfloat16 corrupts exp() decay gates.
            key_map = self.adapter.layer_weight_keys(layer_idx)
            for gate_key in ("A_log", "norm", "dt_bias"):
                if gate_key in key_map and self.shards.has_key(key_map[gate_key]):
                    w[gate_key] = self.shards.get_tensor(key_map[gate_key]).to(self.device)

        bsz, seq_len, _ = hidden.shape
        num_k_heads = cfg.linear_num_key_heads       # 16
        k_head_dim = cfg.linear_key_head_dim         # 128
        num_v_heads = cfg.linear_num_value_heads     # 16
        v_head_dim = cfg.linear_value_head_dim       # 128
        key_dim = num_k_heads * k_head_dim           # 2048
        value_dim = num_v_heads * v_head_dim         # 2048

        # Pre-attention norm
        residual = hidden
        hidden = rmsnorm_qwen35(hidden, w["input_layernorm"], self.eps)

        # ── 1) Projections ──────────────────────────────────
        # QKV from one weight — Qwen3.5 uses CONTIGUOUS layout:
        # [Q_all(2048), K_all(2048), V_all(2048)]
        qkv = hidden @ w["in_proj_qkv"].T          # (B, L, key_dim*2 + value_dim)
        # Output gate z — projected from input, NOT through conv
        z = hidden @ w["in_proj_z"].T               # (B, L, value_dim)
        # Delta-rule parameters — RAW (no activation yet)
        a_raw = hidden @ w["in_proj_a"].T           # (B, L, num_v_heads)
        b_raw = hidden @ w["in_proj_b"].T           # (B, L, num_v_heads)

        # ── 2) Causal Conv1d + SiLU on entire QKV ──────────
        conv_kernel = w["conv1d"]                    # (conv_dim, 1, kernel_size)
        kernel_size = conv_kernel.shape[-1]
        conv_dim = qkv.shape[-1]

        if layer_idx in self._conv_state:
            conv_state = self._conv_state[layer_idx].to(self.device)
        else:
            conv_state = torch.zeros(
                bsz, conv_dim, kernel_size - 1,
                dtype=self.dtype, device=self.device
            )

        qkv_t = qkv.transpose(1, 2)                # (B, conv_dim, L)
        qkv_padded = torch.cat([conv_state, qkv_t], dim=-1)
        # Save conv state BEFORE conv (stores pre-conv values)
        self._conv_state[layer_idx] = qkv_padded[:, :, -(kernel_size - 1):].cpu()
        # Conv1d then SiLU on the ENTIRE output
        qkv_conv = F.conv1d(qkv_padded, conv_kernel, groups=conv_dim, padding=0)
        qkv_conv = F.silu(qkv_conv)
        qkv_conv = qkv_conv.transpose(1, 2)        # (B, L, conv_dim)

        # ── 3) Split contiguously into Q, K, V + reshape ───
        q = qkv_conv[:, :, :key_dim].reshape(bsz, seq_len, num_k_heads, k_head_dim)
        k = qkv_conv[:, :, key_dim:key_dim * 2].reshape(bsz, seq_len, num_k_heads, k_head_dim)
        v = qkv_conv[:, :, key_dim * 2:].reshape(bsz, seq_len, num_v_heads, v_head_dim)

        # ── 4) Reshape to heads ─────────────────────────────
        # NOTE: L2 norm and query scaling are handled INSIDE the
        # chunk/recurrent delta rule functions (use_qk_l2norm_in_kernel=True)
        # Do NOT apply them here or Q gets double-scaled.

        # ── 5) Decay (g) and write strength (beta) ────────
        # All gate math in fp32 to avoid -inf from exp(A_log) in fp16
        A_neg = -torch.exp(w["A_log"].float())    # (num_v_heads,), negative
        g = A_neg * F.softplus(a_raw.float() + w["dt_bias"].float())  # (B, L, num_v_heads)
        beta = torch.sigmoid(b_raw.float())       # (B, L, num_v_heads)

        # ── 7) Expand K/Q heads to match V heads if needed ─
        if num_v_heads != num_k_heads:
            rep = num_v_heads // num_k_heads
            q = q.repeat_interleave(rep, dim=2)
            k = k.repeat_interleave(rep, dim=2)

        # ── 8) Gated delta rule (HF reference implementation) ─
        # Use chunked form for prefill (seq_len > 1) for numerical
        # stability; recurrent form for single-token decode.
        initial_state = None
        if layer_idx in self._recurrent_state:
            initial_state = self._recurrent_state[layer_idx].to(self.device)

        if seq_len > 1:
            attn_out, final_state = _torch_chunk_gated_delta_rule(
                q, k, v, g=g, beta=beta,
                initial_state=initial_state,
                output_final_state=True,
                use_qk_l2norm_in_kernel=True,
            )
        else:
            attn_out, final_state = _torch_recurrent_gated_delta_rule(
                q, k, v, g=g, beta=beta,
                initial_state=initial_state,
                output_final_state=True,
                use_qk_l2norm_in_kernel=True,
            )

        self._recurrent_state[layer_idx] = final_state.cpu()

        # ── 9) Output gate: RMSNormGated(attn_out, z) ────
        # Reshape z to per-head: (B, L, num_v_heads, v_head_dim)
        z_heads = z.reshape(bsz, seq_len, num_v_heads, v_head_dim)

        # RMSNorm per head dim (128), then multiply by SiLU(z)
        norm_w = w["norm"].float()                 # (v_head_dim,)
        attn_flat = attn_out.reshape(-1, v_head_dim).float()
        variance = attn_flat.pow(2).mean(-1, keepdim=True)
        attn_flat = attn_flat * torch.rsqrt(variance + self.eps)
        attn_flat = norm_w * attn_flat
        # Gate: multiply by SiLU(z)
        z_flat = z_heads.reshape(-1, v_head_dim).float()
        attn_flat = attn_flat * F.silu(z_flat)
        attn_out = attn_flat.to(self.dtype).reshape(bsz, seq_len, value_dim)

        # ── 11) Output projection + residual ───────────────
        attn_out = attn_out @ w["out_proj"].T
        hidden = residual + attn_out

        # ── 12) Post-attention norm + SwiGLU MLP ───────────
        residual = hidden
        hidden = rmsnorm_qwen35(hidden, w["post_attention_layernorm"], self.eps)

        gate = F.silu(hidden @ w["gate_proj"].T)
        up = hidden @ w["up_proj"].T
        hidden = (gate * up) @ w["down_proj"].T

        hidden = residual + hidden
        del w
        return hidden

    # ── Unified forward pass ──────────────────────────────────

    def forward_layer(
        self,
        hidden: torch.Tensor,
        layer_idx: int,
        cos: torch.Tensor,
        sin: torch.Tensor,
    ) -> torch.Tensor:
        """Dispatch to the correct attention implementation."""
        layer_type = self.adapter.layer_type(layer_idx)
        if layer_type == "linear_attention":
            return self.forward_linear_attention(hidden, layer_idx)
        else:
            return self.forward_full_attention(hidden, layer_idx, cos, sin)

    def embed_with_vision(
        self,
        input_ids: torch.Tensor,
        pixel_values=None,
        grid_thw=None,
    ) -> torch.Tensor:
        """Create input embeddings, replacing vision placeholders.

        Supports one OR many images. pixel_values/grid_thw may be a single
        tensor (one image) or a list of tensors (a batch of images for one
        prompt). Each image is encoded separately by the ViT, the resulting
        vision-token blocks are concatenated in image order, and they fill the
        <|image_pad|> positions in sequence order. Because the prompt lays out
        the images as consecutive placeholder spans (image 1's span, then image
        2's, ...) and the concatenation is in the same order, image i's tokens
        land in image i's span.

        Args:
            input_ids: (batch, seq_len) token IDs
            pixel_values: tensor (C,H,W)/(1,C,H,W) or list of such tensors
            grid_thw: matching tensor or list of (1,3) patch grids

        Returns:
            hidden: (batch, seq_len, hidden_size) input embeddings
        """
        hidden = self._embed[input_ids]

        if pixel_values is None or self.vision_encoder is None:
            return hidden

        # Normalize single-image and multi-image inputs to parallel lists.
        if isinstance(pixel_values, (list, tuple)):
            pv_list = list(pixel_values)
            if isinstance(grid_thw, (list, tuple)):
                gt_list = list(grid_thw)
            else:
                gt_list = [grid_thw] * len(pv_list)
        else:
            pv_list = [pixel_values]
            gt_list = [grid_thw]

        # Encode each image and concatenate vision tokens in image order.
        blocks = []
        for pv, gt in zip(pv_list, gt_list):
            with PROFILER.phase("vision_encode"):
                vt = self.vision_encoder.encode(
                    pv.to(self.dtype).to(self.device), gt,
                    cancel_check=self._cancel_check,
                )
            blocks.append(vt[0])  # (n_i, hidden) — drop batch dim
        vision_tokens = torch.cat(blocks, dim=0)  # (sum n_i, hidden)

        img_token_id = self.config.image_token_id
        if img_token_id is None:
            return hidden

        for b in range(input_ids.shape[0]):
            img_positions = torch.where(input_ids[b] == img_token_id)[0]
            n_replace = min(img_positions.shape[0], vision_tokens.shape[0])
            if n_replace > 0:
                hidden[b, img_positions[:n_replace]] = \
                    vision_tokens[:n_replace].to(hidden.dtype)

        return hidden

    def forward(
        self,
        input_ids: torch.Tensor,
        position_offset: int = 0,
        pixel_values: Optional[torch.Tensor] = None,
        grid_thw: Optional[torch.Tensor] = None,
        all_positions: bool = False,
    ) -> torch.Tensor:
        """Full forward pass: input token IDs (+ optional image) → logits.

        Args:
            input_ids: (batch, seq_len) token IDs
            position_offset: starting position for RoPE
            pixel_values: optional image tensor for vision encoding
            grid_thw: optional patch grid dimensions
            all_positions: False (default) → LM head on the last position only,
                (batch, vocab), today's behavior. True → head on every position,
                (batch, seq_len, vocab), for the SD verify sweep (spec §6
                Change 1). Default path is unchanged.

        Returns:
            logits: (batch, vocab) or (batch, seq_len, vocab) when all_positions.
        """
        bsz, seq_len = input_ids.shape

        # Embedding (with optional vision token insertion)
        hidden = self.embed_with_vision(input_ids, pixel_values, grid_thw)

        # RoPE
        positions = torch.arange(
            position_offset, position_offset + seq_len,
            device=self.device
        ).unsqueeze(0)
        cos, sin = self._rope_cos_sin(positions)

        # Stream through all layers
        for i in range(self.config.num_hidden_layers):
            # Check cancel between layers for responsive interruption
            if self._cancel_check is not None:
                self._cancel_check()
            _t0 = time.perf_counter()
            hidden = self.forward_layer(hidden, i, cos, sin)
            self.current_layer = i + 1
            self._rest_after_layer(time.perf_counter() - _t0)

        # Final norm
        hidden = rmsnorm_qwen35(hidden, self._final_norm, self.eps)

        # LM head. Default: last position only (batch, vocab) — unchanged.
        # all_positions: every position (batch, seq_len, vocab) for SD verify.
        last_hidden = hidden[:, -1, :]
        head_input = hidden if all_positions else last_hidden
        if self._lm_head is not None:
            logits = head_input @ self._lm_head.T
        elif self._stream_lm_head:
            with PROFILER.phase("disk_read"):
                lm_head = self.shards.load_lm_head(self.dtype).to(self.device)
            logits = head_input @ lm_head.T
            del lm_head
        else:
            logits = head_input @ self._embed.T

        # ── NaN/inf diagnostic ──
        if torch.isnan(logits).any() or torch.isinf(logits).any():
            nan_count = torch.isnan(logits).sum().item()
            inf_count = torch.isinf(logits).sum().item()
            total = logits.numel()
            print(f"  ⚠ FORWARD: logits have {nan_count} NaN, {inf_count} inf "
                  f"out of {total} values!", flush=True)
            # Check which layer introduced the problem
            if torch.isnan(last_hidden).any():
                print(f"  ⚠ FORWARD: last_hidden also has NaN — "
                      f"problem is in the layer stack, not lm_head", flush=True)

        return logits

    def clear_state(self):
        """Clear all cached state (KV cache + recurrent state + conv state)."""
        self.kv_cache.clear()
        self._recurrent_state.clear()
        self._conv_state.clear()

    # ── Speculative-decoding state snapshot/restore (spec §6 Change 2) ──────
    # THE hard part of the build (§6, §10). A HybridStreamer has three kinds of
    # per-token state: full-attention KV (append-only, sliceable), and — for
    # the ~75% linear-attention layers — a running RECURRENT state and a CONV
    # state, both overwritten irreversibly each token in forward_linear_attention
    # (self._recurrent_state[idx] / self._conv_state[idx] are replaced wholesale).
    # You CANNOT "un-step" the recurrent/conv state by slicing; a KV truncation
    # alone would leave them advanced past the accepted prefix and silently
    # corrupt the continuation. So the rollback is snapshot-then-restore (the
    # spec's recommended form), and the SD loop re-advances exactly the accepted
    # tokens afterward (see engine.speculative).
    #
    # Both states are kept on CPU (the layer code does `.cpu()` on write), so a
    # snapshot is a cheap clone of two small dicts. Restore also clones, so one
    # snapshot can be reused across reject/re-advance cycles without aliasing.
    #
    # CORRECTNESS NOTE: losslessness here can only be PROVEN with the model pair
    # loaded (spec §9 — generated text identical to plain greedy across multiple
    # verify blocks). That validation is a target-rig step; this code is dormant
    # (SD disabled by default) until then.

    def snapshot_state(self) -> dict:
        """Capture KV length + recurrent/conv tensors at a verify-block start."""
        return {
            "kv_seq_len": self.kv_cache.seq_len(),
            "recurrent": {i: t.clone() for i, t in self._recurrent_state.items()},
            "conv": {i: t.clone() for i, t in self._conv_state.items()},
        }

    def restore_state(self, snap: dict) -> None:
        """Reset all three state kinds to a captured snapshot.

        KV is truncated (full-attention layers); the recurrent and conv dicts
        are replaced wholesale with clones of the snapshot, resetting every
        linear-attention layer to the block-boundary state. The SD loop then
        re-advances the accepted tokens so the engine state matches the
        committed output exactly.
        """
        self.kv_cache.truncate(int(snap["kv_seq_len"]))
        self._recurrent_state = {i: t.clone() for i, t in snap["recurrent"].items()}
        self._conv_state = {i: t.clone() for i, t in snap["conv"].items()}

    def generate(
        self,
        prompt: str,
        max_new_tokens: int = 100,
        temperature: float = 0.7,
        top_p: float = 0.9,
        top_k: int = 20,
        presence_penalty: float = 0.0,
        stop_tokens: Optional[list[int]] = None,
        on_token: Optional[Callable[[int, int], None]] = None,
        on_checkpoint: Optional[Callable[[int, int, int, list], None]] = None,
        cancel_check: Optional[Callable] = None,
        resume_tokens: Optional[list[int]] = None,
        resume_rng: Optional[bytes] = None,
        pixel_values: Optional[torch.Tensor] = None,
        grid_thw: Optional[torch.Tensor] = None,
    ) -> list[int]:
        """Generate text, optionally conditioned on an image.

        Extends LayerStreamer.generate() with vision input support.
        Image is processed only during the prefill pass.

        Args:
            prompt: Input text string
            max_new_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            top_p: Nucleus sampling threshold
            top_k: Top-k filter
            stop_tokens: Token IDs that stop generation
            on_token: Callback(token_id, step)
            on_checkpoint: Callback(token_id, step, position, tokens)
            resume_tokens: Previously generated tokens to resume from
            resume_rng: Sampler RNG state for deterministic resume
            pixel_values: Optional image tensor (processed during prefill)
            grid_thw: Optional patch grid dimensions

        Returns:
            List of generated token IDs
        """
        if stop_tokens is None:
            stop_tokens = self.config.eos_token_id

        self.clear_state()
        self._cancel_check = cancel_check
        prompt_ids = self.adapter.encode_prompt(prompt)

        if resume_tokens:
            prefill_ids = list(prompt_ids) + list(resume_tokens)
            generated = list(resume_tokens)
        else:
            prefill_ids = list(prompt_ids)
            generated = []

        input_tensor = torch.tensor(
            [prefill_ids], dtype=torch.long, device=self.device
        )

        # Prefill — includes vision encoding if image provided
        _t_pre = time.perf_counter()
        logits = self.forward(
            input_tensor, position_offset=0,
            pixel_values=pixel_values, grid_thw=grid_thw,
        )
        PROFILER.mark("wall_prefill", time.perf_counter() - _t_pre)
        position = len(prefill_ids)
        start_step = len(generated)

        if resume_tokens and resume_rng:
            import numpy as np
            torch.set_rng_state(torch.from_numpy(
                np.frombuffer(resume_rng, dtype=np.uint8).copy()
            ))

        # Autoregressive generation (no vision in decode steps)
        for step in range(start_step, max_new_tokens):
            with PROFILER.phase("sampling"):
                token_id = sample(logits.squeeze(0), temperature, top_p, top_k,
                                  presence_penalty=presence_penalty,
                                  generated_tokens=generated)
            generated.append(token_id)

            if on_token:
                on_token(token_id, step)
            if on_checkpoint:
                on_checkpoint(token_id, step, position, generated)
            if token_id in stop_tokens:
                break

            next_input = torch.tensor(
                [[token_id]], dtype=torch.long, device=self.device
            )
            _t_dec = time.perf_counter()
            logits = self.forward(next_input, position_offset=position)
            PROFILER.mark("wall_decode", time.perf_counter() - _t_dec)
            position += 1

        self._cancel_check = None
        return generated
