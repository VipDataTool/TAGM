"""Gemma 3 layer-streaming inference engine.

Subclasses LayerStreamer, inheriting generate()/checkpoint/KV/SD-snapshot
behavior, and owns the forward pass because Gemma 3's differences are
structural, not parametric (GEMMA3_ADAPTER_BUILD_PLAN.md §3):

- (1+weight) RMSNorm everywhere (LayerStreamer's rmsnorm is standard-only)
- Sandwich norms: post-attention and post-feedforward norms applied to the
  sublayer OUTPUT before the residual add
- GeGLU MLP (gelu_pytorch_tanh) instead of SwiGLU
- Per-layer attention: sliding (band-masked / KV-sliced, local RoPE base)
  vs full (global RoPE base with linear scaling)
- Attention scale from query_pre_attn_scalar, not head_dim
- Embedding scaled by sqrt(hidden_size) at input; tied lm_head uses the
  UNSCALED embedding (base behavior, unchanged)

LayerStreamer and HybridStreamer are untouched: existing families remain
byte-identical (performance spec Class I discipline).
"""

import time

import torch
import torch.nn.functional as F

from engine.streamer import LayerStreamer, apply_rope, repeat_kv
from engine.hybrid_streamer import rmsnorm_qwen35 as rmsnorm_1p


class Gemma3Streamer(LayerStreamer):
    """Layer-streaming engine for the Gemma 3 family (text path)."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        cfg = self.config

        # Embedding scale: sqrt(hidden_size), cast to the embedding dtype
        # BEFORE use — mirrors the reference implementation, so bf16
        # rounding matches for parity.
        self._embed_scale = torch.tensor(
            cfg.hidden_size ** 0.5, dtype=self._embed.dtype)

        # Dual RoPE: base class built the GLOBAL inv_freq via the
        # adapter's build_rope_inv_freq (theta=1M, linear-scaled).
        # Build the LOCAL one (rope_local_base_freq, unscaled) here.
        self._inv_freq_local = self.adapter.build_rope_inv_freq_local(self.device)

        # Attention scale is decoupled from head_dim (they differ on 27B).
        self._attn_scale = float(cfg.query_pre_attn_scalar or cfg.head_dim) ** -0.5

        self._window = int(cfg.sliding_window or 0)

    # ── RoPE (both frequency sets) ───────────────────────────

    def _rope_cos_sin_from(self, inv_freq, positions):
        freqs = positions[:, :, None].float() * inv_freq[None, None, :]
        emb = torch.cat([freqs, freqs], dim=-1)
        return emb.cos().to(self.dtype), emb.sin().to(self.dtype)

    # ── Per-layer forward ────────────────────────────────────

    def forward_layer(self, hidden, layer_idx, cos, sin):
        """One Gemma 3 decoder layer.

        `cos`/`sin` must already be the correct set for this layer's
        type — forward() selects global vs local before dispatch.
        """
        cfg = self.config
        eps = self.eps
        w = self.shards.load_layer(layer_idx, self.dtype)
        w = {k: v.to(self.device) for k, v in w.items()}
        is_sliding = self.adapter.layer_type(layer_idx) == "sliding_attention"

        bsz, seq_len, _ = hidden.shape

        # ── Attention block (sandwich-normed) ───────────────
        residual = hidden
        hidden = rmsnorm_1p(hidden, w["input_layernorm"], eps)

        q = (hidden @ w["q_proj"].T).view(bsz, seq_len, cfg.num_attention_heads, cfg.head_dim)
        k = (hidden @ w["k_proj"].T).view(bsz, seq_len, cfg.num_key_value_heads, cfg.head_dim)
        v = (hidden @ w["v_proj"].T).view(bsz, seq_len, cfg.num_key_value_heads, cfg.head_dim)

        # Per-head QK-norm, (1+weight) variant, before RoPE.
        q = rmsnorm_1p(q, w["q_norm"], eps)
        k = rmsnorm_1p(k, w["k_norm"], eps)

        q = q.transpose(1, 2)
        k = k.transpose(1, 2)
        v = v.transpose(1, 2)

        q, k = apply_rope(q, k, cos, sin)

        # KV cache (full-length storage in v1; window enforced at read).
        cached = self.kv_cache.read(layer_idx)
        if cached is not None:
            past_k, past_v = cached
            k = torch.cat([past_k.to(self.device), k], dim=2)
            v = torch.cat([past_v.to(self.device), v], dim=2)
        self.kv_cache.write(layer_idx, k.cpu(), v.cpu())

        kv_len = k.shape[2]
        offset = kv_len - seq_len  # absolute position of query row 0

        # Sliding layers in DECODE: attend only the last `window`
        # positions — slicing cached K/V is equivalent to the band mask
        # and cheaper. (RoPE was applied at absolute positions before
        # caching, so slicing is safe.)
        if is_sliding and self._window and seq_len == 1 and kv_len > self._window:
            k = k[:, :, -self._window:, :]
            v = v[:, :, -self._window:, :]
            kv_len = self._window
            offset = kv_len - seq_len

        k_rep = repeat_kv(k, self.adapter.gqa_group_size())
        v_rep = repeat_kv(v, self.adapter.gqa_group_size())

        scores = (q @ k_rep.transpose(-1, -2)) * self._attn_scale

        if seq_len > 1:
            # Vectorized causal (+band, for sliding layers) mask.
            # Query row i sits at absolute position offset+i; key column
            # j at absolute position j (kv_len covers [0, kv_len)).
            q_pos = torch.arange(offset, offset + seq_len, device=self.device)
            k_pos = torch.arange(kv_len, device=self.device)
            allowed = k_pos[None, :] <= q_pos[:, None]           # causal
            if is_sliding and self._window:
                allowed &= k_pos[None, :] > (q_pos[:, None] - self._window)
            mask = torch.zeros(seq_len, kv_len, device=self.device, dtype=self.dtype)
            mask[~allowed] = float("-inf")
            scores = scores + mask[None, None, :, :]

        attn = F.softmax(scores.float(), dim=-1).to(self.dtype)
        out = attn @ v_rep
        out = out.transpose(1, 2).contiguous().reshape(bsz, seq_len, -1)
        out = out @ w["o_proj"].T

        # Sandwich: post-attention norm on the OUTPUT, then residual.
        out = rmsnorm_1p(out, w["post_attention_layernorm"], eps)
        hidden = residual + out

        # ── MLP block (sandwich-normed, GeGLU) ───────────────
        residual = hidden
        hidden = rmsnorm_1p(hidden, w["pre_feedforward_layernorm"], eps)

        gate = F.gelu(hidden @ w["gate_proj"].T, approximate="tanh")
        up = hidden @ w["up_proj"].T
        hidden = (gate * up) @ w["down_proj"].T

        hidden = rmsnorm_1p(hidden, w["post_feedforward_layernorm"], eps)
        hidden = residual + hidden

        del w
        return hidden

    # ── Full forward (dual RoPE + embed scaling + (1+w) final norm) ──

    def forward(self, input_ids, position_offset: int = 0,
                all_positions: bool = False):
        bsz, seq_len = input_ids.shape

        hidden = self._embed[input_ids] * self._embed_scale.to(self.device)

        positions = torch.arange(
            position_offset, position_offset + seq_len, device=self.device
        ).unsqueeze(0)
        cos_g, sin_g = self._rope_cos_sin_from(self._inv_freq, positions)
        cos_l, sin_l = self._rope_cos_sin_from(self._inv_freq_local, positions)

        for i in range(self.config.num_hidden_layers):
            if self._cancel_check is not None:
                self._cancel_check()
            _t0 = time.perf_counter()
            if self.adapter.layer_type(i) == "sliding_attention":
                hidden = self.forward_layer(hidden, i, cos_l, sin_l)
            else:
                hidden = self.forward_layer(hidden, i, cos_g, sin_g)
            self.current_layer = i + 1
            self._rest_after_layer(time.perf_counter() - _t0)

        hidden = rmsnorm_1p(hidden, self._final_norm, self.eps)

        head_input = hidden if all_positions else hidden[:, -1, :]
        if self._lm_head is not None:
            logits = head_input @ self._lm_head.T
        elif self._stream_lm_head:
            lm_head = self.shards.load_lm_head(self.dtype).to(self.device)
            logits = head_input @ lm_head.T
            del lm_head
        else:
            # Tied: raw (unscaled) embedding — sqrt(hidden) applies at
            # input only, matching the reference.
            logits = head_input @ self._embed.T

        return logits
