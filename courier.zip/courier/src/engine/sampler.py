"""Token sampling: temperature, top-p, top-k, and presence penalty.

Qwen3.5 docs recommend for non-thinking mode:
    T=0.7, top_p=0.8, top_k=20, presence_penalty=1.5

Do not use greedy (T=0) — the model card warns it causes
endless repetitions. The presence_penalty is critical for
small models that otherwise lock into repetition loops.
"""

import torch


def sample(
    logits: torch.Tensor,
    temperature: float = 0.7,
    top_p: float = 0.9,
    top_k: int = 20,
    presence_penalty: float = 0.0,
    generated_tokens: list[int] | None = None,
) -> int:
    """Sample a token ID from logits.

    Args:
        logits: Shape (vocab_size,) — raw logits for one position
        temperature: Sampling temperature (>0, do not use 0)
        top_p: Nucleus sampling threshold
        top_k: Top-k filter (0 = disabled)
        presence_penalty: Additive penalty for tokens already generated.
            Qwen3.5 recommends 1.5 for non-thinking mode.
        generated_tokens: List of token IDs already generated in this
            sequence. Used by presence_penalty.

    Returns:
        Sampled token ID
    """
    if temperature <= 0:
        return logits.argmax().item()

    # Clone, as distribution() does: .float() is a no-copy when the input is
    # already float32, and the presence-penalty / top-k writes below are
    # in-place — without the clone they corrupt the caller's logits tensor
    # for any second use. Latent today (engines emit bf16, which .float()
    # copies), but armed.
    logits = logits.float().clone()

    # Presence penalty: subtract penalty from logits of already-seen tokens
    if presence_penalty != 0.0 and generated_tokens:
        seen = torch.tensor(list(set(generated_tokens)), dtype=torch.long,
                            device=logits.device)
        logits[seen] -= presence_penalty

    # Temperature scaling
    logits = logits / temperature

    # Top-k filtering
    if top_k > 0:
        top_k = min(top_k, logits.size(-1))
        indices_to_remove = logits < torch.topk(logits, top_k)[0][..., -1, None]
        logits[indices_to_remove] = float("-inf")

    # Softmax
    probs = torch.softmax(logits, dim=-1)

    # Top-p (nucleus) filtering
    if top_p < 1.0:
        sorted_probs, sorted_indices = torch.sort(probs, descending=True)
        cumulative_probs = torch.cumsum(sorted_probs, dim=-1)
        sorted_mask = cumulative_probs - sorted_probs > top_p
        sorted_probs[sorted_mask] = 0.0
        sorted_probs /= sorted_probs.sum()
        idx = torch.multinomial(sorted_probs, num_samples=1)
        token_id = sorted_indices[idx].item()
    else:
        token_id = torch.multinomial(probs, num_samples=1).item()

    return token_id


def distribution(
    logits: torch.Tensor,
    temperature: float = 0.7,
    top_p: float = 0.9,
    top_k: int = 20,
    presence_penalty: float = 0.0,
    generated_tokens: list[int] | None = None,
) -> torch.Tensor:
    """Full-vocab probability vector the sampler draws from.

    Applies the SAME presence-penalty / temperature / top-k / top-p transforms
    as sample(), but returns the explicit distribution instead of a draw.
    Speculative decoding needs the distribution itself to compute accept/reject
    ratios and residuals, and it MUST be the exact distribution sample() would
    draw from so speculative output is distribution-identical to the plain
    decode at the same settings.

    Greedy (temperature <= 0) returns a one-hot at the argmax — which makes the
    speculative accept rule reduce to "accept iff it equals the verifier's
    argmax", i.e. lossless greedy. sample() itself is left untouched; this is
    additive so the non-speculative path is byte-for-byte unchanged.
    """
    # Greedy (temperature <= 0) must mirror sample() EXACTLY: sample() returns
    # logits.argmax() before applying the presence penalty or any scaling, so
    # this does the same — a one-hot at the raw argmax. (If this applied the
    # penalty first, the speculative greedy pick could differ from the plain
    # greedy pick whenever a token repeats and presence_penalty != 0, breaking
    # off-vs-on byte-identity. It must not.)
    if temperature <= 0:
        out = torch.zeros_like(logits.float())
        out[int(torch.argmax(logits))] = 1.0
        return out
    logits = logits.float().clone()
    if presence_penalty != 0.0 and generated_tokens:
        seen = torch.tensor(list(set(generated_tokens)), dtype=torch.long,
                            device=logits.device)
        logits[seen] -= presence_penalty
    logits = logits / temperature
    if top_k and top_k > 0:
        top_k = min(top_k, logits.size(-1))
        kth = torch.topk(logits, top_k)[0][..., -1, None]
        logits[logits < kth] = float("-inf")
    probs = torch.softmax(logits, dim=-1)
    if top_p < 1.0:
        sorted_probs, sorted_idx = torch.sort(probs, descending=True)
        cumulative = torch.cumsum(sorted_probs, dim=-1)
        mask = cumulative - sorted_probs > top_p
        sorted_probs[mask] = 0.0
        probs = torch.zeros_like(probs).scatter(0, sorted_idx, sorted_probs)
        s = probs.sum()
        if s > 0:
            probs = probs / s
    return probs
