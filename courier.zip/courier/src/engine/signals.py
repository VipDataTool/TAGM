"""Engine interruption signals.

``CancelledError`` and ``PausedError`` are control-flow signals, not errors.
They mean "stop what you're doing because the operator asked" — not "something
went wrong". They are raised from inside the inference token loop (via the
``on_token`` flag check) and must travel cleanly up to the queue worker, which
turns them into the correct cycle state (cancelled / paused) and queue action.

They deliberately subclass ``BaseException``, NOT ``Exception``.

The pipeline (``run_pipeline``) and the cycle loop (``run_worker``) each wrap
inference in a broad ``except Exception`` so that a genuine inference failure
is recorded as a failed stage rather than crashing the whole run. If these
signals subclassed ``Exception``, those blocks would swallow them too: an
operator interrupt would be mis-recorded as a stage failure, the pipeline
would carry on to the next stage, and the worker would never learn it was
supposed to stop. Subclassing ``BaseException`` keeps them structurally
outside the reach of ``except Exception`` — exactly how the standard library
treats ``KeyboardInterrupt``, ``GeneratorExit`` and ``asyncio.CancelledError``.

Net effect: ``except Exception`` remains the correct catch for *errors*, and
these signals are caught only by the queue worker's explicit handlers for
them. This module has no dependencies so any layer can import it freely.
"""


class CancelledError(BaseException):
    """Abort the running cycle.

    The queue worker catches this, marks the in-flight cycle ``cancelled``,
    and moves on to the next queued job (or goes idle if the queue is empty).
    """


class PausedError(BaseException):
    """Pause the running cycle.

    The queue worker catches this, marks the in-flight cycle ``paused``,
    returns the job to the front of the queue, and stops until the engine
    is resumed.
    """
