"""Vision encoder for multimodal models.

Implements the Qwen3-VL style Vision Transformer (ViT) used by
Qwen3.5. Runs the ViT one layer at a time (layer-streaming),
consistent with Courier's memory-constrained philosophy.

Architecture (Qwen3.5-4B vision encoder):
- Patch embedding: Conv3d (temporal_patch_size=2, patch_size=16)
- 24 transformer layers with pre-norm, GELU MLP
- Spatial merger: groups spatial_merge_size² patches → 1 token
- Projects to LLM hidden_size via merger MLP

The vision encoder runs BEFORE the LLM. Its output is a sequence
of vision tokens that replace <image> placeholder tokens in the
LLM input embedding.
"""

import math
from typing import Callable, Optional

import torch
import torch.nn.functional as F

from core.adapter.base import ModelAdapter, VisionConfig
from core.shard_manager import ShardManager
from engine.profiler import PROFILER


def gelu_pytorch_tanh(x: torch.Tensor) -> torch.Tensor:
    """GELU activation with tanh approximation (matches PyTorch 2.x)."""
    return F.gelu(x, approximate="tanh")


ACTIVATIONS = {
    "gelu_pytorch_tanh": gelu_pytorch_tanh,
    "gelu": F.gelu,
    "relu": F.relu,
    "silu": F.silu,
}


def _rotate_half(x: torch.Tensor) -> torch.Tensor:
    """Split the last dim in half and rotate: (-x2, x1)."""
    d = x.shape[-1] // 2
    x1, x2 = x[..., :d], x[..., d:]
    return torch.cat((-x2, x1), dim=-1)


def _apply_vision_rope(q: torch.Tensor, k: torch.Tensor,
                       cos: torch.Tensor, sin: torch.Tensor):
    """Apply 2D rotary position embedding to q and k.

    q, k: (B, heads, N, head_dim). cos, sin: (N, head_dim), broadcast over
    batch/heads. Matches Qwen3-VL's apply_rotary_pos_emb_vision.
    """
    cos = cos.unsqueeze(0).unsqueeze(0)  # (1,1,N,head_dim)
    sin = sin.unsqueeze(0).unsqueeze(0)
    q_out = (q * cos) + (_rotate_half(q) * sin)
    k_out = (k * cos) + (_rotate_half(k) * sin)
    return q_out, k_out


class VisionEncoder:
    """Layer-streaming ViT encoder for multimodal models.

    Loads and runs the vision transformer one layer at a time,
    mirroring LayerStreamer's approach for the LLM backbone.
    The ViT is much smaller than the LLM (typically ~300M params
    vs 4B+), so memory pressure is modest, but streaming keeps
    the pattern consistent and enables future scaling.

    Usage:
        encoder = VisionEncoder(shard_manager, adapter)
        vision_tokens = encoder.encode(pixel_values, grid_thw)
    """

    def __init__(
        self,
        shard_manager: ShardManager,
        adapter: ModelAdapter,
        dtype: torch.dtype = torch.bfloat16,
        device: str = "cpu",
    ):
        if not adapter.is_multimodal:
            raise ValueError(
                f"Adapter {adapter.MODEL_TYPE} is not multimodal — "
                f"no vision_config present"
            )

        self.shards = shard_manager
        self.adapter = adapter
        self.vision_cfg = adapter.config.vision
        self.dtype = dtype
        self.device = device
        self.act_fn = ACTIVATIONS.get(
            self.vision_cfg.hidden_act, gelu_pytorch_tanh
        )

        # Pre-load small persistent weights
        self._load_persistent_weights()

    def _load_persistent_weights(self):
        """Load patch embedding and merger weights (small, persist in RAM)."""
        keys = self.adapter.vision_embedding_keys()
        self._persistent = {}
        for role, key in keys.items():
            if self.shards.has_key(key):
                self._persistent[role] = self.shards.get_tensor(
                    key, self.dtype
                ).to(self.device)

        # Positional embedding (model.visual.pos_embed.weight) is loaded above
        # via vision_embedding_keys and applied in _add_pos_embed().

    def patch_embed(self, pixel_values: torch.Tensor) -> torch.Tensor:
        """Extract patch embeddings from pixel values.

        Args:
            pixel_values: (batch, channels, temporal, height, width)
                For single images: temporal=1, but Conv3d expects
                temporal_patch_size frames minimum.

        Returns:
            Patch embeddings: (batch, num_patches, hidden_size)
        """
        v = self.vision_cfg
        weight = self._persistent["patch_embed_proj"]
        bias = self._persistent.get("patch_embed_bias")

        # Conv3d: (out_channels, in_channels/groups, kT, kH, kW)
        # For images, pixel_values should be (B, C*T, H, W) reshaped
        # to (B, C, T, H, W) where T = temporal_patch_size
        if pixel_values.dim() == 4:
            B, C, H, W = pixel_values.shape
            # Reshape for Conv3d: treat as single temporal frame
            # Repeat to fill temporal_patch_size if needed
            T = v.temporal_patch_size
            if C == v.in_channels:
                pixel_values = pixel_values.unsqueeze(2).expand(-1, -1, T, -1, -1)
            else:
                # C might already include temporal: C = in_channels * T
                pixel_values = pixel_values.view(B, v.in_channels, T, H, W)

        # Manual Conv3d: F.conv3d
        patches = F.conv3d(
            pixel_values.to(self.dtype),
            weight,
            bias=bias,
            stride=(v.temporal_patch_size, v.patch_size, v.patch_size),
        )

        # Reshape: (B, hidden_size, T', H', W') → (B, num_patches, hidden_size)
        B = patches.shape[0]
        patches = patches.flatten(2).transpose(1, 2)  # (B, N, hidden_size)

        return patches

    def forward_vit_layer(
        self,
        hidden: torch.Tensor,
        layer_idx: int,
        cos: Optional[torch.Tensor] = None,
        sin: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Run one ViT transformer layer.

        Standard pre-norm transformer block:
            h = h + attn(norm1(h))
            h = h + mlp(norm2(h))

        Args:
            hidden: (batch, seq_len, hidden_size)
            layer_idx: ViT layer index

        Returns:
            Updated hidden states
        """
        v = self.vision_cfg
        keys = self.adapter.vision_layer_keys(layer_idx)
        with PROFILER.phase("vision_disk"):
            w = {role: self.shards.get_tensor(key, self.dtype).to(self.device)
                 for role, key in keys.items()
                 if self.shards.has_key(key)}

        eps = 1e-6  # ViT typically uses 1e-6

        # ── Pre-attention LayerNorm ──────────────────────────
        residual = hidden
        hidden = F.layer_norm(hidden, (v.hidden_size,), weight=w["ln1"],
                              bias=w.get("ln1_bias"), eps=eps)

        # ── Self-Attention ───────────────────────────────────
        B, N, D = hidden.shape
        head_dim = D // v.num_heads

        # QKV projection (fused: output is 3 * hidden_size)
        qkv = hidden @ w["qkv"].T
        if "qkv_bias" in w:
            qkv = qkv + w["qkv_bias"]
        qkv = qkv.reshape(B, N, 3, v.num_heads, head_dim)
        qkv = qkv.permute(2, 0, 3, 1, 4)  # (3, B, heads, N, head_dim)
        q, k, val = qkv[0], qkv[1], qkv[2]

        # 2D rotary position embedding (applied every layer, like Qwen3-VL).
        # Without this, the ViT has only absolute pos_embed and loses relative
        # spatial structure — patches read as a scrambled mosaic.
        if cos is not None and sin is not None:
            q, k = _apply_vision_rope(q, k, cos.to(q.dtype), sin.to(k.dtype))

        # Scaled dot-product attention (no causal mask for ViT)
        scale = head_dim ** -0.5
        attn = (q @ k.transpose(-1, -2)) * scale
        attn = F.softmax(attn.float(), dim=-1).to(self.dtype)
        out = (attn @ val).transpose(1, 2).reshape(B, N, D)

        # Output projection
        out = out @ w["proj"].T
        if "proj_bias" in w:
            out = out + w["proj_bias"]
        hidden = residual + out

        # ── Pre-MLP LayerNorm ────────────────────────────────
        residual = hidden
        hidden = F.layer_norm(hidden, (v.hidden_size,), weight=w["ln2"],
                              bias=w.get("ln2_bias"), eps=eps)

        # ── MLP (GELU) ──────────────────────────────────────
        fc1_out = hidden @ w["fc1"].T
        if "fc1_bias" in w:
            fc1_out = fc1_out + w["fc1_bias"]
        fc1_out = self.act_fn(fc1_out)

        fc2_out = fc1_out @ w["fc2"].T
        if "fc2_bias" in w:
            fc2_out = fc2_out + w["fc2_bias"]

        hidden = residual + fc2_out

        del w
        return hidden

    def spatial_merge(self, hidden: torch.Tensor, grid_thw: torch.Tensor) -> torch.Tensor:
        """Spatial merger: per-patch norm, group merge² patches, project to LLM dim.

        Matches the Qwen patch-merger: LayerNorm on the ViT hidden dim FIRST
        (per patch), then concatenate spatial_merge_size² adjacent patches into
        one token of (merge²·D), then a 2-layer MLP (merge²·D → merge²·D →
        llm_hidden). Names/shapes confirmed against the checkpoint:
        merger.norm(1024), merger.linear_fc1(4096→4096), merger.linear_fc2(4096→2560).

        Args:
            hidden: (batch, num_patches, vit_hidden_size)
            grid_thw: (batch, 3) — temporal, height, width grid (in patches)

        Returns:
            Vision tokens: (batch, num_vision_tokens, llm_hidden_size)
        """
        v = self.vision_cfg
        merge = v.spatial_merge_size
        p = self._persistent
        B, N, D = hidden.shape

        # 1. Per-patch LayerNorm on the ViT hidden dim, BEFORE grouping.
        if "merger_norm" in p:
            hidden = F.layer_norm(
                hidden, (D,), weight=p["merger_norm"],
                bias=p.get("merger_norm_bias"), eps=1e-6,
            )

        # 2. Group merge×merge spatially-adjacent patches → (B, N/merge², merge²·D).
        if grid_thw is not None and grid_thw.dim() >= 1:
            row = grid_thw[0] if grid_thw.dim() > 1 else grid_thw
            T, H, W = int(row[0]), int(row[1]), int(row[2])
        else:
            T = 1
            H = W = int(math.sqrt(N))

        H_out, W_out = H // merge, W // merge
        hidden = hidden.view(B, T, H_out, merge, W_out, merge, D)
        hidden = hidden.permute(0, 1, 2, 4, 3, 5, 6)  # (B, T, H', W', m, m, D)
        hidden = hidden.reshape(B, T * H_out * W_out, merge * merge * D)

        # 3. Merger MLP: (merge²·D) → merge²·D → llm_hidden.
        # NB: the merger uses exact (erf) GELU, while the ViT block MLPs use the
        # tanh approximation (hidden_act). Matching both exactly matters.
        if "merger_fc1" in p:
            hidden = hidden @ p["merger_fc1"].T
            if "merger_fc1_bias" in p:
                hidden = hidden + p["merger_fc1_bias"]
            hidden = F.gelu(hidden)  # exact GELU
        if "merger_fc2" in p:
            hidden = hidden @ p["merger_fc2"].T
            if "merger_fc2_bias" in p:
                hidden = hidden + p["merger_fc2_bias"]

        return hidden  # (B, num_vision_tokens, llm_hidden_size)

    def _add_pos_embed(self, hidden: torch.Tensor, grid_thw: torch.Tensor) -> torch.Tensor:
        """Add the learned absolute position embedding, bicubic-interpolated
        from its base grid to this image's patch grid.

        The checkpoint stores model.visual.pos_embed.weight as (base², D) — a
        square base grid (e.g. 48×48). For an H×W patch grid it's reshaped to
        (base, base, D) and interpolated to (H, W). This is the standard ViT
        variable-resolution pos-embed interpolation.
        """
        p = self._persistent
        if "pos_embed" not in p:
            return hidden
        pe = p["pos_embed"]
        base = int(round(pe.shape[0] ** 0.5))
        D = pe.shape[1]
        if grid_thw is not None and grid_thw.dim() >= 1:
            row = grid_thw[0] if grid_thw.dim() > 1 else grid_thw
            T, H, W = int(row[0]), int(row[1]), int(row[2])
        else:
            T = 1
            H = W = base

        if (H, W) == (base, base):
            pe_grid = pe.to(hidden.dtype)
        else:
            # Bilinear with align_corners=True == sampling at linspace(0, base-1, H/W),
            # matching Qwen3-VL's fast_pos_embed_interpolate corner weighting.
            pe2d = pe.reshape(1, base, base, D).permute(0, 3, 1, 2).float()
            pe2d = F.interpolate(pe2d, size=(H, W), mode="bilinear", align_corners=True)
            pe_grid = pe2d.permute(0, 2, 3, 1).reshape(H * W, D).to(hidden.dtype)

        pe_seq = pe_grid.unsqueeze(0)
        if T > 1:
            pe_seq = pe_seq.repeat(1, T, 1)
        return hidden + pe_seq

    def _vision_rope(self, grid_thw, head_dim: int, n_patches: int):
        """Build 2D rotary cos/sin for the patch grid, in row-major order.

        Each patch carries its (h, w) position. Half the rotary frequencies
        encode the row, half the column. theta=10000, rotary dim = head_dim//2
        (h and w each fill head_dim//4 freqs), then duplicated to head_dim and
        cos/sin'd — matching Qwen3-VL's vision RoPE. Patches are row-major
        (p = h*W + w), matching the order patch_embed produces.
        """
        if grid_thw is not None and grid_thw.dim() >= 1:
            row = grid_thw[0] if grid_thw.dim() > 1 else grid_thw
            T, H, W = int(row[0]), int(row[1]), int(row[2])
        else:
            T = 1
            H = W = int(round(n_patches ** 0.5))

        dim = head_dim // 2  # split across h and w
        inv_freq = 1.0 / (10000.0 ** (
            torch.arange(0, dim, 2, dtype=torch.float32, device=self.device) / dim))

        hpos = torch.arange(H, device=self.device).repeat_interleave(W)  # row-major
        wpos = torch.arange(W, device=self.device).repeat(H)
        freqs_h = torch.outer(hpos.float(), inv_freq)   # (N, dim/2)
        freqs_w = torch.outer(wpos.float(), inv_freq)   # (N, dim/2)
        rotary = torch.cat((freqs_h, freqs_w), dim=-1)  # (N, dim)
        emb = torch.cat((rotary, rotary), dim=-1)       # (N, head_dim)
        if T > 1:
            emb = emb.repeat(T, 1)
        return emb.cos().to(self.dtype), emb.sin().to(self.dtype)

    def encode(
        self,
        pixel_values: torch.Tensor,
        grid_thw: Optional[torch.Tensor] = None,
        cancel_check: Optional[Callable] = None,
    ) -> torch.Tensor:
        """Full vision encoding pipeline: pixels → LLM-ready tokens.

        Args:
            pixel_values: Raw image tensor.
                For single images: (batch, channels, height, width)
                For video frames: (batch, channels*temporal, height, width)
            grid_thw: (batch, 3) grid dimensions [temporal, height, width]
                after patch embedding. If None, inferred from pixel_values.
            cancel_check: Optional callable polled between ViT layers,
                mirroring the LLM layer loop. Before this, the entire
                vision encode was one uninterruptible block — a cancel
                landing during an image prefill waited out all
                `vision_cfg.depth` layers on whatever hardware was at hand.
                Raises (CancelledError/PausedError) propagate to the caller.

        Returns:
            Vision token embeddings: (batch, num_tokens, llm_hidden_size)
            Ready to be inserted into the LLM input sequence where
            <image> placeholder tokens appear.
        """
        if cancel_check is not None:
            cancel_check()

        # 1. Patch embedding
        hidden = self.patch_embed(pixel_values)

        # 1b. Add the learned (interpolated) absolute position embedding.
        hidden = self._add_pos_embed(hidden, grid_thw)

        # 1c. Build 2D rotary cos/sin for this grid (row-major patch order).
        head_dim = self.vision_cfg.hidden_size // self.vision_cfg.num_heads
        cos, sin = self._vision_rope(grid_thw, head_dim,
                                     n_patches=hidden.shape[1])

        # 2. Stream through ViT layers (rotary applied inside each)
        for i in range(self.vision_cfg.depth):
            if cancel_check is not None:
                cancel_check()
            hidden = self.forward_vit_layer(hidden, i, cos=cos, sin=sin)

        # 3. Spatial merge → project to LLM dimension
        vision_tokens = self.spatial_merge(hidden, grid_thw)

        return vision_tokens


def _fit_image_grid(w: int, h: int, patch_size: int, merge_size: int,
                    max_pixels: int, min_pixels: int):
    """Pure-math resize planner for the ViT (no torch/PIL — cold-testable).

    Scales (w, h) to fit the pixel budget, then rounds DOWN to a multiple of
    patch_size * merge_size. Rounding to patch_size alone is NOT enough:
    spatial_merge folds the patch grid in merge_size x merge_size blocks and
    does a .view() that requires the patch count per side to be divisible by
    merge_size. An odd patch count (e.g. 39 with merge_size=2) makes that view
    fail. Rounding to patch_size*merge_size guarantees h_patches and w_patches
    are multiples of merge_size. Rounding down keeps us within max_pixels.

    Returns (w, h, h_patches, w_patches).
    """
    total = w * h
    if total > max_pixels:
        scale = math.sqrt(max_pixels / total)
        w = int(w * scale)
        h = int(h * scale)
    elif total < min_pixels:
        scale = math.sqrt(min_pixels / total)
        w = int(w * scale)
        h = int(h * scale)

    block = patch_size * merge_size
    w = max(block, (w // block) * block)
    h = max(block, (h // block) * block)
    return w, h, h // patch_size, w // patch_size


def preprocess_image(
    image_path: str,
    patch_size: int = 16,
    max_pixels: int = 1280 * 28 * 28,
    min_pixels: int = 4 * 28 * 28,
    merge_size: int = 2,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Load and preprocess an image for the vision encoder.

    Resizes to maintain aspect ratio while respecting min/max pixel
    budgets and ensuring the patch grid is divisible by patch_size AND by
    merge_size (so spatial_merge's block view is always valid).

    Args:
        image_path: Path to the image file
        patch_size: ViT patch size (must divide both dimensions)
        max_pixels: Maximum total pixels after resize
        min_pixels: Minimum total pixels after resize
        merge_size: ViT spatial-merge size; the patch grid must be a multiple
            of this (passed from vision_cfg.spatial_merge_size by the caller)

    Returns:
        pixel_values: (1, 3, height, width) normalized float tensor
        grid_thw: (1, 3) tensor [temporal=1, h_patches, w_patches]
    """
    from PIL import Image

    img = Image.open(image_path).convert("RGB")
    w, h = img.size

    # Plan the resize so the patch grid is merge-divisible (see helper).
    w, h, h_patches, w_patches = _fit_image_grid(
        w, h, patch_size, merge_size, max_pixels, min_pixels)

    img = img.resize((w, h), Image.BICUBIC)

    # Convert to tensor and normalize. Qwen3-VL's ViT is a SigLIP backbone:
    # mean/std = 0.5 (NOT the CLIP/ImageNet stats).
    import numpy as np
    pixels = np.array(img, dtype=np.float32) / 255.0
    mean = np.array([0.5, 0.5, 0.5])
    std = np.array([0.5, 0.5, 0.5])
    pixels = (pixels - mean) / std

    # (H, W, C) → (1, C, H, W)
    pixel_values = torch.from_numpy(pixels).permute(2, 0, 1).unsqueeze(0)

    # Grid dimensions after patch embedding
    grid_thw = torch.tensor([[1, h_patches, w_patches]])

    return pixel_values, grid_thw
