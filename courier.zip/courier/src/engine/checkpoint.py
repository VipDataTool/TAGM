"""Checkpoint management for resumable inference.

Saves generation state periodically so inference can resume after
interruption. Works at two levels:

1. Stage-level: completed stage outputs are saved to the database.
   On resume, completed stages are skipped.

2. Token-level: within a stage, generation state (tokens, position,
   RNG state) is saved every checkpoint_interval steps. On resume,
   KV cache is restored from disk and generation continues.
"""

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import torch

from core.db import Database


@dataclass
class CheckpointState:
    """State of a generation checkpoint."""
    cycle_id: str
    stage_index: int
    generation_step: int
    tokens: list[int]
    position: int           # RoPE position offset
    rng_state: Optional[bytes] = None
    kv_cache_dir: Optional[str] = None
    prompt: Optional[str] = None    # stage prompt — pinned so a resume re-feeds it exactly
    active_seconds: float = 0.0     # banked active compute time for this stage as of this row


def save_checkpoint(db: Database, state: CheckpointState):
    """Write a checkpoint to the database."""
    rng_bytes = None
    if state.rng_state is not None:
        rng_bytes = state.rng_state
    else:
        rng_bytes = torch.get_rng_state().numpy().tobytes()

    db.save_checkpoint(
        cycle_id=state.cycle_id,
        stage_index=state.stage_index,
        generation_step=state.generation_step,
        tokens=state.tokens,
        position=state.position,
        rng_state=rng_bytes,
        kv_cache_dir=state.kv_cache_dir,
        prompt=state.prompt,
        active_seconds=state.active_seconds,
    )


def load_checkpoint(db: Database, cycle_id: str,
                    stage_index: Optional[int] = None) -> Optional[CheckpointState]:
    """Load the latest checkpoint for a cycle/stage."""
    data = db.get_latest_checkpoint(cycle_id, stage_index)
    if data is None:
        return None

    return CheckpointState(
        cycle_id=data["cycle_id"],
        stage_index=data["stage_index"],
        generation_step=data["generation_step"],
        tokens=data["tokens"],
        position=data["position"],
        rng_state=data["rng_state"],
        kv_cache_dir=data.get("kv_cache_dir"),
        prompt=data.get("prompt"),
        active_seconds=data.get("active_seconds") or 0.0,
    )


def restore_rng(state: CheckpointState):
    """Restore PyTorch RNG state from a checkpoint."""
    if state.rng_state is not None:
        import numpy as np
        rng_tensor = torch.from_numpy(
            np.frombuffer(state.rng_state, dtype=np.uint8).copy()
        )
        torch.set_rng_state(rng_tensor)


def make_checkpoint_callback(db: Database, cycle_id: str, stage_index: int,
                             interval: int = 10, prompt: Optional[str] = None,
                             kv_cache_dir: Optional[str] = None,
                             clock: Optional[callable] = None):
    """Create a callback for generate() that banks checkpoints.

    The streamer calls this after every token; the callback decides when
    to persist — every `interval` steps. Each checkpoint is one atomic
    SQLite row carrying the tokens generated so far and the pinned stage
    prompt, so a crash costs at most `interval` tokens and a recovery
    needs nothing from memory.

    `clock`, if given, is a zero-arg callable returning this stage's
    accumulated *active* compute time in seconds. It is banked alongside
    the tokens so a resume continues the elapsed clock from the checkpoint
    rather than from a wall-clock delta that would silently count the dead
    time the machine spent off. Time is banked exactly where tokens are.

    Returns a callable: (token_id, step, position, tokens_so_far) -> None
    """
    def callback(token_id: int, step: int, position: int, tokens: list[int]):
        if interval > 0 and (step + 1) % interval == 0:
            state = CheckpointState(
                cycle_id=cycle_id,
                stage_index=stage_index,
                generation_step=step,
                tokens=list(tokens),
                position=position,
                kv_cache_dir=kv_cache_dir,
                prompt=prompt,
                active_seconds=float(clock()) if clock else 0.0,
            )
            save_checkpoint(db, state)

    return callback
