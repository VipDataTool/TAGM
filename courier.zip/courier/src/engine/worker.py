"""Cycle worker: collect → infer → report → repeat.

Runs inference cycles using data from the ingestion buffer.
Handles cycle creation, data snapshotting, pipeline execution,
result storage, and session recovery.
"""

import datetime
import json
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

from core.db import Database
from data.ingest import snapshot_data
from engine.energy import EnergyMeter
from template import Template
from pipeline import run_pipeline, PipelineResult, stage_token_count

_ENERGY_METER: EnergyMeter | None = None


def get_meter() -> EnergyMeter:
    """One meter per process: instrument detection happens once, and the
    chosen method is stable across a run so receipts are comparable."""
    global _ENERGY_METER
    if _ENERGY_METER is None:
        _ENERGY_METER = EnergyMeter()
        print(f"[courier] Energy metering: {_ENERGY_METER.describe()}", flush=True)
    return _ENERGY_METER
from report import render_receipt
from engine.checkpoint import load_checkpoint


def _write_receipt(db: Database, cycle_id: str, template: Template,
                   pipeline_result, output_path, total_tokens: int) -> None:
    """Write the canonical cycle receipt (the persistent 'deadman' artifact).

    Renders from DB stages — the same source the dashboard popout and HTML
    download use — so the deadman copy and the live UI can never show
    different content. Falls back to in-memory pipeline_result.stages if
    the DB stages are missing (defensive: they should always be there,
    since on_stage_complete persists each stage before this runs).

    The cycle row is not updated with completion fields until after this
    returns (receipt-before-commit is the crash-safe order), so everything
    the row doesn't carry yet — completed_at, status, tokens — is overlaid
    here. Without the overlay the archived file permanently reads
    'inferring' / 0 tokens while the API render shows the real values.
    """
    cycle = db.get_cycle(cycle_id) or {"id": cycle_id}
    cycle["status"] = "complete"
    cycle["tokens_generated"] = total_tokens
    config = cycle.get("config")
    if isinstance(config, str):
        try:
            config = json.loads(config)
        except (ValueError, TypeError):
            config = {}
    # Single source of truth: read stages from the DB so every rendering
    # pipeline (deadman markdown, popout HTML, API download) sees the same
    # data. If DB stages are empty, fall back to in-memory stages so the
    # deadman copy is never blank — but log the mismatch.
    stages = db.get_stages(cycle_id)
    if not stages:
        print(f"  ⚠ Receipt: no stages in DB for {cycle_id}; "
              f"falling back to in-memory ({len(pipeline_result.stages)} stage(s)).",
              flush=True)
        stages = pipeline_result.stages
    md = render_receipt(cycle, config or {}, stages,
                        template=template, completed_at=time.time(),
                        images=db.cycle_image_names(cycle_id))
    Path(output_path).write_text(md, encoding="utf-8")


def _records_by_source(db: Database, cycle_id: str, template: Template) -> dict:
    """Group this cycle's in-scope ledger records by template source.

    Scope = the windowed inbox snapshot claimed for this cycle ∪ all persistent
    reference rows. The DB is the single source of truth; this is what replaces
    the directory glob. Binding rule, per template source:
      - image_file sources receive ALL in-scope image records (the totality of
        the cycle's images is one analytical input), as raw ledger rows whose
        `path` the engine dereferences.
      - tabular sources receive rows whose `source_id` matches the source name
        if any exist (named binding, e.g. a 'sensors' source ← sensors.csv),
        else all in-scope tabular rows; content JSON is parsed back to dicts so
        the adapter's render_records sees the same shape it would from a file.
    """
    window = db.get_snapshot_records(cycle_id)     # inbox, claimed for this cycle
    reference = db.get_reference_records()          # persistent companions
    in_scope = list(window) + list(reference)

    def _is_image(r):
        return (r.get("mime_type") or "").startswith("image/")

    image_recs = [r for r in in_scope if _is_image(r)]
    tabular_recs = [r for r in in_scope if not _is_image(r)]

    def _as_dict(r):
        try:
            d = json.loads(r["content"])
            return d if isinstance(d, dict) else {"value": d}
        except (ValueError, TypeError):
            return {"value": r.get("content", "")}

    out: dict[str, list] = {}
    for name, src in template.sources.items():
        if src.adapter == "image_file":
            out[name] = image_recs                  # raw rows (path pointers)
        else:
            named = [r for r in tabular_recs if r.get("source_id") == name]
            chosen = named if named else tabular_recs
            out[name] = [_as_dict(r) for r in chosen]
    return out


def _move_consumed_to_processed(db: Database, cycle_id: str) -> int:
    """After a cycle writes its report, retire the inbox files it consumed.

    Consume-on-success: only called once the report is durably written, so a
    crash mid-cycle leaves files in place for a clean resume. Each unique inbox
    file path is moved to a sibling `processed/` directory. Reference files are
    never here (get_snapshot_records returns inbox only) so companion data is
    never moved. Best-effort: a move failure is logged, not fatal.
    """
    moved = 0
    seen = set()
    for r in db.get_snapshot_records(cycle_id):
        p = r.get("path")
        if not p or p in seen:
            continue
        seen.add(p)
        src = Path(p)
        if not src.exists():
            continue
        try:
            dest_dir = src.parent / "processed"
            dest_dir.mkdir(parents=True, exist_ok=True)
            shutil.move(str(src), str(dest_dir / src.name))
            moved += 1
        except OSError as e:
            print(f"  Consume: could not move {src.name} to processed/: {e}",
                  flush=True)
    return moved


@dataclass
class CycleConfig:
    """Configuration for the cycle loop."""
    max_cycles: int = 0         # 0 = unlimited; N = run N then stop
    trigger_threshold: int = 0  # 0 = trigger when any data exists
    auto_resume: bool = True    # resume interrupted cycles on startup
    checkpoint_interval: int = 10
    # ── Run identity ─────────────────────────────────────────
    # Snapshotted onto each cycle's config blob so the dashboard can show
    # who/what the run belongs to, stable across restarts.
    project_name: str = ""
    user_name: str = ""
    # ── Model identity ───────────────────────────────────────
    # The model that *actually* runs inference, resolved at job-queue
    # time from the loaded model path — NOT from the template, which
    # may name a different model. Empty string = fall back to
    # template.model.id (legacy behavior).
    model_id: str = ""
    # ── Cycle pacing ─────────────────────────────────────────
    # on_demand: cycles run back-to-back, no wait (stops when data runs out).
    # timed:     fixed interval between cycle STARTS; an overrun forfeits a slot.
    # scheduled: cycles pinned to a daily clock time; a missed time is skipped.
    pacing_mode: str = "on_demand"
    interval_seconds: int = 0       # timed mode: seconds between cycle starts
    scheduled_time: str = ""        # scheduled mode: daily clock time "HH:MM"
    alert_threshold: int = 0        # consecutive skipped/missed before alert (0 = off)


@dataclass
class WorkerResult:
    """Result of a worker run."""
    cycles_completed: int = 0
    cycles_failed: int = 0
    cycles_skipped: int = 0       # cycle fired but found no data
    cycles_missed: int = 0        # cycle's slot was forfeited (previous run overran)
    total_tokens: int = 0
    consecutive_empty: int = 0    # current run of consecutive skipped/missed cycles
    alert: bool = False           # consecutive_empty crossed alert_threshold
    errors: list[str] = field(default_factory=list)


def _next_scheduled(hhmm: str, after_ts: float) -> float:
    """Timestamp of the next daily 'HH:MM' occurrence strictly after after_ts."""
    try:
        hh, mm = (int(x) for x in hhmm.split(":"))
        datetime.time(hh, mm)  # validate range
    except Exception:
        # Malformed time — fall back to an hour out so the loop cannot spin.
        return after_ts + 3600
    after = datetime.datetime.fromtimestamp(after_ts)
    cand = after.replace(hour=hh, minute=mm, second=0, microsecond=0)
    if cand <= after:
        cand += datetime.timedelta(days=1)
    return cand.timestamp()


def _hold(target_ts: float, cancel_event=None, pause_event=None):
    """Sleep until target_ts, interruptibly.

    Cancel ends the hold immediately. Pause freezes it — the clock does not
    advance while paused, and the target shifts forward by the paused
    duration so resuming does not 'owe' the frozen time.

    Returns (status, paused_seconds): status is 'ok' (target reached) or
    'cancelled'; paused_seconds is total time spent frozen, so the caller
    can shift the rest of the schedule by the same amount.
    """
    paused_total = 0.0
    while True:
        if cancel_event is not None and cancel_event.is_set():
            return "cancelled", paused_total
        if pause_event is not None and pause_event.is_set():
            p0 = time.time()
            while pause_event.is_set():
                if cancel_event is not None and cancel_event.is_set():
                    return "cancelled", paused_total
                time.sleep(0.25)
            dp = time.time() - p0
            paused_total += dp
            target_ts += dp        # frozen time does not count against the hold
            continue
        remaining = target_ts - time.time()
        if remaining <= 0:
            return "ok", paused_total
        time.sleep(min(remaining, 1.0))


def run_worker(
    db: Database,
    template: Template,
    infer_fn: Callable,
    data_paths: dict[str, str],
    default_max_tokens: int,
    export_dir: str | Path = "export",
    cycle_config: Optional[CycleConfig] = None,
    on_cycle_start: Optional[Callable[[str, int], None]] = None,
    on_cycle_end: Optional[Callable[[str, int, PipelineResult], None]] = None,
    on_progress: Optional[Callable] = None,
    on_hold: Optional[Callable[[Optional[float]], None]] = None,
    cancel_event=None,
    pause_event=None,
    infer_fns: Optional[dict] = None,
) -> WorkerResult:
    """Run the collect→infer→report cycle loop.

    Args:
        db: Database instance
        template: Template to execute
        infer_fn: Inference function (from make_infer_fn or stub)
        data_paths: {source_name: file_path} for pipeline data sources
        export_dir: Directory for output files
        cycle_config: Loop configuration
        on_cycle_start: Callback(cycle_id, cycle_number) at cycle start
        on_cycle_end: Callback(cycle_id, cycle_number, result) at cycle end
        on_progress: Callback(stage_index, stage_count, stage_label, stage_max)
                     forwarded to run_pipeline for live stage telemetry
        on_hold: Callback(next_cycle_ts) when a pacing hold begins, and
                 Callback(None) when it ends — lets the caller surface the wait

    Returns:
        WorkerResult with cycle counts and any errors
    """
    if cycle_config is None:
        cycle_config = CycleConfig()

    export_dir = Path(export_dir)
    export_dir.mkdir(parents=True, exist_ok=True)

    result = WorkerResult()

    # Check for interrupted cycle
    interrupted = db.get_interrupted_cycle()
    if interrupted and cycle_config.auto_resume:
        print(f"  Resuming interrupted cycle {interrupted['id']}...", flush=True)
        _resume_cycle(db, interrupted, template, infer_fn, data_paths,
                      export_dir, result,
                      default_max_tokens=default_max_tokens,
                      on_cycle_start=on_cycle_start,
                      on_progress=on_progress,
                      infer_fns=infer_fns)

    # ── Main paced loop ──────────────────────────────────────
    mode = (cycle_config.pacing_mode or "on_demand").lower()
    interval = max(1, cycle_config.interval_seconds) if mode == "timed" else 0
    max_cycles = cycle_config.max_cycles
    cycle_number = db.next_cycle_number()
    anchor = time.time()          # schedule origin; shifts forward when paused
    consecutive_empty = 0         # consecutive skipped/missed cycles

    def _bus(k):
        """Scheduled start time for cycle index k, or None for on-demand."""
        if mode == "timed":
            return anchor + k * interval
        if mode == "scheduled":
            t = anchor
            for _ in range(k + 1):
                t = _next_scheduled(cycle_config.scheduled_time, t)
            return t
        return None

    def _record_empty(outcome):
        """Write a skipped/missed cycle row and update the alert state."""
        nonlocal consecutive_empty
        cid = db.create_cycle(cycle_number=cycle_number,
                              template_id=template.metadata.id,
                              config={"pacing": mode})
        db.update_cycle(cid, status=outcome, completed_at=time.time())
        consecutive_empty += 1
        result.alert = (cycle_config.alert_threshold > 0
                        and consecutive_empty >= cycle_config.alert_threshold)

    k = 0
    while True:
        if max_cycles > 0 and k >= max_cycles:
            break
        if cancel_event is not None and cancel_event.is_set():
            break

        # ── Pacing hold ──────────────────────────────────────
        bus = _bus(k)
        if bus is not None:
            # Cycle 0 defines the schedule anchor and always runs immediately;
            # only later slots can be forfeited by a previous cycle overrunning.
            if k > 0 and time.time() > bus:
                # A previous cycle overran this slot — it is forfeited.
                _record_empty("missed")
                result.cycles_missed += 1
                print(f"  Cycle {cycle_number}: missed slot ({mode}).", flush=True)
                cycle_number += 1
                k += 1
                continue
            waiting = bus > time.time()   # a real wait, not an instant pass
            if on_hold and waiting:
                on_hold(bus)              # report the wait so the UI can show it
            status, paused = _hold(bus, cancel_event, pause_event)
            if on_hold and waiting:
                on_hold(None)             # hold over (cycle starts, or cancelled)
            anchor += paused              # frozen time shifts the whole schedule
            if status == "cancelled":
                break

        # ── Data check ───────────────────────────────────────
        unconsumed = db.unconsumed_count()
        if unconsumed < max(1, cycle_config.trigger_threshold):
            if mode == "on_demand":
                # On-demand has no schedule to keep — stop when data runs out.
                break
            # Timed/scheduled keep the heartbeat: log a skipped cycle.
            _record_empty("skipped")
            result.cycles_skipped += 1
            print(f"  Cycle {cycle_number}: skipped — no data.", flush=True)
            cycle_number += 1
            k += 1
            continue

        # ── Run the cycle ────────────────────────────────────
        cycle_id = db.create_cycle(
            cycle_number=cycle_number,
            template_id=template.metadata.id,
            config={
                "model_id": cycle_config.model_id or template.model.id,
                "max_new_tokens": default_max_tokens,
                "temperature": template.model.temperature,
                "pacing": mode,
                # Run identity, fixed at the moment this cycle is created.
                "project_name": cycle_config.project_name,
                "user_name": cycle_config.user_name,
                "max_cycles": cycle_config.max_cycles,
                # Job-relative position: this is cycle (k+1) of this job.
                # Distinct from cycle_number, which is the lifetime counter
                # used by History — the Active Cycle panel must never show
                # that one.
                "run_index": k + 1,
            },
        )

        if on_cycle_start:
            on_cycle_start(cycle_id, cycle_number)

        # Snapshot data: claim this cycle's windowed inbox rows. The records
        # the model actually reasons over now come from the ledger (windowed
        # inbox ∪ reference), grouped by source — not from a directory glob.
        snap_count, _ = snapshot_data(db, cycle_id)
        records_by_source = _records_by_source(db, cycle_id, template)
        db.update_cycle(cycle_id, status="inferring",
                        infer_started=time.time())
        energy = get_meter().start()

        print(f"  Cycle {cycle_number} ({cycle_id}): "
              f"{snap_count} records snapshotted", flush=True)

        # Run the pipeline. Each stage is persisted the instant it finishes
        # (on_stage_complete) so a crash mid-cycle never loses a completed
        # stage — recovery resumes from the first unfinished one.
        def _save_stage(sr):
            db.save_stage(
                cycle_id=cycle_id,
                stage_index=sr.index,
                label=sr.label,
                thinking=sr.thinking,
                output_text=sr.output,
                input_tokens=sr.input_chars // 4,
                output_tokens=stage_token_count(sr),
                time_seconds=sr.time_seconds,
                status="failed" if sr.error else "complete",
                error=sr.error,
            )

        try:
            pipeline_result = run_pipeline(template, data_paths, infer_fn,
                                           default_max_tokens=default_max_tokens,
                                           on_progress=on_progress,
                                           on_stage_complete=_save_stage,
                                           records_by_source=records_by_source,
                                           infer_fns=infer_fns)

            # Write output. Token total is computed first so the receipt
            # carries the same number the cycle row is about to commit.
            total_tokens = sum(stage_token_count(sr) for sr in pipeline_result.stages)
            output_path = export_dir / f"cycle_{cycle_number:04d}_{cycle_id}.md"
            _write_receipt(db, cycle_id, template, pipeline_result, output_path,
                           total_tokens)

            # Update cycle
            e = energy.stop()
            db.update_cycle(
                cycle_id,
                status="complete",
                completed_at=time.time(),
                result_path=str(output_path),
                tokens_generated=total_tokens,
                energy_j=e["joules"],
                energy_method=e["method"],
            )
            # Cycle finished cleanly — its banked checkpoints are spent.
            db.clear_checkpoints(cycle_id)

            # Consume-on-success: retire the inbox files this cycle used.
            moved = _move_consumed_to_processed(db, cycle_id)
            if moved:
                print(f"  Cycle {cycle_number}: moved {moved} consumed "
                      f"file(s) to processed/", flush=True)

            result.cycles_completed += 1
            result.total_tokens += total_tokens
            consecutive_empty = 0       # a real cycle clears the empty streak

            _ecost = (f", {e['joules']:.0f} J via {e['method']}"
                      if e.get("joules") is not None else "")
            print(f"  Cycle {cycle_number} complete: "
                  f"{total_tokens} tokens → {output_path.name}{_ecost}",
                  flush=True)

            if on_cycle_end:
                on_cycle_end(cycle_id, cycle_number, pipeline_result)

        except Exception as e:
            # A genuine cycle failure. Operator interrupts (CancelledError /
            # PausedError) subclass BaseException and are NOT caught here —
            # they propagate out of run_worker to the queue worker, which
            # records the cycle as cancelled/paused and handles the queue.
            error_msg = str(e)
            db.update_cycle(cycle_id, status="failed", error=error_msg,
                            completed_at=time.time())
            result.cycles_failed += 1
            result.errors.append(f"Cycle {cycle_number}: {error_msg}")
            consecutive_empty = 0       # a cycle that ran is not an empty slot
            print(f"  Cycle {cycle_number} failed: {error_msg}", flush=True)

        result.alert = (cycle_config.alert_threshold > 0
                        and consecutive_empty >= cycle_config.alert_threshold)

        # Advance
        cycle_number += 1
        k += 1

    result.consecutive_empty = consecutive_empty
    return result


def _stage_uses_images(stage, template: Template) -> bool:
    """True if any of the stage's data sources is an image_file source."""
    return any(
        template.sources[n].adapter == "image_file"
        for n in (stage.input.get("sources") or [])
        if n in template.sources
    )


def _resume_cycle(db: Database, cycle: dict, template: Template,
                  infer_fn: Callable, data_paths: dict[str, str],
                  export_dir: Path, result: WorkerResult,
                  default_max_tokens: int = 2048,
                  on_cycle_start: Optional[Callable[[str, int], None]] = None,
                  on_progress: Optional[Callable] = None,
                  infer_fns: Optional[dict] = None):
    """Resume an interrupted cycle from its last banked checkpoint.

    Stages that finished before the interruption are reused from their
    persisted DB rows — not re-inferred. The stage that was in progress is
    continued from its latest token checkpoint by re-prefilling the pinned
    prompt plus the banked tokens. Stages after it run fresh. Recovery is
    driven entirely by durable DB state.
    """
    cycle_id = cycle["id"]
    cycle_number = cycle["cycle_number"]

    # Stamp live progress state to this resumed cycle so the dashboard's
    # telemetry attaches to it rather than showing a stale cycle.
    if on_cycle_start:
        on_cycle_start(cycle_id, cycle_number)

    completed = db.completed_stage_count(cycle_id)
    total_stages = len(template.stages)

    if completed >= total_stages:
        # Every stage finished before the interruption — only finalisation
        # is left.
        db.update_cycle(cycle_id, status="complete", completed_at=time.time())
        db.clear_checkpoints(cycle_id)
        result.cycles_completed += 1
        print(f"  Cycle {cycle_number}: all stages complete, finalized.", flush=True)
        return

    # Latest token checkpoint for the in-progress stage, if any was banked
    # before the interruption.
    cp = load_checkpoint(db, cycle_id, stage_index=completed)

    # Token-level resume is text-only. The checkpoint pins the PROMPT the
    # banked tokens were generated against, but not the image conditioning:
    # re-prefilling a vision stage from the pinned text embeds its
    # <|image_pad|> spans as ordinary tokens, rebuilding a KV that no longer
    # matches the banked tokens and silently corrupting the continuation.
    # Re-deriving the conditioning isn't guaranteed identical either (the
    # reference-image scope is the CURRENT set — see db.cycle_image_names).
    # So a vision stage discards its banked tokens and re-runs from the
    # stage boundary, with images re-fetched; completed stages are still
    # reused. Correct and loud beats resumed and wrong.
    if cp and _stage_uses_images(template.stages[completed], template):
        print(f"  Cycle {cycle_number}: stage {completed} uses image sources — "
              f"discarding {len(cp.tokens)} banked token(s); token-level "
              f"resume cannot restore image conditioning. Re-running the "
              f"stage from its boundary.", flush=True)
        cp = None

    completed_rows = [r for r in db.get_stages(cycle_id)
                      if r["status"] == "complete"]
    resume = {
        "completed": completed_rows,
        "stage_index": completed,
        "resume_tokens": cp.tokens if cp else None,
        "prompt": cp.prompt if cp else None,
        "rng_state": cp.rng_state if cp else None,
        # Active compute time already banked for the in-progress stage. The
        # resumed stage's clock continues from here, so its final persisted
        # time_seconds covers the pre-crash work too — not just the part run
        # after recovery — and the dead gap is never counted.
        "active_seconds": cp.active_seconds if cp else 0.0,
    }

    banked = len(cp.tokens) if cp else 0
    print(f"  Cycle {cycle_number}: {completed}/{total_stages} stages done; "
          f"resuming stage {completed} from {banked} banked token(s).", flush=True)

    def _save_stage(sr):
        db.save_stage(
            cycle_id=cycle_id,
            stage_index=sr.index,
            label=sr.label,
            thinking=sr.thinking,
            output_text=sr.output,
            input_tokens=sr.input_chars // 4,
            output_tokens=stage_token_count(sr),
            time_seconds=sr.time_seconds,
            status="failed" if sr.error else "complete",
            error=sr.error,
        )

    try:
        # run_pipeline reuses the completed stages and continues the rest;
        # on_stage_complete fires only for stages it actually runs, so the
        # already-persisted stages are not written twice.
        # Records were claimed under this cycle_id before the interruption;
        # rebuild the same windowed scope (no new snapshot) so the resumed
        # run reasons over exactly the data the original cycle did.
        records_by_source = _records_by_source(db, cycle_id, template)
        energy = get_meter().start()
        pipeline_result = run_pipeline(template, data_paths, infer_fn,
                                       default_max_tokens=default_max_tokens,
                                       on_progress=on_progress,
                                       on_stage_complete=_save_stage,
                                       resume=resume,
                                       records_by_source=records_by_source,
                                       infer_fns=infer_fns)

        total_tokens = sum(stage_token_count(sr) for sr in pipeline_result.stages)
        output_path = export_dir / f"cycle_{cycle_number:04d}_{cycle_id}.md"
        _write_receipt(db, cycle_id, template, pipeline_result, output_path,
                       total_tokens)

        # Energy covers the resumed portion only — the pre-crash joules
        # died unrecorded with the process. Honest partial beats invented total.
        e = energy.stop()
        db.update_cycle(
            cycle_id, status="complete", completed_at=time.time(),
            result_path=str(output_path), tokens_generated=total_tokens,
            energy_j=e["joules"], energy_method=e["method"],
        )
        db.clear_checkpoints(cycle_id)
        _move_consumed_to_processed(db, cycle_id)

        result.cycles_completed += 1
        result.total_tokens += total_tokens
        print(f"  Cycle {cycle_number} resumed and completed.", flush=True)

    except Exception as e:
        # Operator interrupts (CancelledError / PausedError) subclass
        # BaseException and are not caught here — they propagate to the
        # queue worker, which leaves the cycle interrupted so the next
        # recovery picks it up again.
        db.update_cycle(cycle_id, status="failed", error=str(e),
                        completed_at=time.time())
        result.cycles_failed += 1
        result.errors.append(f"Resume cycle {cycle_number}: {e}")


def recover_interrupted(db: Database, template: Template, infer_fn: Callable,
                        data_paths: dict[str, str], export_dir: str | Path,
                        default_max_tokens: int,
                        on_cycle_start: Optional[Callable] = None,
                        on_progress: Optional[Callable] = None,
                        infer_fns: Optional[dict] = None) -> WorkerResult:
    """Resume a single interrupted cycle, if one exists. Runs no new cycles.

    Recovery is driven by durable DB state — a cycle left 'inferring' (a
    crash) or 'paused' is found and resumed from its last banked checkpoint.
    Safe to call on every startup: if there is nothing to recover it is a
    no-op, and if the process dies again mid-recovery the cycle is still
    interrupted, so the next startup recovers it once more.
    """
    result = WorkerResult()
    interrupted = db.get_interrupted_cycle()
    if interrupted:
        export_dir = Path(export_dir)
        export_dir.mkdir(parents=True, exist_ok=True)
        _resume_cycle(db, interrupted, template, infer_fn, data_paths,
                      export_dir, result,
                      default_max_tokens=default_max_tokens,
                      on_cycle_start=on_cycle_start, on_progress=on_progress,
                      infer_fns=infer_fns)
    return result
