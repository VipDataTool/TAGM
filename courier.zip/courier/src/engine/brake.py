"""Dynamic CPU brake — a utilization setpoint for the inter-layer rest.

The operator-facing **Max CPU (%)** dial is a target the per-layer rest is
sized to hold. Below the target the brake yields nothing (full speed); as the
process presses against the ceiling, timed rests appear between layers and grow
— bleeding off sustained load so the box and the always-on collector stay
responsive. One mechanism, one number: the existing fixed rest, given a target.

Control law is borrowed from cpulimit (opsengine/cpulimit): an EMA-smoothed
utilization measurement feeding a multiplicative duty-cycle update, here
converted to a per-layer sleep sized by the layer's own compute time. The
closed loop self-calibrates the wall-time-duty <-> capacity-fraction mapping
via feedback, so the multi-core relationship need not be modelled explicitly.

`CpuBrake` is a pure controller (measurement injected) — cold-probe testable
with synthetic load sequences, no torch, no weights. `process_load_frac()` is
the psutil reader that sits at the edge and feeds it live.

See courier-throttle-design-spec.md §5.
"""

from __future__ import annotations

import os
from typing import Optional


class CpuBrake:
    """Closed-loop controller that sizes an inter-layer rest to a setpoint."""

    def __init__(self, target_frac: float, alpha: float = 0.1,
                 floor: float = 0.05):
        """
        Args:
            target_frac: Target utilization as a fraction of *total* machine
                capacity (0..1). <= 0 or >= 1 disables the brake (zero rest).
            alpha: EMA weight for the measurement (smaller = smoother/slower).
            floor: Minimum working-rate, so the duty cannot collapse to zero
                when the target is briefly unreachable (anti-windup clamp).
        """
        self.target = float(target_frac)
        self.alpha = float(alpha)
        self.floor = float(floor)
        # Working rate (active duty fraction), seeded at full speed (1.0): the
        # brake only engages when the process is measured *above* target. A
        # workload already under the setpoint keeps working-rate pinned at 1.0
        # and never rests — "below the target, full speed." Carried across
        # calls; this is the integral-style memory of the loop.
        self.workingrate = 1.0
        self.ema: Optional[float] = None

    @property
    def _enabled(self) -> bool:
        return 0.0 < self.target < 1.0

    def update(self, compute_s: float, measured_frac: Optional[float]) -> float:
        """Return the rest (seconds) to sleep after a layer that took compute_s.

        Args:
            compute_s: Wall time the just-finished layer's compute took.
            measured_frac: Process CPU usage as a fraction of total capacity
                (0..1), or None when no reading is available yet (first layer).

        Returns:
            Rest duration in seconds (>= 0). Zero when disabled or unmeasured.
        """
        if not self._enabled:
            return 0.0
        if measured_frac is None:
            return 0.0
        # EMA-smooth the measurement to take the noise out of short windows.
        if self.ema is None:
            self.ema = measured_frac
        else:
            self.ema = (1.0 - self.alpha) * self.ema + self.alpha * measured_frac
        m = max(self.ema, 1e-6)
        # cpulimit multiplicative law: above target shrinks the active slice,
        # below grows it; clamped to [floor, 1].
        self.workingrate = min(self.workingrate / m * self.target, 1.0)
        self.workingrate = max(self.workingrate, self.floor)
        # Duty -> rest. Compute occupied `compute_s`; to make that a
        # `workingrate` fraction of the whole compute+rest cycle, rest for the
        # remainder.
        if compute_s <= 0:
            return 0.0
        return compute_s * (1.0 / self.workingrate - 1.0)


# ── Live measurement (edge; not on the cold-probe path) ──────────

_PROC = None
_NCPU = None


def process_load_frac() -> Optional[float]:
    """This process's CPU usage as a fraction of total machine capacity (0..1).

    Non-blocking: compares against the previous call. Returns None on the very
    first call (psutil's priming 0.0 is meaningless and is discarded), so the
    first layer never rests on noise.
    """
    global _PROC, _NCPU
    import psutil
    if _PROC is None:
        _PROC = psutil.Process(os.getpid())
        _NCPU = psutil.cpu_count() or 1
        _PROC.cpu_percent(None)  # prime; first reading discarded
        return None
    pct = _PROC.cpu_percent(None)        # 0 .. NCPU*100, since last call
    return pct / (100.0 * _NCPU)         # -> 0..1 of total capacity
