"""Engine phase profiler — the `test_vision_smoke` of performance (handoff §6
Step 0). Answers the question the project has been ASSERTING but never measured:
of a ~30-minute image cycle, how much is disk-read (layer streaming) vs matmul
compute vs per-token decode vs ViT vision-encode? The profile dictates which
optimization actually pays off; optimizing the wrong phase is how you spend a
week for 5%.

Design constraints:
  * ZERO measurable overhead when OFF. The decode loop hits these markers tens
    of thousands of times (32 layers x hundreds of tokens), and the binding
    constraint is the target CPU at RUNTIME (profiler off). When disabled,
    `phase()` returns a shared no-op in a couple of attribute lookups; nothing
    is timed, locked, or allocated.
  * EXCLUSIVE time per bucket. Phases use a stack: a phase's time excludes any
    nested phase, so buckets never double-count and sum to ~wall. (Leaf markers
    here don't nest today, but the stack makes the tool safe to extend.)
  * It only MEASURES. It never changes what the engine computes — so turning it
    on cannot change a single output token. That is the non-negotiable in §6.

Enable via env var (no code change): COURIER_PROFILE=1, or call enable().
Read results with snapshot()/report(). The profiler script drives all this.
"""
import os
import threading
import time


class _Profiler:
    def __init__(self):
        self._enabled = os.environ.get("COURIER_PROFILE", "") not in ("", "0")
        self._lock = threading.Lock()
        self._excl = {}        # name -> exclusive seconds (minus nested)
        self._count = {}       # name -> entry count
        self._marks = {}       # name -> raw seconds (inclusive, e.g. wall_*)
        self._stack = []       # [(name, start, child_accum)] per thread? single
        self._t0 = None        # wall-clock anchor for the whole profiled run

    # ── control ──────────────────────────────────────────────────────────
    @property
    def enabled(self):
        return self._enabled

    def enable(self):
        self._enabled = True

    def disable(self):
        self._enabled = False

    def reset(self):
        with self._lock:
            self._excl.clear()
            self._count.clear()
            self._marks.clear()
            self._stack.clear()
            self._t0 = time.perf_counter()

    # ── measurement ──────────────────────────────────────────────────────
    def phase(self, name):
        """Context manager timing exclusive wall-time under `name`.

        No-op (and allocation-free) when disabled.
        """
        if not self._enabled:
            return _NOOP
        return _Phase(self, name)

    def mark(self, name, seconds):
        """Add raw inclusive seconds to a named counter (e.g. wall_prefill)."""
        if not self._enabled:
            return
        with self._lock:
            self._marks[name] = self._marks.get(name, 0.0) + seconds

    # ── internal, called by _Phase ──────────────────────────────────────
    def _enter(self):
        # push (name resolved by caller); track child time for the parent
        self._stack.append(0.0)  # accumulator for THIS phase's children

    def _exit(self, name, elapsed):
        # elapsed includes children; subtract child time already popped
        child = self._stack.pop()
        exclusive = elapsed - child
        if self._stack:
            self._stack[-1] += elapsed   # this phase counts as child of parent
        with self._lock:
            self._excl[name] = self._excl.get(name, 0.0) + exclusive
            self._count[name] = self._count.get(name, 0) + 1

    # ── readout ──────────────────────────────────────────────────────────
    def snapshot(self):
        with self._lock:
            wall = (time.perf_counter() - self._t0) if self._t0 else None
            return {
                "wall_total": wall,
                "exclusive": dict(self._excl),
                "counts": dict(self._count),
                "marks": dict(self._marks),
            }

    def report(self):
        snap = self.snapshot()
        excl = snap["exclusive"]
        marks = snap["marks"]
        counts = snap["counts"]
        measured = sum(excl.values())
        wall = snap["wall_total"] or measured
        lines = []
        lines.append("=" * 68)
        lines.append("ENGINE PHASE PROFILE")
        lines.append("=" * 68)
        lines.append(f"{'phase':<22}{'seconds':>12}{'% wall':>10}{'calls':>12}")
        lines.append("-" * 68)
        order = sorted(excl, key=excl.get, reverse=True)
        for name in order:
            sec = excl[name]
            pct = (100.0 * sec / wall) if wall else 0.0
            lines.append(f"{name:<22}{sec:>12.2f}{pct:>9.1f}%{counts.get(name, 0):>12,}")
        unattributed = wall - measured
        if wall:
            lines.append(f"{'(unattributed)':<22}{unattributed:>12.2f}"
                         f"{100.0*unattributed/wall:>9.1f}%{'':>12}")
        lines.append("-" * 68)
        lines.append(f"{'WALL TOTAL':<22}{wall:>12.2f}{'100.0%':>10}")
        if marks:
            lines.append("")
            lines.append("phase split (inclusive wall, may overlap the above):")
            for name in sorted(marks, key=marks.get, reverse=True):
                sec = marks[name]
                pct = (100.0 * sec / wall) if wall else 0.0
                lines.append(f"  {name:<20}{sec:>12.2f}{pct:>9.1f}%")
        lines.append("=" * 68)
        return "\n".join(lines)


class _Phase:
    __slots__ = ("prof", "name", "start")

    def __init__(self, prof, name):
        self.prof = prof
        self.name = name

    def __enter__(self):
        self.prof._enter()
        self.start = time.perf_counter()
        return self

    def __exit__(self, *exc):
        elapsed = time.perf_counter() - self.start
        self.prof._exit(self.name, elapsed)
        return False


class _Noop:
    __slots__ = ()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


_NOOP = _Noop()

# Process-wide singleton. Import and use PROFILER.phase(...) at hot boundaries.
PROFILER = _Profiler()
