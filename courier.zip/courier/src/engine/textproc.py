"""Torch-free text mechanics for the inference layer.

Prompt scaffolding and output cleanup live here — separated from
engine.inference (which imports torch transitively via the adapter
registry) so cold probes can exercise every rule without a model.

The rules encode three receipt-integrity guarantees:

1. **No-think priming** (`nothink_primer`): with thinking disabled, the
   assistant turn opens with an empty think pair — the Qwen3-family
   convention — so the model spends ZERO generated tokens emitting
   `<think></think>` scaffolding itself. Before this, a 32-token stage
   lost ~5 tokens to scaffolding the receipt then displayed as output.

2. **Think cleanup** (`clean_think_blocks`): empty think pairs are pure
   noise and are stripped ALWAYS (even in thinking mode). A closed think
   block is stripped whenever thinking is off — regardless of truncation:
   the old `not hit_cap` guard existed to protect UNCLOSED blocks but
   caught closed ones too, which is how truncated receipts came to
   display `<think></think>` junk. Unclosed blocks are left alone (they
   cannot be stripped without eating the visible answer).

3. **Marker cleanup** (`strip_chat_markers`): raw decode keeps special
   tokens (skip_special_tokens=True eats think-block content on Qwen3.5),
   so chat-template markers are removed by regex afterwards.
"""
import re

# Chat template constants (ChatML / Qwen family).
IM_START = "<|im_start|>"
IM_END = "<|im_end|>"

# The Qwen3-family "thinking off" priming: an already-closed think block
# opening the assistant turn tells the model the thought is over.
NOTHINK_PRIMER = "<think>\n\n</think>\n\n"

_CHAT_MARKERS = re.compile(
    r'<\|im_start\|>(?:system|user|assistant)?\n?|<\|im_end\|>|<\|endoftext\|>'
)
_EMPTY_THINK = re.compile(r"<think>\s*</think>\s*")
_FULL_THINK = re.compile(r"<think>.*?</think>\s*", re.DOTALL)


def nothink_primer(thinking: bool) -> str:
    """Assistant-turn suffix for the requested thinking mode."""
    return "" if thinking else NOTHINK_PRIMER


def strip_chat_markers(text: str) -> str:
    """Remove chat-template markers left by raw (non-skipping) decode."""
    return _CHAT_MARKERS.sub("", text).strip()


def clean_think_blocks(text: str, thinking: bool) -> str:
    """Apply the think-block display rules (see module docstring).

    Safe by construction: a full-block strip that would leave nothing
    keeps the original text instead — better to show a model's odd output
    than to blank a receipt.
    """
    out = _EMPTY_THINK.sub("", text).lstrip()
    if not thinking and "<think>" in out and "</think>" in out:
        cleaned = _FULL_THINK.sub("", out).strip()
        if cleaned:
            out = cleaned
    return out


def truncation_notice(max_new_tokens: int) -> str:
    """The receipt's truncation banner. Appended AFTER token accounting —
    the banner is the UI talking, and must never count as model output."""
    return (f"\n\n[⚠ Truncated: generation hit the {max_new_tokens}-token "
            f"limit before completing. Raise max_new_tokens for this stage.]")
