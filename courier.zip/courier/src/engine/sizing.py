"""Resident-RAM budget sizing.

Pure functions translating the operator-facing **Max RAM (%)** dial into a
byte cap for the shard manager's resident cache. The percentage is of *total*
system RAM (a fixed, reproducible policy) and is floored so a hard reserve of
real RAM always remains for the OS and the always-on collector — "90%" can
never strand the box into swapping (which on this system means thrashing the
SSD the design exists to protect).

No torch, no psutil here — total RAM is injected by the caller (build_engine
reads it once via psutil). That keeps this math cold-probe testable.

See courier-throttle-design-spec.md §4.
"""

from __future__ import annotations


def resident_budget_bytes(
    total_ram_bytes: int,
    max_ram_percent: float,
    reserve_bytes: int,
) -> int:
    """Bytes the resident weight cache may use.

    Args:
        total_ram_bytes: Total system RAM (the fixed denominator).
        max_ram_percent: Operator dial. <= 0 means "off" — caller keeps the
            streaming default and must NOT enable resident mode.
        reserve_bytes: Hard floor of RAM left for OS + collector.

    Returns:
        A byte cap >= 0. A return of 0 means "do not enable a resident cap":
        either the dial is off, or the reserve floor consumed the whole
        percentage. The caller MUST treat 0 as "stream" and never pass it to
        the shard manager as a cap, because there 0 means *unlimited*.
    """
    if max_ram_percent <= 0:
        return 0
    budget = total_ram_bytes * (max_ram_percent / 100.0)
    # Floor: never let inference claim into the OS/collector reserve.
    budget = min(budget, total_ram_bytes - reserve_bytes)
    return max(int(budget), 0)


def layers_that_fit(
    budget_bytes: int,
    per_layer_bytes: int,
    n_layers: int,
) -> int:
    """How many resident layers a budget buys — telemetry only.

    Enforcement is the byte cap inside the shard manager (it caches layers
    until the cap is hit, then streams the rest); this is purely for showing
    the operator the consequence of their setting. Not on the hot path.
    """
    if budget_bytes <= 0 or per_layer_bytes <= 0:
        return 0
    return min(budget_bytes // per_layer_bytes, n_layers)


# Smallest resident weight cap the streaming *verifier* (primary) may be left
# with before admission refuses the pair outright. Below this the primary would
# thrash the SSD layer-by-layer instead of streaming usefully — the failure the
# multimodel spec (§5) says to refuse rather than degrade into.
#
# PROVISIONAL — one of the spec's explicitly-open constants. The right value is
# hardware-dependent (a function of per-layer byte size and how many resident
# layers keep the streaming verifier off the thrash floor) and MUST be
# re-measured on the target rig with layers_that_fit(). 512 MiB is a cautious
# placeholder, not a measured number.
DEFAULT_PRIMARY_MIN_CAP = 512 * 1024 ** 2


def partition_resident_budget(
    total_ram_bytes: int,
    max_ram_percent: float,
    reserve_bytes: int,
    secondary_footprint_bytes: int,
    primary_kv_headroom_bytes: int = 0,
    secondary_kv_headroom_bytes: int = 0,
    primary_min_cap: int = DEFAULT_PRIMARY_MIN_CAP,
) -> dict | None:
    """Split one resident-RAM budget into non-overlapping caps for two engines.

    The single budget authority over a two-engine rig (a streaming *primary*
    verifier plus a fully-resident *secondary* — the speculative-decoding draft,
    or a second routing engine). Gates Channels A and B whenever a second engine
    is resident (multimodel spec §5). Cold and pure: RAM is injected, no torch,
    no psutil — so it verifies without weights, like resident_budget_bytes.

    Policy:
      - One budget for the whole box, via resident_budget_bytes() — the SAME
        authority the single-engine path uses, so the two never disagree.
      - The secondary is pinned at its FULL weight size: it lives entirely in
        RAM, never streams, and is immune to the primary's cache churn (the two
        shard managers hold independent caches — §4). Its cap is its footprint.
      - Whatever remains, minus KV headroom for both engines, is the primary's
        resident cap. In the streaming regime that cap *is* the verifier's
        per-token disk-read volume, so this number sets both fit and speed (§5).

    Admission REFUSES (returns None) rather than degrading into thrash when:
      - the budget is off or the reserve floor ate it whole (budget <= 0 —
        covers the "Max RAM dial off" case, since resident_budget_bytes returns
        0 there);
      - the secondary plus its KV headroom leaves no room (oversized draft); or
      - the primary's resulting cap would fall below ``primary_min_cap``.

    Returns:
        ``{"secondary_cap": int, "primary_cap": int}`` with non-overlapping caps
        that, with both KV-headroom reservations, sum to at most the budget — or
        ``None`` if the pair is refused.

    Caller contract (NOT this pure function's job): hand ``primary_cap`` to the
    primary engine's resident cap and derive any GGUF ``cache_budget_mb`` from
    the SAME number — never let resident_max_bytes and cache_budget_mb both
    claim budget independently, or RAM is double-counted (§4/§10). The math is in
    bf16 terms; cache-quantization is a separate, deferred trade.
    """
    for label, val in (
        ("total_ram_bytes", total_ram_bytes),
        ("reserve_bytes", reserve_bytes),
        ("secondary_footprint_bytes", secondary_footprint_bytes),
        ("primary_kv_headroom_bytes", primary_kv_headroom_bytes),
        ("secondary_kv_headroom_bytes", secondary_kv_headroom_bytes),
        ("primary_min_cap", primary_min_cap),
    ):
        if val < 0:
            raise ValueError(f"{label} must be non-negative, got {val}")

    budget = resident_budget_bytes(total_ram_bytes, max_ram_percent, reserve_bytes)
    if budget <= 0:
        return None  # dial off, or reserve consumed the whole percentage

    secondary_cap = int(secondary_footprint_bytes)
    if secondary_cap + secondary_kv_headroom_bytes >= budget:
        return None  # oversized secondary / no room for the draft

    primary_cap = (
        budget - secondary_cap
        - primary_kv_headroom_bytes - secondary_kv_headroom_bytes
    )
    if primary_cap < primary_min_cap:
        return None  # primary would be starved into thrash — refuse, don't degrade

    return {"secondary_cap": int(secondary_cap), "primary_cap": int(primary_cap)}
