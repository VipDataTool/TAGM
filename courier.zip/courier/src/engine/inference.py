"""Integration layer: connects the inference engine to the pipeline.

Creates a callable infer_fn that the pipeline can use. Handles:
- Chat template formatting via tokenizer.apply_chat_template
  (model-family aware: Qwen3 vs Qwen3.5 differences handled automatically)
- Thinking mode control via enable_thinking parameter
- Multimodal prompt formatting with vision token placeholders
- Tokenization and decoding
- Truncation detection and warnings

For multimodal models, the infer_fn accepts an optional 'image_paths'
kwarg containing paths to images. These are preprocessed and passed
to the hybrid streamer for vision encoding during prefill.
"""

import os
from typing import Optional

from core.adapter.registry import detect_adapter
from core.shard_manager import ShardManager
from engine.textproc import (IM_START, IM_END, nothink_primer,
                             strip_chat_markers, clean_think_blocks,
                             truncation_notice)


def format_prompt(system_prompt: str, user_content: str, thinking: bool = False) -> str:
    """Format a prompt using plain ChatML template.

    Used as a fallback when the tokenizer does not support
    apply_chat_template with enable_thinking.

    Args:
        system_prompt: The system instruction
        user_content: The user's data/question
        thinking: When False, the assistant turn is primed with an empty
            think pair (the Qwen3-family convention) so the model spends
            zero generated tokens emitting scaffolding.

    Returns:
        Formatted prompt string ready for tokenization
    """
    return (
        f"{IM_START}system\n{system_prompt}{IM_END}\n"
        f"{IM_START}user\n{user_content}{IM_END}\n"
        f"{IM_START}assistant\n{nothink_primer(thinking)}"
    )


def format_multimodal_prompt(
    system_prompt: str,
    user_content: str,
    num_images: int = 0,
    image_token_counts: Optional[list] = None,
    thinking: bool = False,
) -> str:
    """Format a multimodal prompt with image placeholders.

    For Qwen3.5, each image is represented in the chat template as:
        <|vision_start|><|image_pad|>...<|image_pad|><|vision_end|>

    The number of <|image_pad|> tokens for an image MUST equal the number of
    vision tokens its encoder produces ((t·h·w)/merge²), because the engine
    replaces each placeholder position with one vision embedding. A single
    placeholder (the old behaviour) injects only the first vision token and
    leaves the image effectively unseen. image_token_counts[i] gives that count
    per image; when omitted it falls back to 1 (text-equivalent placeholder).

    Args:
        system_prompt: The system instruction
        user_content: The user's data/question
        num_images: Number of images to include
        image_token_counts: Per-image vision-token counts (len == num_images)
        thinking: When False, the assistant turn is primed with an empty
            think pair so no generated tokens are spent on scaffolding

    Returns:
        Formatted prompt with the right number of vision placeholders
    """
    parts = []
    parts.append(f"{IM_START}system\n{system_prompt}{IM_END}\n")
    parts.append(f"{IM_START}user\n")

    for i in range(num_images):
        n = 1
        if image_token_counts and i < len(image_token_counts):
            n = max(1, int(image_token_counts[i]))
        parts.append("<|vision_start|>" + ("<|image_pad|>" * n) + "<|vision_end|>\n")

    parts.append(f"{user_content}{IM_END}\n")
    parts.append(f"{IM_START}assistant\n" + nothink_primer(thinking))

    return "".join(parts)


def make_infer_fn(
    streamer,
    default_temperature: float,
    default_top_p: float,
    default_max_tokens: int,
    default_presence_penalty: float = 0.0,  # matches FACTORY_DEFAULTS; real value comes from cfg
    default_top_k: int = 20,                 # matches FACTORY_DEFAULTS / sampler / generate()
    default_enable_thinking: bool = False,
    default_max_images: int = 8,
    draft_streamer=None,
    speculative_block_k: int = 4,
):
    """Create a pipeline-compatible inference function.

    Returns a callable: (prompt_text, **kwargs) ->
        (response_text, generated_token_count)
    (The pipeline also accepts a bare response_text for stubs.)

    The prompt_text comes from the pipeline as:
        "{system_prompt}\\n\\n---\\n\\n{input_text}"

    This wrapper splits it on the --- separator, formats it using the
    model's chat template, runs inference, and returns the decoded text.

    Kwargs accepted:
        thinking (bool): override enable_thinking for this call
        temperature (float): override default temperature
        top_p (float): override default top_p
        top_k (int): override default top_k
        presence_penalty (float): override default presence penalty
        max_new_tokens (int): override default max tokens
        image_paths (list[str]): paths to images for multimodal input

    Speculative decoding (Channel B, spec §7) is OPT-IN: when
    ``draft_streamer`` is None (the default) this behaves exactly as the
    single-model build. When a draft engine is supplied, eligible
    text-only greedy calls route through speculative_generate; every
    other call (multimodal, resumed, or with a draft absent) falls back
    to the unchanged ``streamer.generate`` path.
    """
    is_multimodal = hasattr(streamer, 'vision_encoder') and streamer.adapter.is_multimodal
    tokenizer = streamer.adapter.tokenizer

    def infer(prompt: str, **kwargs) -> str:
        # Per-stage thinking override; falls back to system default
        thinking = kwargs.get("thinking", default_enable_thinking)
        temperature = kwargs.get("temperature", default_temperature)
        top_p = kwargs.get("top_p", default_top_p)
        top_k = kwargs.get("top_k", default_top_k)  # config-backed default, per-call overridable
        presence_penalty = kwargs.get("presence_penalty", default_presence_penalty)
        max_new_tokens = kwargs.get("max_new_tokens", default_max_tokens)
        image_paths = kwargs.get("image_paths", [])
        max_images = int(kwargs.get("max_images", default_max_images))
        max_pixels = kwargs.get("max_pixels", None)  # vision resolution budget

        # Split pipeline prompt into system and user parts
        if "\n\n---\n\n" in prompt:
            system_prompt, user_content = prompt.split("\n\n---\n\n", 1)
        else:
            system_prompt = "You are a helpful analyst."
            user_content = prompt

        # Format prompt — use tokenizer.apply_chat_template for text-only
        # (handles enable_thinking correctly per model family), fall back
        # to manual formatting for multimodal with image placeholders.
        # Prepare image(s) and format prompt. Each image is encoded separately
        # by the ViT, all their vision tokens are concatenated into one
        # sequence, and each image gets its own <|image_pad|> span sized to its
        # token count — so the model sees the whole set in a single inference
        # and can reason across images. The number of images is capped
        # (max_images_per_cycle) so an accidental folder of thousands of photos
        # can't launch a multi-day run.
        prepared_images = []  # list of (pixel_values, grid_thw)
        if is_multimodal and image_paths:
            from engine.vision import preprocess_image
            merge = streamer.vision_encoder.vision_cfg.spatial_merge_size
            chosen = image_paths[:max_images]
            if len(image_paths) > max_images:
                print(f"  [vision] {len(image_paths)} images provided; capping at "
                      f"max_images_per_cycle={max_images} "
                      f"(dropping {len(image_paths) - max_images}).", flush=True)
            counts = []
            for ip in chosen:
                if max_pixels is not None:
                    pv, gt = preprocess_image(str(ip), max_pixels=int(max_pixels),
                                              merge_size=merge)
                else:
                    pv, gt = preprocess_image(str(ip), merge_size=merge)
                t, h, w = int(gt[0][0]), int(gt[0][1]), int(gt[0][2])
                counts.append(t * (h // merge) * (w // merge))
                prepared_images.append((pv, gt))
            formatted = format_multimodal_prompt(
                system_prompt, user_content,
                num_images=len(chosen),
                image_token_counts=counts,
                thinking=thinking,
            )
        else:
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_content},
            ]
            try:
                formatted = tokenizer.apply_chat_template(
                    messages,
                    tokenize=False,
                    add_generation_prompt=True,
                    enable_thinking=thinking,
                )
            except TypeError:
                # Tokenizer doesn't support enable_thinking kwarg —
                # fall back to plain ChatML
                formatted = format_prompt(system_prompt, user_content, thinking)

        # Vision data for multimodal models (reuse the images prepared above).
        pixel_values = None
        grid_thw = None
        if prepared_images:
            pixel_values = [pv for pv, _ in prepared_images]
            grid_thw = [gt for _, gt in prepared_images]

        # Build generate kwargs
        gen_kwargs = dict(
            prompt=formatted,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            top_p=top_p,
            top_k=int(top_k),
            presence_penalty=presence_penalty,
            on_token=kwargs.get("on_token"),
            on_checkpoint=kwargs.get("on_checkpoint"),
            cancel_check=kwargs.get("cancel_check"),
            resume_tokens=kwargs.get("resume_tokens"),
            resume_rng=kwargs.get("resume_rng"),
        )

        # Add vision data for multimodal models
        if pixel_values is not None:
            gen_kwargs["pixel_values"] = pixel_values
            gen_kwargs["grid_thw"] = grid_thw

        # Speculative decode (Channel B) is taken whenever a draft engine is
        # configured for a plain text, non-resumed call. It runs at the SAME
        # sampling settings as the plain decode (passed through below) — it does
        # not pick or override the temperature. Multimodal / resumed / draft-
        # absent calls use the original path untouched.
        use_speculative = (
            draft_streamer is not None
            and pixel_values is None
            and kwargs.get("resume_tokens") is None
        )
        if use_speculative:
            from engine.speculative import speculative_generate
            tokens = speculative_generate(
                verifier=streamer,
                draft=draft_streamer,
                prompt=formatted,
                max_new_tokens=max_new_tokens,
                block_k=speculative_block_k,
                temperature=temperature,
                top_p=top_p,
                top_k=int(top_k),
                presence_penalty=presence_penalty,
                stop_tokens=getattr(streamer.config, "eos_token_id", None),
                on_token=kwargs.get("on_token"),
                on_checkpoint=kwargs.get("on_checkpoint"),
                cancel_check=kwargs.get("cancel_check"),
            )
        else:
            tokens = streamer.generate(**gen_kwargs)

        # Detect truncation: ran full budget without hitting an EOS token
        eos = set(getattr(streamer.config, "eos_token_id", []) or [])
        hit_cap = len(tokens) >= max_new_tokens and (not tokens or tokens[-1] not in eos)

        # Decode — use raw decode with manual chat-marker cleanup.
        # skip_special_tokens=True strips too aggressively on Qwen3.5,
        # eating think-block content. Raw decode + regex is more reliable.
        # Cleanup rules live in engine.textproc (torch-free, cold-probed):
        # empty think pairs always stripped; closed blocks stripped when
        # thinking is off REGARDLESS of truncation (the old hit_cap guard
        # protected unclosed blocks but caught closed ones — truncated
        # receipts displayed the junk); unclosed blocks left intact.
        raw_text = streamer.adapter.tokenizer.decode(tokens, skip_special_tokens=False)
        text = clean_think_blocks(strip_chat_markers(raw_text), thinking)

        # Truncation warning — the banner is the UI talking, appended after
        # cleanup and never part of the token count returned below.
        unclosed_think = "<think>" in text and "</think>" not in text
        if hit_cap or unclosed_think:
            text += truncation_notice(max_new_tokens)

        # Return (text, generated_token_count): the pipeline records the
        # REAL count. The old str-only contract forced downstream to
        # estimate len(text)//4 — counting think scaffolding and the
        # truncation banner as model output ("66 tokens" on a 32-token
        # stage). The pipeline accepts both shapes.
        return text, len(tokens)

    return infer


def _gemm_seconds(torch_dtype, n: int = 1024, reps: int = 3) -> float:
    """Median wall time of one (n, n) @ (n, n) GEMM at the given dtype.

    Sized to finish in well under a second per candidate on a slow
    dual-core while still being large enough that kernel dispatch —
    native vs emulated bf16 — dominates the measurement. One warmup rep
    absorbs allocator and thread-pool spin-up.
    """
    import statistics
    import time

    import torch

    a = torch.randn(n, n, dtype=torch.float32).to(torch_dtype)
    b = torch.randn(n, n, dtype=torch.float32).to(torch_dtype)
    _ = a @ b  # warmup
    times = []
    for _i in range(reps):
        t0 = time.perf_counter()
        _ = a @ b
        times.append(time.perf_counter() - t0)
    return statistics.median(times)


def resolve_dtype(requested: str, dtype_map: dict, bench=None) -> str:
    """Resolve a config dtype string, handling 'auto' by measurement.

    Explicit names ('bfloat16'/'float16'/'float32') pass through
    untouched — the default path is byte-identical to before this
    function existed. 'auto' benches bf16 vs fp32 on this box and
    returns the faster; ANY failure falls back to 'bfloat16' with a
    warning, never an exception (thread-sizing's guarded style).

    `bench` is injectable for the cold probe: (torch_dtype) -> seconds.
    """
    req = (requested or "").strip().lower()
    if req != "auto":
        return req

    try:
        import torch
        timer = bench if bench is not None else _gemm_seconds
        t_bf16 = timer(torch.bfloat16)
        t_fp32 = timer(torch.float32)
        pick = "bfloat16" if t_bf16 <= t_fp32 else "float32"
        ratio = (max(t_bf16, t_fp32) / max(min(t_bf16, t_fp32), 1e-9))
        print(f"  dtype auto → {pick} "
              f"(bf16 {t_bf16 * 1e3:.1f} ms vs fp32 {t_fp32 * 1e3:.1f} ms, "
              f"{ratio:.1f}× apart; COURIER_DTYPE overrides)", flush=True)
        return pick
    except Exception as e:  # noqa: BLE001 — never let tuning break a build
        print(f"  ⚠ dtype autotune skipped ({e}); using bfloat16", flush=True)
        return "bfloat16"


def build_engine(
    model_path: str,
    config: dict,
    dtype: str = "bfloat16",
    device: str = "cpu",
    kv_cache_dir: Optional[str] = None,
    max_kv_ram_layers: int = -1,
    draft_streamer=None,
    speculative_block_k: int = 4,
) -> tuple:
    """Convenience: build engine and infer_fn from a model path.

    Automatically selects LayerStreamer (text-only) or HybridStreamer
    (multimodal) based on the detected model type.

    Args:
        model_path: Path to the model directory
        config: System config dict (from load_config). All inference
                defaults come from here — nothing is hardcoded.
        dtype: Weight precision
        device: Device to run on
        kv_cache_dir: Directory for KV cache spillover
        max_kv_ram_layers: Max KV cache layers in RAM (-1 = all)
        draft_streamer: optional drafter for speculative decoding
                (Channel B). None (default) ⇒ single-model behavior.
        speculative_block_k: draft tokens per verify sweep when a draft
                is supplied.

    Returns:
        (streamer, infer_fn) tuple
    """
    import torch

    # ── CPU thread sizing (same policy as start.py's env seeding) ────
    # Default torch's intra-op pool to PHYSICAL cores: CPU-inference GEMM
    # is memory-bandwidth-bound, so hyperthreads add scheduling overhead
    # without throughput. COURIER_THREADS overrides in either direction
    # (benchmark dial). If the env already sized the pool (server path,
    # OMP_NUM_THREADS) the values agree and this is a no-op. Guarded:
    # some torch builds refuse set_num_threads after parallel work has
    # started — never let thread tuning break an engine build.
    try:
        import os as _os
        _t = _os.environ.get("COURIER_THREADS", "").strip()
        if _t:
            _target = max(1, int(_t))
        else:
            import psutil as _psutil
            _target = _psutil.cpu_count(logical=False) or 0
        if _target and torch.get_num_threads() != _target:
            torch.set_num_threads(_target)
            print(f"  torch threads → {_target} "
                  f"(physical cores; COURIER_THREADS overrides)", flush=True)
    except (ValueError, RuntimeError) as _e:
        print(f"  ⚠ thread sizing skipped: {_e}", flush=True)

    dtype_map = {"bfloat16": torch.bfloat16, "float16": torch.float16, "float32": torch.float32}
    # ── dtype autotune (performance spec §5, Phase 3; Class N, opt-in) ──
    # 'auto' (config dtype or COURIER_DTYPE) benches one representative
    # GEMM per candidate on THIS box's silicon and picks the winner:
    # bf16 GEMM is native only with AVX-512-BF16/AMX, emulated elsewhere
    # (Kaby Lake, many arm64 builds), where fp32 can flatly win. Explicit
    # dtypes are honored verbatim — the default stays bfloat16, so
    # existing configs are byte-identical. The pick is logged with the
    # measured ratio so a box's choice is auditable, and the whole thing
    # is guarded: any bench failure falls back to bfloat16 rather than
    # ever breaking an engine build.
    import os as _os
    _env_dtype = _os.environ.get("COURIER_DTYPE", "").strip().lower()
    if _env_dtype:
        dtype = _env_dtype  # env overrides config, matching COURIER_THREADS
    dtype = resolve_dtype(dtype, dtype_map)
    torch_dtype = dtype_map.get(dtype, torch.bfloat16)

    adapter = detect_adapter(model_path)

    # KV cache settings flow from config like every other engine knob
    # (layer_delay, throttle, residency). Explicit arguments still win;
    # before this, the kv_cache_dir / max_kv_ram_layers config keys were
    # dead on the server path — never passed in — so spillover could not
    # be configured at all from the dashboard.
    if kv_cache_dir is None:
        kv_cache_dir = config.get("kv_cache_dir") or None
    if max_kv_ram_layers == -1:
        max_kv_ram_layers = int(config.get("max_kv_ram_layers", -1) or -1)

    # ── Format detection: GGUF or safetensors ─────────────
    from pathlib import Path as _Path
    _model_dir = _Path(model_path)
    _gguf_files = sorted(_model_dir.glob("*.gguf"))

    if _gguf_files:
        from core.gguf_shard_manager import GGUFShardManager
        shard_mgr = GGUFShardManager(_gguf_files[0], adapter)
    else:
        # Resident-RAM mode. Two ways to enable it:
        #   1. Max RAM (%) dial — % of *total* system RAM, floored to leave a
        #      hard reserve for the OS + collector, resolved to a byte cap. The
        #      shard manager caches layers up to that cap and streams the rest,
        #      so resident depth is emergent from the budget. See engine/sizing.
        #   2. Explicit resident_weights / resident_max_gb override.
        # Either way resident_max_gb/bytes caps the cache so a low-RAM box
        # degrades to streaming instead of OOM.
        resident = bool(config.get("resident_weights", False))
        resident_max_gb = float(config.get("resident_max_gb", 0) or 0)
        resident_max_bytes = int(resident_max_gb * (1024 ** 3))

        ram_pct = float(config.get("max_ram_percent", 0) or 0)
        if ram_pct > 0:
            import psutil
            from engine.sizing import resident_budget_bytes
            reserve = int(float(config.get("ram_reserve_gb", 1.0)) * (1024 ** 3))
            budget = resident_budget_bytes(
                psutil.virtual_memory().total, ram_pct, reserve
            )
            # budget == 0 means the reserve ate the percentage — fall through to
            # streaming. Never pass 0 as a cap: to the shard manager 0 = ∞.
            if budget > 0:
                resident = True
                resident_max_bytes = budget

        # Tier-2 raw-at-rest residency (performance spec §4, retargeted to
        # the safetensors path): pins int8+scale pairs beyond what tier 1
        # holds dequantized. Config key qresident_max_gb; COURIER_QRESIDENT_GB
        # overrides (benchmark dial, same style as COURIER_THREADS).
        _qgb = os.environ.get("COURIER_QRESIDENT_GB", "").strip()
        qres_gb = float(_qgb) if _qgb else float(config.get("qresident_max_gb", 0) or 0)
        shard_mgr = ShardManager(
            model_path, adapter,
            resident=resident,
            resident_max_bytes=resident_max_bytes,
            qresident_max_bytes=int(qres_gb * (1024 ** 3)),
        )

    # Choose the right streamer based on model capabilities
    layer_delay = float(config.get("layer_delay", 0.0))
    # Max CPU (%) dial -> dynamic brake setpoint. 100 (default) disables it.
    cpu_pct = float(config.get("max_cpu_percent", 100) or 100)
    brake = None
    if 0 < cpu_pct < 100:
        from engine.brake import CpuBrake
        brake = CpuBrake(target_frac=cpu_pct / 100.0)
    if adapter.config.model_type.startswith("gemma3"):
        # Family dispatch must precede capability flags: a multimodal
        # Gemma would otherwise route to HybridStreamer and run Qwen3.5
        # math (wrong norms, wrong MLP, no sliding windows).
        from engine.gemma3_streamer import Gemma3Streamer
        streamer = Gemma3Streamer(
            shard_mgr, adapter,
            dtype=torch_dtype,
            device=device,
            kv_cache_dir=kv_cache_dir,
            max_kv_ram_layers=max_kv_ram_layers,
            layer_delay=layer_delay,
            brake=brake,
        )
    elif adapter.is_multimodal or adapter.has_hybrid_attention:
        from engine.hybrid_streamer import HybridStreamer
        streamer = HybridStreamer(
            shard_mgr, adapter,
            dtype=torch_dtype,
            device=device,
            kv_cache_dir=kv_cache_dir,
            max_kv_ram_layers=max_kv_ram_layers,
            layer_delay=layer_delay,
            brake=brake,
        )
    else:
        from engine.streamer import LayerStreamer
        streamer = LayerStreamer(
            shard_mgr, adapter,
            dtype=torch_dtype,
            device=device,
            kv_cache_dir=kv_cache_dir,
            max_kv_ram_layers=max_kv_ram_layers,
            layer_delay=layer_delay,
            brake=brake,
        )

    infer_fn = make_primary_infer_fn(
        streamer, config,
        draft_streamer=draft_streamer,
        speculative_block_k=speculative_block_k,
    )

    # ── Prewarm (opt-in: COURIER_PREWARM=1) ───────────────────────────
    # Walks every layer through the shard manager once at build time, so
    # the first-pass costs — readahead ramp, cache fill (resident layers
    # or OS page cache), allocator warmup — land here, with progress
    # output, instead of inside the first user query's first token.
    # Synchronous BY DESIGN: the shard managers' file handles and caches
    # are not thread-safe, so a background prewarm could race the first
    # inference. Moves no total work; moves WHEN it happens.
    if os.environ.get("COURIER_PREWARM", "").strip() == "1":
        prewarm_engine(streamer)

    return streamer, infer_fn


def prewarm_engine(streamer, log_every: int = 8) -> float:
    """Prime caches by loading every layer once. Returns elapsed seconds.

    Spins the torch parallel pool with a throwaway matmul first, then
    walks load_layer(0..N) in order — sequential disk reads, which the
    kernel's readahead serves far faster than the demand-fault order of
    a real forward pass. With a resident/layer cache enabled this fills
    it; without one it still warms the OS page cache (useful whenever
    the model file fits in free RAM).
    """
    import time as _time
    import torch as _torch

    _torch.mm(_torch.randn(64, 64), _torch.randn(64, 64))  # pool warmup

    n = streamer.config.num_hidden_layers
    t0 = _time.perf_counter()
    print(f"  Prewarming {n} layers...", flush=True)
    for i in range(n):
        streamer.shards.load_layer(i, streamer.dtype)
        if log_every and (i + 1) % log_every == 0:
            print(f"    layer {i + 1}/{n} "
                  f"({_time.perf_counter() - t0:.1f}s)", flush=True)
    elapsed = _time.perf_counter() - t0
    print(f"  Prewarm complete: {n} layers in {elapsed:.1f}s", flush=True)
    return elapsed


def make_primary_infer_fn(streamer, config: dict, draft_streamer=None, speculative_block_k: int = 4):
    """Build the pipeline infer_fn for an already-constructed primary streamer
    from the system config, optionally wiring a speculative draft. Shared by
    build_engine() and the server's live speculative re-wire so the inference
    defaults are derived in exactly one place.
    """
    cfg = config
    required = ("temperature", "top_p", "max_new_tokens")
    missing = [k for k in required if k not in cfg]
    if missing:
        raise ValueError(
            f"System config missing required keys: {', '.join(missing)}. "
            f"Check courier_config.json or reset via the CONFIG tab."
        )
    return make_infer_fn(
        streamer,
        default_temperature=float(cfg["temperature"]),
        default_top_p=float(cfg["top_p"]),
        default_max_tokens=int(cfg["max_new_tokens"]),
        default_presence_penalty=float(cfg.get("presence_penalty", 0.0)),
        default_top_k=int(cfg.get("top_k", 20)),
        default_enable_thinking=bool(cfg.get("enable_thinking", False)),
        default_max_images=int(cfg.get("max_images_per_cycle", 8)),
        draft_streamer=draft_streamer,
        speculative_block_k=int(speculative_block_k),
    )
