"""Layer-streaming inference engine.

Runs a transformer decoder forward pass one layer at a time,
loading weights from disk on demand. For a 70B model, only one
layer's weights (~1.75 GB) occupy RAM at a time. For the 0.6B
prototype, all layers fit but the streaming path is exercised
identically.

Supports model families with standard (non-hybrid) attention:
- Pre-norm RMSNorm (standard or (1+weight) variant)
- Q/K/V projection with optional QK-LayerNorm
- RoPE (split-half layout; standard or adapter-specific scaling)
- Grouped Query Attention (GQA)
- SwiGLU MLP
- Tied or untied lm_head

Architecture-specific details (QK-norm, RoPE scaling, sampling
defaults, chat templates) are read from the adapter at runtime.
"""

import time
from typing import Optional, Callable

import torch
import torch.nn.functional as F

from core.adapter.base import ModelAdapter
from core.shard_manager import ShardManager
from engine.kv_cache import KVCacheManager
from engine.sampler import sample


# ── Math primitives ──────────────────────────────────────────

def rmsnorm(x: torch.Tensor, weight: torch.Tensor, eps: float) -> torch.Tensor:
    """RMSNorm: x * rsqrt(mean(x²) + eps) * weight.

    Computes in fp32 for numerical stability, casts back to input dtype.
    """
    orig_dtype = x.dtype
    x = x.float()
    rms = torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + eps)
    return (weight.float() * (x * rms)).to(orig_dtype)


def rotate_half(x: torch.Tensor) -> torch.Tensor:
    """Split-half RoPE rotation: [-x2, x1]."""
    half = x.shape[-1] // 2
    x1, x2 = x[..., :half], x[..., half:]
    return torch.cat([-x2, x1], dim=-1)


def apply_rope(
    q: torch.Tensor,
    k: torch.Tensor,
    cos: torch.Tensor,
    sin: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Apply rotary position embeddings (split-half layout).

    cos, sin: shape (1, seq_len, head_dim), broadcast over heads.
    q, k: shape (batch, n_heads, seq_len, head_dim).
    """
    cos = cos.unsqueeze(1)  # (1, 1, seq_len, head_dim)
    sin = sin.unsqueeze(1)
    q_rot = q * cos + rotate_half(q) * sin
    k_rot = k * cos + rotate_half(k) * sin
    return q_rot, k_rot


def repeat_kv(x: torch.Tensor, n_rep: int) -> torch.Tensor:
    """Repeat KV heads to match query heads for GQA.

    Input:  (batch, num_kv_heads, seq_len, head_dim)
    Output: (batch, num_kv_heads * n_rep, seq_len, head_dim)
    """
    if n_rep == 1:
        return x
    return x.repeat_interleave(n_rep, dim=1)


# ── Layer Streamer ───────────────────────────────────────────

class LayerStreamer:
    """Layer-streaming inference engine."""

    def __init__(
        self,
        shard_manager: ShardManager,
        adapter: ModelAdapter,
        dtype: torch.dtype = torch.bfloat16,
        device: str = "cpu",
        kv_cache_dir: Optional[str] = None,
        max_kv_ram_layers: int = -1,
        layer_delay: float = 0.0,
        brake=None,
    ):
        self.shards = shard_manager
        self.adapter = adapter
        self.config = adapter.config
        self.dtype = dtype
        self.device = device
        self.eps = self.config.rms_norm_eps
        self.layer_delay = layer_delay
        # Dynamic CPU brake (utilization setpoint). None = no setpoint; the
        # fixed layer_delay floor still applies. See engine/brake.py.
        self._brake = brake

        # Precompute RoPE inverse frequencies
        self._inv_freq = self._build_inv_freq()

        # Load embedding + final norm (persist in RAM — small)
        self._embed = self.shards.load_embedding(dtype).to(device)
        self._final_norm = self.shards.load_final_norm(dtype).to(device)

        # LM head: use tied embedding, pin in RAM, or stream from disk.
        # For GGUF models, streaming avoids pinning 1+ GB permanently,
        # leaving more RAM for layer caching.
        self._lm_head = None
        self._stream_lm_head = False
        lm_head_key = self.adapter.lm_head_key()
        if lm_head_key is not None and self.shards.has_key(lm_head_key):
            from core.gguf_shard_manager import GGUFShardManager
            if isinstance(self.shards, GGUFShardManager):
                self._stream_lm_head = True  # load on demand per token
            else:
                self._lm_head = self.shards.load_lm_head(dtype).to(device)
        elif lm_head_key is not None:
            # The adapter says the model has an untied LM head, but the
            # key wasn't found. This silently falls through to tied-
            # embedding logits, producing garbage output. Fail loud.
            available = [k for k in self.shards.all_keys()
                         if "lm_head" in k or "output" in k.split(".")[-1]]
            raise KeyError(
                f"Untied LM head key '{lm_head_key}' not found in model shards. "
                f"The model has tie_word_embeddings=false, so a separate LM head "
                f"is required. Candidates in shard index: {available or '(none)'}. "
                f"Check that the adapter's lm_head_key() matches the safetensors "
                f"weight map."
            )

        # KV cache
        self.kv_cache = KVCacheManager(
            n_layers=self.config.num_hidden_layers,
            num_kv_heads=self.config.num_key_value_heads,
            head_dim=self.config.head_dim,
            max_ram_layers=max_kv_ram_layers,
            cache_dir=kv_cache_dir,
            dtype=dtype,
        )

        # Cancel callback — checked between layers for responsive interruption
        self._cancel_check = None

        # Live layer heartbeat: the index of the most recently completed layer
        # in the current forward pass (0..num_hidden_layers). The dashboard's
        # Layer bar reads this off the persistent streamer handle so the
        # operator sees motion within a single (possibly very slow) token even
        # when the token-level Generation bar is barely moving.
        self.current_layer = 0

    def _rest_after_layer(self, compute_s: float) -> None:
        """Pace inference between layers: fixed floor plus dynamic brake.

        The fixed `layer_delay` is a manual minimum rest. The dynamic brake, if
        present, sizes an additional rest to hold the Max CPU utilization
        setpoint. `time.sleep` releases the GIL, so the rest also yields the
        core to the always-on collector. A strict no-op when both are off.
        """
        rest = self.layer_delay
        if self._brake is not None:
            from engine.brake import process_load_frac
            rest = max(rest, self._brake.update(compute_s, process_load_frac()))
        if rest > 0:
            time.sleep(rest)

    def _build_inv_freq(self) -> torch.Tensor:
        """Precompute RoPE inverse frequencies.

        Delegates to the adapter's build_rope_inv_freq(), which handles
        model-specific scaling (e.g. Llama 3.1's piecewise scheme).
        """
        return self.adapter.build_rope_inv_freq(self.device)

    def _rope_cos_sin(self, positions: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Compute RoPE cos/sin for given position IDs.

        Args:
            positions: shape (1, seq_len), position indices

        Returns:
            cos, sin: each shape (1, seq_len, head_dim)
        """
        freqs = positions[:, :, None].float() * self._inv_freq[None, None, :]
        emb = torch.cat([freqs, freqs], dim=-1)  # (1, seq_len, head_dim)
        return emb.cos().to(self.dtype), emb.sin().to(self.dtype)

    def forward_layer(
        self,
        hidden: torch.Tensor,
        layer_idx: int,
        cos: torch.Tensor,
        sin: torch.Tensor,
    ) -> torch.Tensor:
        """Run one decoder layer.

        Args:
            hidden: (batch, seq_len, hidden_size)
            layer_idx: which layer
            cos, sin: RoPE embeddings (1, seq_len, head_dim)

        Returns:
            Updated hidden states (batch, seq_len, hidden_size)
        """
        cfg = self.config
        w = self.shards.load_layer(layer_idx, self.dtype)
        # Move to device
        w = {k: v.to(self.device) for k, v in w.items()}

        bsz, seq_len, _ = hidden.shape

        # ── Pre-attention norm ──────────────────────────────
        residual = hidden
        hidden = rmsnorm(hidden, w["input_layernorm"], self.eps)

        # ── Q/K/V projections ───────────────────────────────
        q = (hidden @ w["q_proj"].T).view(bsz, seq_len, cfg.num_attention_heads, cfg.head_dim)
        k = (hidden @ w["k_proj"].T).view(bsz, seq_len, cfg.num_key_value_heads, cfg.head_dim)
        v = (hidden @ w["v_proj"].T).view(bsz, seq_len, cfg.num_key_value_heads, cfg.head_dim)

        # ── QK-LayerNorm (model-family-specific) ────────────
        # Qwen3/Qwen3.5: per-head RMSNorm on Q and K before RoPE.
        # Llama 3 and others: skip (no q_norm/k_norm weights).
        if self.adapter.has_qk_norm:
            q = rmsnorm(q, w["q_norm"], self.eps)
            k = rmsnorm(k, w["k_norm"], self.eps)

        # Transpose to (batch, heads, seq, head_dim)
        q = q.transpose(1, 2)
        k = k.transpose(1, 2)
        v = v.transpose(1, 2)

        # ── RoPE ────────────────────────────────────────────
        q, k = apply_rope(q, k, cos, sin)

        # ── KV cache ────────────────────────────────────────
        cached = self.kv_cache.read(layer_idx)
        if cached is not None:
            past_k, past_v = cached
            past_k = past_k.to(self.device)
            past_v = past_v.to(self.device)
            k = torch.cat([past_k, k], dim=2)
            v = torch.cat([past_v, v], dim=2)
        self.kv_cache.write(layer_idx, k.cpu(), v.cpu())

        # ── GQA: repeat KV heads ────────────────────────────
        gqa_rep = self.adapter.gqa_group_size()
        k_rep = repeat_kv(k, gqa_rep)
        v_rep = repeat_kv(v, gqa_rep)

        # ── Attention ───────────────────────────────────────
        scale = cfg.head_dim ** -0.5
        scores = (q @ k_rep.transpose(-1, -2)) * scale

        # Causal mask only during prefill (seq_len > 1)
        if seq_len > 1:
            kv_len = k_rep.shape[2]
            # Build causal mask: position i can attend to positions ≤ i
            causal = torch.full((seq_len, kv_len), float("-inf"),
                               device=self.device, dtype=self.dtype)
            offset = kv_len - seq_len  # for appended KV cache
            for i in range(seq_len):
                causal[i, :offset + i + 1] = 0
            scores = scores + causal[None, None, :, :]

        attn = F.softmax(scores.float(), dim=-1).to(self.dtype)
        out = attn @ v_rep  # (batch, heads, seq_len, head_dim)

        # ── Output projection ───────────────────────────────
        out = out.transpose(1, 2).contiguous().reshape(bsz, seq_len, -1)
        out = out @ w["o_proj"].T

        hidden = residual + out

        # ── Post-attention norm + SwiGLU MLP ────────────────
        residual = hidden
        hidden = rmsnorm(hidden, w["post_attention_layernorm"], self.eps)

        gate = F.silu(hidden @ w["gate_proj"].T)
        up = hidden @ w["up_proj"].T
        hidden = (gate * up) @ w["down_proj"].T

        hidden = residual + hidden

        # Release layer weights (for memory-constrained operation)
        del w

        return hidden

    def forward(self, input_ids: torch.Tensor, position_offset: int = 0,
                all_positions: bool = False) -> torch.Tensor:
        """Full forward pass: input token IDs → logits.

        Streams through all layers one at a time.

        Args:
            input_ids: (batch, seq_len) token IDs
            position_offset: starting position for RoPE (0 for prefill,
                            seq_len for subsequent decode steps)
            all_positions: when False (default) the LM head is applied to the
                LAST position only and the return shape is (batch, vocab) —
                today's behavior, unchanged. When True the head is applied to
                EVERY position, returning (batch, seq_len, vocab). Used solely
                by the speculative-decoding verify step (spec §6 Change 1); the
                normal decode path leaves it False and pays nothing.

        Returns:
            logits: (batch, vocab_size) for the last position, or
            (batch, seq_len, vocab_size) when all_positions=True.
        """
        bsz, seq_len = input_ids.shape

        # Embedding lookup
        hidden = self._embed[input_ids]  # (batch, seq_len, hidden_size)

        # RoPE cos/sin for these positions
        positions = torch.arange(
            position_offset, position_offset + seq_len,
            device=self.device
        ).unsqueeze(0)
        cos, sin = self._rope_cos_sin(positions)

        # Stream through all layers
        for i in range(self.config.num_hidden_layers):
            if self._cancel_check is not None:
                self._cancel_check()
            _t0 = time.perf_counter()
            hidden = self.forward_layer(hidden, i, cos, sin)
            self.current_layer = i + 1
            self._rest_after_layer(time.perf_counter() - _t0)

        # Final norm
        hidden = rmsnorm(hidden, self._final_norm, self.eps)

        # LM head. Default: last position only (batch, vocab) — unchanged.
        # all_positions: every position (batch, seq_len, vocab) for SD verify.
        head_input = hidden if all_positions else hidden[:, -1, :]
        if self._lm_head is not None:
            logits = head_input @ self._lm_head.T
        elif self._stream_lm_head:
            lm_head = self.shards.load_lm_head(self.dtype).to(self.device)
            logits = head_input @ lm_head.T
            del lm_head
        else:
            logits = head_input @ self._embed.T  # tied embeddings

        return logits  # (batch, vocab) or (batch, seq_len, vocab)

    # ── Speculative-decoding state snapshot/restore (spec §6 Change 2) ──────
    # LayerStreamer is pure full-attention: its only per-token state is the KV
    # cache, which is append-only, so a rollback is a KV truncation. (The hard
    # case is HybridStreamer, whose recurrent/conv state needs real snapshots.)
    # Dormant: only the SD verify loop calls these.

    def snapshot_state(self) -> dict:
        """Capture the rollback point at a verify-block boundary."""
        return {"kv_seq_len": self.kv_cache.seq_len()}

    def restore_state(self, snap: dict) -> None:
        """Roll the KV cache back to a previously captured length."""
        self.kv_cache.truncate(int(snap["kv_seq_len"]))

    def clear_state(self):
        """Clear all cached state (KV cache).

        Called by speculative_generate at the start of each generation.
        LayerStreamer has no recurrent or conv state — only the KV cache.
        """
        self.kv_cache.clear()

    def generate(
        self,
        prompt: str,
        max_new_tokens: int = 100,
        temperature: float = 0.7,
        top_p: float = 0.9,
        top_k: int = 20,
        presence_penalty: float = 0.0,
        stop_tokens: Optional[list[int]] = None,
        on_token: Optional[Callable[[int, int], None]] = None,
        on_checkpoint: Optional[Callable[[int, int, int, list], None]] = None,
        cancel_check: Optional[Callable] = None,
        resume_tokens: Optional[list[int]] = None,
        resume_rng: Optional[bytes] = None,
    ) -> list[int]:
        """Generate text from a prompt.

        Args:
            prompt: Input text string
            max_new_tokens: Maximum tokens to generate (total for the stage,
                inclusive of any resume_tokens)
            temperature: Sampling temperature
            top_p: Nucleus sampling threshold
            top_k: Top-k filter
            stop_tokens: Token IDs that stop generation (default: model's eos)
            on_token: Callback(token_id, step) called after each token
            on_checkpoint: Callback(token_id, step, position, tokens_so_far)
                called after each token, so the caller can bank progress
            resume_tokens: Tokens already generated for this stage by an
                earlier, interrupted run. When given, the KV cache is
                rebuilt by prefilling [prompt + resume_tokens] in a single
                pass and generation continues from there — the banked
                tokens are re-fed, never lost. The token list is the whole
                resume state; nothing is read from disk.
            resume_rng: Sampler RNG state (raw bytes) banked alongside
                resume_tokens. Restored after the re-prefill so the
                continuation matches the interrupted run token-for-token.

        Returns:
            List of generated token IDs (the full stage output, including
            any resume_tokens that were re-fed).
        """
        if stop_tokens is None:
            stop_tokens = self.config.eos_token_id

        # Every stage begins from a clean KV cache; the prefill below
        # rebuilds it — from the prompt alone for a fresh run, or from the
        # prompt plus the tokens banked before an interruption for a resume.
        self.kv_cache.clear()
        self._cancel_check = cancel_check
        prompt_ids = self.adapter.encode_prompt(prompt)

        if resume_tokens:
            # Resume: re-prefill prompt + already-generated tokens so the KV
            # cache is reconstructed exactly, then continue generating.
            prefill_ids = list(prompt_ids) + list(resume_tokens)
            generated = list(resume_tokens)
        else:
            prefill_ids = list(prompt_ids)
            generated = []

        input_tensor = torch.tensor(
            [prefill_ids], dtype=torch.long, device=self.device
        )
        logits = self.forward(input_tensor, position_offset=0)
        position = len(prefill_ids)
        start_step = len(generated)

        # Resume: restore the sampler RNG so the continuation is identical
        # to what the interrupted run would have produced. The re-prefill
        # above runs only forward passes — deterministic, consuming no
        # sampler RNG — so restoring here, after the prefill and before the
        # first sampled token, lands the generator on the exact draw the
        # original run was about to make.
        if resume_tokens and resume_rng:
            import numpy as np
            torch.set_rng_state(torch.from_numpy(
                np.frombuffer(resume_rng, dtype=np.uint8).copy()
            ))

        # Generate tokens
        for step in range(start_step, max_new_tokens):
            token_id = sample(logits.squeeze(0), temperature, top_p, top_k,
                              presence_penalty=presence_penalty,
                              generated_tokens=generated)
            generated.append(token_id)

            if on_token:
                on_token(token_id, step)

            if on_checkpoint:
                on_checkpoint(token_id, step, position, generated)

            if token_id in stop_tokens:
                break

            # Decode step: single token
            next_input = torch.tensor(
                [[token_id]], dtype=torch.long, device=self.device
            )
            logits = self.forward(next_input, position_offset=position)
            position += 1

        self._cancel_check = None
        return generated
