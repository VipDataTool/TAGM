"""Engine registry — the shared spine for multi-model Courier (spec §2, §8).

Holds >=1 loaded engine keyed by role. With nothing enabled it holds exactly
one entry, ``primary``, and behaves identically to the single-model build: a
caller that only ever asks for ``primary`` (or passes no role) sees today's
engine and nothing else.

This module is deliberately torch-free. An entry is a plain dict of already-
built handles and metadata:

    {
      "streamer":       <LayerStreamer | HybridStreamer>,
      "infer_fn":       <callable(prompt, **kw) -> str>,
      "model_path":     str,
      "multimodal":     bool,
      "footprint_bytes":int,   # full resident weight size (for §5 partition)
      "resident_cap":   int,   # bytes handed to this engine's shard cache
    }

Each engine is built by build_engine(), which mints its OWN ShardManager — so
two engines hold two independent resident caches with no cross-eviction (§4).
The registry only tracks handles; it does not share or pool caches.

Keeping the role->entry bookkeeping here (pure) means routing (Channel A) and
speculative decoding (Channel B) resolve engines through one tested path,
while the torch-coupled load/teardown stays in server.py.
"""
from __future__ import annotations

from typing import Any, Callable, Iterable, Optional

PRIMARY = "primary"

# Fields an entry is expected to carry. Missing optional fields default below.
_REQUIRED = ("streamer", "infer_fn", "model_path")
_OPTIONAL_DEFAULTS = {
    "multimodal": False,
    "footprint_bytes": 0,
    "resident_cap": 0,
}


def make_entry(
    streamer: Any,
    infer_fn: Callable[..., str],
    model_path: str,
    *,
    multimodal: bool = False,
    footprint_bytes: int = 0,
    resident_cap: int = 0,
) -> dict:
    """Build a normalized registry entry. Pure; no torch."""
    return {
        "streamer": streamer,
        "infer_fn": infer_fn,
        "model_path": str(model_path),
        "multimodal": bool(multimodal),
        "footprint_bytes": int(footprint_bytes),
        "resident_cap": int(resident_cap),
    }


class EngineRegistry:
    """A role -> engine-entry map with a guaranteed ``primary``.

    Default state (only ``primary`` present) is indistinguishable from the
    single-engine build: ``resolve(None)`` and ``resolve("primary")`` both
    return the one engine, and ``roles()`` is ``["primary"]``.
    """

    def __init__(self) -> None:
        self._engines: dict[str, dict] = {}

    # ── mutation ─────────────────────────────────────────────
    def set(self, role: str, entry: dict) -> None:
        """Register (or replace) the engine for ``role``."""
        for k in _REQUIRED:
            if k not in entry:
                raise ValueError(f"engine entry for role '{role}' missing '{k}'")
        normalized = dict(entry)
        for k, default in _OPTIONAL_DEFAULTS.items():
            normalized.setdefault(k, default)
        self._engines[role] = normalized

    def set_primary(self, entry: dict) -> None:
        self.set(PRIMARY, entry)

    def remove(self, role: str) -> None:
        """Drop a non-primary engine. Refuses to remove ``primary``."""
        if role == PRIMARY:
            raise ValueError("refusing to remove the primary engine")
        self._engines.pop(role, None)

    def clear_secondary(self) -> None:
        """Drop everything except primary — reverts to the single-engine state."""
        primary = self._engines.get(PRIMARY)
        self._engines = {PRIMARY: primary} if primary is not None else {}

    # ── lookup ───────────────────────────────────────────────
    def has(self, role: Optional[str]) -> bool:
        return (role or PRIMARY) in self._engines

    def get(self, role: Optional[str]) -> Optional[dict]:
        return self._engines.get(role or PRIMARY)

    def resolve(self, role: Optional[str]) -> dict:
        """Return the engine for ``role``, falling back to primary.

        Routing policy (Channel A): an absent/None/unknown role resolves to
        primary, so a stage with no ``model`` set behaves exactly as today.
        Raises only if there is no primary at all (engine not loaded yet).
        """
        if role and role in self._engines:
            return self._engines[role]
        primary = self._engines.get(PRIMARY)
        if primary is None:
            raise KeyError("no primary engine is loaded")
        return primary

    @property
    def primary(self) -> Optional[dict]:
        return self._engines.get(PRIMARY)

    def roles(self) -> list[str]:
        # primary first, then the rest in insertion order
        rest = [r for r in self._engines if r != PRIMARY]
        return ([PRIMARY] if PRIMARY in self._engines else []) + rest

    def infer_fns(self) -> dict[str, Callable[..., str]]:
        """role -> infer_fn map, for handing to run_pipeline (Channel A)."""
        return {r: e["infer_fn"] for r, e in self._engines.items()}

    def count(self) -> int:
        return len(self._engines)

    def is_single(self) -> bool:
        """True when only primary is loaded — the dormant/default shape."""
        return self.roles() == [PRIMARY]

    # ── budget accounting (feeds §5 partition) ───────────────
    def total_footprint_bytes(self) -> int:
        return sum(int(e.get("footprint_bytes", 0)) for e in self._engines.values())

    def secondary_footprint_bytes(self, role: str) -> int:
        e = self._engines.get(role)
        return int(e.get("footprint_bytes", 0)) if e else 0

    def __contains__(self, role: object) -> bool:
        return role in self._engines

    def __len__(self) -> int:
        return len(self._engines)
