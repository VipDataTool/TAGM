"""Single-file template store.

All templates live in one JSON file (`templates/templates.json`), keyed by id,
instead of one file per template. The list, the Run picker, the editor, and the
cycle runner all read this one file — they cannot drift (the "one source of
truth" principle from courier-ux-design-spec.md §2).

On first use the file is seeded from the existing read-only `builtin/*.json`
shipping templates, so nothing is lost in the migration. After that the single
file is authoritative and every template in it is viewable, editable, and
deletable.

Stored values are the operator's *raw* template JSON (round-trip faithful for
the editor); every read/write validates through `Template` so an invalid
template can never be saved or served.

No torch, no engine — cold-probe testable.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional

from template import Template


class TemplateStore:
    def __init__(self, path, seed_dir):
        """
        Args:
            path: the single JSON file (templates/templates.json).
            seed_dir: directory of builtin/*.json used to seed the file once.
        """
        self.path = Path(path)
        self.seed_dir = Path(seed_dir)

    # ── file I/O ────────────────────────────────────────────────
    def _ensure(self) -> None:
        """Create the single file from the builtin seeds if it doesn't exist."""
        if self.path.exists():
            return
        data: dict = {}
        if self.seed_dir.exists():
            for f in sorted(self.seed_dir.glob("*.json")):
                try:
                    raw = json.loads(f.read_text(encoding="utf-8"))
                    t = Template.from_dict(raw)  # validate before seeding
                    data[t.metadata.id] = raw
                except Exception:
                    pass  # skip a malformed seed rather than abort migration
        self._write(data)

    def _read(self) -> dict:
        self._ensure()
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _write(self, data: dict) -> None:
        """Whole-file rewrite, atomic via temp + rename (last-write-wins)."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_name(self.path.name + ".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        os.replace(tmp, self.path)

    # ── reads ───────────────────────────────────────────────────
    def ids(self) -> list[str]:
        return list(self._read().keys())

    def get_raw(self, tid: str) -> Optional[dict]:
        """The raw stored template JSON (what the editor shows), or None."""
        return self._read().get(tid)

    def get_template(self, tid: str) -> Optional[Template]:
        """A validated Template object, or None if absent."""
        raw = self.get_raw(tid)
        return Template.from_dict(raw) if raw is not None else None

    def first_template(self) -> Optional[Template]:
        """Validated Template for the first id (stable order), or None."""
        data = self._read()
        if not data:
            return None
        return Template.from_dict(data[sorted(data)[0]])

    def list_summaries(self) -> list[dict]:
        """Picker/list summaries, sorted by name. Mirrors the old _get_templates."""
        out = []
        for raw in self._read().values():
            try:
                t = Template.from_dict(raw)
            except Exception:
                continue
            out.append({
                "id": t.metadata.id, "name": t.metadata.name,
                "stages": len(t.stages), "version": t.metadata.version,
                "description": t.metadata.description,
                "stage_detail": [
                    {"label": s.label, "thinking": s.thinking,
                     "max_tokens": s.max_new_tokens,
                     "sources": s.input.get("sources", [])}
                    for s in t.stages
                ],
                "sources": list(t.sources.keys()),
            })
        return sorted(out, key=lambda x: x["name"].lower())

    # ── writes ──────────────────────────────────────────────────
    def save(self, tid: str, raw: dict) -> Template:
        """Validate `raw` then persist it. The template's own id is the key,
        so an edited id moves the entry. Raises ValueError on invalid template."""
        t = Template.from_dict(raw)          # loud validation before any write
        key = t.metadata.id or tid
        data = self._read()
        # If the id was changed in the editor, drop the old key.
        if tid and tid != key and tid in data:
            del data[tid]
        data[key] = raw
        self._write(data)
        return t

    def delete(self, tid: str) -> bool:
        data = self._read()
        if tid in data:
            del data[tid]
            self._write(data)
            return True
        return False
