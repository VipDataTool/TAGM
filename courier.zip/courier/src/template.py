"""Template loader: parse, validate, and populate defaults.

A template is a JSON file that fully specifies a Courier inference
cycle: metadata, model config, data sources, and a stage pipeline.
"""

import json
import time
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class StageConfig:
    """One stage in the chain-of-thought pipeline."""
    label: str
    system_prompt: str
    input: dict = field(default_factory=lambda: {"sources": ["default"]})
    thinking: bool = False
    # Optional per-stage model overrides
    temperature: Optional[float] = None
    max_new_tokens: Optional[int] = None
    # Channel A (stage routing, multimodel spec §2/§8 step 5): the engine role
    # this stage runs on. None ⇒ the primary engine = today's behavior. When
    # set, the orchestrator selects engines[model] from the registry; absent in
    # the registry, it falls back to primary (EngineRegistry.resolve).
    model: Optional[str] = None
    # Telegraph contract: when set, the stage's response is a dense dispatch
    # line the renderer expands deterministically (see schema_instruction /
    # expand_dispatch). On a layer-streaming rig prompt tokens are cheap and
    # every output token costs a full pass through the layers — so the format
    # spends the prompt to make the response telegraphic.
    output_schema: Optional[dict] = None


@dataclass
class SourceConfig:
    """Configuration for one data source."""
    adapter: str
    budget_tokens: int = 500
    # All other fields are adapter-specific
    params: dict = field(default_factory=dict)
    # Connection fields passed to adapter.connect()
    endpoint: Optional[str] = None
    module: Optional[str] = None
    path: Optional[str] = None
    aggregation: Optional[str] = None


@dataclass
class ModelSpec:
    """Model configuration from the template."""
    id: str
    dtype: str = "bfloat16"
    max_new_tokens: int = 2048
    temperature: float = 0.3
    top_p: float = 0.9


@dataclass
class TemplateMetadata:
    """Template provenance and identification."""
    id: str
    name: str
    description: str = ""
    version: str = "0.1.0"
    created: str = ""
    updated: str = ""
    author_name: str = ""
    author_organization: str = ""
    author_contact: str = ""
    project_id: str = ""
    project_name: str = ""
    project_description: str = ""
    courier_version: str = ""
    min_courier_version: str = ""
    docnotes: str = ""


@dataclass
class Template:
    """Complete template specification."""
    metadata: TemplateMetadata
    model: ModelSpec
    sources: dict[str, SourceConfig]
    stages: list[StageConfig]

    @classmethod
    def load(cls, path: str | Path) -> "Template":
        """Load and validate a template from a JSON file.

        Args:
            path: Path to the JSON template file

        Returns:
            A validated Template instance with defaults populated

        Raises:
            FileNotFoundError: if the file doesn't exist
            ValueError: if required fields are missing or invalid
        """
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Template not found: {path}")

        with open(path, encoding="utf-8") as f:
            raw = json.load(f)

        return cls._from_dict(raw)

    @classmethod
    def from_dict(cls, raw: dict) -> "Template":
        """Create a template from a dictionary (e.g., from API request)."""
        return cls._from_dict(raw)

    @classmethod
    def _from_dict(cls, raw: dict) -> "Template":
        """Parse and validate a raw dict into a Template."""
        errors = []

        # ── Metadata ────────────────────────────────────────
        tmpl = raw.get("template", {})
        if not tmpl.get("id"):
            errors.append("template.id is required")
        if not tmpl.get("name"):
            errors.append("template.name is required")

        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        author = tmpl.get("author", {})
        project = tmpl.get("project", {})
        software = tmpl.get("software", {})
        notes = tmpl.get("notes", {})

        metadata = TemplateMetadata(
            id=tmpl.get("id", ""),
            name=tmpl.get("name", ""),
            description=tmpl.get("description", ""),
            version=tmpl.get("version", "0.1.0"),
            created=tmpl.get("created", now),
            updated=tmpl.get("updated", now),
            author_name=author.get("name", ""),
            author_organization=author.get("organization", ""),
            author_contact=author.get("contact", ""),
            project_id=project.get("id", ""),
            project_name=project.get("name", ""),
            project_description=project.get("description", ""),
            courier_version=software.get("courier_version", ""),
            min_courier_version=software.get("min_courier_version", ""),
            docnotes=notes.get("docnotes", ""),
        )

        # ── Model ───────────────────────────────────────────
        model_raw = raw.get("model", {})
        if not model_raw.get("id"):
            errors.append("model.id is required")

        model = ModelSpec(
            id=model_raw.get("id", ""),
            dtype=model_raw.get("dtype", "bfloat16"),
            max_new_tokens=model_raw.get("max_new_tokens", 2048),
            temperature=model_raw.get("temperature", 0.3),
            top_p=model_raw.get("top_p", 0.9),
        )

        # ── Data sources ────────────────────────────────────
        sources_raw = raw.get("data", {}).get("sources", {})
        sources = {}
        for name, src in sources_raw.items():
            sources[name] = SourceConfig(
                adapter=src.get("adapter", "verbatim"),
                budget_tokens=src.get("budget_tokens", 500),
                params=src.get("params", {}),
                endpoint=src.get("endpoint"),
                module=src.get("module"),
                path=src.get("path"),
                aggregation=src.get("aggregation"),
            )

        # ── Stages ──────────────────────────────────────────
        stages_raw = raw.get("stages", [])
        if not stages_raw:
            errors.append("At least one stage is required")

        stages = []
        for i, stage in enumerate(stages_raw):
            if not stage.get("system_prompt"):
                errors.append(f"stages[{i}].system_prompt is required")
            stages.append(StageConfig(
                label=stage.get("label", f"Stage {i + 1}"),
                system_prompt=stage.get("system_prompt", ""),
                input=stage.get("input", {"sources": ["default"]}),
                thinking=stage.get("thinking", False),
                temperature=stage.get("temperature"),
                max_new_tokens=stage.get("max_new_tokens"),
                model=stage.get("model"),
                output_schema=_parse_output_schema(
                    stage.get("output_schema"), i, errors),
            ))

        # ── Validate ────────────────────────────────────────
        if errors:
            raise ValueError(
                "Template validation failed:\n  " + "\n  ".join(errors)
            )

        return cls(
            metadata=metadata,
            model=model,
            sources=sources,
            stages=stages,
        )

    def to_dict(self) -> dict:
        """Serialize back to a dict (for storage/export)."""
        return {
            "template": {
                "id": self.metadata.id,
                "name": self.metadata.name,
                "description": self.metadata.description,
                "version": self.metadata.version,
                "created": self.metadata.created,
                "updated": self.metadata.updated,
                "author": {
                    "name": self.metadata.author_name,
                    "organization": self.metadata.author_organization,
                },
                "project": {
                    "id": self.metadata.project_id,
                    "name": self.metadata.project_name,
                },
                "software": {
                    "courier_version": self.metadata.courier_version,
                },
                "notes": {
                    "docnotes": self.metadata.docnotes,
                },
            },
            "model": {
                "id": self.model.id,
                "dtype": self.model.dtype,
                "max_new_tokens": self.model.max_new_tokens,
                "temperature": self.model.temperature,
                "top_p": self.model.top_p,
            },
            "data": {
                "sources": {
                    name: {
                        "adapter": src.adapter,
                        "budget_tokens": src.budget_tokens,
                        "params": src.params,
                    }
                    for name, src in self.sources.items()
                },
            },
            "stages": [
                {
                    "label": s.label,
                    "system_prompt": s.system_prompt,
                    "input": s.input,
                    "thinking": s.thinking,
                    # Channel A: emit the routing override only when set, so
                    # templates that don't use routing serialize unchanged.
                    **({"model": s.model} if s.model else {}),
                    # Telegraph: same rule — schema-less stages serialize
                    # byte-identical. The authored system_prompt is emitted
                    # untouched; the dispatch instruction attaches at prompt
                    # assembly (pipeline), never at rest.
                    **({"output_schema": s.output_schema}
                       if s.output_schema else {}),
                }
                for s in self.stages
            ],
        }


# ── Telegraph contract (output schemas) ─────────────────────────────────────

def _parse_output_schema(raw, idx: int, errors: list):
    """Validate and normalize a stage's output_schema. Loud failures —
    config can't smuggle in a half-described dispatch format."""
    if raw is None:
        return None
    p = f"stages[{idx}].output_schema"
    if not isinstance(raw, dict):
        errors.append(f"{p} must be an object")
        return None
    fields = raw.get("fields")
    if not isinstance(fields, list) or not fields:
        errors.append(f"{p}.fields must be a non-empty list")
        return None
    norm_fields, seen = [], set()
    for j, f in enumerate(fields):
        if not isinstance(f, dict) or not str(f.get("id") or "").strip():
            errors.append(f"{p}.fields[{j}] needs a non-empty id")
            return None
        fid = str(f["id"]).strip()
        if fid in seen:
            errors.append(f"{p}.fields[{j}] duplicates id '{fid}'")
            return None
        seen.add(fid)
        values = f.get("values")
        if values is not None and not (
                isinstance(values, dict) and values and all(
                    isinstance(k, str) and isinstance(v, str)
                    for k, v in values.items())):
            errors.append(f"{p}.fields[{j}].values must map code -> expansion")
            return None
        nf = {"id": fid, "label": str(f.get("label") or fid)}
        if values:
            nf["values"] = values
        norm_fields.append(nf)
    glossary = raw.get("glossary")
    if glossary is not None and not (
            isinstance(glossary, dict) and all(
                isinstance(k, str) and isinstance(v, str)
                for k, v in glossary.items())):
        errors.append(f"{p}.glossary must map code -> expansion")
        return None
    out = {"delimiter": str(raw.get("delimiter") or "|"),
           "fields": norm_fields}
    if glossary:
        out["glossary"] = glossary
    return out


def schema_instruction(schema: dict) -> str:
    """The prompt-side half of the contract: teach the model the dispatch
    format. Spent on the cheap side of the ledger (one prefill pass),
    saved on the expensive side (every output token is a layer-stream)."""
    delim = schema.get("delimiter", "|")
    fields = schema["fields"]
    lines = ["RESPONSE FORMAT — dispatch only:",
             ("Reply with ONE line: a value for each field, in this order, "
              f'separated by " {delim} ":'),
             "  " + f" {delim} ".join(f["id"] for f in fields)]
    for f in fields:
        desc = f"  {f['id']}: {f['label']}"
        values = f.get("values")
        if values:
            desc += " — one of " + ", ".join(
                f"{code} ({exp})" for code, exp in values.items())
        lines.append(desc)
    glossary = schema.get("glossary")
    if glossary:
        lines.append("Use these codes verbatim: " + "; ".join(
            f"{c} = {e}" for c, e in glossary.items()))
    lines.append('Use "-" for a field with nothing to report. No headers, '
                 "no markdown, no extra prose — the renderer expands your "
                 "dispatch into the full report.")
    return "\n".join(lines)


def expand_dispatch(schema: dict, text: str) -> dict:
    """The render-side half: expand a dispatch deterministically. The clerk
    is never inventive — closed-set codes map through the schema, glossary
    codes expand only on word boundaries, and anything that doesn't match
    is refused (ok=False) so the caller shows the model's text verbatim."""
    delim = schema.get("delimiter", "|")
    fields = schema["fields"]
    lines = [ln.strip() for ln in (text or "").strip().splitlines()
             if ln.strip()]
    if not lines:
        return {"ok": False, "rows": [], "raw": "", "note": "empty output"}
    raw = lines[0]
    note = f"{len(lines) - 1} extra line(s) ignored" if len(lines) > 1 else None
    vals = [v.strip() for v in raw.split(delim)]
    if len(vals) != len(fields):
        return {"ok": False, "rows": [], "raw": raw,
                "note": (f"dispatch has {len(vals)} value(s); "
                         f"schema expects {len(fields)}")}
    glossary = schema.get("glossary") or {}
    rows = []
    for f, v in zip(fields, vals):
        values = f.get("values")
        if v == "-":
            out = "—"
        elif values:
            out = values.get(v) or f"{v} (unrecognized code)"
        else:
            out = v
            for code, expansion in glossary.items():
                out = re.sub(rf"\b{re.escape(code)}\b", expansion, out)
        rows.append((f["label"], out))
    return {"ok": True, "rows": rows, "raw": raw, "note": note}
