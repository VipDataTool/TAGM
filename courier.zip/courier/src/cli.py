"""Courier CLI: command-line interface for all operations.

Usage:
    courier start [--insecure] [--port PORT]
    courier status
    courier token create --name NAME [--read-only]
    courier token list
    courier token revoke NAME
    courier model list
    courier model verify ID
    courier template list
    courier template show ID
    courier ingest FILE_OR_DIR [--source-id ID]
    courier data status
    courier run TEMPLATE_ID --model MODEL_ID [--cycles N]
    courier cycle status
    courier result latest
    courier result list
    courier result CYCLE_ID
"""

import argparse
import json
import sys
import time
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))


def get_paths():
    """Standard paths relative to the courier directory."""
    base = Path(__file__).parent.parent
    return {
        "base": base,
        "db": base / "courier.db",
        "models": base / "models",
        "templates": base / "templates" / "builtin",
        "data": base / "data",
        "export": base / "export",
    }


# ── Commands ─────────────────────────────────────────────────

def cmd_start(args):
    """Start the Courier server."""
    import uvicorn
    from server import create_app

    app = create_app(insecure=args.insecure)

    print(f"\n  Starting Courier on port {args.port}...")
    if args.insecure:
        print("  WARNING: Running without authentication (--insecure)")
    print(f"  Dashboard: http://localhost:{args.port}/")
    print(f"  API:       http://localhost:{args.port}/api/status")
    print("  Press Ctrl+C to stop.\n")

    uvicorn.run(app, host="0.0.0.0", port=args.port,
                log_level="error")


def cmd_status(args):
    """Show system status."""
    paths = get_paths()
    from core.db import Database

    if not paths["db"].exists():
        print("Courier database not found. Run 'courier start' first.")
        return

    db = Database(paths["db"])
    stats = db.ingestion_stats()
    cycles = db.cycle_count()

    print(f"  Database:    {paths['db']}")
    print(f"  Records:     {stats['total_records']} ({stats['unconsumed']} unconsumed)")
    print(f"  Cycles:      {cycles} completed")

    # Check for models
    model_count = sum(1 for d in paths["models"].glob("*")
                      if (d / "config.json").exists())
    print(f"  Models:      {model_count} available")

    template_count = sum(1 for f in paths["templates"].glob("*.json"))
    print(f"  Templates:   {template_count} available")

    db.close()


def cmd_token_create(args):
    """Create an API token."""
    paths = get_paths()
    from core.security import TokenManager

    tm = TokenManager(paths["db"])
    token = tm.create_token(args.name, read_only=args.read_only)
    print(f"  Token created: {args.name}")
    print(f"  Role: {'read-only' if args.read_only else 'read-write'}")
    print(f"  Token: {token}")
    print("  (Save this — it cannot be retrieved later)")
    tm.close()


def cmd_token_list(args):
    """List API tokens."""
    paths = get_paths()
    from core.security import TokenManager

    tm = TokenManager(paths["db"])
    tokens = tm.list_tokens()
    if not tokens:
        print("  No tokens configured.")
    else:
        for t in tokens:
            used = time.strftime("%Y-%m-%d %H:%M", time.localtime(t["last_used"])) \
                if t["last_used"] else "never"
            print(f"  {t['name']:20s}  {t['role']:12s}  last used: {used}")
    tm.close()


def cmd_token_revoke(args):
    """Revoke an API token."""
    paths = get_paths()
    from core.security import TokenManager

    tm = TokenManager(paths["db"])
    if tm.revoke(args.name):
        print(f"  Token '{args.name}' revoked.")
    else:
        print(f"  Token '{args.name}' not found.")
    tm.close()


def cmd_model_list(args):
    """List available models."""
    paths = get_paths()
    for d in sorted(paths["models"].glob("*")):
        config_path = d / "config.json"
        if config_path.exists():
            with open(config_path, encoding="utf-8") as f:
                c = json.load(f)
            size = sum(f.stat().st_size for f in d.glob("*.safetensors"))
            print(f"  {d.name:30s}  {c.get('model_type','?'):8s}  "
                  f"{c.get('num_hidden_layers','?')} layers  "
                  f"{size/(1024**3):.2f} GB")


def cmd_model_verify(args):
    """Verify model integrity."""
    paths = get_paths()
    model_path = paths["models"] / args.id
    if not (model_path / "config.json").exists():
        print(f"  Model '{args.id}' not found in {paths['models']}")
        return

    from core.adapter.registry import detect_adapter
    adapter = detect_adapter(model_path)
    print(f"  Model:   {args.id}")
    print(f"  Type:    {adapter.config.model_type}")
    print(f"  Layers:  {adapter.config.num_hidden_layers}")
    print(f"  Hidden:  {adapter.config.hidden_size}")
    print(f"  Vocab:   {adapter.config.vocab_size}")
    print(f"  Status:  OK")


def cmd_template_list(args):
    """List available templates."""
    paths = get_paths()
    from template import Template

    for f in sorted(paths["templates"].glob("*.json")):
        try:
            t = Template.load(f)
            print(f"  {t.metadata.id:30s}  {len(t.stages)} stages  {t.metadata.name}")
        except Exception as e:
            print(f"  {f.stem:30s}  ERROR: {e}")


def cmd_template_show(args):
    """Show template details."""
    paths = get_paths()
    from template import Template

    path = paths["templates"] / f"{args.id}.json"
    if not path.exists():
        print(f"  Template '{args.id}' not found.")
        return

    t = Template.load(path)
    print(f"  ID:          {t.metadata.id}")
    print(f"  Name:        {t.metadata.name}")
    print(f"  Description: {t.metadata.description}")
    print(f"  Model:       {t.model.id}")
    print(f"  Stages:      {len(t.stages)}")
    for i, s in enumerate(t.stages):
        thinking = " [thinking]" if s.thinking else ""
        print(f"    {i+1}. {s.label}{thinking}")


def cmd_ingest(args):
    """Ingest data from a file or directory."""
    paths = get_paths()
    from core.db import Database
    from data.ingest import ingest_json_file, ingest_csv_file, ingest_directory

    db = Database(paths["db"])
    path = Path(args.path)
    source_id = args.source_id or path.stem

    if path.is_dir():
        count = ingest_directory(db, path, source_id)
    elif path.suffix == ".json":
        count = ingest_json_file(db, path, source_id)
    elif path.suffix == ".csv":
        count = ingest_csv_file(db, path, source_id)
    else:
        print(f"  Unsupported file type: {path.suffix}")
        db.close()
        return

    stats = db.ingestion_stats()
    print(f"  Ingested {count} records from {path.name}")
    print(f"  Total: {stats['total_records']} ({stats['unconsumed']} unconsumed)")
    db.close()


def cmd_data_status(args):
    """Show ingestion buffer status."""
    paths = get_paths()
    from core.db import Database

    if not paths["db"].exists():
        print("  No database. Nothing ingested yet.")
        return

    db = Database(paths["db"])
    stats = db.ingestion_stats()
    print(f"  Total records:    {stats['total_records']}")
    print(f"  Unconsumed:       {stats['unconsumed']}")
    print(f"  Consumed:         {stats['consumed']}")
    db.close()


def cmd_run(args):
    """Run inference cycle(s)."""
    paths = get_paths()
    from core.db import Database
    from engine.inference import build_engine
    from engine.worker import run_worker, CycleConfig
    from template import Template

    # Find template
    template_path = paths["templates"] / f"{args.template_id}.json"
    if not template_path.exists():
        print(f"  Template '{args.template_id}' not found.")
        return

    # Find model
    model_path = paths["models"] / args.model
    if not (model_path / "config.json").exists():
        print(f"  Model '{args.model}' not found.")
        return

    template = Template.load(template_path)

    print(f"  Template: {template.metadata.name}")
    print(f"  Model:    {args.model}")
    print(f"  Cycles:   {args.cycles if args.cycles > 0 else 'unlimited'}")
    print(f"  Loading model...", end=" ", flush=True)

    # build_engine and run_worker grew required parameters the CLI never
    # learned about (config; default_max_tokens) — this path crashed with
    # TypeError since. The server's config file is honored when present so
    # CLI runs match dashboard runs.
    cfg_file = Path("courier_config.json")
    cfg = json.loads(cfg_file.read_text(encoding="utf-8")) if cfg_file.exists() else {}
    streamer, infer_fn = build_engine(str(model_path), config=cfg)
    print("done.", flush=True)

    db = Database(paths["db"])

    # Build data paths
    data_paths = {}
    for name in template.sources:
        for ext in [".json", ".csv"]:
            p = paths["data"] / f"test_{name}{ext}"
            if p.exists():
                data_paths[name] = str(p)
                break

    result = run_worker(
        db=db,
        template=template,
        infer_fn=infer_fn,
        data_paths=data_paths,
        default_max_tokens=int(cfg.get("default_max_tokens", 256) or 256),
        export_dir=paths["export"],
        cycle_config=CycleConfig(max_cycles=args.cycles),
    )

    print(f"\n  Completed: {result.cycles_completed} cycle(s)")
    print(f"  Tokens:    {result.total_tokens}")
    if result.errors:
        print(f"  Errors:    {len(result.errors)}")
        for e in result.errors:
            print(f"    {e}")
    db.close()


def cmd_cycle_status(args):
    """Show current cycle status."""
    paths = get_paths()
    from core.db import Database

    if not paths["db"].exists():
        print("  No database.")
        return

    db = Database(paths["db"])
    cycle = db.get_latest_cycle()
    if cycle is None:
        print("  No cycles recorded.")
    else:
        print(f"  Cycle:     {cycle['cycle_number']} ({cycle['id']})")
        print(f"  Status:    {cycle['status']}")
        print(f"  Template:  {cycle['template_id']}")
        print(f"  Tokens:    {cycle['tokens_generated']}")
        if cycle['error']:
            print(f"  Error:     {cycle['error']}")

        stages = db.get_stages(cycle["id"])
        if stages:
            print(f"  Stages:")
            for s in stages:
                print(f"    {s['stage_index']+1}. {s['label']} — {s['status']}")
    db.close()


def cmd_result_latest(args):
    """Show the most recent result."""
    paths = get_paths()
    from core.db import Database

    if not paths["db"].exists():
        print("  No database.")
        return

    db = Database(paths["db"])
    cycle = db.get_latest_cycle()
    if cycle is None or cycle["status"] != "complete":
        print("  No completed cycles.")
        db.close()
        return

    result_path = cycle.get("result_path")
    if result_path and Path(result_path).exists():
        print(Path(result_path).read_text(encoding="utf-8"))
    else:
        stages = db.get_stages(cycle["id"])
        for s in stages:
            print(f"## {s['label']}\n")
            print(s["output_text"] or "[no output]")
            print()
    db.close()


def cmd_result_list(args):
    """List all completed cycles."""
    paths = get_paths()
    from core.db import Database

    if not paths["db"].exists():
        print("  No database.")
        return

    db = Database(paths["db"])
    cycles = db.get_cycles()
    for c in cycles:
        ts = time.strftime("%Y-%m-%d %H:%M", time.localtime(c["created_at"]))
        print(f"  {c['id']}  cycle {c['cycle_number']:3d}  {c['status']:10s}  "
              f"{ts}  {c['tokens_generated']} tok")
    db.close()


# ── Argument Parser ──────────────────────────────────────────

def build_parser():
    parser = argparse.ArgumentParser(prog="courier", description="Courier Edge LLM")
    sub = parser.add_subparsers(dest="command")

    # start
    p = sub.add_parser("start", help="Start the server")
    p.add_argument("--insecure", action="store_true", help="Disable auth")
    p.add_argument("--port", type=int, default=8000)

    # status
    sub.add_parser("status", help="System status")

    # token
    token = sub.add_parser("token", help="Token management")
    token_sub = token.add_subparsers(dest="token_cmd")
    tc = token_sub.add_parser("create")
    tc.add_argument("--name", required=True)
    tc.add_argument("--read-only", action="store_true")
    token_sub.add_parser("list")
    tr = token_sub.add_parser("revoke")
    tr.add_argument("name")

    # model
    model = sub.add_parser("model", help="Model management")
    model_sub = model.add_subparsers(dest="model_cmd")
    model_sub.add_parser("list")
    mv = model_sub.add_parser("verify")
    mv.add_argument("id")

    # template
    tmpl = sub.add_parser("template", help="Template management")
    tmpl_sub = tmpl.add_subparsers(dest="template_cmd")
    tmpl_sub.add_parser("list")
    ts = tmpl_sub.add_parser("show")
    ts.add_argument("id")

    # ingest
    p = sub.add_parser("ingest", help="Ingest data")
    p.add_argument("path", help="File or directory to ingest")
    p.add_argument("--source-id", help="Source identifier")

    # data
    data = sub.add_parser("data", help="Data management")
    data_sub = data.add_subparsers(dest="data_cmd")
    data_sub.add_parser("status")

    # run
    p = sub.add_parser("run", help="Run inference cycle(s)")
    p.add_argument("template_id", help="Template ID")
    p.add_argument("--model", required=True, help="Model ID")
    p.add_argument("--cycles", type=int, default=1, help="Number of cycles (0=unlimited)")

    # cycle
    cycle = sub.add_parser("cycle", help="Cycle management")
    cycle_sub = cycle.add_subparsers(dest="cycle_cmd")
    cycle_sub.add_parser("status")

    # result
    result = sub.add_parser("result", help="View results")
    result_sub = result.add_subparsers(dest="result_cmd")
    result_sub.add_parser("latest")
    result_sub.add_parser("list")

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    dispatch = {
        "start": cmd_start,
        "status": cmd_status,
        "token": lambda a: {
            "create": cmd_token_create,
            "list": cmd_token_list,
            "revoke": cmd_token_revoke,
        }.get(a.token_cmd, lambda _: print("Usage: courier token {create|list|revoke}"))(a),
        "model": lambda a: {
            "list": cmd_model_list,
            "verify": cmd_model_verify,
        }.get(a.model_cmd, lambda _: print("Usage: courier model {list|verify}"))(a),
        "template": lambda a: {
            "list": cmd_template_list,
            "show": cmd_template_show,
        }.get(a.template_cmd, lambda _: print("Usage: courier template {list|show}"))(a),
        "ingest": cmd_ingest,
        "data": lambda a: {
            "status": cmd_data_status,
        }.get(a.data_cmd, lambda _: print("Usage: courier data {status}"))(a),
        "run": cmd_run,
        "cycle": lambda a: {
            "status": cmd_cycle_status,
        }.get(a.cycle_cmd, lambda _: print("Usage: courier cycle {status}"))(a),
        "result": lambda a: {
            "latest": cmd_result_latest,
            "list": cmd_result_list,
        }.get(a.result_cmd, lambda _: print("Usage: courier result {latest|list}"))(a),
    }

    handler = dispatch.get(args.command)
    if handler:
        handler(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
