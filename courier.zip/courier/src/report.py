"""Cycle receipt renderer — the canonical, persistent artifact.

This is the server-side twin of the dashboard's report view-model. The
worker renders the receipt here, automatically, as the final durable step
of every cycle (the "deadman" copy that survives on the export volume even
if the SSD/database is lost). Any API endpoint that wants the same markdown
should render it from here too, so the archived file and the dashboard
popout are projections of one view-model and cannot drift.

Timestamps are emitted as explicit UTC: a receipt has to be unambiguous
when read off a USB stick on some other machine, in some other timezone,
possibly years later.
"""

import json
from datetime import datetime, timezone
from urllib.parse import quote


# ── Formatting helpers ───────────────────────────────────────

def _epoch_fmt(ts):
    """Full UTC timestamp, e.g. '7 June 2026 18:56:26 UTC'."""
    if not ts:
        return "—"
    d = datetime.fromtimestamp(ts, tz=timezone.utc)
    return f"{d.day} {d.strftime('%B %Y %H:%M:%S')} UTC"


def _short_date(ts):
    """Date only, e.g. '7 June 2026'."""
    if not ts:
        return "—"
    d = datetime.fromtimestamp(ts, tz=timezone.utc)
    return f"{d.day} {d.strftime('%B %Y')}"


def _fmt_int(n):
    try:
        return f"{int(n):,}"
    except (TypeError, ValueError):
        return str(n)


def _fmt_dur(s):
    if not isinstance(s, (int, float)):
        return "—"
    s = int(round(s))
    if s < 60:
        return f"{s}s"
    if s < 3600:
        return f"{s // 60}m {s % 60}s"
    return f"{s // 3600}h {(s % 3600) // 60}m"


def _stage_field(st, attr, *fallbacks):
    """Read a field from a StageResult object or a DB row dict."""
    if isinstance(st, dict):
        for key in (attr, *fallbacks):
            if key in st and st[key] is not None:
                return st[key]
        return None
    return getattr(st, attr, None)


# ── View-model: the single source of truth ───────────────────

def build_view_model(cycle, config, stages, *, template=None, completed_at=None,
                     images=None):
    """Assemble the cycle receipt view-model.

    Args:
        cycle:   DB cycle row (dict) — cycle_number, status, timestamps,
                 error, tokens_generated, template_id.
        config:  Parsed cycle config (dict) — user_name, project_name,
                 model_id, and any sampling parameters.
        stages:  Iterable of StageResult objects or stage row dicts
                 (each exposing a label and an output/output_text).
        template: Optional Template, for name/version/model fallbacks.
        completed_at: Optional completion epoch (the worker passes this,
                 since the row is not updated until after the write).
    """
    config = config or {}
    meta = getattr(template, "metadata", None)
    model_obj = getattr(template, "model", None)

    number = cycle.get("cycle_number")
    cycle_id = cycle.get("id", "—")
    tmpl_name = (getattr(meta, "name", None)
                 or config.get("template_id")
                 or cycle.get("template_id") or "—")
    tmpl_version = getattr(meta, "version", None)
    template_label = tmpl_name + (f" v{tmpl_version}" if tmpl_version else "")
    model = (config.get("model_id")
             or getattr(model_obj, "id", None) or "—")

    created = cycle.get("created_at")
    infer_started = cycle.get("infer_started")
    completed = completed_at if completed_at is not None else cycle.get("completed_at")
    if completed and infer_started:
        duration = completed - infer_started
    else:
        duration = cycle.get("time_s")

    tstages = list(getattr(template, "stages", None) or [])
    stage_list = []
    for i, st in enumerate(stages or []):
        _schema = (getattr(tstages[i], "output_schema", None)
                   if i < len(tstages) else None)
        stage_list.append({
            "n": i + 1,
            "label": _stage_field(st, "label") or "",
            "output": _maybe_expand(
                _schema, _stage_field(st, "output", "output_text") or ""),
        })

    meta_sections = [
        ("Author", [
            ("Operator", config.get("user_name") or "—"),
            ("Project", config.get("project_name") or "—"),
            ("Date", _short_date(created)),
        ]),
        ("Model & Template", [
            ("Model", model),
            ("Template", template_label),
            ("Stages", str(len(stage_list))),
        ]),
        ("Timeline", [
            ("Created", _epoch_fmt(created)),
            ("Inference Started", _epoch_fmt(infer_started)),
            ("Completed", _epoch_fmt(completed)),
            ("Wall time", _fmt_dur(duration)),
        ]),
    ]

    # Sampling parameters — render whatever the config actually carries.
    candidates = [
        ("Temperature", config.get("temperature")),
        ("Top-p", config.get("top_p")),
        ("Top-k", config.get("top_k")),
        ("Presence Penalty", config.get("presence_penalty")),
        ("Max Tokens", config.get("max_new_tokens")),
        ("Thinking Mode", "Enabled" if config.get("enable_thinking") else None),
        ("Checkpoint Interval",
         f"{config['checkpoint_interval']} tokens" if config.get("checkpoint_interval") else None),
        ("Max RAM",
         f"{config['max_ram_percent']}% of total" if config.get("max_ram_percent") else None),
        ("Layer Delay",
         f"{config['layer_delay']}s" if config.get("layer_delay") else None),
    ]
    param_rows = [
        ("Status", str(cycle.get("status", "—"))),
        ("Total Tokens", _fmt_int(cycle.get("tokens_generated") or 0)),
    ]
    param_rows += [(k, str(v)) for k, v in candidates if v is not None]

    # Joules-per-verdict: the cost line. Method rides along so an estimate
    # can never be mistaken for a measurement.
    _ej = cycle.get("energy_j")
    if _ej is not None:
        _em = cycle.get("energy_method") or "?"
        _row = f"{_ej:.0f} J ({_em})"
        if duration and duration > 0:
            _row += f" · {(_ej / duration):.1f} W avg"
        param_rows.append(("Energy", _row))

    img_list = []
    for im in (images or []):
        name = im.get("name") if isinstance(im, dict) else str(im)
        if not name:
            continue
        img_list.append({"name": name, "url": "/api/image/" + quote(name)})

    return {
        "title": f"Cycle #{number} — {tmpl_name}",
        "cycle_id": cycle_id,
        "meta_sections": meta_sections,
        "param_rows": param_rows,
        "stages": stage_list,
        "images": img_list,
        "error": cycle.get("error") or "",
        "generated_at": _short_date(datetime.now(tz=timezone.utc).timestamp()),
    }


# ── Markdown projection ───────────────────────────────────────

def _maybe_expand(schema, text):
    """The clerk: expand a stage's dispatch into the receipt, deterministically
    and for free. The raw dispatch always rides along — nothing the model said
    is hidden — and on any mismatch the model's text is shown verbatim with a
    note. The renderer never guesses."""
    if not schema or not text:
        return text
    from template import expand_dispatch
    exp = expand_dispatch(schema, text)
    if not exp["ok"]:
        return (text.rstrip() + "\n\n**Note:** dispatch did not match the "
                f"schema ({exp['note']}) — output shown verbatim.")
    esc = lambda x: str(x).replace("|", "\\|")
    lines = ["| Field | Value |", "|---|---|"]
    lines += [f"| {esc(label)} | {esc(value)} |" for label, value in exp["rows"]]
    md = "\n".join(lines) + f"\n\n*Dispatch:* `{exp['raw']}`"
    if exp["note"]:
        md += f"\n\n**Note:** {exp['note']}"
    return md


def _stages_markdown(stages):
    if not stages:
        return "*No results available.*\n"
    blocks = [f"### {st['n']}. {st['label']}\n\n{st['output']}" for st in stages]
    return "\n\n---\n\n".join(blocks) + "\n"


def render_markdown(vm):
    """Render a view-model to the canonical markdown receipt."""
    out = [f"# {vm['title']}\n"]
    for title, items in vm["meta_sections"]:
        out.append(f"## {title}\n")
        out.append("| Field | Value |")
        out.append("|---|---|")
        out += [f"| {label} | {value} |" for label, value in items]
        out.append("")
    out.append("## Sampling Parameters\n")
    out.append("| Parameter | Value |")
    out.append("|---|---|")
    out += [f"| {k} | {v} |" for k, v in vm["param_rows"]]
    out.append("")
    out.append("## Results\n")
    out.append(_stages_markdown(vm["stages"]))
    if vm.get("images"):
        out.append("## Source Images\n")
        out += [f"![{im['name']}]({im['url']})" for im in vm["images"]]
        out.append("")
    if vm["error"]:
        out.append(f"## Error\n\n{vm['error']}\n")
    return "\n".join(out)


def render_receipt(cycle, config, stages, *, template=None, completed_at=None,
                   images=None):
    """View-model → markdown in one call (the worker's entry point)."""
    vm = build_view_model(cycle, config, stages,
                          template=template, completed_at=completed_at,
                          images=images)
    return render_markdown(vm)


def normalize_config_json(raw):
    """Guarantee a cycle's stored config is presentable JSON.

    Returns (json_str, repaired, error):
      valid JSON        -> (raw, False, None)           - untouched
      Python-repr row   -> (re-dumped JSON, True, None) - legacy builds
      anything else     -> ("{}", False, reason)        - degrade loudly

    The receipt contract this serves: a malformed config column must never
    cost the client the row's honest ledger facts. The API sends the error
    reason alongside; the dashboard displays it instead of silent dashes.
    Repair uses ast.literal_eval - literals only, never code execution.
    """
    if not isinstance(raw, str) or not raw:
        return (raw, False, None)
    try:
        json.loads(raw)
        return (raw, False, None)
    except ValueError:
        pass
    try:
        import ast
        return (json.dumps(ast.literal_eval(raw)), True, None)
    except (ValueError, SyntaxError):
        return ("{}", False,
                "stored config unparseable; ledger facts unaffected")
