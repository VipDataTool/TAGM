"""FastAPI server: dashboard + API + background inference.

Two-loop architecture:
- Fast loop: HTTP endpoints (always responsive)
- Slow loop: background inference worker (runs cycles)

Communication: SQLite (state) + SSE (dashboard push).
"""

import asyncio
import json
import os
import socket
import sys
import tempfile
import threading
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

import psutil
from fastapi import Depends, FastAPI, File, Form, HTTPException, Header, Request, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse, StreamingResponse

sys.path.insert(0, str(Path(__file__).parent))

from core.db import Database
from core.security import TokenManager, write_posture
from core.adapter.registry import detect_adapter
from engine.inference import build_engine
from engine.worker import run_worker, recover_interrupted, CycleConfig, \
    get_meter
from engine.signals import CancelledError, PausedError
from engine.checkpoint import make_checkpoint_callback
from template import Template
from template_store import TemplateStore
from report import render_receipt, _maybe_expand, normalize_config_json

# ── Paths ────────────────────────────────────────────────────

STATIC_DIR = Path(__file__).parent.parent / "static"
MODELS_DIR = Path(__file__).parent.parent / "models"
TEMPLATES_DIR = Path(__file__).parent.parent / "templates" / "builtin"
TEMPLATES_FILE = Path(__file__).parent.parent / "templates" / "templates.json"
# Single source of truth for templates: one JSON file, seeded once from the
# read-only builtin/ shipping templates. See courier-ux-design-spec.md §5.
TEMPLATE_STORE = TemplateStore(TEMPLATES_FILE, TEMPLATES_DIR)
EXPORT_DIR = Path(__file__).parent.parent / "export"
IMPORT_DIR = Path(__file__).parent.parent / "import"
DATA_DIR = Path(__file__).parent.parent / "data"
IMAGE_SRC_DIR = Path(__file__).parent.parent / "image-src"
DB_PATH = Path(__file__).parent.parent / "courier.db"
CONFIG_PATH = Path(__file__).parent.parent / "courier_config.json"

PROJECT_ROOT = Path(__file__).parent.parent
ENV_FILE = PROJECT_ROOT / ".env"


def _load_dotenv(path: Path = ENV_FILE) -> None:
    """Populate os.environ from a project-root .env file (turnkey secrets).

    Dependency-free KEY=VALUE parser: blank lines and #-comments are ignored,
    surrounding quotes are stripped, and an optional leading `export ` is
    allowed. Real environment variables ALWAYS win — a value already present
    (a shell export, a Codespaces/CI secret) is never overwritten — so .env is
    purely a fallback for local laptop runs. Used for HF_TOKEN (gated model
    downloads) and COURIER_INSECURE; see .env.example.
    """
    try:
        if not path.exists():
            return
        for line in path.read_text(encoding="utf-8").splitlines():
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            if s.startswith("export "):
                s = s[len("export "):].lstrip()
            if "=" not in s:
                continue
            key, _, val = s.partition("=")
            key = key.strip()
            val = val.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = val
    except Exception:
        pass  # a malformed .env must never prevent the server from starting


# Load .env at import so any secret it carries is in the environment before
# the first code path (HF download, auth) reads it.
_load_dotenv()

FACTORY_DEFAULTS = {
    "max_cycles": 1,
    "trigger_threshold": 0,
    "auto_resume": True,
    "checkpoint_interval": 10,
    "project_name": "Untitled Project",
    "user_name": "operator",
    "pacing_mode": "on_demand",
    "interval_seconds": 0,
    "scheduled_time": "",
    "alert_threshold": 0,
    "refresh_interval": 5,
    # Inference defaults — generic fallback values. Model-specific
    # recommended defaults live in each adapter's recommended_defaults()
    # method and are merged on first model load. See:
    #   core/adapter/qwen3.py   → Qwen3 family defaults
    #   core/adapter/qwen35.py  → Qwen3.5 family defaults
    #   core/adapter/llama3.py  → Llama 3.x family defaults
    #   core/adapter/gemma3.py  → Gemma 3 family defaults
    "temperature": 0.7,
    "top_p": 0.9,
    "top_k": 20,
    "presence_penalty": 0.0,
    "enable_thinking": False,
    "max_new_tokens": 2048,
    "max_images_per_cycle": 8,
    "max_kv_ram_layers": -1,
    "kv_cache_dir": "",
    "layer_delay": 0.0,
    # Pipeline throttle (see courier-throttle-design-spec.md).
    # max_ram_percent: % of TOTAL system RAM for resident weights (0 = off,
    #   stream). max_cpu_percent: dynamic-brake utilization setpoint (100 = off).
    #   ram_reserve_gb: hard RAM floor left for the OS + collector.
    # 50, not 0: a fresh install should not pay full streaming tax on a
    # model that fits in RAM. The hard reserve still protects the OS and
    # collector; mission deployments dial DOWN explicitly. Saved configs
    # override this — changing it never disturbs an existing install.
    "max_ram_percent": 50,
    "max_cpu_percent": 100,
    "ram_reserve_gb": 1.0,
    # Energy metering (estimate method). ONE source of truth: this config,
    # edited in Settings → System — not an env var. Pushed onto the live
    # meter by _apply_live_energy at boot and on every save.
    "watts_per_core": 6.0,
    "energy_sample_interval": 5.0,
    "max_models_disk": 3,
    "export_dir": "./export/",
    "default_model": "",
    # Prefer GGUF variants: catalog models with a published GGUF quant
    # (validated families only) list and load as that quant instead of
    # safetensors+INT8. OFF = byte-for-byte the safetensors behavior.
    "prefer_gguf": False,
    # Auto-ingest: watch import folder for new data files
    "auto_ingest": False,
    "import_dir": "./import/",
    "ingest_poll_hours": 1,
    "ingest_archive": True,
    # ── Multi-model & speculative decoding ───────────────────────
    # See courier-multimodel-design-spec.md. Both blocks default OFF:
    # with these values the runtime is byte-for-byte a single-model
    # build — no secondary/draft weights are made resident and the
    # speculative decode path is never entered. Opt in by naming a
    # draft model (Channel B) and/or a secondary model (Channel A).
    #   speculative.enabled     gate for the draft/verify decode loop
    #   speculative.draft_model  small model path used as the drafter
    #   speculative.block_k      draft tokens proposed per verify pass
    #   registry.secondary_model second resident model for stage routing
    "speculative": {"enabled": False, "draft_model": None, "block_k": 4},
    "registry": {"secondary_model": None},
}


# ── Model validation ──────────────────────────────────────────

def _model_ready(path) -> bool:
    """True if a model directory has config AND weight files."""
    path = Path(path)
    if not (path / "config.json").exists():
        return False
    has_weights = (
        list(path.glob("model*.safetensors")) or
        list(path.glob("model-*.safetensors")) or
        list(path.glob("*.gguf"))
    )
    return bool(has_weights)


def _model_incomplete(path) -> bool:
    """True if config.json exists but no weight files — partial download."""
    path = Path(path)
    if not (path / "config.json").exists():
        return False
    return not _model_ready(path)


def _model_size_gb(path) -> float:
    """Total size of a model directory in GB."""
    path = Path(path)
    if not path.exists():
        return 0.0
    total = sum(f.stat().st_size for f in path.rglob("*") if f.is_file())
    return total / (1024 ** 3)


def _ready_models_on_disk() -> list[Path]:
    """List model directories that are fully downloaded and valid."""
    result = []
    for d in sorted(MODELS_DIR.glob("*")):
        if _model_ready(d):
            result.append(d)
    return result


def _cleanup_incomplete(path) -> bool:
    """Remove an incomplete model directory. Returns True if cleaned."""
    import shutil
    path = Path(path)
    if _model_incomplete(path):
        try:
            shutil.rmtree(path)
            return True
        except Exception:
            return False
    return False


def _evict_lru_model(keep: str = "") -> dict:
    """Remove the oldest ready model (by mtime) to free disk space.

    Skips the currently loaded model and `keep` (the one being loaded).
    Returns {evicted, freed_gb} or {evicted: None} if nothing to evict.
    """
    import shutil
    loaded_name = Path(STATE.get("model_path") or "").name
    candidates = []
    for d in _ready_models_on_disk():
        if d.name == loaded_name or d.name == keep:
            continue
        mtime = max(f.stat().st_mtime for f in d.rglob("*") if f.is_file())
        candidates.append((mtime, d))
    if not candidates:
        return {"evicted": None, "freed_gb": 0}
    candidates.sort()  # oldest first
    _, oldest = candidates[0]
    size = _model_size_gb(oldest)
    try:
        shutil.rmtree(oldest)
        return {"evicted": oldest.name, "freed_gb": round(size, 2)}
    except Exception as e:
        return {"evicted": None, "freed_gb": 0, "error": str(e)}


def apply_adapter_defaults(adapter) -> None:
    """Apply model-family defaults to inference parameters.

    Called when a model is loaded. Unconditionally overwrites inference
    parameters with the adapter's recommended values so switching from
    Qwen to Llama (or vice versa) gives the user the right starting
    point. Non-inference settings (project name, export dir, etc.)
    are never touched.
    """
    defaults = adapter.recommended_defaults()
    if not defaults:
        return
    cfg = load_config()
    for key, meta in defaults.items():
        value = meta["value"] if isinstance(meta, dict) else meta
        if key in FACTORY_DEFAULTS:
            cfg[key] = value
    save_config(cfg)


def get_adapter_tips() -> dict:
    """Return tooltip text from the current adapter's recommended defaults.

    Used by /api/config/defaults to serve model-specific tooltips to
    the dashboard. Returns {key: tip_text} for all parameters that
    have adapter-specific tips, empty dict if no adapter is loaded.
    """
    adapter = STATE.get("adapter")
    if adapter is None:
        return {}
    defaults = adapter.recommended_defaults()
    tips = {}
    for key, meta in defaults.items():
        if isinstance(meta, dict) and "tip" in meta:
            tips[key] = meta["tip"]
    return tips


def load_config() -> dict:
    if CONFIG_PATH.exists():
        try:
            with open(CONFIG_PATH, encoding="utf-8") as f:
                merged = {**FACTORY_DEFAULTS, **json.load(f)}
            # Deep-merge the nested-dict blocks (speculative, registry) so a
            # partially-specified block keeps its default sub-keys. Only keys
            # whose factory default is itself a dict are affected — every
            # pre-existing scalar setting is untouched.
            for key, default in FACTORY_DEFAULTS.items():
                if isinstance(default, dict):
                    user_block = merged.get(key)
                    merged[key] = {**default, **user_block} if isinstance(user_block, dict) else dict(default)
            return merged
        except Exception:
            pass
    return dict(FACTORY_DEFAULTS)


def save_config(cfg: dict) -> None:
    allowed = set(FACTORY_DEFAULTS.keys())
    clean = {k: v for k, v in cfg.items() if k in allowed}
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(clean, f, indent=2)


def _reject_traversal(name: str) -> None:
    """Reject a user-supplied name that could escape its base directory.

    One guard shared by every route that joins an external name onto a base
    dir (image serving, model read + delete, ingest upload). Raises 404 on any
    path separator or parent reference — 404 rather than 400 so it doesn't
    confirm intent.
    """
    if not name or "/" in name or "\\" in name or ".." in name:
        raise HTTPException(404)


def _max_upload_bytes() -> int:
    """Upload ceiling for the file-accepting endpoints, in bytes.

    Env-tunable (COURIER_MAX_UPLOAD_MB, default 256) because the right cap is
    hardware-relative: a RAM-starved field unit should refuse a runaway upload
    long before it swaps. Registered in the README's recognized-variables
    table and `.env.example`. Read per-request so `.env` load order can't
    stale it; a malformed value falls back to the default loudly.
    """
    raw = os.environ.get("COURIER_MAX_UPLOAD_MB", "")
    try:
        mb = float(raw) if raw else 256.0
        if mb <= 0:
            raise ValueError
    except ValueError:
        print(f"  [upload] ignoring malformed COURIER_MAX_UPLOAD_MB={raw!r}; "
              f"using 256", flush=True)
        mb = 256.0
    return int(mb * 1024 * 1024)


async def _read_upload_bounded(file) -> bytes:
    """Read an UploadFile fully, aborting with 413 past the operator cap.

    Chunked so the cap is enforced while reading, not after the whole body
    already sits in memory — the failure this prevents is an OOM'd field
    node, not a slow request.
    """
    cap = _max_upload_bytes()
    chunks: list[bytes] = []
    total = 0
    while True:
        chunk = await file.read(1024 * 1024)
        if not chunk:
            break
        total += len(chunk)
        if total > cap:
            raise HTTPException(
                413, f"Upload exceeds the {cap // (1024 * 1024)} MB limit "
                     f"(COURIER_MAX_UPLOAD_MB)")
        chunks.append(chunk)
    return b"".join(chunks)


def _sync_primary_engine() -> None:
    """Mirror the current single-model fields into STATE['engines'].

    Additive bookkeeping only. STATE['streamer'] / ['infer_fn'] /
    ['model_path'] stay the authoritative aliases every existing call
    site uses; this keeps the opt-in EngineRegistry's 'primary' role in
    lockstep with them after any (un)load. With default config the
    registry ends up holding exactly one entry, so nothing downstream
    behaves differently. Never raises into the caller.
    """
    try:
        from engine.registry import EngineRegistry, make_entry
        streamer = STATE.get("streamer")
        if streamer is None:
            STATE["engines"] = None
            return
        reg = STATE.get("engines")
        if not isinstance(reg, EngineRegistry):
            reg = EngineRegistry()
        reg.set_primary(make_entry(
            streamer=streamer,
            infer_fn=STATE.get("infer_fn"),
            model_path=STATE.get("model_path") or "",
        ))
        STATE["engines"] = reg
    except Exception as e:  # pragma: no cover - bookkeeping must never break load
        print(f"  (engine registry sync skipped: {e})", flush=True)


def _draft_footprint_bytes(draft_dir: Path) -> int:
    """RESIDENT footprint estimate for a draft engine, from disk.

    The resident cache stores DEQUANTIZED bf16 tensors, so an INT8 model's
    in-RAM footprint is ~2x its disk size (the marker file is the tell).
    Plain bf16 safetensors are resident at disk size. GGUF dequantizes to
    bf16 too — 2x is a conservative estimate for Q8-class quants.
    Pure (path in, int out) so it cold-tests without weights.
    """
    st_bytes = sum(f.stat().st_size for f in draft_dir.glob("*.safetensors"))
    if st_bytes:
        if (draft_dir / "quantization_config.json").exists():
            return st_bytes * 2
        return st_bytes
    return sum(f.stat().st_size for f in draft_dir.glob("*.gguf")) * 2


def _partition_for_draft(cfg: dict, draft_footprint: int, total_ram: int):
    """Admission decision for a two-engine pair (multimodel spec §5).

    Returns (partition_dict, None) when the pair fits, or (None, reason)
    when it must be refused. Pure — RAM is injected — so it verifies cold,
    like the sizing functions it fronts.
    """
    from engine.sizing import partition_resident_budget, resident_budget_bytes
    pct = float(cfg.get("max_ram_percent", 0) or 0)
    reserve = int(float(cfg.get("ram_reserve_gb", 1.0)) * (1024 ** 3))
    budget = resident_budget_bytes(total_ram, pct, reserve)
    if budget <= 0:
        return None, ("speculative draft refused: MAX RAM dial is off — a "
                      "resident draft needs a resident budget (spec §5 "
                      "refuses rather than thrash)")
    part = partition_resident_budget(total_ram, pct, reserve, draft_footprint)
    if part is None:
        return None, (f"speculative draft refused: draft needs "
                      f"{draft_footprint / 2**30:.2f} GB resident, but the "
                      f"{budget / 2**30:.2f} GB budget can't hold it plus a "
                      f"usable primary (>=0.5 GB floor). Raise MAX RAM or "
                      f"pick a smaller draft.")
    return part, None


def _apply_engine_budgets(cfg: dict, primary_streamer=None) -> None:
    """Apply the single resident-budget authority to the PRIMARY engine.

    With no draft resident: the plain single-engine budget (same math
    build_engine used). With a draft resident (STATE['draft_footprint']):
    the §5 partition's primary_cap, so the pair's caps never overlap — the
    draft build previously handed BOTH engines a full budget, which is the
    2x over-commit that OOM'd the first speculative cycle. The draft's own
    cap is pinned once at admission and never changes. If a live dial change
    makes the pair unfit, fall back to streaming (always memory-safe) until
    the config-save re-wire re-admits or tears the draft down. GGUF primaries
    have no set_resident_budget and are left untouched, as before.
    Never raises into the caller.
    """
    try:
        streamer = primary_streamer or STATE.get("streamer")
        shards = getattr(streamer, "shards", None)
        if shards is None or not hasattr(shards, "set_resident_budget"):
            return
        import psutil
        from engine.sizing import resident_budget_bytes
        total = psutil.virtual_memory().total
        footprint = STATE.get("draft_footprint") or 0
        if footprint:
            part, _reason = _partition_for_draft(cfg, footprint, total)
            if part is not None:
                shards.set_resident_budget(True, part["primary_cap"])
            else:
                shards.set_resident_budget(False, 0)  # stream until re-wire
            return
        pct = float(cfg.get("max_ram_percent", 0) or 0)
        reserve = int(float(cfg.get("ram_reserve_gb", 1.0)) * (1024 ** 3))
        budget = resident_budget_bytes(total, pct, reserve) if pct > 0 else 0
        shards.set_resident_budget(budget > 0, budget)
    except Exception:
        pass


def _build_draft_if_configured(cfg: dict):
    """Build the speculative-decoding draft engine if it's opted in.

    Returns (draft_streamer, draft_path, block_k). When speculative decoding
    is off, no draft model is set, the draft isn't ready on disk, or the build
    fails, returns (None, None, block_k) and the primary runs single-model —
    a draft problem must NEVER take down the primary load. The outcome is also
    recorded in STATE['draft_error'] (None on success/disabled, else a reason
    string) so the dashboard can show *why* SD didn't engage instead of failing
    silently to the server log.
    """
    spec = cfg.get("speculative") or {}
    block_k = int(spec.get("block_k", 4) or 4)
    if not spec.get("enabled") or not spec.get("draft_model"):
        STATE["draft_error"] = None
        STATE["draft_footprint"] = None
        _apply_engine_budgets(cfg)  # restore single-engine budget on re-wire
        return None, None, block_k
    draft_dir = MODELS_DIR / str(spec["draft_model"])
    if not _model_ready(draft_dir):
        msg = f"draft '{spec['draft_model']}' not found on disk"
        STATE["draft_error"] = msg
        STATE["draft_footprint"] = None
        _apply_engine_budgets(cfg)
        print(f"  Speculative decoding: {msg} — running single-model.", flush=True)
        return None, None, block_k
    # §5 admission BEFORE building: one budget, two engines, non-overlapping
    # caps. Without this, the draft inherited the same config as the primary
    # and both shard managers claimed a FULL resident budget — a 2x
    # over-commit that hard-OOM'd the box the first time a speculative
    # cycle ran. Refuse (per spec) rather than degrade into thrash.
    try:
        import psutil
        footprint = _draft_footprint_bytes(draft_dir)
        part, refusal = _partition_for_draft(
            cfg, footprint, psutil.virtual_memory().total)
    except Exception as e:
        part, refusal = None, f"speculative draft refused: partition failed ({e})"
    if part is None:
        STATE["draft_error"] = refusal
        STATE["draft_footprint"] = None
        _apply_engine_budgets(cfg)
        print(f"  {refusal} — running single-model.", flush=True)
        return None, None, block_k
    try:
        print(f"  Loading draft model: {draft_dir.name} (speculative decoding, block_k={block_k})...", flush=True)
        draft_streamer, _ = build_engine(str(draft_dir), config=cfg)
        # Pin the draft at its full footprint and hand the primary the
        # remainder — the partition's caller contract.
        dshards = getattr(draft_streamer, "shards", None)
        if dshards is not None and hasattr(dshards, "set_resident_budget"):
            dshards.set_resident_budget(True, part["secondary_cap"])
        STATE["draft_footprint"] = footprint
        _apply_engine_budgets(cfg)  # caps a live primary now (re-wire path);
                                    # boot paths apply it right after build_engine
        print(f"  Resident budget partitioned (spec §5): draft pinned at "
              f"{part['secondary_cap'] / 2**30:.2f} GB, primary capped at "
              f"{part['primary_cap'] / 2**30:.2f} GB.", flush=True)
        # Warn if the draft is a different model family from the primary.
        # The SD algorithm is still correct (verifier is the source of truth),
        # but a cross-family draft's proposals will all be rejected because the
        # vocabularies don't match, making it slower than single-model.
        primary = STATE.get("adapter")
        if primary is not None:
            # gemma3_text (1B) and gemma3 (4B+) are ONE family — same
            # tokenizer — despite distinct model_type strings; normalize
            # before comparing so the legitimate 1B→4B+ pair doesn't warn.
            _fam = lambda t: {"gemma3_text": "gemma3"}.get(t, t)
            p_type = _fam(getattr(primary.config, "model_type", ""))
            d_type = _fam(getattr(draft_streamer.adapter.config, "model_type", ""))
            if p_type and d_type and p_type != d_type:
                print(f"  ⚠ Draft family mismatch: primary is '{p_type}', "
                      f"draft is '{d_type}'. Speculative decoding will work "
                      f"but all draft tokens will be rejected (different "
                      f"tokenizer/vocabulary). Use a same-family draft.",
                      flush=True)
        STATE["draft_error"] = None
        return draft_streamer, str(draft_dir), block_k
    except Exception as e:
        msg = f"draft load failed: {e}"
        STATE["draft_error"] = msg
        STATE["draft_footprint"] = None
        _apply_engine_budgets(cfg)
        print(f"  {msg} — running single-model.", flush=True)
        return None, None, block_k


def _register_draft(draft_streamer, draft_path) -> None:
    """Track the draft engine under the 'draft' role (additive). Clears any
    stale draft from a previous load first; with no draft, leaves the registry
    single. Never raises into the caller."""
    try:
        from engine.registry import EngineRegistry, make_entry
        reg = STATE.get("engines")
        if not isinstance(reg, EngineRegistry):
            return
        reg.remove("draft")  # drop a stale draft from a prior load (no-op if absent)
        if draft_streamer is not None:
            reg.set("draft", make_entry(streamer=draft_streamer, infer_fn=None, model_path=draft_path or ""))
    except Exception as e:  # pragma: no cover
        print(f"  (draft registry note: {e})", flush=True)


def _rewire_speculative() -> None:
    """Apply the current speculative config to the already-loaded primary
    WITHOUT re-streaming it: (re)build or tear down the draft engine and
    re-wrap the primary's infer_fn. No-op when no model is loaded. Runs in a
    background thread on config save (draft streaming can be slow). Never
    raises into the caller.
    """
    streamer = STATE.get("streamer")
    if streamer is None:
        return
    try:
        from engine.inference import make_primary_infer_fn
        cfg = load_config()
        draft_streamer, draft_path, block_k = _build_draft_if_configured(cfg)
        STATE["infer_fn"] = make_primary_infer_fn(
            streamer, cfg, draft_streamer=draft_streamer, speculative_block_k=block_k)
        _sync_primary_engine()
        _register_draft(draft_streamer, draft_path)
        print(f"  Speculative decoding re-wired: draft "
              f"{'ON ('+Path(draft_path).name+')' if draft_streamer is not None else 'OFF'}", flush=True)
    except Exception as e:  # pragma: no cover
        print(f"  (speculative re-wire skipped: {e})", flush=True)


# Per-cycle disk-write accounting. Only one cycle is active at a time, so we
# keep a single baseline of psutil's cumulative write counter captured the
# first time we observe the active cycle and report the delta since.
_CYCLE_IO = {"cycle_id": None, "base": 0}


def _disk_writes_lifetime_gb():
    """Best-effort cumulative disk writes (GB) via psutil's since-boot counter.

    Honest caveats: this is writes since boot, container/overlay-scoped, NOT
    true SSD lifetime/TBW (SMART wear data isn't readable from a sandbox or
    most containers). Returns None when the counter is unavailable so the UI
    can show '—' instead of a misleading 0.
    """
    try:
        io = psutil.disk_io_counters()
        if not io:
            return None
        return round(io.write_bytes / (1024 ** 3), 1)
    except Exception:
        return None


def _cycle_disk_writes_mb(cycle_id, stored):
    """Best-effort MB written during the active cycle: the delta of psutil's
    cumulative write counter from when this cycle was first observed. Falls back
    to the stored column then 0. Approximate + container-scoped (see above)."""
    try:
        io = psutil.disk_io_counters()
        if io:
            if _CYCLE_IO["cycle_id"] != cycle_id:
                _CYCLE_IO["cycle_id"] = cycle_id
                _CYCLE_IO["base"] = io.write_bytes
            return round(max(0, io.write_bytes - _CYCLE_IO["base"]) / (1024 ** 2), 1)
    except Exception:
        pass
    return stored or 0


def _speculative_status() -> dict:
    """Live speculative-decoding state for the dashboard MODEL panel.

    Reflects whether a draft engine is actually resident (the registry 'draft'
    role), not merely whether the config opted in — so the panel can't claim SD
    is engaged if the draft failed to load on the rig. When SD was requested but
    isn't active, 'error' carries the reason so the UI can show it loudly.
    """
    try:
        from engine.registry import EngineRegistry
        reg = STATE.get("engines")
        active = isinstance(reg, EngineRegistry) and reg.has("draft")
        spec = load_config().get("speculative") or {}
        requested = bool(spec.get("enabled") and spec.get("draft_model"))
        name = ""
        if active:
            draft = reg.get("draft") or {}
            if draft.get("model_path"):
                name = Path(draft["model_path"]).name
        error = None
        if requested and not active:
            error = STATE.get("draft_error") or "draft did not load"
        return {
            "requested": requested,
            "active": bool(active),
            "draft_model": name or (spec.get("draft_model") or ""),
            "block_k": int(spec.get("block_k", 4) or 4),
            "error": error,
        }
    except Exception as e:
        print(f"  [speculative status] could not read draft state: {e}", flush=True)
        return {"requested": False, "active": False, "draft_model": "", "block_k": 4,
                "error": f"status unavailable: {e}"}

def _recovery_effective_config(interrupted: dict, cfg: dict) -> dict:
    """Effective config for resuming an interrupted cycle.

    A job is a self-contained record: the RUN panel's widgets are folded
    into the job at enqueue, and create_cycle pins that job's settings
    into the cycle row's config snapshot. Recovery therefore derives its
    settings from the INTERRUPTED CYCLE'S OWN SNAPSHOT — never from the
    live system config, which was never told about the job's per-run
    overrides. (Before this helper, recovery rebuilt the job from `cfg`,
    so a crash mid-cycle silently resumed under factory-ish settings,
    discarding the operator's max-tokens/temperature decorations.)

    The system config remains the fallback for anything the snapshot
    does not carry, and a malformed or missing snapshot degrades to a
    plain copy of `cfg` — recovery must never fail because a row is odd.

    Args:
        interrupted: the interrupted cycle's DB row; its "config" field
            is the JSON snapshot create_cycle stored (str or dict).
        cfg: the live system config. Read only; never mutated.

    Returns:
        A new dict shaped like `cfg` with the snapshot's per-run
        settings (max_new_tokens, temperature) overlaid.
    """
    snap = interrupted.get("config") or {}
    if isinstance(snap, str):
        try:
            snap = json.loads(snap)
        except (ValueError, TypeError):
            snap = {}
    if not isinstance(snap, dict):
        snap = {}
    eff = dict(cfg)
    for key in ("max_new_tokens", "temperature"):
        if snap.get(key) is not None:
            eff[key] = snap[key]
    eff.setdefault("max_new_tokens", 2048)
    return eff


def _resident_draft():
    """The resident speculative draft engine, if one is registered.

    Returns (draft_streamer | None, block_k). The registry — not the config —
    is the source of truth for whether a draft is actually loaded, so an
    infer_fn built from this can never claim SD the rig doesn't have (and
    never rebuilds a draft that _rewire_speculative already made resident).
    block_k still comes from config: it is a pure parameter, not a handle.
    """
    from engine.registry import EngineRegistry
    spec = load_config().get("speculative") or {}
    block_k = int(spec.get("block_k", 4) or 4)
    reg = STATE.get("engines")
    if isinstance(reg, EngineRegistry) and reg.has("draft"):
        return (reg.get("draft") or {}).get("streamer"), block_k
    return None, block_k


# ── App + State ──────────────────────────────────────────────

STATE = {
    "db": None,
    "tokens": None,
    "model_path": None,
    "adapter": None,
    "streamer": None,
    "infer_fn": None,
    "worker_thread": None,
    "worker_active": False,
    "model_loading": None,
    # Secure by default: write routes require a token. Opt out only via an
    # explicit COURIER_INSECURE=1 (set in lifespan), never silently.
    "insecure": False,
    "start_time": None,
    "job_queue": [],
    # Guards every read/write of job_queue. The queue is mutated from
    # both API endpoints (main thread) and the worker thread; the GIL
    # makes individual ops atomic but not compound check-then-act
    # sequences (e.g. "queue non-empty" followed by pop(0)).
    "queue_lock": threading.Lock(),
    "current_job": None,
    "cancel": threading.Event(),
    "paused": threading.Event(),
    # Epoch timestamp the worker is holding until between paced cycles,
    # or None when not in a hold. Set via run_worker's on_hold callback.
    "hold_until": None,
    # Live mid-cycle telemetry for the active cycle (stage + token counts),
    # or None when idle. Maintained by the worker thread, read by the
    # dashboard via _build_cycle_status. See _live_reset / _live_progress.
    "live": None,
    # Multi-model engine registry (see courier-multimodel-design-spec.md).
    # None until a model is loaded, then an EngineRegistry whose "primary"
    # role mirrors STATE["streamer"]/["infer_fn"]/["model_path"]. Those
    # three fields remain the authoritative single-model aliases for all
    # existing call sites; the registry is an additive superset consulted
    # only by the (opt-in) routing/speculative paths. With default config
    # it holds exactly one entry and changes nothing.
    "engines": None,
}


@asynccontextmanager
async def lifespan(app: FastAPI):
    # ── Startup ──────────────────────────────────────────────
    STATE["start_time"] = time.time()
    STATE["db"] = Database(DB_PATH)
    STATE["tokens"] = TokenManager(DB_PATH)

    token = STATE["tokens"].ensure_default_token()
    if token:
        # SECURITY: never print the token to stdout — that leaks the secret
        # into terminal scrollback and into any file the server's output is
        # piped/redirected to. The token is stored only as a hash, so it
        # cannot be recovered later; write it once to a private, owner-only
        # file and tell the operator where to find it instead.
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        token_file = DATA_DIR / "default_token.txt"
        token_file.write_text(token, encoding="utf-8")
        try:
            os.chmod(token_file, 0o600)  # owner read/write only (POSIX)
        except OSError:
            pass  # best-effort; on Windows the user-profile ACL already restricts access
        print(f"[courier] API token: written to {token_file} "
              f"(read-write — keep private; delete once saved)", flush=True)
        

    # Auth posture is decided here, not in create_app(): the launcher runs
    # `uvicorn src.server:app` directly, so create_app() never executes on a
    # normal start. Secure unless explicitly waived; loud when trust is
    # broad (see core.security.write_posture for the full precedence).
    posture = write_posture()
    if posture["mode"] == "insecure-bypass":
        STATE["insecure"] = True

    if os.environ.get("HF_TOKEN"):
        print("[courier] HF_TOKEN: found (gated model downloads enabled)", flush=True)
    else:
        print("[courier] HF_TOKEN: not set (gated models like meta-llama will fail to download)", flush=True)

    print(f"[courier] Auth: {posture['summary']}", flush=True)
    if posture["loud"]:
        print(f"[courier] ⚠ AUTH WARNING: {posture['note']}", flush=True)

    # Energy dials: seed the live meter from config (the one source).
    # The short-lived env vars are IGNORED, loudly — one parameter must
    # not live in two places.
    _apply_live_energy(load_config())
    for _var in ("COURIER_WATTS_PER_CORE", "COURIER_ENERGY_SAMPLE_INTERVAL"):
        if os.environ.get(_var):
            print(f"[courier] ⚠ {_var} is ignored — this dial moved to "
                  f"Settings → System (persistent config). One source of "
                  f"truth; unset the variable.", flush=True)

    for d in sorted(MODELS_DIR.glob("*")):
        if _model_incomplete(d):
            print(f"[courier] Model: {d.name} incomplete (config.json but no weights — cleaning up)", flush=True)
            _cleanup_incomplete(d)
            continue
        if _model_ready(d):
            cfg = load_config()
            default = cfg.get("default_model", "")
            if default and _model_ready(MODELS_DIR / default):
                d = MODELS_DIR / default
            STATE["model_path"] = str(d)
            try:
                STATE["adapter"] = detect_adapter(d)
                apply_adapter_defaults(STATE["adapter"])
                cfg = load_config()  # reload with adapter defaults applied
                draft_streamer, draft_path, block_k = _build_draft_if_configured(cfg)
                streamer, infer_fn = build_engine(str(d), config=cfg,
                                                  draft_streamer=draft_streamer,
                                                  speculative_block_k=block_k)
                _apply_engine_budgets(cfg, streamer)  # §5 partition (no-op single-model)
                STATE["streamer"] = streamer
                STATE["infer_fn"] = infer_fn
                _sync_primary_engine()
                _register_draft(draft_streamer, draft_path)
                print(f"[courier] Model: {d.name} loaded", flush=True)
            except Exception as e:
                print(f"[courier] ⚠ Model load failed: {e}", flush=True)
            break

    EXPORT_DIR.mkdir(parents=True, exist_ok=True)

    # ── Crash recovery ───────────────────────────────────────
    # A cycle left 'inferring' or 'paused' by a previous process was
    # interrupted (a crash, a power loss, a deliberate stop). Recovery is
    # driven by durable DB state, not the in-memory queue (empty on a
    # fresh start): a priority recovery job is enqueued so the cycle is
    # never orphaned. Whether it resumes on its own is governed by the
    # auto_resume config setting — ON means the host comes back from a
    # power failure and the work continues with no operator action; OFF
    # means the cycle waits, re-queued, for the operator to press Resume.
    try:
        interrupted = STATE["db"].get_interrupted_cycle()
        if interrupted and STATE.get("streamer") is not None:
            tpl = TEMPLATE_STORE.get_template(interrupted['template_id'])
            if tpl is not None:
                from engine.inference import make_primary_infer_fn
                cfg = load_config()
                # The settings a resumed cycle runs under come from its own
                # record, not the live config — see _recovery_effective_config.
                eff = _recovery_effective_config(interrupted, cfg)
                draft_streamer, block_k = _resident_draft()
                STATE["job_queue"].insert(0, {
                    "recovery": True,
                    "eff_cfg": eff,
                    "template": tpl,
                    "template_name": tpl.metadata.name,
                    "template_id": tpl.metadata.id,
                    "model_id": _loaded_model_id(),
                    # Same derivation as every other path — including the
                    # resident draft, which the old hand-rolled call dropped
                    # (fresh stages after the resumed one are SD-eligible).
                    "infer_fn": make_primary_infer_fn(
                        STATE["streamer"], eff,
                        draft_streamer=draft_streamer,
                        speculative_block_k=block_k,
                    ),
                    "data_paths": _resolve_data_paths(tpl),
                    "export_dir": cfg.get("export_dir") or "./export/",
                    "checkpoint_interval": int(cfg.get("checkpoint_interval", 10)),
                    "max_tokens": int(eff["max_new_tokens"]),
                })
                if cfg.get("auto_resume", True):
                    print(f"[courier] Recovery: interrupted cycle {interrupted['id']} "
                          f"— auto-resuming from its last checkpoint "
                          f"(auto_resume is ON).", flush=True)
                    _start_queue_worker()
                else:
                    # Re-queued so it is not orphaned, but not run: the
                    # operator opted out of automatic resumption. The
                    # engine boots paused and Resume picks the cycle up.
                    STATE["paused"].set()
                    print(f"[courier] Recovery: interrupted cycle {interrupted['id']} "
                          f"re-queued; auto_resume is OFF — engine booting "
                          f"paused, press Resume to continue it.", flush=True)
            else:
                print(f"[courier] Recovery: interrupted cycle {interrupted['id']} found, "
                      f"but template '{interrupted['template_id']}' is missing — "
                      f"cannot resume.", flush=True)
        elif interrupted:
            print(f"[courier] Recovery: interrupted cycle {interrupted['id']} found, "
                  f"but no model is loaded — cannot resume.", flush=True)
    except Exception as e:
        print(f"[courier] ⚠ Recovery check failed: {e}", flush=True)

    # ── Auto-ingest watcher ──────────────────────────────────
    cfg = load_config()
    import_dir = Path(cfg.get("import_dir") or "./import/")
    import_dir.mkdir(parents=True, exist_ok=True)
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    _start_ingest_watcher()
    if cfg.get("auto_ingest"):
        print(f"[courier] Auto-ingest: watching {import_dir}", flush=True)
    else:
        print("[courier] Auto-ingest: disabled (enable in settings)", flush=True)

    yield

    # ── Shutdown ─────────────────────────────────────────────
    if STATE["db"]:
        STATE["db"].close()
    if STATE["tokens"]:
        STATE["tokens"].close()


app = FastAPI(title="Courier", version="0.2.7", lifespan=lifespan)


def _host_is_local(host: Optional[str]) -> bool:
    """True if the Host header names THIS machine — loopback literals,
    'localhost', or '0.0.0.0'. A real domain name pointed at this server is
    the signature of a DNS-rebinding attack, so it's rejected — and so is a
    non-loopback IP literal: the old check accepted ANY IP literal ("covers
    LAN access"), which let every browser on the LAN through the no-token
    write path. Remote operators use the bearer token instead.
    """
    if not host:
        return True  # HTTP/1.1 clients send Host; absence isn't a browser attack
    import ipaddress
    h = host.rsplit(":", 1)[0].strip().strip("[]").lower()  # strip :port and ipv6 []
    if h in ("localhost", "0.0.0.0"):
        return True
    try:
        return ipaddress.ip_address(h).is_loopback
    except ValueError:
        return False


def require_write(
    request: Request,
    authorization: Optional[str] = Header(None),
    sec_fetch_site: Optional[str] = Header(None),
    origin: Optional[str] = Header(None),
    host: Optional[str] = Header(None),
):
    """Authorize a state-changing request.

    Turnkey by design: the local dashboard works with no token because its own
    calls are same-origin to a local Host. Protection without a credential
    comes from rejecting cross-site browser requests (so a page you happen to
    visit can't drive this API) and non-local Hosts (DNS-rebinding). A valid
    bearer token is *also* accepted for scripts/remote/automation, and
    COURIER_INSECURE=1 bypasses everything for fully trusted setups.
    """
    # Hard lock — beats every other mode including the insecure bypass:
    # when COURIER_REQUIRE_TOKEN and COURIER_INSECURE are both set, safest
    # wins. This is the setting for any node reachable through a proxy or
    # shared port (see core.security.write_posture).
    if os.environ.get("COURIER_REQUIRE_TOKEN") == "1":
        if authorization and authorization.startswith("Bearer ") and \
                STATE["tokens"].can_write(authorization.split(" ", 1)[1]):
            return True
        raise HTTPException(403, "This node requires a bearer token for "
                                 "all writes (COURIER_REQUIRE_TOKEN=1)")
    # Full escape hatch.
    if STATE.get("insecure"):
        return True
    # An explicit, valid token authorizes regardless of origin.
    if authorization and authorization.startswith("Bearer "):
        if STATE["tokens"].can_write(authorization.split(" ", 1)[1]):
            return True
        raise HTTPException(403, "Insufficient permissions")
    # No token — the turnkey local path. Verified behavior (not guessed;
    # two prior versions of this check each guessed wrong):
    #   * docs.github.com: CODESPACES is "always true while in a codespace".
    #   * uvicorn docs: --proxy-headers defaults ON and trusts
    #     X-Forwarded-For from loopback peers — so behind the Codespaces
    #     forwarding agent (which connects from loopback but forwards the
    #     browser's address), request.client.host is the END USER'S real
    #     public IP. Address-based checks structurally cannot work there.
    # In a codespace the transport is already GitHub-authenticated
    # (forwarded ports are private to the account), so the peer check is
    # skipped under that env — or under COURIER_TRUST_PROXY=1 for other
    # authenticated-proxy deployments. Everywhere else the TCP peer must be
    # loopback: a direct client (curl) chooses its own Host header, so Host
    # can't authenticate anything — it survives below only as browser
    # DNS-rebinding defense. On a field LAN, remote writes need the bearer
    # token. Refusals log the actual peer so the next surprise is data.
    if not (os.environ.get("COURIER_TRUST_PROXY") == "1"
            or (os.environ.get("CODESPACES")
                and os.environ.get("COURIER_TRUST_PROXY") != "0")):
        peer = getattr(getattr(request, "client", None), "host", "") or ""
        if peer not in ("", "testclient"):
            import ipaddress
            try:
                if not ipaddress.ip_address(peer).is_loopback:
                    print(f"  [auth] write refused: peer={peer} is not "
                          f"loopback and sent no token", flush=True)
                    raise HTTPException(403, "Remote writes require a bearer token")
            except ValueError:
                print(f"  [auth] write refused: unparseable peer={peer!r}",
                      flush=True)
                raise HTTPException(403, "Remote writes require a bearer token")
    # Browser-origin defense for the tokenless path. Two facts drive the
    # shape of this check (verified, not guessed):
    #   * "Site" ignores ports, so a page served by ANY other local service
    #     (localhost:9999) is *same-site* to this server — blocking only
    #     "cross-site" would let such a page drive writes. The dashboard's
    #     own calls are "same-origin"; direct navigations/tools send "none".
    #   * Browsers that predate Sec-Fetch-Site send no fetch metadata at
    #     all. They DO send Origin on state-changing requests, so when the
    #     metadata is absent, Origin is the fallback: present and not this
    #     machine (or the literal "null" of a sandboxed context) → reject.
    # Non-browser clients (curl) send neither header and are covered by the
    # loopback-peer requirement above, per the design.
    if sec_fetch_site in ("cross-site", "same-site"):
        raise HTTPException(403, "Cross-site request blocked")
    if sec_fetch_site is None and origin:
        from urllib.parse import urlparse
        o = origin.strip().lower()
        o_host = (urlparse(o).hostname or "") if o != "null" else ""
        if not o_host or not _host_is_local(o_host):
            print(f"  [auth] write refused: cross-origin browser request "
                  f"(Origin={origin!r}, no fetch metadata)", flush=True)
            raise HTTPException(403, "Cross-site request blocked")
    if not _host_is_local(host):
        raise HTTPException(403, "Unrecognized Host")
    return True


# ── Helpers (shared by REST + SSE) ───────────────────────────

def _loaded_model_id() -> str:
    """Resolve the full model ID (e.g. 'Qwen/Qwen3.5-9B') for the currently
    loaded model. Falls back to the bare directory name if the model isn't
    in SUPPORTED_MODELS."""
    model_path = STATE.get("model_path") or ""
    if not model_path:
        return ""
    dir_name = Path(model_path).name
    for m in SUPPORTED_MODELS:
        if m["id"].split("/", 1)[-1] == dir_name:
            return m["id"]
    return dir_name


def _get_model_info():
    adapter = STATE.get("adapter")
    if adapter:
        c = adapter.config
        size_bytes = sum(
            f.stat().st_size
            for f in Path(STATE["model_path"]).glob("*.safetensors")
        )
        # Also check for GGUF files if no safetensors found
        if size_bytes == 0:
            size_bytes = sum(
                f.stat().st_size
                for f in Path(STATE["model_path"]).glob("*.gguf")
            )
        # Correct param count: sum all weight parameters
        total_params = (
            c.vocab_size * c.hidden_size +                            # embed
            c.num_hidden_layers * (
                c.hidden_size * (c.num_attention_heads * c.head_dim) +  # q
                c.hidden_size * (c.num_key_value_heads * c.head_dim) +  # k
                c.hidden_size * (c.num_key_value_heads * c.head_dim) +  # v
                (c.num_attention_heads * c.head_dim) * c.hidden_size +  # o
                c.hidden_size * c.intermediate_size * 2 +               # gate+up
                c.intermediate_size * c.hidden_size                     # down
            )
        )
        param_str = f"{total_params / 1e9:.1f}B"
        # Derive model ID from SUPPORTED_MODELS or model path
        dir_name = Path(STATE["model_path"]).name
        model_id = dir_name
        for m in SUPPORTED_MODELS:
            if m["id"].split("/", 1)[1] == dir_name:
                model_id = m["id"]
                break
        family_name = getattr(adapter, "FAMILY_DISPLAY_NAME", c.model_type)
        # Storage format, read from disk rather than asserted: this string
        # was a hardcoded "bfloat16" and would have said so for GGUF and
        # INT8 alike. Compute precision is still bf16 either way — INT8 is
        # a storage format, dequantized per load (shard_manager._dequant_int8).
        mp = Path(STATE["model_path"])
        if (mp / "quantization_config.json").exists():
            dtype_str = "int8 → bf16"
        elif list(mp.glob("*.gguf")):
            dtype_str = "gguf"
        else:
            dtype_str = "bfloat16"
        return {
            "id": model_id,
            "layers": c.num_hidden_layers,
            "params": param_str,
            "dtype": dtype_str,
            "size_gb": round(size_bytes / (1024**3), 2),
            "adapter": c.model_type,
            "adapter_family": family_name,
            "status": "ready",
        }
    loading = STATE.get("model_loading")
    if loading:
        return {"id": loading, "layers": 0, "params": "—", "dtype": "",
                "size_gb": 0, "adapter": "", "adapter_family": "",
                "status": "loading"}
    return {"id": "none", "layers": 0, "params": "0", "dtype": "",
            "size_gb": 0, "adapter": "", "adapter_family": "", "status": "not_loaded"}


def _get_templates():
    return TEMPLATE_STORE.list_summaries()


def _get_active_template(templates):
    """Return the template for the currently running cycle, or empty."""
    job = STATE.get("current_job")
    if job and job.get("template"):
        t = job["template"]
        return {"id": t.metadata.id, "name": t.metadata.name,
                "stages": len(t.stages), "version": t.metadata.version}
    return {"id": "", "name": "", "stages": 0, "version": ""}


_BUILTIN_MODELS = [
    # ── Qwen3 (vocab 151,936 · standard transformer · model_type "qwen3") ──
    # All share the same tokenizer. Any smaller can draft for any larger.
    {"id": "Qwen/Qwen3-0.6B",  "params": "0.6B", "family": "qwen3",   "size_gb": 1.5,
     "gguf": {"repo": "Qwen/Qwen3-0.6B-GGUF",  "quant": "q4_k_m", "size_gb": 0.5}},
    {"id": "Qwen/Qwen3-1.7B",  "params": "1.7B", "family": "qwen3",   "size_gb": 3.5,
     "gguf": {"repo": "Qwen/Qwen3-1.7B-GGUF",  "quant": "q4_k_m", "size_gb": 1.2}},
    {"id": "Qwen/Qwen3-4B",    "params": "4B",   "family": "qwen3",   "size_gb": 8.5,
     "gguf": {"repo": "Qwen/Qwen3-4B-GGUF",    "quant": "q4_k_m", "size_gb": 2.6}},
    {"id": "Qwen/Qwen3-8B",    "params": "8B",   "family": "qwen3",   "size_gb": 17,
     "gguf": {"repo": "Qwen/Qwen3-8B-GGUF",    "quant": "q4_k_m", "size_gb": 5.1}},
    {"id": "Qwen/Qwen3-14B",   "params": "14B",  "family": "qwen3",   "size_gb": 29,
     "gguf": {"repo": "Qwen/Qwen3-14B-GGUF",   "quant": "q4_k_m", "size_gb": 9.0}},
    {"id": "Qwen/Qwen3-32B",   "params": "32B",  "family": "qwen3",   "size_gb": 65,
     "gguf": {"repo": "Qwen/Qwen3-32B-GGUF",   "quant": "q4_k_m", "size_gb": 20}},
    # ── Qwen3.5 (vocab 248,320 · hybrid DeltaNet+attention · "qwen3_5") ──
    # Same tokenizer within this group. NOT cross-compatible with Qwen3
    # (different vocabulary).
    {"id": "Qwen/Qwen3.5-0.8B","params": "0.8B", "family": "qwen3_5", "size_gb": 1.8},
    {"id": "Qwen/Qwen3.5-2B",  "params": "2B",   "family": "qwen3_5", "size_gb": 4.5},
    {"id": "Qwen/Qwen3.5-4B",  "params": "4B",   "family": "qwen3_5", "size_gb": 9},
    {"id": "Qwen/Qwen3.5-9B",  "params": "9B",   "family": "qwen3_5", "size_gb": 19},
    {"id": "Qwen/Qwen3.5-27B", "params": "27B",  "family": "qwen3_5", "size_gb": 55},
    # ── Llama 3.x (vocab 128,256 · standard transformer · "llama") ────
    # All Llama 3.x share the same tiktoken BPE tokenizer regardless of
    # the version number (3.1, 3.2) or Meta's naming convention changes
    # ("Meta-Llama-3.1-*" vs "Llama-3.2-*"). Fully cross-compatible for
    # speculative decoding.
    #
    # Llama 3.0 8B is intentionally excluded — 3.1 8B is the same
    # architecture with 128K context (vs 8K) and better benchmarks.
    {"id": "meta-llama/Llama-3.2-1B-Instruct",    "params": "1B",  "family": "llama", "size_gb": 2.5,
     "gguf": {"repo": "bartowski/Llama-3.2-1B-Instruct-GGUF", "quant": "q4_k_m",
              "size_gb": 0.9, "base": "meta-llama/Llama-3.2-1B-Instruct"}},
    {"id": "meta-llama/Llama-3.2-3B-Instruct",    "params": "3B",  "family": "llama", "size_gb": 6.5,
     "gguf": {"repo": "bartowski/Llama-3.2-3B-Instruct-GGUF", "quant": "q4_k_m",
              "size_gb": 2.1, "base": "meta-llama/Llama-3.2-3B-Instruct"}},
    {"id": "meta-llama/Meta-Llama-3.1-8B-Instruct","params": "8B",  "family": "llama", "size_gb": 16,
     "gguf": {"repo": "bartowski/Meta-Llama-3.1-8B-Instruct-GGUF", "quant": "q4_k_m",
              "size_gb": 5.0, "base": "meta-llama/Meta-Llama-3.1-8B-Instruct"}},
    {"id": "meta-llama/Meta-Llama-3.1-70B-Instruct","params": "70B", "family": "llama", "size_gb": 140,
     "gguf": {"repo": "bartowski/Meta-Llama-3.1-70B-Instruct-GGUF", "quant": "q4_k_m",
              "size_gb": 42, "base": "meta-llama/Meta-Llama-3.1-70B-Instruct"}},
    # ── Gemma 3 (vocab 262,208 · dense, 5:1 sliding/global attention ·
    # model_type "gemma3_text" for 1B, "gemma3" for 4B+) ──────────────
    # One tokenizer across all sizes: any smaller drafts for any larger
    # (the catalog family string is deliberately "gemma3" for ALL sizes,
    # including the 1B, so dashboard SD pairing sees one family; the two
    # model_type strings are normalized server-side for the same reason).
    # 4B+ checkpoints are multimodal upstream; Courier runs them TEXT-ONLY
    # until vision Phase C lands (GEMMA3_ADAPTER_BUILD_PLAN.md).
    # Downloads require accepting Google's terms on the HF model page once;
    # HF_TOKEN must be set, same flow as meta-llama (see README →
    # Security & Networking → Authentication).
    {"id": "google/gemma-3-1b-it",  "params": "1B",  "family": "gemma3", "size_gb": 2.0},
    {"id": "google/gemma-3-4b-it",  "params": "4B",  "family": "gemma3", "size_gb": 8.6},
    {"id": "google/gemma-3-12b-it", "params": "12B", "family": "gemma3", "size_gb": 25},
    {"id": "google/gemma-3-27b-it", "params": "27B", "family": "gemma3", "size_gb": 54},
]




MODELS_CATALOG_PATH = PROJECT_ROOT / "models_catalog.json"


def _load_supported_models() -> list[dict]:
    """The model catalog, operator-editable.

    If models_catalog.json exists at the repo root, it IS the catalog:
    add a profile there (id, params, family, size_gb, optional gguf
    block) and it appears in the dashboard on next boot — no code edit.
    The file ships pre-populated with the built-in catalog, so editing
    starts from the known-good state. Accepted shapes: a bare list, or
    {"models": [...]} with an optional "_readme" key (JSON has no
    comments; "_"-prefixed keys are ignored).

    A missing file means the built-in catalog (nothing breaks if the
    file is deleted). A MALFORMED file falls back to the built-in
    catalog LOUDLY — a field box must boot with a working model list
    even when an edit went wrong, but never silently ignore the edit.
    Minimal per-entry validation: id/params/family/size_gb required;
    a bad entry is skipped by name, the rest of the file still loads.
    """
    if not MODELS_CATALOG_PATH.exists():
        return list(_BUILTIN_MODELS)
    try:
        with open(MODELS_CATALOG_PATH, encoding="utf-8") as f:
            data = json.load(f)
        entries = data if isinstance(data, list) else data.get("models")
        if not isinstance(entries, list):
            raise ValueError('expected a list or {"models": [...]}')
        out = []
        for e in entries:
            missing = [k for k in ("id", "params", "family", "size_gb")
                       if k not in e]
            if missing:
                print(f"[courier] models_catalog.json: skipping entry "
                      f"{e.get('id', '<no id>')!r} — missing {missing}",
                      flush=True)
                continue
            out.append(e)
        if not out:
            raise ValueError("no valid entries")
        return out
    except Exception as e:
        print(f"[courier] \u26a0 models_catalog.json unusable ({e}) — "
              f"using the built-in catalog. Fix or delete the file.",
              flush=True)
        return list(_BUILTIN_MODELS)


SUPPORTED_MODELS = _load_supported_models()

def _local_model_entry(name: str, disk_state: str) -> dict:
    """List entry for an on-disk model directory that is not in the
    SUPPORTED_MODELS catalog — above all, GGUF quants fetched with
    `download_model.py --gguf`, which land as e.g. Qwen3-0.6B-GGUF.

    The engine has auto-detected GGUF since the format-detection branch
    in create_engine, and /api/models/load loads any ready directory by
    name — but the dashboard's dropdown renders only what this listing
    returns, so an uncatalogued directory was unreachable from the UI.
    Payload law, model edition: what is on disk must have a road to the
    operator.

    Family comes from config.json's model_type, normalized by the same
    rule the SD-pairing code uses (gemma3_text → gemma3), so speculative
    draft eligibility works unchanged for local entries.
    """
    path = MODELS_DIR / name
    family = ""
    try:
        with open(path / "config.json", encoding="utf-8") as f:
            mt = json.load(f).get("model_type", "")
        family = {"gemma3_text": "gemma3"}.get(mt, mt)
    except Exception:
        pass  # unreadable config: entry still lists, family stays ""
    is_gguf = bool(list(path.glob("*.gguf")))
    size_gb = _model_size_gb(path)
    return {
        "id": name,               # no repo prefix — this exists only on disk
        "dir_name": name,
        "family": family,
        "params": (f"gguf · {size_gb:.1f} GB" if is_gguf
                   else f"{size_gb:.1f} GB"),
        "size_gb": round(size_gb, 2),
        "format": "gguf" if is_gguf else "safetensors",
        "local": True,
        "_disk_state": disk_state,
    }


def _get_models():
    """Return the supported models list with on-disk and loaded status,
    plus on-disk models that are not in the catalog (local entries)."""
    on_disk = {}  # name → "ready" | "incomplete"
    for d in sorted(MODELS_DIR.glob("*")):
        if _model_ready(d):
            on_disk[d.name] = "ready"
        elif _model_incomplete(d):
            on_disk[d.name] = "incomplete"

    loaded_path = STATE.get("model_path") or ""
    loaded_name = Path(loaded_path).name if loaded_path else ""
    loading_name = STATE.get("model_loading")

    def _status(dir_name, disk_state):
        if dir_name == loaded_name:
            return "loaded"
        if loading_name and dir_name == loading_name:
            return "loading"
        if disk_state == "ready":
            return "downloaded"
        if disk_state == "incomplete":
            return "incomplete"
        return "not_downloaded"

    models = []
    catalog_dirs = set()
    # Prefer GGUF variants (Settings → Model): a catalog entry with a
    # published, validated quant presents AS that quant — same row,
    # not a sibling — with the GGUF directory's own status. The
    # safetensors row is hidden UNLESS it is the loaded/loading model
    # (a toggle flip must never make the running model vanish from the
    # UI). Entries without gguf metadata (Qwen3.5, Gemma — see README
    # GGUF Compatibility) are untouched, as are uncatalogued local
    # directories below.
    prefer_gguf = bool(load_config().get("prefer_gguf", False))
    for m in SUPPORTED_MODELS:
        dir_name = m["id"].split("/", 1)[1]
        catalog_dirs.add(dir_name)
        g = m.get("gguf")
        if prefer_gguf and g:
            gdir = dir_name + "-GGUF"
            catalog_dirs.add(gdir)
            models.append({
                "id": g["repo"], "dir_name": gdir, "family": m["family"],
                "params": m["params"] + " · " + g["quant"].upper(),
                "size_gb": g.get("size_gb", m["size_gb"]),
                "format": "gguf", "gguf_variant": True,
                "status": _status(gdir, on_disk.get(gdir)),
            })
            if dir_name not in (loaded_name, loading_name):
                continue  # safetensors row hidden while the toggle is on
        models.append({**m, "dir_name": dir_name,
                       "status": _status(dir_name, on_disk.get(dir_name))})

    # Local entries: everything downloaded that the catalog doesn't claim.
    for name, disk_state in sorted(on_disk.items()):
        if name in catalog_dirs:
            continue
        entry = _local_model_entry(name, disk_state)
        entry["status"] = _status(name, entry.pop("_disk_state"))
        models.append(entry)
    return models


def _kv_ram_mb() -> int:
    """Live KV-cache RAM footprint in MB, or 0 when the engine is down."""
    streamer = STATE.get("streamer")
    if streamer is None:
        return 0
    try:
        return round(streamer.kv_cache.stats()["ram_mb"])
    except Exception:
        return 0


def _resident_stats() -> dict:
    """Live resident-weight cache telemetry for the System panel read-out.

    Lets the operator see the resident cache fill against the Max RAM budget,
    which is the honest signal the throttle is working — total RAM is muddied
    by the OS page-caching the streamed model file.
    """
    off = {"on": False, "mb": 0, "budget_mb": 0, "layers": 0}
    streamer = STATE.get("streamer")
    shards = getattr(streamer, "shards", None) if streamer else None
    if shards is None or not hasattr(shards, "cache_stats"):
        return off
    try:
        s = shards.cache_stats()
        cap = s.get("resident_max_bytes", 0) or 0
        return {
            "on": bool(s.get("resident")),
            "mb": round(s.get("resident_bytes", 0) / (1024 ** 2)),
            "budget_mb": round(cap / (1024 ** 2)) if cap > 0 else 0,
            "layers": s.get("layers_cached", 0),
        }
    except Exception:
        return off


def _apply_live_energy(cfg: dict) -> None:
    """Push the energy dials from config onto the live meter.

    The meter is a process singleton; its instrument never changes at
    runtime, but the estimate-method calibration (watts_per_core) and the
    battery sampling cadence are ordinary settings — applied at boot and
    on every config save, effective from the next cycle, no restart.
    """
    from engine.energy import (DEFAULT_WATTS_PER_CORE,
                               DEFAULT_SAMPLE_INTERVAL)
    from engine.worker import get_meter
    m = get_meter()
    try:
        m.watts_per_core = float(cfg.get("watts_per_core")
                                 or DEFAULT_WATTS_PER_CORE)
    except (TypeError, ValueError):
        m.watts_per_core = DEFAULT_WATTS_PER_CORE
    try:
        m.sample_interval = float(cfg.get("energy_sample_interval")
                                  or DEFAULT_SAMPLE_INTERVAL)
    except (TypeError, ValueError):
        m.sample_interval = DEFAULT_SAMPLE_INTERVAL


def _apply_live_throttle(cfg: dict) -> None:
    """Push throttle dials onto the running streamer so a config save takes
    effect without a model reload.

    The throttle otherwise resolves only at build_engine (model load), which
    makes the dials look dead when changed mid-run. These are attribute writes
    the per-layer / per-load paths read fresh, so they apply over the next
    forward passes. The resident cache is never cleared here (that would race
    the worker); lowering Max RAM stops new caching, full reclaim is at reload.
    """
    streamer = STATE.get("streamer")
    if streamer is None:
        return
    # Fixed layer-delay floor
    try:
        streamer.layer_delay = float(cfg.get("layer_delay", 0.0) or 0.0)
    except Exception:
        pass
    # Dynamic CPU brake target (100 = off)
    try:
        from engine.brake import CpuBrake
        cpu_pct = float(cfg.get("max_cpu_percent", 100) or 100)
        if 0 < cpu_pct < 100:
            if getattr(streamer, "_brake", None) is None:
                streamer._brake = CpuBrake(target_frac=cpu_pct / 100.0)
            else:
                streamer._brake.target = cpu_pct / 100.0
        else:
            streamer._brake = None
    except Exception:
        pass
    # RAM resident budget (safetensors path only; GGUF streams natively).
    # Delegated to the single budget authority so a settings save respects a
    # live §5 partition instead of stomping the primary's cap back to full.
    _apply_engine_budgets(cfg, streamer)


def _resolve_data_paths(template) -> dict:
    """Map a template's data sources to files/directories on disk.

    For text sources: prefer `{name}.json`/`.csv` in DATA_DIR, then a
    `test_{name}` variant, then fall back to the first available *.json.
    For image_file sources: resolve to IMAGE_SRC_DIR.

    Used both when a cycle is triggered and when an interrupted cycle
    is recovered, so the two paths resolve identically.
    """
    data_paths: dict = {}
    for name, src in template.sources.items():
        # Image sources resolve to the image-src directory
        if src.adapter == "image_file":
            IMAGE_SRC_DIR.mkdir(parents=True, exist_ok=True)
            data_paths[name] = str(IMAGE_SRC_DIR)
            continue

        # Text sources: look for matching files in DATA_DIR
        for ext in [".json", ".csv"]:
            for stem in [name, f"test_{name}"]:
                p = DATA_DIR / f"{stem}{ext}"
                if p.exists():
                    data_paths[name] = str(p)
                    break
            if name in data_paths:
                break
    if "default" not in data_paths or not data_paths.get("default"):
        for f in sorted(DATA_DIR.glob("*.json")):
            data_paths["default"] = str(f)
            break
    return data_paths


def _build_cycle_status():
    """Cycle status with proper defaults for idle state."""
    cfg = load_config()
    _idle = {"status": "idle", "id": "", "cycle_number": 0, "stage_index": 0,
             "stage_label": "", "stage_count": 0, "thinking": False,
             "generation_step": 0, "max_generation_steps": 0,
             "layer": 0, "total_layers": 0, "tokens_generated": 0,
             "tokens_per_hour": 0, "elapsed_seconds": 0, "started_at": 0,
             "active_baseline": 0, "segment_started_at": 0,
             "estimated_completion": "", "disk_writes_mb": 0,
             "kv_cache_ram_mb": 0, "kv_cache_disk_mb": 0,
             "checkpoint_count": 0, "data_records": 0,
             "project_name": "", "user_name": "", "total_cycles": 0,
             "created_at": 0,
             "recovered": False, "recovery_msg": "",
             "stages_complete": [], "error": None}
    db = STATE["db"]
    if not db:
        return _idle

    cycle = db.get_latest_cycle()
    # "Active Cycle" means a cycle that is actually running. A finished cycle
    # (complete / failed / cancelled / skipped / missed) belongs to history,
    # not here — fall through to the idle state.
    if cycle is None or cycle["status"] not in ("created", "inferring", "paused"):
        return _idle

    stages = db.get_stages(cycle["id"])
    # Elapsed is accumulated *active* compute time, not a wall-clock span.
    # Each finished stage banked its active seconds into time_seconds; the
    # in-flight stage's live segment is added below once live state is known.
    # Summing banked per-stage time means an interruption's dead gap is never
    # counted, and a resumed stage already carries its pre-crash time.
    prior_active = sum((s["time_seconds"] or 0.0) for s in stages)

    stages_complete = [
        {"label": s["label"], "tokens": s["output_tokens"] or 0,
         "time_s": round(s["time_seconds"] or 0, 1), "status": s["status"]}
        for s in stages
    ]

    n_layers = STATE["adapter"].config.num_hidden_layers if STATE.get("adapter") else 28

    # Run identity, snapshotted into the cycle's config blob when it was
    # created — project, operator, and the cycle target in force at the
    # time the run started. Read from the DB row so it is correct across
    # restarts and independent of any later config edits.
    try:
        ccfg = json.loads(cycle["config"] or "{}")
    except Exception:
        ccfg = {}

    # Live mid-cycle telemetry, if it belongs to this cycle. The worker
    # maintains STATE["live"] per token; the cycle's DB row only carries
    # tokens at completion, so for an in-flight cycle the live state is
    # the accurate source. Fall back to the DB row when there is none.
    lv = STATE.get("live")
    live = lv if (lv and lv.get("cycle_id") == cycle["id"]) else None

    # Cycle clock = active time banked by finished stages + the in-flight
    # stage's live segment (seed banked at its last checkpoint + wall time
    # since the segment opened). active_baseline + segment_started_at are
    # handed to the dashboard so it can tick every second client-side while
    # staying correct across a resume: it computes
    #   shown = active_baseline + (now - segment_started_at).
    # On a fresh single-segment run this reduces to (now - start), exactly the
    # old behaviour; across a resume the dead gap drops out.
    segment_started_at = 0.0
    stage_seed = 0.0
    if live and lv.get("stage_started_at"):
        segment_started_at = lv["stage_started_at"]
        stage_seed = lv.get("stage_active_seed") or 0.0
        live_active = stage_seed + max(0.0, time.time() - segment_started_at)
    else:
        live_active = 0.0
    elapsed = prior_active + live_active
    active_baseline = prior_active + stage_seed
    if live:
        s_index = live["stage_index"]
        s_count = live["stage_count"]
        s_label = live["stage_label"]
        s_step  = live["stage_tokens"]
        s_max   = live["stage_max"] if live["stage_max"] else ccfg.get("max_new_tokens") or cfg["max_new_tokens"]
        tot     = live["total_tokens"]
    else:
        s_index = len(stages_complete)
        s_count = len(stages_complete)
        s_label = stages_complete[-1]["label"] if stages_complete else ""
        s_step  = cycle["tokens_generated"] or 0
        s_max   = ccfg.get("max_new_tokens") or cfg["max_new_tokens"]
        tot     = cycle["tokens_generated"] or 0

    # Live layer heartbeat: the streamer (persistent handle) tracks the
    # current layer of the in-flight forward pass. Show it only while this
    # cycle is the live one and actively generating — otherwise a stale value
    # from a prior run could linger on a paused bar.
    streamer = STATE.get("streamer")
    cur_layer = getattr(streamer, "current_layer", 0) if (live and streamer) else 0

    return {
        "id": cycle["id"],
        "cycle_number": cycle["cycle_number"],
        "status": cycle["status"],
        "stage_index": s_index,
        "stage_label": s_label,
        "stage_count": s_count,
        "thinking": False,
        "generation_step": s_step,
        "max_generation_steps": s_max,
        "layer": cur_layer, "total_layers": n_layers,
        "tokens_generated": tot,
        "tokens_per_hour": round(tot / max(elapsed / 3600, 0.001)) if elapsed > 0 else 0,
        "elapsed_seconds": round(elapsed),
        # Absolute epoch start time (UTC) of the original run. Kept for
        # display/back-compat; the live clock now uses the anchors below.
        "started_at": cycle["infer_started"] or 0,
        # Active-compute clock anchors. The dashboard ticks
        #   active_baseline + (now - segment_started_at)
        # every second, which excludes any time the machine spent off.
        # segment_started_at == 0 means no live segment (idle/between stages):
        # the client falls back to the static elapsed_seconds.
        "active_baseline": round(active_baseline, 3),
        "segment_started_at": segment_started_at or 0,
        "estimated_completion": "",
        "disk_writes_mb": _cycle_disk_writes_mb(cycle["id"], cycle["disk_writes_mb"]),
        "kv_cache_ram_mb": _kv_ram_mb(), "kv_cache_disk_mb": 0,
        "checkpoint_count": db.count_checkpoints(cycle["id"]),
        "data_records": db.count_snapshot_records(cycle["id"]),
        "project_name": ccfg.get("project_name", ""),
        "user_name": ccfg.get("user_name", ""),
        "total_cycles": ccfg.get("max_cycles", 0),
        "created_at": cycle["created_at"] or 0,
        "recovered": False, "recovery_msg": "",
        "stages_complete": stages_complete,
        "error": cycle["error"],
    }


def _build_history():
    db = STATE["db"]
    if not db:
        return []
    cycles = db.get_cycles(50)
    result = []
    for c in cycles:
        stages = db.get_stages(c["id"])
        # Active compute time = sum of banked per-stage time. For a cycle that
        # was interrupted and resumed this excludes the dead gap that a raw
        # completed_at - infer_started span would wrongly include.
        elapsed = sum((s["time_seconds"] or 0.0) for s in stages)
        completed_str = ""
        if c["completed_at"]:
            completed_str = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(c["completed_at"]))
        result.append({
            "id": c["id"], "number": c["cycle_number"],
            "status": c["status"], "records": 0,
            "tokens": c["tokens_generated"] or 0,
            "time_s": round(elapsed, 1), "stages": len(stages),
            "completed": completed_str, "error": c["error"],
            "energy_j": c["energy_j"], "energy_method": c["energy_method"],
        })
    return result


def _build_full_state():
    """Complete state snapshot for SSE."""
    db = STATE["db"]
    uptime = time.time() - STATE["start_time"] if STATE["start_time"] else 0
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    templates = _get_templates()
    _thr = load_config()

    system = {
        "hostname": socket.gethostname(),
        "uptime_hours": round(uptime / 3600, 1),
        "ram_total_mb": round(mem.total / (1024**2)),
        "ram_used_mb": round(mem.used / (1024**2)),
        "disk_total_gb": round(disk.total / (1024**3), 1),
        "disk_used_gb": round(disk.used / (1024**3), 1),
        "disk_writes_lifetime_gb": _disk_writes_lifetime_gb(),
        "cpu_percent": psutil.cpu_percent(interval=0),
        "auto_resume": True,
        # Throttle settings echoed for the read-out: the System gauges show the
        # consequence; these show the policy the operator set.
        "max_ram_percent": _thr.get("max_ram_percent", 0),
        "max_cpu_percent": _thr.get("max_cpu_percent", 100),
        "resident": _resident_stats(),
        "model": _get_model_info(),
        "speculative": _speculative_status(),
        "template": _get_active_template(templates),
        # The instrument behind every receipt's Energy row — surfaced so the
        # UI can say which method a joule figure came from before one exists.
        "energy": {"method": get_meter().method,
                   "description": get_meter().describe()},
    }

    # Ingestion
    stats = db.ingestion_stats() if db else {"total_records": 0, "unconsumed": 0}
    sources = []
    if db:
        with db._lock:
            rows = db._conn.execute(
                "SELECT source_id, COUNT(*) as cnt, MAX(timestamp) as last, "
                "SUM(CASE WHEN consumed=0 THEN 1 ELSE 0 END) as unconsumed, "
                "MAX(mime_type) as mime "
                "FROM ingestion GROUP BY source_id"
            ).fetchall()
        sources = [
            {"id": r["source_id"], "records": r["cnt"],
             "unconsumed": r["unconsumed"] or 0, "mime": r["mime"] or "",
             "last_seen": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(r["last"])) if r["last"] else "",
             "rate_hr": 0}
            for r in rows
        ]

    # Results for completed cycles
    results = {}
    if db:
        for c in db.get_cycles(20):
            if c["status"] == "complete":
                stages = db.get_stages(c["id"])
                if stages:
                    results[c["id"]] = _cycle_result_payload(c)

    # Records (last 100)
    records = []
    if db:
        with db._lock:
            rows = db._conn.execute(
                "SELECT id, source_id, timestamp, mime_type, consumed, cycle_id, content "
                "FROM ingestion ORDER BY timestamp DESC LIMIT 100"
            ).fetchall()
        records = [
            {"id": r["id"], "source_id": r["source_id"],
             "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(r["timestamp"])) if r["timestamp"] else "",
             "mime_type": r["mime_type"], "consumed": bool(r["consumed"]),
             "cycle_id": r["cycle_id"], "content": r["content"]}
            for r in rows
        ]

    # Config
    cfg = load_config()

    # Template detail for config tab (full metadata of active/first template)
    template_detail = {"author": "", "organization": "", "project": "",
                       "version": "", "courier_version": "", "stages": []}
    if templates:
        try:
            t = TEMPLATE_STORE.get_template(templates[0]['id'])
            template_detail = {
                "author": t.metadata.author_name,
                "organization": t.metadata.author_organization,
                "project": t.metadata.project_name,
                "version": t.metadata.version,
                "courier_version": t.metadata.courier_version,
                "stages": [{"label": s.label, "thinking": s.thinking}
                            for s in t.stages],
            }
        except Exception:
            pass

    # Job queue (snapshot under lock to avoid mutation mid-iteration)
    with STATE["queue_lock"]:
        queue = [
            {"template_id": j["template_id"], "template_name": j["template_name"],
             "max_cycles": j.get("max_cycles", 0), "max_tokens": j.get("max_tokens", 0)}
            for j in STATE["job_queue"]
        ]
    current = None
    if STATE["current_job"]:
        cj = STATE["current_job"]
        current = {"template_id": cj["template_id"],
                   "template_name": cj["template_name"],
                   "max_cycles": cj.get("max_cycles", 0)}

    return {
        "system": system,
        "cycle": _build_cycle_status(),
        "ingestion": {"total_records": stats["total_records"], "unconsumed": stats["unconsumed"], "sources": sources},
        "history": _build_history(),
        "records": records,
        "results": results,
        "queue": {"running": current, "pending": queue, "worker_active": STATE["worker_active"], "paused": STATE["paused"].is_set(), "cancelling": STATE["cancel"].is_set(), "hold_until": STATE["hold_until"]},
        "available_templates": templates,
        "available_models": _get_models(),
        "config": cfg,
        "template_detail": template_detail,
    }


# ── SSE Endpoint ─────────────────────────────────────────────

async def _event_stream(request: Request):
    """Push state to dashboard when it changes. Keepalive when idle.

    Stops cleanly when the client disconnects (closed/refreshed tab) so the
    loop doesn't outlive its browser, and bails out after a run of build
    errors instead of emitting an error frame on every tick forever.
    """
    last_hash = ""
    consecutive_errors = 0
    while True:
        # Client gone (tab closed/refreshed)? End the generator so this
        # background loop doesn't accumulate one-per-connection.
        if await request.is_disconnected():
            break
        try:
            state = _build_full_state()
            fp = json.dumps({
                "s": state["cycle"].get("status"),
                "t": state["cycle"].get("tokens_generated"),
                # Live layer + stage-step: during prefill/re-prefill no new
                # tokens are emitted, so "t" is static and the push would never
                # fire — freezing the Layer heartbeat in exactly the recovery
                # window it exists for. Including the layer sweep here lets a
                # state push land (still rate-bounded by the sleep below).
                "l": state["cycle"].get("layer"),
                "g": state["cycle"].get("generation_step"),
                "u": state["ingestion"]["unconsumed"],
                "r": state["ingestion"]["total_records"],
                "h": len(state["history"]),
                "w": STATE["worker_active"],
                "q": len(STATE["job_queue"]),
                "p": STATE["paused"].is_set(),
                "j": STATE["current_job"]["template_id"] if STATE["current_job"] else "",
                "hu": STATE["hold_until"] is not None,
            }, sort_keys=True)

            if fp != last_hash:
                last_hash = fp
                yield f"data: {json.dumps(state)}\n\n"
            else:
                # A *named event*, not an SSE comment (": keepalive"): the
                # EventSource API surfaces named events but comments are
                # invisible to it by spec, so a comment keepalive leaves the
                # client unable to tell a quiet-but-live stream from one an
                # intermediary proxy has silently buffered to death. The
                # dashboard listens for "ping" and treats prolonged total
                # silence as a cue to fall back to GET /api/state.
                yield "event: ping\ndata: {}\n\n"
            consecutive_errors = 0
        except Exception as e:
            consecutive_errors += 1
            yield f"data: {json.dumps({'error': str(e)})}\n\n"
            # Persistent failure (state builder is broken, not a transient
            # blip): stop the stream rather than emit an error frame forever.
            if consecutive_errors >= 5:
                break

        # Dashboard refresh cadence — operator-set, read live each loop.
        try:
            interval = int(load_config().get("refresh_interval", 5))
        except Exception:
            interval = 5
        await asyncio.sleep(max(1, interval))


@app.get("/api/events")
async def sse_events(request: Request):
    return StreamingResponse(
        _event_stream(request),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive",
                 "X-Accel-Buffering": "no"},
    )


# ── Dashboard ────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
def serve_dashboard():
    path = STATIC_DIR / "dashboard.html"
    if not path.exists():
        raise HTTPException(404, "Dashboard not found")
    # no-store: the dashboard is a single self-contained HTML+JS app with no
    # cache-busting hashes, so a heuristically-cached copy silently runs OLD
    # app code against a NEW server — the classic symptom being popout
    # receipts with dashed-out metadata that the current code fetches fine.
    # The file is small and local; always serving fresh costs nothing.
    return HTMLResponse(path.read_text(encoding="utf-8"),
                        headers={"Cache-Control": "no-store"})


@app.get("/api/image/{filename}")
def serve_cycle_image(filename: str):
    """Serve a source image referenced by a report, by filename.

    Checks processed/ (where consume-on-success moves files) and the live
    image source dir. A missing file returns 404 — the report link simply
    doesn't open; nothing crashes. Path traversal is rejected.
    """
    from fastapi.responses import FileResponse
    _reject_traversal(filename)
    for base in (IMAGE_SRC_DIR / "processed", IMAGE_SRC_DIR,
                 DATA_DIR / "processed", DATA_DIR):
        p = base / filename
        if p.exists() and p.is_file():
            return FileResponse(p)
    raise HTTPException(404, "Image not found")


@app.get("/static/{filename}")
def serve_static(filename: str):
    from fastapi.responses import FileResponse
    import mimetypes
    if ".." in filename or "/" in filename or "\\" in filename:
        raise HTTPException(404)
    path = STATIC_DIR / filename
    if not path.exists():
        raise HTTPException(404)
    mime = mimetypes.guess_type(filename)[0] or "application/octet-stream"
    if filename.endswith(".svg"):
        mime = "image/svg+xml"
    # App code (html/css/js) must never be cache-stale against the live
    # server (see serve_dashboard); images and other assets may cache.
    if filename.endswith((".html", ".css", ".js")):
        return FileResponse(path, media_type=mime,
                            headers={"Cache-Control": "no-store"})
    return FileResponse(path, media_type=mime)


# ── REST Endpoints (direct API access, CLI, external) ────────

@app.get("/api/status")
def api_status():
    state = _build_full_state()
    return state["system"] | {
        "available_templates": state["available_templates"],
        "available_models": state["available_models"],
    }


@app.get("/api/state")
def api_state():
    """The full dashboard state — the exact object an SSE frame carries.

    Payload law: every payload the UI renders must have an on-demand
    fetch; SSE is an optimization, never the only road to the data.
    This is that road for the main state. Same builder as the event
    stream (_build_full_state), so the two can never drift apart —
    the same discipline _cycle_result_payload established for results.
    The dashboard uses it for first paint and as the fallback when the
    stream goes silent (e.g. a proxy that buffers SSE indefinitely).
    """
    return _build_full_state()


# ── Node identity & network view ─────────────────────────────
# A network of one is still a network: this is the single-node
# representation of the current instance — the stable identity and
# address surface that the courier-network exchange protocol (designed,
# not yet built) will attach to. Everything reported here is real,
# current state; the `peers` block says so honestly.

NODE_ID_KEY = "courier_id"


def _node_id(db) -> str:
    """Stable node identity: minted once, persisted in the ledger's meta
    table so it survives restarts, renames, and DHCP leases, and travels
    with a DB export. Future receipts/envelopes sign as this name."""
    nid = db.get_meta(NODE_ID_KEY)
    if not nid:
        nid = "courier-" + uuid.uuid4().hex[:12]
        db.set_meta(NODE_ID_KEY, nid)
    return nid


def _interface_addresses() -> list[dict]:
    """Non-loopback IPv4 addresses, per interface — where this node can
    actually be reached on its LAN."""
    out = []
    try:
        for iface, addrs in psutil.net_if_addrs().items():
            for a in addrs:
                if a.family == socket.AF_INET and \
                        not a.address.startswith("127."):
                    out.append({"interface": iface, "address": a.address})
    except Exception:
        pass
    return out


def _corpus_stats(full: bool = False) -> dict:
    """Corpus index stats; graceful shape when no corpus exists yet."""
    db = STATE["db"]
    if not db:
        return {"present": False, "documents": 0, "chunks": 0}
    from core.corpus import CorpusStore, DEFAULT_CORPUS_FILENAME
    path = Path(db.path).parent / DEFAULT_CORPUS_FILENAME
    if not path.exists():
        return {"present": False, "documents": 0, "chunks": 0,
                "path": str(path)}
    store = CorpusStore(path)
    try:
        st = store.stats()
    finally:
        store.close()
    out = {"present": True, "documents": st["documents"],
           "chunks": st["chunks"], "path": st["path"]}
    if full:
        out["listing"] = st["listing"]
    return out


@app.get("/api/node")
def api_node(request: Request):
    db = STATE["db"]
    if not db:
        raise HTTPException(503, "Node starting: ledger not ready")
    uptime = time.time() - STATE["start_time"] if STATE["start_time"] else 0
    totals = db.cycle_totals()
    current = db.get_interrupted_cycle() or db.get_latest_cycle()
    last_complete = next((c for c in db.get_cycles(50)
                          if c["status"] == "complete"), None)
    meter = get_meter()
    return {
        "identity": {
            "courier_id": _node_id(db),
            "hostname": socket.gethostname(),
            "version": app.version,
        },
        "network": {
            "status": "online",          # this response is the proof
            "reached_at": f"{request.url.hostname}:{request.url.port or 80}",
            "scheme": request.url.scheme,
            "addresses": _interface_addresses(),
            "auth": write_posture(),
            "uptime_hours": round(uptime / 3600, 1),
        },
        "work": {
            "current_cycle": current and {
                "id": current["id"], "number": current["cycle_number"],
                "status": current["status"]},
            "last_completed": last_complete and {
                "id": last_complete["id"],
                "number": last_complete["cycle_number"],
                "completed_at": last_complete["completed_at"],
                "energy_j": last_complete["energy_j"],
                "energy_method": last_complete["energy_method"]},
            "totals": totals,
        },
        "energy": {"method": meter.method,
                   "description": meter.describe()},
        "corpus": _corpus_stats(),
        "peers": {
            "count": 0,
            "list": [],
            "protocol": "not yet implemented",
            "note": "Envelope exchange between nodes is designed but "
                    "unbuilt; this node currently stands alone.",
        },
    }


@app.get("/api/corpus")
def api_corpus():
    return _corpus_stats(full=True)


@app.get("/api/cycle/status")
def api_cycle_status():
    return _build_cycle_status()


@app.get("/api/cycles")
def api_cycles(limit: int = 50):
    return _build_history()


@app.get("/api/cycles/{cycle_id}")
def api_get_cycle(cycle_id: str):
    cycle = STATE["db"].get_cycle(cycle_id)
    if cycle is None:
        raise HTTPException(404, "Cycle not found")
    # Contract: the config column reaches the client as valid JSON, or the
    # response says why not — a client-side parse throw must never void the
    # row's honest ledger facts (timestamps, energy, template). The logic
    # lives in report.normalize_config_json so cold probes exercise it.
    raw = cycle.get("config")
    fixed, repaired, err = normalize_config_json(raw)
    if repaired:
        cycle["config"], cycle["config_repaired"] = fixed, True
    elif err:
        cycle["config"], cycle["config_error"] = fixed, err
        print(f"  [receipt] cycle {cycle_id}: config column unparseable "
              f"({str(raw)[:60]!r}...)", flush=True)
    return cycle




def _cycle_result_payload(cycle: dict) -> dict:
    """One result payload, two consumers: the SSE state's results map and
    GET /api/cycles/{id}/result. They previously diverged — the REST shape
    omitted `images`, so a popout populated by fetch silently lost its
    Source Images section. Model identity comes from the cycle's own
    config (a receipt is a historical record), stages from the ledger.
    Images are the cycle's full scope — windowed inbox snapshot ∪ persistent
    reference images, the same union the engine reasons over (see
    db.cycle_image_names); files may have moved to processed/, and the link
    resolver checks both, so a missing file is just a dead link.
    """
    db = STATE["db"]
    cyc_cfg = cycle.get("config") or "{}"
    if isinstance(cyc_cfg, str):
        try:
            cyc_cfg = json.loads(cyc_cfg)
        except (ValueError, TypeError):
            cyc_cfg = {}
    stages = db.get_stages(cycle["id"])
    stage_payloads, tpl_version = _stage_payloads(cycle["template_id"], stages)
    return {
        "model": cyc_cfg.get("model_id") or "—",
        "template": cycle["template_id"],
        "template_version": tpl_version,
        "images": [im["name"] for im in db.cycle_image_names(cycle["id"])],
        "stages": stage_payloads,
    }


def _stage_payloads(template_id, stages):
    """Stage dicts for the results APIs — one shape, two endpoints. When the
    cycle's template stage carries an output schema, the clerk's rendering
    rides along as "output_rendered"; the raw dispatch stays "output" — the
    truth. Best-effort: a deleted or renamed template degrades to raw output,
    never an error. Also the one honest source for the template version the
    receipts display (previously hardcoded "1.0.0")."""
    tpl = None
    try:
        tpl = TEMPLATE_STORE.get_template(template_id) if template_id else None
    except Exception:
        tpl = None
    tstages = list(getattr(tpl, "stages", None) or [])
    tver = getattr(getattr(tpl, "metadata", None), "version", None) or "\u2014"
    out = []
    for i, s in enumerate(stages):
        d = {"label": s["label"], "thinking": bool(s["thinking"]),
             "tokens": s["output_tokens"] or 0,
             "time_s": round(s["time_seconds"] or 0, 1),
             "output": s["output_text"] or ""}
        schema = (getattr(tstages[i], "output_schema", None)
                  if i < len(tstages) else None)
        if schema and d["output"]:
            rendered = _maybe_expand(schema, d["output"])
            if rendered != d["output"]:
                d["output_rendered"] = rendered
        out.append(d)
    return out, tver


@app.get("/api/cycles/{cycle_id}/result")
def api_cycle_result(cycle_id: str):
    db = STATE["db"]
    cycle = db.get_cycle(cycle_id)
    if cycle is None:
        raise HTTPException(404, "Cycle not found")
    return _cycle_result_payload(cycle)


@app.get("/api/cycles/{cycle_id}/receipt.md")
def api_cycle_receipt(cycle_id: str):
    """The canonical cycle receipt as markdown.

    Single source of truth: the worker writes this same render to the export
    directory, and the dashboard's download button fetches it from here. The
    markdown is produced in exactly one place (report.render_receipt) so the
    archived file and the downloaded file cannot drift.
    """
    db = STATE["db"]
    cycle = db.get_cycle(cycle_id)
    if cycle is None:
        raise HTTPException(404, "Cycle not found")
    config = cycle.get("config")
    if isinstance(config, str):
        try:
            config = json.loads(config)
        except (ValueError, TypeError):
            config = {}
    stages = db.get_stages(cycle_id)
    template = TEMPLATE_STORE.get_template(cycle.get("template_id"))
    md = render_receipt(cycle, config or {}, stages, template=template,
                        images=db.cycle_image_names(cycle_id))
    filename = f"cycle_{cycle.get('cycle_number') or 0:04d}_{cycle_id}_report.md"
    return PlainTextResponse(
        md, media_type="text/markdown",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.get("/api/ingest/records")
def api_ingest_records(limit: int = 100, offset: int = 0,
                       source: Optional[str] = None):
    db = STATE["db"]
    query = ("SELECT id, source_id, timestamp, mime_type, consumed, "
             "cycle_id, content FROM ingestion")
    conditions, params = [], []
    if source and source != "all":
        conditions.append("source_id = ?")
        params.append(source)
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
    query += " ORDER BY timestamp DESC LIMIT ? OFFSET ?"
    params.extend([limit, offset])
    with db._lock:
        rows = db._conn.execute(query, params).fetchall()
    return [dict(r) for r in rows]


@app.get("/api/ingest/records/{record_id}")
def api_get_record(record_id: int):
    db = STATE["db"]
    with db._lock:
        row = db._conn.execute(
            "SELECT * FROM ingestion WHERE id = ?", (record_id,)
        ).fetchone()
    if row is None:
        raise HTTPException(404, "Record not found")
    return dict(row)


@app.get("/api/ingest/sources")
def api_ingest_sources():
    """Dataset summaries — one row per source_id — for the Data viewer's
    dataset queue. Cheap aggregate; record payloads are fetched per-dataset
    in the popout. See courier-ux-design-spec.md §4."""
    db = STATE["db"]
    with db._lock:
        rows = db._conn.execute(
            "SELECT source_id, "
            "COUNT(*) AS records, "
            "SUM(CASE WHEN consumed=0 THEN 1 ELSE 0 END) AS unconsumed, "
            "MAX(timestamp) AS last_ts, "
            "MAX(mime_type) AS mime "
            "FROM ingestion GROUP BY source_id ORDER BY last_ts DESC"
        ).fetchall()
    return [dict(r) for r in rows]


@app.post("/api/ingest")
def api_ingest(_auth: bool = Depends(require_write)):
    return {"status": "use_cli", "message": "Use CLI: courier ingest <file>"}


@app.post("/api/ingest/file")
async def api_ingest_file(
    file: UploadFile = File(...),
    source_type: str = Form("inbox"),
    _auth: bool = Depends(require_write),
):
    """Accept a JSON, CSV, or image upload; record it in the ledger and save
    it where pipeline sources can reach it.

    source_type:
      - 'inbox'     (default) — windowed data, consumed once per cycle
      - 'reference' — persistent companion data (e.g. a star catalog or vessel
                      registry), returned to every cycle and never consumed.

    Images are saved to IMAGE_SRC_DIR (pixels stay on disk, the ledger holds a
    pointer); tabular files go to DATA_DIR. Recording goes through the same
    ingest_file dispatcher the auto-ingest sweeper uses.
    """
    from data.ingest import ingest_file, IMAGE_EXTENSIONS

    source_type = (source_type or "inbox").lower()
    if source_type not in ("inbox", "reference"):
        raise HTTPException(400, "source_type must be 'inbox' or 'reference'")

    # The multipart filename is attacker-controlled; without this guard,
    # "../models/x/config.json" passes the .json extension check below and
    # write_bytes clobbers a file OUTSIDE dest_dir. Same shared guard as the
    # image/model routes (one guard, every join — see _reject_traversal).
    _reject_traversal(file.filename or "")

    content = await _read_upload_bounded(file)
    suffix = Path(file.filename).suffix.lower()
    is_image = suffix in IMAGE_EXTENSIONS
    if suffix not in (".json", ".csv") and not is_image:
        raise HTTPException(
            400, "Unsupported file type — use .json, .csv, or an image "
                 "(.jpg/.jpeg/.png/.bmp/.tiff/.webp)")

    # Images → image source dir; tabular → data dir. Pixels never enter the DB.
    dest_dir = IMAGE_SRC_DIR if is_image else DATA_DIR
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / file.filename
    dest.write_bytes(content)

    # Record in the ledger (tabular → rows, image → metadata+pointer row).
    try:
        count = ingest_file(STATE["db"], dest, source_type=source_type)
    except Exception as e:
        raise HTTPException(422, f"File saved but ingestion failed: {e}")

    return {"status": "ok", "count": count, "filename": file.filename,
            "source_id": Path(file.filename).stem, "source_type": source_type,
            "kind": "image" if is_image else "tabular"}


@app.post("/api/templates")
async def api_upload_template(
    file: UploadFile = File(...),
    _auth: bool = Depends(require_write),
):
    """Accept a JSON template file, validate it, and save to the store."""
    content = await _read_upload_bounded(file)
    try:
        raw = json.loads(content)
        t = TEMPLATE_STORE.save(raw.get("template", {}).get("id", ""), raw)
    except json.JSONDecodeError as e:
        raise HTTPException(400, f"Invalid JSON: {e}")
    except ValueError as e:
        raise HTTPException(422, f"Template validation failed: {e}")
    return {"status": "ok", "id": t.metadata.id, "name": t.metadata.name,
            "stages": len(t.stages)}


@app.get("/api/config")
def api_get_config():
    """Return current persistent configuration."""
    return load_config()


@app.post("/api/config")
async def api_save_config(
    request: Request,
    _auth: bool = Depends(require_write),
):
    """Persist configuration changes.

    Starts from the current config and overlays the user's changes,
    so keys the dashboard doesn't manage (like default_model) are
    preserved.
    """
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(400, "Invalid JSON body")
    cfg = load_config()
    prev_spec = dict(cfg.get("speculative") or {})
    cfg.update(body)
    save_config(cfg)
    # Push throttle dials onto the running engine so they take effect now,
    # not only at the next model load.
    _apply_live_throttle(cfg)
    _apply_live_energy(cfg)
    # If the speculative block changed, (re)build/teardown the draft engine and
    # re-wrap the primary's infer_fn live — so the switch takes effect without a
    # model reload. Done in the background since streaming a draft can be slow.
    new_spec = dict((load_config().get("speculative")) or {})
    if new_spec != prev_spec:
        threading.Thread(target=_rewire_speculative, daemon=True).start()
    return {"status": "saved", "config": load_config()}


@app.post("/api/config/reset")
def api_reset_config(_auth: bool = Depends(require_write)):
    """Reset all configuration to factory defaults."""
    if CONFIG_PATH.exists():
        CONFIG_PATH.unlink()
    # Re-apply adapter defaults for the currently loaded model
    if STATE.get("adapter"):
        apply_adapter_defaults(STATE["adapter"])
    return {"status": "reset", "config": load_config()}


@app.get("/api/config/defaults")
def api_config_defaults():
    """Model-specific default values and tooltips for the dashboard.

    Returns the current adapter's recommended defaults, including
    tooltip text explaining each parameter for the loaded model family.
    The dashboard reads this on load and when the model changes,
    updating tooltip content dynamically.
    """
    adapter = STATE.get("adapter")
    if adapter is None:
        return {"model_family": None, "adapter_family": None, "defaults": {}, "tips": {}}
    defaults = adapter.recommended_defaults()
    values = {k: (m["value"] if isinstance(m, dict) else m) for k, m in defaults.items()}
    # Possibly redundant with get_adapter_tips() — same extraction logic.
    tips = {k: m["tip"] for k, m in defaults.items() if isinstance(m, dict) and "tip" in m}
    family_name = getattr(adapter, "FAMILY_DISPLAY_NAME", adapter.MODEL_TYPE)
    return {
        "model_family": adapter.MODEL_TYPE,
        "adapter_family": family_name,
        "defaults": values,
        "tips": tips,
    }


@app.delete("/api/data/records")
def api_clear_records(_auth: bool = Depends(require_write)):
    """Clear all ingestion records."""
    db = STATE["db"]
    with db._lock:
        count = db._conn.execute("SELECT COUNT(*) FROM ingestion").fetchone()[0]
        db._conn.execute("DELETE FROM ingestion")
        db._conn.commit()
    return {"status": "cleared", "removed": count}


@app.delete("/api/data/history")
def api_clear_history(_auth: bool = Depends(require_write)):
    """Clear all cycle history, stages, and checkpoints."""
    db = STATE["db"]
    with db._lock:
        cycles = db._conn.execute("SELECT COUNT(*) FROM cycles").fetchone()[0]
        db._conn.execute("DELETE FROM checkpoints")
        db._conn.execute("DELETE FROM cycle_stages")
        db._conn.execute("DELETE FROM cycles")
        db._conn.commit()
    return {"status": "cleared", "cycles_removed": cycles}


@app.get("/api/export/db")
def api_export_db():
    """Download the entire database file."""
    from fastapi.responses import FileResponse
    if not DB_PATH.exists():
        raise HTTPException(404, "Database not found")
    return FileResponse(
        path=str(DB_PATH),
        filename="courier.db",
        media_type="application/x-sqlite3",
    )


def _live_reset(cycle_id, cycle_number):
    """Initialise live telemetry for a new (or resumed) cycle.

    Wired as run_worker's on_cycle_start callback. Stamping the cycle_id
    here lets _build_cycle_status verify the live data belongs to the
    cycle it is rendering, so a new cycle never shows a stale count.
    """
    job = STATE.get("current_job")
    STATE["live"] = {
        "cycle_id": cycle_id,
        "stage_index": 0,
        "stage_count": len(job["template"].stages) if job else 0,
        "stage_label": "",
        "stage_max": 0,
        "stage_tokens": 0,    # tokens generated in the current stage
        "prior_tokens": 0,    # tokens banked from completed stages
        "total_tokens": 0,    # prior_tokens + stage_tokens (single-read field)
        # ── Active-time anchors ──────────────────────────────────
        # The elapsed clock is accumulated active compute, not a wall-clock
        # span. stage_active_seed is the active time already banked for the
        # in-flight stage (0 for a fresh stage; the checkpoint's banked time
        # for a resumed one); stage_started_at is the wall clock of the
        # current live segment. live active = seed + (now - started_at), so
        # the dead time across an interruption is never counted. Set
        # authoritatively per stage in _wrap_infer_fn; cleared between stages.
        "stage_active_seed": 0.0,
        "stage_started_at": 0.0,
    }


def _live_progress(stage_index, stage_count, stage_label, stage_max):
    """Advance live telemetry to a new stage.

    Wired as run_pipeline's on_progress callback. The previous stage's
    token count is banked into prior_tokens here, when stage_index > 0.
    """
    lv = STATE.get("live")
    if lv is None:
        return
    if stage_index > 0:
        lv["prior_tokens"] += lv["stage_tokens"]
    lv["stage_index"] = stage_index
    lv["stage_count"] = stage_count
    lv["stage_label"] = stage_label
    lv["stage_max"] = stage_max
    lv["stage_tokens"] = 0
    lv["total_tokens"] = lv["prior_tokens"]
    # New stage: drop the previous segment anchor. _wrap_infer_fn sets the
    # seed and start authoritatively when this stage's inference begins; until
    # then the cycle clock reads the banked total of completed stages.
    lv["stage_active_seed"] = 0.0
    lv["stage_started_at"] = 0.0


def _start_queue_worker():
    """Start the queue worker thread if not already running.

    The worker slot is claimed atomically under queue_lock BEFORE the thread
    is spawned. The flag used to be set inside the spawned thread, so two
    near-simultaneous triggers (or trigger + resume) could both observe it
    False and start two workers racing on one engine, one DB, and one KV
    cache. Check-then-act on a shared flag must be one critical section.
    """
    with STATE["queue_lock"]:
        if STATE["worker_active"]:
            return
        STATE["worker_active"] = True

    def _wrap_infer_fn(fn, checkpoint_interval):
        """Wrap infer_fn with the per-token callbacks the engine needs.

        Two callbacks are injected per stage:
          - on_token: enforces cancel/pause and feeds live token telemetry.
          - on_checkpoint: banks a durable checkpoint every
            checkpoint_interval tokens. Built fresh per stage so it carries
            the live cycle/stage and pins this stage's prompt — everything
            a recovery needs to re-feed it exactly.
        """
        def wrapped(prompt, **kwargs):
            def check_flags(token_id, step):
                if STATE["cancel"].is_set():
                    raise CancelledError("Job cancelled by user")
                if STATE["paused"].is_set():
                    raise PausedError("Engine paused by user")
                # Record live token progress for the dashboard. step is
                # 0-indexed, so step + 1 is the count generated so far.
                lv = STATE.get("live")
                if lv is not None:
                    lv["stage_tokens"] = step + 1
                    lv["total_tokens"] = lv["prior_tokens"] + step + 1
            kwargs["on_token"] = check_flags

            # Lightweight cancel check for between-layer interruption
            # (no telemetry, just the flag check for fast response)
            def cancel_check():
                if STATE["cancel"].is_set():
                    raise CancelledError("Job cancelled by user")
                if STATE["paused"].is_set():
                    raise PausedError("Engine paused by user")
            kwargs["cancel_check"] = cancel_check

            # Bank checkpoints for whichever cycle/stage is live now. The
            # worker keeps STATE["live"] current; on_progress has already
            # stamped the stage index before this stage's infer call.
            lv = STATE.get("live")
            if lv is not None:
                # Open a fresh active-time segment for this stage. A resumed
                # stage (re-prefilling banked tokens) continues its clock from
                # the time banked at that checkpoint; a fresh stage starts at
                # zero. Either way the wall anchor is *now*, so the gap a crash
                # opened up is never counted.
                seed = 0.0
                if kwargs.get("resume_tokens") and lv.get("cycle_id"):
                    cp = STATE["db"].get_latest_checkpoint(
                        lv["cycle_id"], lv["stage_index"])
                    if cp:
                        seed = cp.get("active_seconds") or 0.0
                lv["stage_active_seed"] = seed
                lv["stage_started_at"] = time.time()

            def _stage_active():
                """This stage's accumulated active compute time, in seconds."""
                l = STATE.get("live")
                if not l or not l.get("stage_started_at"):
                    return 0.0
                return (l.get("stage_active_seed") or 0.0) + (
                    time.time() - l["stage_started_at"])

            if checkpoint_interval > 0 and lv and lv.get("cycle_id"):
                kwargs["on_checkpoint"] = make_checkpoint_callback(
                    STATE["db"], lv["cycle_id"], lv["stage_index"],
                    interval=checkpoint_interval, prompt=prompt,
                    clock=_stage_active,
                )
            return fn(prompt, **kwargs)
        return wrapped

    def _worker():
        # worker_active was claimed by _start_queue_worker; this thread
        # only ever releases it (at the bottom).
        STATE["cancel"].clear()
        while True:
            # Check pause before starting next job
            if STATE["paused"].is_set():
                print("  Queue: engine paused. Waiting for resume.", flush=True)
                break
            if STATE["cancel"].is_set():
                STATE["cancel"].clear()
                continue
            # Atomically check non-empty and pop: a bare `while queue`
            # followed by pop(0) can race with clear()/remove on the
            # main thread and raise IndexError.
            with STATE["queue_lock"]:
                if not STATE["job_queue"]:
                    break
                job = STATE["job_queue"].pop(0)
            STATE["current_job"] = job
            is_recovery = job.get("recovery", False)
            if is_recovery:
                print("\n  Queue: recovering an interrupted cycle...", flush=True)
            else:
                print(f"\n  Queue: starting {job['template_name']} "
                      f"({job['max_cycles']} cycle(s))", flush=True)
            try:
                # Re-resolve the engine AT DEQUEUE. Jobs captured infer_fn
                # at enqueue, so a model swap while queued silently ran the
                # job on the old, stale streamer. The job's effective config
                # is preserved; the engine is whatever is loaded NOW.
                base_fn = job["infer_fn"]
                if STATE.get("streamer") is not None:
                    try:
                        from engine.inference import make_primary_infer_fn
                        d_s, b_k = _resident_draft()
                        base_fn = make_primary_infer_fn(
                            STATE["streamer"], job.get("eff_cfg") or load_config(),
                            draft_streamer=d_s, speculative_block_k=b_k)
                        jm, cm = job.get("model_id") or "", _loaded_model_id()
                        if jm and cm and jm != cm:
                            print(f"  Queue: job was enqueued under {jm}; "
                                  f"running on {cm} (current model).", flush=True)
                    except Exception:
                        base_fn = job["infer_fn"]  # fall back to the capture
                infer_fn = _wrap_infer_fn(base_fn, job["checkpoint_interval"])
                if is_recovery:
                    # Recovery resumes only the interrupted cycle from its
                    # last banked checkpoint — it starts no new cycles.
                    recover_interrupted(
                        db=STATE["db"],
                        template=job["template"],
                        infer_fn=infer_fn,
                        data_paths=job["data_paths"],
                        export_dir=Path(job["export_dir"]),
                        default_max_tokens=job["max_tokens"],
                        on_cycle_start=_live_reset,
                        on_progress=_live_progress,
                        infer_fns=(STATE["engines"].infer_fns()
                                   if STATE.get("engines") is not None
                                   and not STATE["engines"].is_single() else None),
                    )
                else:
                    run_worker(
                        db=STATE["db"],
                        template=job["template"],
                        infer_fn=infer_fn,
                        data_paths=job["data_paths"],
                        export_dir=Path(job["export_dir"]),
                        default_max_tokens=job["max_tokens"],
                        cycle_config=CycleConfig(
                            max_cycles=job["max_cycles"],
                            checkpoint_interval=job["checkpoint_interval"],
                            auto_resume=job.get("auto_resume", True),
                            project_name=job.get("project_name", ""),
                            user_name=job.get("user_name", ""),
                            model_id=job.get("model_id", ""),
                            pacing_mode=job.get("pacing_mode", "on_demand"),
                            interval_seconds=job.get("interval_seconds", 0),
                            scheduled_time=job.get("scheduled_time", ""),
                            alert_threshold=job.get("alert_threshold", 0),
                        ),
                        cancel_event=STATE["cancel"],
                        pause_event=STATE["paused"],
                        on_hold=lambda ts: STATE.__setitem__("hold_until", ts),
                        on_cycle_start=_live_reset,
                        on_progress=_live_progress,
                        infer_fns=(STATE["engines"].infer_fns()
                                   if STATE.get("engines") is not None
                                   and not STATE["engines"].is_single() else None),
                    )
                print(f"  Queue: {job['template_name']} complete.", flush=True)
            except CancelledError:
                print(f"  Queue: {job['template_name']} cancelled.", flush=True)
                db = STATE["db"]
                cycle = db.get_latest_cycle()
                if cycle and cycle["status"] == "inferring":
                    db.update_cycle(cycle["id"], status="cancelled",
                                    completed_at=time.time())
                STATE["cancel"].clear()
            except PausedError:
                print(f"  Queue: {job['template_name']} paused mid-stage.", flush=True)
                db = STATE["db"]
                cycle = db.get_latest_cycle()
                if cycle and cycle["status"] == "inferring":
                    db.update_cycle(cycle["id"], status="paused")
                # Put job back at front so it resumes on unpause
                with STATE["queue_lock"]:
                    STATE["job_queue"].insert(0, job)
                break
            except Exception as e:
                print(f"  Queue: {job['template_name']} error: {e}", flush=True)
        STATE["current_job"] = None
        STATE["worker_active"] = False
        STATE["hold_until"] = None
        STATE["live"] = None
        if STATE["paused"].is_set():
            print("  Queue: worker stopped (paused).", flush=True)
        else:
            print("  Queue: empty, worker idle.", flush=True)
    try:
        threading.Thread(target=_worker, daemon=True).start()
    except Exception:
        # Could not spawn: release the claimed slot or the engine is
        # permanently wedged with worker_active=True and no worker.
        STATE["worker_active"] = False
        raise


# ── Auto-Ingest Watcher ──────────────────────────────────────

def _start_ingest_watcher():
    """Start background thread that watches the import folder for new files.

    When new files appear in the import folder:
      1. Copy them to DATA_DIR (where pipeline data adapters find them)
      2. Archive originals to import/archive/{timestamp}/
      3. Remove originals from import/

    This is purely a data pipe. The existing pipeline controls when
    and how inference runs — the watcher never queues cycles.
    """
    import shutil as _shutil

    def _sweep():
        """Move files from import/ to data/ and record them in the ledger.

        Tabular/text go to DATA_DIR, images to IMAGE_SRC_DIR. Every swept file
        is also recorded in the ingestion ledger (source_type='inbox') so a
        cycle can SELECT its windowed scope from the DB rather than globbing.
        Returns count of files moved.
        """
        from data.ingest import ingest_file, IMAGE_EXTENSIONS
        cfg = load_config()
        import_dir = Path(cfg.get("import_dir") or "./import/")
        if not import_dir.exists():
            return 0

        accepted = (".json", ".csv", ".txt") + tuple(IMAGE_EXTENSIONS)
        files = [f for f in import_dir.iterdir()
                 if f.is_file() and f.suffix.lower() in accepted]
        if not files:
            return 0

        print(f"[courier] Auto-ingest: {len(files)} new file(s) in {import_dir}",
              flush=True)

        # Route each file to its data directory (images vs tabular/text).
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        IMAGE_SRC_DIR.mkdir(parents=True, exist_ok=True)
        db = STATE.get("db")
        moved = 0
        for f in files:
            is_image = f.suffix.lower() in IMAGE_EXTENSIONS
            dest = (IMAGE_SRC_DIR if is_image else DATA_DIR) / f.name
            _shutil.copy2(f, dest)
            # Record in the ledger as windowed (inbox) data.
            if db is not None:
                try:
                    ingest_file(db, dest, source_type="inbox")
                except Exception as e:
                    print(f"[courier] ⚠ Auto-ingest: ledger record failed for {f.name}: {e}",
                          flush=True)
            f.unlink()
            moved += 1

        print(f"[courier] Auto-ingest: moved {moved} file(s) and recorded to ledger",
              flush=True)
        return moved

    def _watcher():
        last_sweep = STATE.get("last_sweep", 0)
        while True:
            time.sleep(60)  # check clock every 60 seconds
            cfg = load_config()
            if not cfg.get("auto_ingest"):
                continue
            interval = float(cfg.get("ingest_poll_hours", 1)) * 3600
            if time.time() - last_sweep < interval:
                continue
            try:
                count = _sweep()
                if count > 0:
                    last_sweep = time.time()
                    STATE["last_sweep"] = last_sweep
                else:
                    # No files — still mark the check so we wait the full interval
                    last_sweep = time.time()
            except Exception as e:
                print(f"[courier] ⚠ Auto-ingest error: {e}", flush=True)

    threading.Thread(target=_watcher, daemon=True, name="ingest-watcher").start()


@app.get("/api/ingest/status")
def api_ingest_status():
    """Return auto-ingest status."""
    from data.ingest import IMAGE_EXTENSIONS

    cfg = load_config()
    import_dir = Path(cfg.get("import_dir") or "./import/")
    accepted = (".json", ".csv", ".txt") + tuple(IMAGE_EXTENSIONS)
    pending = []
    if import_dir.exists():
        pending = [f.name for f in import_dir.iterdir()
                   if f.is_file() and f.suffix.lower() in accepted]

    archive_dir = import_dir / "archive"
    archive_count = 0
    if archive_dir.exists():
        archive_count = len(list(archive_dir.iterdir()))

    return {
        "enabled": cfg.get("auto_ingest", False),
        "import_dir": str(import_dir),
        "poll_hours": cfg.get("ingest_poll_hours", 1),
        "pending_files": pending,
        "pending_count": len(pending),
        "archive_batches": archive_count,
        "last_sweep": STATE.get("last_sweep", 0),
    }


@app.post("/api/ingest/trigger")
def api_ingest_trigger(_auth: bool = Depends(require_write)):
    """Manually trigger a sweep of the import folder.

    Mirrors the background auto-ingest sweeper: each file is routed to its
    data directory (images -> IMAGE_SRC_DIR, tabular/text -> DATA_DIR) AND
    recorded in the ingestion ledger via ingest_file(), so a cycle can
    SELECT its windowed scope from the DB. Moving files on disk alone is not
    enough -- without the ingest_file() step the data never enters the
    ingestion pathway, which is the same path manual file selection uses.
    """
    import shutil as _shutil
    from data.ingest import ingest_file, IMAGE_EXTENSIONS

    cfg = load_config()
    import_dir = Path(cfg.get("import_dir") or "./import/")
    if not import_dir.exists():
        import_dir.mkdir(parents=True, exist_ok=True)
        return {"swept": 0, "message": "Import folder created but empty"}

    accepted = (".json", ".csv", ".txt") + tuple(IMAGE_EXTENSIONS)
    files = [f for f in import_dir.iterdir()
             if f.is_file() and f.suffix.lower() in accepted]
    if not files:
        return {"swept": 0, "message": "No files in import folder"}

    # Route each file to its data dir AND record it in the ledger.
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    IMAGE_SRC_DIR.mkdir(parents=True, exist_ok=True)
    db = STATE.get("db")
    records = 0
    errors = []
    for f in files:
        is_image = f.suffix.lower() in IMAGE_EXTENSIONS
        dest = (IMAGE_SRC_DIR if is_image else DATA_DIR) / f.name
        _shutil.copy2(f, dest)
        if db is not None:
            try:
                records += ingest_file(db, dest, source_type="inbox")
            except Exception as e:
                errors.append(f"{f.name}: {e}")
        f.unlink()

    STATE["last_sweep"] = time.time()
    msg = (f"Swept {len(files)} file(s); recorded {records} "
           f"record(s) to the ledger")
    if errors:
        msg += f" ({len(errors)} failed: {'; '.join(errors)})"
    return {"swept": len(files), "records": records,
            "files": [f.name for f in files], "errors": errors,
            "message": msg}


@app.post("/api/cycle/trigger")
async def api_trigger_cycle(
    request: Request,
    _auth: bool = Depends(require_write),
):
    if STATE["infer_fn"] is None:
        raise HTTPException(503, "No model loaded — check server startup logs")
    db = STATE["db"]

    # Read form body
    try:
        body = await request.json()
    except Exception:
        body = {}

    # Resolve template
    template_id = body.get("template", "")
    template = TEMPLATE_STORE.get_template(template_id) if template_id else None
    if template is None:
        template = TEMPLATE_STORE.first_template()
        if template is None:
            raise HTTPException(503, "No templates available")

    # Build data_paths
    data_paths = _resolve_data_paths(template)

    # Sampling overrides
    cfg = load_config()
    max_cycles = int(body.get("cycles") or cfg["max_cycles"] or 1)
    checkpoint_interval = int(body.get("checkpoint") or cfg["checkpoint_interval"])

    # Run identity. The template carries it when it specifies one; otherwise
    # the system defaults from config stand in — same thing, just a fallback.
    project_name = template.metadata.project_name or cfg.get("project_name", "")
    user_name = template.metadata.author_name or cfg.get("user_name", "")

    # Effective config for this run: the system config with the request's
    # overrides folded in, fed through make_primary_infer_fn — the same
    # single place every other path derives inference defaults from. The
    # hand-rolled make_infer_fn call this replaces silently dropped the
    # speculative draft and max_images_per_cycle.
    from engine.inference import make_primary_infer_fn
    eff = dict(cfg)
    for key, cast in (("temperature", float), ("top_p", float), ("top_k", int),
                      ("presence_penalty", float), ("enable_thinking", bool)):
        if body.get(key) is not None:
            eff[key] = cast(body[key])
    if body.get("max_tokens"):
        eff["max_new_tokens"] = int(body["max_tokens"])
    draft_streamer, block_k = _resident_draft()
    infer_fn = make_primary_infer_fn(
        STATE["streamer"], eff,
        draft_streamer=draft_streamer,
        speculative_block_k=block_k,
    )

    # Enqueue the job
    job = {
        "template": template,
        "template_name": template.metadata.name,
        "template_id": template.metadata.id,
        "model_id": _loaded_model_id(),
        "infer_fn": infer_fn,
        "eff_cfg": eff,
        "data_paths": data_paths,
        "export_dir": body.get("output") or cfg["export_dir"] or "./export/",
        "max_cycles": max_cycles,
        "checkpoint_interval": checkpoint_interval,
        "auto_resume": cfg.get("auto_resume", True),
        "project_name": project_name,
        "user_name": user_name,
        "temperature": float(eff["temperature"]),
        "top_p": float(eff["top_p"]),
        "max_tokens": int(eff["max_new_tokens"]),
        # Pacing: per-run override (body) falls back to the system default (cfg).
        "pacing_mode": body.get("pacing_mode") or cfg.get("pacing_mode", "on_demand"),
        "interval_seconds": int(body.get("interval_seconds") or cfg.get("interval_seconds", 0)),
        "scheduled_time": body.get("scheduled_time") or cfg.get("scheduled_time", ""),
        "alert_threshold": int(body.get("alert_threshold") or cfg.get("alert_threshold", 0)),
    }
    with STATE["queue_lock"]:
        STATE["job_queue"].append(job)
        position = len(STATE["job_queue"])

    # Start worker if idle
    _start_queue_worker()

    return {"status": "queued", "position": position,
            "template": template.metadata.id,
            "cycles": max_cycles, "unconsumed": db.unconsumed_count(),
            "queue_length": position}


@app.get("/api/queue")
def api_queue():
    """Return the current job queue status."""
    with STATE["queue_lock"]:
        queue = [
            {"template_id": j["template_id"], "template_name": j["template_name"],
             "max_cycles": j.get("max_cycles", 0),
             "recovery": j.get("recovery", False)}
            for j in STATE["job_queue"]
        ]
    current = None
    if STATE["current_job"]:
        cj = STATE["current_job"]
        current = {"template_id": cj["template_id"],
                   "template_name": cj["template_name"]}
    return {"running": current, "pending": queue,
            "worker_active": STATE["worker_active"]}


@app.delete("/api/queue")
def api_clear_queue(_auth: bool = Depends(require_write)):
    """Clear all pending jobs (does not stop the current one)."""
    with STATE["queue_lock"]:
        cleared = len(STATE["job_queue"])
        STATE["job_queue"].clear()
    return {"status": "cleared", "removed": cleared}


@app.post("/api/queue/cancel")
def api_cancel_current(_auth: bool = Depends(require_write)):
    """Cancel the running task and drop every pending task.

    Cancel is terminal and works in any engine state. If the engine is
    paused, the worker thread has already exited and the held task is
    sitting back in the queue — clearing the queue and lifting the pause
    discards it. If a worker is mid-task, the cancel flag stops it after
    the current token; clearing the queue first means it then exits
    instead of advancing to the next task.
    """
    running = STATE["current_job"]
    # Drop all pending tasks first, so a mid-task worker exits after it
    # finishes cancelling rather than picking up the next one.
    with STATE["queue_lock"]:
        dropped = len(STATE["job_queue"])
        STATE["job_queue"].clear()
    # Lift any pause so the engine is not left stuck in a paused state.
    was_paused = STATE["paused"].is_set()
    STATE["paused"].clear()
    # If a worker is mid-task, signal it to stop after the current token.
    if running:
        STATE["cancel"].set()
    # Mark any in-flight or paused cycle as cancelled in the database.
    db = STATE["db"]
    cycle = db.get_latest_cycle()
    orphan = cycle and cycle["status"] in ("inferring", "paused")
    if orphan:
        db.update_cycle(cycle["id"], status="cancelled",
                        completed_at=time.time())
    if running:
        return {"status": "cancelling", "template": running["template_name"],
                "dropped": dropped}
    if was_paused or orphan or dropped:
        return {"status": "cancelled", "dropped": dropped}
    return {"status": "nothing_to_cancel"}


@app.delete("/api/queue/{index}")
def api_remove_job(index: int, _auth: bool = Depends(require_write)):
    """Remove a specific pending job by index (0-based)."""
    with STATE["queue_lock"]:
        if index < 0 or index >= len(STATE["job_queue"]):
            raise HTTPException(404, f"No job at index {index}")
        removed = STATE["job_queue"].pop(index)
        remaining = len(STATE["job_queue"])
    return {"status": "removed", "template": removed["template_name"],
            "remaining": remaining}


@app.post("/api/engine/pause")
def api_engine_pause(_auth: bool = Depends(require_write)):
    """Pause the inference engine. Stops after the current token."""
    STATE["paused"].set()
    return {"status": "pausing", "message": "Engine will pause after current token"}


@app.post("/api/engine/resume")
def api_engine_resume(_auth: bool = Depends(require_write)):
    """Resume the inference engine."""
    STATE["paused"].clear()
    if STATE["job_queue"] and not STATE["worker_active"]:
        _start_queue_worker()
    return {"status": "resumed", "queue_length": len(STATE["job_queue"])}


@app.get("/api/engine/status")
def api_engine_status():
    return {
        "paused": STATE["paused"].is_set(),
        "worker_active": STATE["worker_active"],
        "current_job": STATE["current_job"]["template_name"] if STATE["current_job"] else None,
        "queue_length": len(STATE["job_queue"]),
    }


@app.get("/api/models")
def api_models():
    return _get_models()


@app.post("/api/models/load")
async def api_load_model(request: Request, _auth: bool = Depends(require_write)):
    """Download (if needed) and load a model. Returns immediately; work runs in background."""
    body = await request.json()
    model_name = body.get("model", "").strip()
    if not model_name:
        raise HTTPException(400, "Missing 'model' field")

    with STATE["queue_lock"]:
        if STATE.get("current_job"):
            raise HTTPException(409, "Cannot switch models while inference is running")

    if STATE.get("model_loading"):
        raise HTTPException(409, f"Already loading model: {STATE['model_loading']}")

    model_path = MODELS_DIR / model_name

    # Already loaded — return instantly
    loaded_name = Path(STATE.get("model_path") or "").name
    if loaded_name == model_name and STATE.get("streamer") is not None:
        return {"status": "loaded", "model": model_name}

    # Look up HuggingFace repo ID and size estimate (fast)
    hf_id = None
    model_size_gb = 0
    gguf_spec = None  # catalog GGUF variant: drives the download branch
    for m in SUPPORTED_MODELS:
        dir_name = m["id"].split("/", 1)[1]
        if dir_name == model_name:
            hf_id = m["id"]
            model_size_gb = m.get("size_gb", 0)
            break
        g = m.get("gguf")
        if g and dir_name + "-GGUF" == model_name:
            # A catalog GGUF variant (Settings → Prefer GGUF Variants).
            # Downloaded via scripts/download_model.py --gguf, whose dest
            # convention (models/<repo tail>) matches this dir name.
            gguf_spec = {**g, "base": g.get("base")}
            model_size_gb = g.get("size_gb", 0)
            break
    if not hf_id and not gguf_spec and not _model_ready(model_path):
        raise HTTPException(404, f"\'{model_name}\' is not a supported model")

    # Preflight disk space check (fast, accounts for pending evictions)
    if not _model_ready(model_path) and model_size_gb > 0:
        import shutil as _shutil
        disk = _shutil.disk_usage(str(MODELS_DIR))
        free_gb = disk.free / (1024 ** 3)
        needed_gb = model_size_gb + 1.0
        if free_gb < needed_gb:
            raise HTTPException(507,
                f"Not enough disk space. {model_name} needs ~{model_size_gb} GB "
                f"but only {free_gb:.1f} GB free. Free up space first.")

    # ── Everything below runs in a background thread ──────────
    def _bg_load():
        STATE["model_loading"] = model_name
        old_path = STATE.get("model_path", "")
        try:
            # Clean incomplete downloads
            if _model_incomplete(model_path):
                print(f"  {model_name}: cleaning up incomplete download", flush=True)
                _cleanup_incomplete(model_path)

            # Download if not on disk
            if not _model_ready(model_path):
                cfg = load_config()
                max_models = int(cfg.get("max_models_disk", 3))
                ready_count = len(_ready_models_on_disk())
                while ready_count >= max_models:
                    evicted = _evict_lru_model(keep=model_name)
                    if evicted.get("evicted"):
                        print(f"  Model limit ({max_models}): evicted "
                              f"{evicted['evicted']} ({evicted['freed_gb']} GB freed)", flush=True)
                        ready_count -= 1
                    else:
                        break

                if gguf_spec:
                    # Catalog GGUF variant: reuse the tested script path
                    # (quant scan, base-config resolution, loud failure
                    # when no config.json can be fetched). Subprocess for
                    # the same reason quantization is: its failure or
                    # OOM-kill never takes the server with it.
                    import subprocess
                    print(f"  Downloading {model_name} "
                          f"({gguf_spec['quant']})...", flush=True)
                    argv = [sys.executable,
                            str(PROJECT_ROOT / "scripts" / "download_model.py"),
                            "--model", gguf_spec["repo"],
                            "--gguf", gguf_spec["quant"]]
                    if gguf_spec.get("base"):
                        argv += ["--base", gguf_spec["base"]]
                    proc = subprocess.run(argv, stderr=subprocess.PIPE, text=True)
                    if proc.returncode != 0:
                        print(f"  {model_name}: GGUF download failed: "
                              f"{(proc.stderr or '').strip()[-300:]}", flush=True)
                        return
                else:
                    from huggingface_hub import snapshot_download
                    print(f"  Downloading {model_name}...", flush=True)
                    model_path.mkdir(parents=True, exist_ok=True)
                    snapshot_download(
                        repo_id=hf_id,
                        local_dir=str(model_path),
                        token=os.environ.get("HF_TOKEN") or None,
                        allow_patterns=[
                            "config.json", "tokenizer.json", "tokenizer_config.json",
                            "generation_config.json", "special_tokens_map.json",
                            "chat_template.jinja", "merges.txt", "vocab.json",
                            "tokenizer.model", "model.safetensors",
                            "model.safetensors.index.json",
                            "model.safetensors-*.safetensors",
                            "model-*.safetensors", "preprocessor_config.json",
                            "*.gguf",
                        ],
                    )
                if not _model_ready(model_path):
                    print(f"  {model_name}: download incomplete", flush=True)
                    return
                print(f"  Download complete: {model_name}", flush=True)

            # Auto-quantize safetensors to INT8 (skip GGUF models). Hoisted
            # OUT of the download branch above: a model that downloaded but
            # never converted (e.g. the quantize step was OOM-killed mid-way)
            # is _model_ready on the next attempt, so the old nesting skipped
            # conversion forever and silently loaded bf16. The marker file
            # keeps this idempotent — a converted model is never touched again.
            has_safetensors = list(model_path.glob("*.safetensors"))
            quant_marker = model_path / "quantization_config.json"
            if has_safetensors and not quant_marker.exists():
                try:
                    print(f"  Quantizing to INT8...", flush=True)
                    # Subprocess, not in-process: the conversion's memory peak
                    # then belongs to a child the kernel can OOM-kill WITHOUT
                    # taking the server down, and the memory genuinely returns
                    # to the OS afterwards. stdout is inherited so the
                    # per-shard progress still reaches the console.
                    import subprocess
                    proc = subprocess.run(
                        [sys.executable,
                         str(PROJECT_ROOT / "scripts" / "quantize_model.py"),
                         str(model_path)],
                        stderr=subprocess.PIPE, text=True,
                    )
                    if proc.returncode != 0:
                        reason = {
                            -9: "killed (SIGKILL) — out of memory",
                            -15: ("terminated (SIGTERM) — likely a "
                                  "memory-pressure watchdog"),
                        }.get(proc.returncode) or (
                            (proc.stderr or "").strip()[-300:]
                            or f"exit {proc.returncode}")
                        raise RuntimeError(reason)
                    print(f"  Quantization complete", flush=True)
                except Exception as qe:
                    print(f"  Quantization failed (will use BF16): {qe}", flush=True)

            # Build engine
            print(f"  Loading engine: {model_name}...", flush=True)
            cfg = load_config()
            adapter = detect_adapter(model_path)
            apply_adapter_defaults(adapter)
            cfg = load_config()
            draft_streamer, draft_path, block_k = _build_draft_if_configured(cfg)
            streamer, infer_fn = build_engine(str(model_path), config=cfg,
                                              draft_streamer=draft_streamer,
                                              speculative_block_k=block_k)
            _apply_engine_budgets(cfg, streamer)  # §5 partition (no-op single-model)
            STATE["adapter"] = adapter
            STATE["streamer"] = streamer
            STATE["infer_fn"] = infer_fn
            STATE["model_path"] = str(model_path)
            _sync_primary_engine()
            _register_draft(draft_streamer, draft_path)
            cfg["default_model"] = model_name
            save_config(cfg)
            print(f"  Model loaded: {model_name}", flush=True)
        except Exception as e:
            print(f"[courier] ⚠ Model load failed: {e}", flush=True)
            if old_path and Path(old_path).exists():
                try:
                    a2 = detect_adapter(old_path)
                    s2, fn2 = build_engine(old_path, config=load_config())
                    STATE["adapter"] = a2
                    STATE["streamer"] = s2
                    STATE["infer_fn"] = fn2
                    STATE["model_path"] = old_path
                except Exception:
                    STATE["adapter"] = None
                    STATE["streamer"] = None
                    STATE["infer_fn"] = None
                    STATE["model_path"] = ""
        finally:
            _sync_primary_engine()
            _register_draft(None, None)  # restored/failed load runs single-model until next clean load
            STATE["draft_footprint"] = None
            STATE["model_loading"] = None

    threading.Thread(target=_bg_load, daemon=True).start()
    return {"status": "loading", "model": model_name}

@app.get("/api/models/preflight/{model_name}")
def api_model_preflight(model_name: str):
    """Pre-download check: what will happen if this model is loaded?

    Returns disk space info, eviction plan, and RAM feasibility so
    the dashboard can show a confirmation dialog before proceeding.
    """
    import shutil as _shutil

    model_path = MODELS_DIR / model_name
    loaded_name = Path(STATE.get("model_path") or "").name

    # Find the model in SUPPORTED_MODELS (or as a catalog GGUF variant)
    model_info = None
    gguf_variant = None
    for m in SUPPORTED_MODELS:
        dir_name = m["id"].split("/", 1)[1]
        if dir_name == model_name:
            model_info = m
            break
        g = m.get("gguf")
        if g and dir_name + "-GGUF" == model_name:
            gguf_variant = g
            break

    # Already on disk?
    already_downloaded = _model_ready(model_path)
    already_loaded = loaded_name == model_name and STATE.get("streamer") is not None
    needs_download = not already_downloaded

    # Size
    if already_downloaded:
        model_size_gb = _model_size_gb(model_path)
    elif model_info:
        model_size_gb = model_info.get("size_gb", 0)
    elif gguf_variant:
        model_size_gb = gguf_variant.get("size_gb", 0)
    else:
        model_size_gb = 0

    is_gguf = bool(list(model_path.glob("*.gguf"))) if already_downloaded else (
        True if gguf_variant else
        (model_info.get("format") == "gguf" if model_info else False)
    )

    # Disk space
    disk = _shutil.disk_usage(str(MODELS_DIR))
    disk_free_gb = disk.free / (1024 ** 3)
    disk_total_gb = disk.total / (1024 ** 3)

    # What would be evicted?
    evictions = []
    if needs_download:
        cfg = load_config()
        max_models = int(cfg.get("max_models_disk", 3))
        ready = _ready_models_on_disk()
        # Exclude the currently loaded model from eviction candidates
        candidates = [d for d in ready if d.name != loaded_name and d.name != model_name]
        candidates.sort(key=lambda d: max(
            (f.stat().st_mtime for f in d.rglob("*") if f.is_file()), default=0
        ))

        # How many need to go?
        ready_count = len(ready)
        evict_idx = 0
        while ready_count >= max_models and evict_idx < len(candidates):
            c = candidates[evict_idx]
            evictions.append({
                "name": c.name,
                "size_gb": round(_model_size_gb(c), 2),
            })
            ready_count -= 1
            evict_idx += 1

    evicted_gb = sum(e["size_gb"] for e in evictions)

    # RAM check
    mem = psutil.virtual_memory()
    ram_available_gb = mem.available / (1024 ** 3)
    ram_total_gb = mem.total / (1024 ** 3)

    # Layer-streaming RAM estimate.
    #
    # Courier does NOT load the full model into RAM. It streams one layer
    # at a time from disk, keeping only these permanently resident:
    #   - Embedding table: vocab × hidden_size × 2 bytes (~0.5–2 GB)
    #   - LM head (if untied): same size as embedding
    #   - Final norm: negligible
    #   - One layer's weights: model_size / num_layers (~0.3–2 GB)
    #   - Working memory (activations, KV cache): ~0.5 GB
    #
    # With Max RAM > 0%, additional layers are cached in RAM for speed,
    # but that's bounded by the dial — it can't OOM.
    #
    # The old heuristic (model_size * 0.6) assumed mmap page-in and
    # scared users away from models that stream fine.
    if is_gguf:
        ram_needed_gb = 2.5
        ram_note = "GGUF models stream from disk — low RAM usage"
    else:
        # Try to read exact sizes from config.json if model is on disk.
        streaming_floor_gb = None
        if already_downloaded:
            try:
                cfg_path = model_path / "config.json"
                if cfg_path.exists():
                    import json as _json
                    with open(cfg_path, encoding="utf-8") as _f:
                        mcfg = _json.load(_f)
                    # Navigate into text_config for composite models (Qwen3.5)
                    tcfg = mcfg.get("text_config", mcfg)
                    vocab = tcfg.get("vocab_size", 32000)
                    hidden = tcfg.get("hidden_size", 4096)
                    n_layers = tcfg.get("num_hidden_layers", 32)
                    tied = mcfg.get("tie_word_embeddings",
                                   tcfg.get("tie_word_embeddings", False))
                    embed_bytes = vocab * hidden * 2  # bf16
                    head_bytes = 0 if tied else embed_bytes
                    layer_bytes = (model_size_gb * (1024 ** 3)) / max(n_layers, 1)
                    overhead = 0.5 * (1024 ** 3)
                    streaming_floor_gb = (embed_bytes + head_bytes +
                                         layer_bytes + overhead) / (1024 ** 3)
            except Exception:
                pass
        if streaming_floor_gb is None:
            # Fallback estimate without config.json:
            # embedding + head ≈ 10% of model, one layer ≈ 1/32,
            # overhead ≈ 0.5 GB. Floor of 1.5 GB for tiny models.
            streaming_floor_gb = max(1.5, model_size_gb * 0.13 + 0.5)
        ram_needed_gb = round(streaming_floor_gb, 1)
        ram_note = (f"Layer streaming: ~{ram_needed_gb} GB to run "
                    f"(embedding + one layer + overhead). "
                    f"More RAM = more cached layers = faster.")

    if ram_available_gb < 1.5:
        ram_warning = "critically_low"
        ram_message = (f"Only {ram_available_gb:.1f} GB RAM free. "
                       f"Even layer streaming needs ~{ram_needed_gb} GB.")
    elif ram_available_gb < ram_needed_gb:
        ram_warning = "tight"
        ram_message = (f"{ram_available_gb:.1f} GB free, streaming needs "
                       f"~{ram_needed_gb} GB. May need to unload the "
                       f"current model first.")
    else:
        ram_warning = "ok"
        ram_message = ""

    return {
        "model": model_name,
        "params": (model_info["params"] if model_info else
                   (gguf_variant["quant"].upper() if gguf_variant else "?")),
        "already_downloaded": already_downloaded,
        "already_loaded": already_loaded,
        "needs_download": needs_download,
        "model_size_gb": round(model_size_gb, 2),
        "is_gguf": is_gguf,
        "disk_free_gb": round(disk_free_gb, 1),
        "disk_total_gb": round(disk_total_gb, 1),
        "disk_after_gb": round(disk_free_gb + evicted_gb - (model_size_gb if needs_download else 0), 1),
        "evictions": evictions,
        "ram_available_gb": round(ram_available_gb, 1),
        "ram_total_gb": round(ram_total_gb, 1),
        "ram_warning": ram_warning,
        "ram_message": ram_message,
        "ram_note": ram_note,
    }


@app.delete("/api/models/{model_name}")
def api_delete_model(model_name: str, _auth: bool = Depends(require_write)):
    """Delete a specific model from disk."""
    import shutil
    _reject_traversal(model_name)
    model_path = MODELS_DIR / model_name

    if not model_path.exists():
        raise HTTPException(404, f"Model '{model_name}' not found on disk")

    # Don't delete the currently loaded model
    loaded_name = Path(STATE.get("model_path") or "").name
    if model_name == loaded_name and STATE.get("streamer") is not None:
        raise HTTPException(409, f"Cannot delete '{model_name}' — it is currently loaded")

    size_gb = _model_size_gb(model_path)
    try:
        shutil.rmtree(model_path)
        return {"deleted": model_name, "freed_gb": round(size_gb, 2)}
    except Exception as e:
        raise HTTPException(500, f"Failed to delete: {e}")


@app.get("/api/models/{model_id}")
def api_model(model_id: str):
    _reject_traversal(model_id)
    p = MODELS_DIR / model_id
    if not (p / "config.json").exists():
        raise HTTPException(404, "Model not found")
    with open(p / "config.json", encoding="utf-8") as f:
        c = json.load(f)
    return {"id": model_id, "config": c}


@app.get("/api/storage")
def api_storage():
    """Disk usage breakdown: models, HuggingFace cache, KV cache."""
    import shutil

    # Models
    models = []
    for d in sorted(MODELS_DIR.glob("*")):
        if d.is_dir():
            size = _model_size_gb(d)
            status = "ready" if _model_ready(d) else "incomplete" if _model_incomplete(d) else "other"
            has_gguf = bool(list(d.glob("*.gguf")))
            has_st = bool(list(d.glob("*.safetensors")))
            fmt = "gguf" if has_gguf else "safetensors" if has_st else "unknown"
            loaded_name = Path(STATE.get("model_path") or "").name
            models.append({
                "name": d.name,
                "size_gb": round(size, 2),
                "status": status,
                "format": fmt,
                "loaded": d.name == loaded_name,
            })

    # HuggingFace cache
    hf_cache = Path.home() / ".cache" / "huggingface"
    hf_size_gb = 0.0
    if hf_cache.exists():
        hf_size_gb = sum(f.stat().st_size for f in hf_cache.rglob("*") if f.is_file()) / (1024**3)

    # KV cache
    cfg = load_config()
    kv_dir = cfg.get("kv_cache_dir", "")
    kv_size_gb = 0.0
    if kv_dir and Path(kv_dir).exists():
        kv_size_gb = sum(f.stat().st_size for f in Path(kv_dir).rglob("*") if f.is_file()) / (1024**3)

    disk = shutil.disk_usage(str(MODELS_DIR))

    return {
        "models": models,
        "models_total_gb": round(sum(m["size_gb"] for m in models), 2),
        "hf_cache_gb": round(hf_size_gb, 3),
        "hf_cache_path": str(hf_cache),
        "kv_cache_gb": round(kv_size_gb, 3),
        "kv_cache_path": kv_dir or "(not configured)",
        "disk_free_gb": round(disk.free / (1024**3), 1),
        "disk_total_gb": round(disk.total / (1024**3), 1),
    }


@app.delete("/api/cache/hf")
def api_clear_hf_cache(_auth: bool = Depends(require_write)):
    """Clear the HuggingFace download cache."""
    import shutil
    hf_cache = Path.home() / ".cache" / "huggingface" / "hub"
    if not hf_cache.exists():
        return {"cleared": False, "message": "No HuggingFace cache found"}
    size_before = sum(f.stat().st_size for f in hf_cache.rglob("*") if f.is_file()) / (1024**3)
    try:
        shutil.rmtree(hf_cache)
        return {"cleared": True, "freed_gb": round(size_before, 3)}
    except Exception as e:
        raise HTTPException(500, f"Failed to clear HF cache: {e}")


@app.delete("/api/cache/kv")
def api_clear_kv_cache(_auth: bool = Depends(require_write)):
    """Clear the KV cache spillover directory."""
    import shutil
    cfg = load_config()
    kv_dir = cfg.get("kv_cache_dir", "")
    if not kv_dir or not Path(kv_dir).exists():
        return {"cleared": False, "message": "No KV cache directory configured or found"}
    size_before = sum(f.stat().st_size for f in Path(kv_dir).rglob("*") if f.is_file()) / (1024**3)
    try:
        for f in Path(kv_dir).glob("*"):
            if f.is_file():
                f.unlink()
            elif f.is_dir():
                shutil.rmtree(f)
        return {"cleared": True, "freed_gb": round(size_before, 3)}
    except Exception as e:
        raise HTTPException(500, f"Failed to clear KV cache: {e}")


@app.get("/api/templates")
def api_templates():
    return _get_templates()


@app.get("/api/templates/{template_id}")
def api_template(template_id: str):
    raw = TEMPLATE_STORE.get_raw(template_id)
    if raw is None:
        raise HTTPException(404, "Template not found")
    return raw


@app.put("/api/templates/{template_id}")
async def api_save_template(template_id: str, request: Request,
                            _auth: bool = Depends(require_write)):
    """Validate an edited template and persist it to the single store file.

    Loud failure: invalid JSON or a failed schema check writes nothing and
    returns a specific error to the editor.
    """
    try:
        raw = await request.json()
    except Exception as e:
        raise HTTPException(400, f"Invalid JSON: {e}")
    try:
        t = TEMPLATE_STORE.save(template_id, raw)
    except ValueError as e:
        raise HTTPException(422, f"Template validation failed: {e}")
    return {"status": "ok", "id": t.metadata.id, "name": t.metadata.name,
            "stages": len(t.stages)}


@app.delete("/api/templates/{template_id}")
def api_delete_template(template_id: str, _auth: bool = Depends(require_write)):
    if not TEMPLATE_STORE.delete(template_id):
        raise HTTPException(404, "Template not found")
    return {"status": "deleted", "id": template_id}


def create_app(insecure=False, db_path=None):
    if db_path:
        global DB_PATH
        DB_PATH = Path(db_path)
    STATE["insecure"] = insecure
    return app
