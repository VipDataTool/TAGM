"""Stage pipeline: configure → connect → pipe → run → collate.

Executes a template's stage pipeline sequentially. Each stage is
a single clean inference pass: system prompt + data → response.
No conversational history between stages.

The infer_fn is a callable: (prompt: str) → str. The pipeline
doesn't know or care whether it's a stub, a local model, or an
API call.
"""

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

from template import Template, StageConfig, schema_instruction
from data.adapter_base import DataAdapter
from data.adapters import (verbatim, json_file, csv_file, image_file,
                           corpus_search)


@dataclass
class StageResult:
    """Output of a single pipeline stage."""
    index: int
    label: str
    thinking: bool
    system_prompt_preview: str  # first 100 chars for logging
    input_text: str             # assembled input (data + prior outputs)
    input_chars: int
    output: str
    output_chars: int
    time_seconds: float
    error: Optional[str] = None
    image_paths: list = field(default_factory=list)  # paths to images used
    output_tokens: Optional[int] = None  # REAL generated count when the
    # engine reports one; None means downstream falls back to the chars//4
    # estimate (stub infer fns, legacy rows)


@dataclass
class PipelineResult:
    """Output of a full pipeline run."""
    template_id: str
    template_name: str
    stages: list[StageResult] = field(default_factory=list)
    total_time_seconds: float = 0.0
    collated_output: str = ""

    def write(self, path: str | Path) -> None:
        """Write collated output to a file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(self.collated_output, encoding="utf-8")


# ── Adapter Registry ─────────────────────────────────────────

ADAPTER_REGISTRY: dict[str, type] = {
    "verbatim": verbatim.Adapter,
    "json_file": json_file.Adapter,
    "csv_file": csv_file.Adapter,
    "image_file": image_file.Adapter,
    "corpus_search": corpus_search.Adapter,
}


def _get_adapter(adapter_type: str) -> DataAdapter:
    """Instantiate a data adapter by type name."""
    cls = ADAPTER_REGISTRY.get(adapter_type)
    if cls is None:
        known = ", ".join(sorted(ADAPTER_REGISTRY.keys()))
        raise ValueError(f"Unknown adapter type '{adapter_type}'. Known: {known}")
    return cls()


# ── Token Budget Allocation ──────────────────────────────────

def stage_token_count(sr: "StageResult") -> int:
    """A stage's token count for receipts: the engine's REAL generated
    count when reported, else the historical chars//4 estimate (stub
    engines, rows persisted before the count existed)."""
    return (sr.output_tokens if sr.output_tokens is not None
            else sr.output_chars // 4)


def allocate_budgets(
    source_budgets: dict[str, int],
    available_tokens: int,
) -> dict[str, int]:
    """Allocate token budgets proportionally when they exceed available space.

    If total requested budgets fit, return as-is.
    Otherwise, scale proportionally so they sum to available_tokens.

    Args:
        source_budgets: {source_name: requested_tokens}
        available_tokens: total tokens available for data

    Returns:
        {source_name: allocated_tokens}
    """
    if not source_budgets:
        return {}

    total_requested = sum(source_budgets.values())

    if total_requested <= available_tokens:
        return dict(source_budgets)

    # Scale proportionally
    scale = available_tokens / total_requested
    allocated = {}
    for name, budget in source_budgets.items():
        allocated[name] = max(1, int(budget * scale))

    return allocated


# ── Data Fetching ────────────────────────────────────────────

def fetch_source_data(
    source_names: list[str],
    template: Template,
    data_paths: dict[str, str],
    available_tokens: int,
    records_by_source: Optional[dict] = None,
) -> tuple[str, list[str]]:
    """Fetch and format data from the specified sources.

    Two feeders, one formatter. When records_by_source is provided (the
    DB-backed path), each source is rendered from ledger records via the
    adapter's render_records(); the format is byte-identical to the legacy
    file path because both go through the same renderer. When it is None
    (CLI/tests), the adapter reads from data_paths as before. The glob is no
    longer load-bearing — it is the fallback, not the source of truth.

    Args:
        source_names: which sources to fetch
        template: the template (for source configs)
        data_paths: {source_name: path_override} — legacy file feeder
        available_tokens: token budget for all sources combined
        records_by_source: {source_name: [ledger records]} — DB feeder

    Returns:
        (text, image_paths) — combined formatted text and any image paths.
    """
    # Collect budgets
    budgets = {}
    for name in source_names:
        if name in template.sources:
            budgets[name] = template.sources[name].budget_tokens
        else:
            budgets[name] = 500  # default

    # Allocate
    allocated = allocate_budgets(budgets, available_tokens)

    # Fetch each source
    sections = []
    image_paths: list[str] = []
    for name in source_names:
        budget = allocated.get(name, 500)

        # Determine adapter type and config
        if name in template.sources:
            src = template.sources[name]
            adapter_type = src.adapter
            config = {
                "endpoint": src.endpoint,
                "module": src.module,
                "path": data_paths.get(name, src.path),
                "params": src.params,
                "aggregation": src.aggregation,
            }
        elif name in data_paths:
            # Source not in template but caller provided a path
            path = data_paths[name]
            if path.endswith(".json"):
                adapter_type = "json_file"
            elif path.endswith(".csv"):
                adapter_type = "csv_file"
            else:
                adapter_type = "verbatim"
            config = {"path": path}
        else:
            sections.append(f"[Source '{name}': not configured and no path provided]")
            continue

        adapter = _get_adapter(adapter_type)
        # On the records-fed path there is no file path; connect() only needs
        # it for the file feeder, so coerce None to "" to keep connect happy.
        if config.get("path") is None:
            config["path"] = ""
        adapter.connect(config)
        params = config.get("params", {}) or {}

        # DB feeder: render from ledger records. File feeder: read from disk.
        if records_by_source is not None and hasattr(adapter, "render_records"):
            recs = records_by_source.get(name, [])
            text = adapter.render_records(recs, budget, params)
        else:
            text = adapter.fetch(budget, params)
        sections.append(text)

        # Collect image paths from image_file adapters
        if hasattr(adapter, "image_paths") and adapter.image_paths:
            image_paths.extend(str(p) for p in adapter.image_paths)

    return "\n\n---\n\n".join(sections), image_paths


# ── Pipeline Execution ───────────────────────────────────────

def select_stage_infer_fn(
    stage: "StageConfig",
    infer_fn: Callable[[str], str],
    infer_fns: Optional[dict[str, Callable[[str], str]]] = None,
) -> Callable[[str], str]:
    """Pick the engine a stage runs on (Channel A, multimodel spec §2/§8 step 5).

    Back-compatible by construction:
      - No routing map (``infer_fns is None``) ⇒ always the single ``infer_fn``
        — byte-for-byte today's behavior.
      - A map present but the stage sets no ``model`` (or names a role not in
        the map) ⇒ fall back to ``infer_fn`` (the primary). A stage only leaves
        the default engine when it explicitly names a loaded role.
    Pure: no torch, no I/O — the selection logic verifies cold.
    """
    if not infer_fns:
        return infer_fn
    role = getattr(stage, "model", None)
    if not role:
        return infer_fn
    return infer_fns.get(role, infer_fn)


def run_pipeline(
    template: Template,
    data: dict[str, str],
    infer_fn: Callable[[str], str],
    default_max_tokens: int,
    context_window: int = 4096,
    on_progress: Optional[Callable] = None,
    on_stage_complete: Optional[Callable] = None,
    resume: Optional[dict] = None,
    records_by_source: Optional[dict] = None,
    infer_fns: Optional[dict[str, Callable[[str], str]]] = None,
) -> PipelineResult:
    """Execute a template's stage pipeline.

    Args:
        template: The loaded template
        data: {source_name: file_path} mapping for data sources
        infer_fn: callable that takes a prompt string and returns
            a response string (stub, real engine, or API call)
        context_window: total context window in tokens
        default_max_tokens: system default from config — used when
            neither the template nor the stage sets max_new_tokens
        on_progress: Callback(stage_index, stage_count, stage_label, stage_max)
            invoked before each stage, so callers can surface live progress
        on_stage_complete: Callback(StageResult) invoked the moment a stage
            finishes, so the caller can persist it immediately — a stage is
            durable as soon as it completes, not at end of cycle.
        resume: When recovering an interrupted cycle, a dict with keys:
            "completed"     — DB stage rows for stages finished before the
                              interruption (reused, not re-inferred);
            "stage_index"   — index of the stage that was in progress;
            "resume_tokens" — tokens already banked for that stage, or None;
            "prompt"        — the pinned prompt those tokens were generated
                              against;
            "rng_state"     — sampler RNG state banked with those tokens.
                              Stages after the in-progress one run fresh.

    Returns:
        PipelineResult with all stage outputs and collated text
    """
    result = PipelineResult(
        template_id=template.metadata.id,
        template_name=template.metadata.name,
    )

    prior_outputs: list[StageResult] = []
    pipeline_start = time.time()
    resume_at = resume["stage_index"] if resume else -1

    for i, stage in enumerate(template.stages):
        # Report stage progress so callers can surface live telemetry.
        if on_progress:
            stage_max = stage.max_new_tokens or default_max_tokens
            on_progress(i, len(template.stages), stage.label, stage_max)

        # ── Resume: a stage that finished before the interruption is
        #    reused from its persisted output — never re-inferred — so the
        #    input chain for later stages stays intact. ──
        if resume and i < resume_at:
            row = next((r for r in resume["completed"]
                        if r["stage_index"] == i), None)
            if row is not None:
                sr = StageResult(
                    index=i, label=row["label"],
                    thinking=bool(row["thinking"]),
                    system_prompt_preview="", input_text="[reused on resume]",
                    input_chars=0, output=row["output_text"] or "",
                    output_chars=len(row["output_text"] or ""),
                    output_tokens=row.get("output_tokens"),
                    time_seconds=row["time_seconds"] or 0.0,
                    error=row["error"],
                )
                result.stages.append(sr)
                prior_outputs.append(sr)
                continue
            # No stored row (unexpected) — fall through and re-run it.

        stage_start = time.time()
        resuming_this = bool(resume and i == resume_at
                             and resume.get("resume_tokens"))
        pinned = resume.get("prompt") if resuming_this else None

        # ── Assemble input ──────────────────────────────────
        stage_image_paths: list[str] = []
        if pinned:
            # In-progress stage: the checkpoint pinned the exact prompt the
            # banked tokens were generated against. Use it verbatim and skip
            # re-assembly (and the data re-fetch) — a data-file change since
            # the crash cannot then corrupt the continuation.
            prompt = pinned
            input_text = "[resumed from checkpoint]"
        else:
            input_parts = []

            # Prior stage outputs
            stage_input = stage.input
            prior_mode = stage_input.get("prior")
            if prior_mode == "last" and prior_outputs:
                input_parts.append(prior_outputs[-1].output)
            elif prior_mode == "all" and prior_outputs:
                for po in prior_outputs:
                    input_parts.append(f"## {po.label}\n\n{po.output}")

            # Data sources
            source_names = stage_input.get("sources", [])
            if source_names:
                # Budget: context window minus system prompt and response
                sys_tokens = max(1, len(stage.system_prompt) // 4)
                response_budget = stage.max_new_tokens or default_max_tokens
                prior_tokens = sum(len(p) // 4 for p in input_parts)
                available = context_window - sys_tokens - response_budget - prior_tokens
                available = max(100, available)

                data_text, data_images = fetch_source_data(
                    source_names, template, data, available,
                    records_by_source=records_by_source)
                if data_text:
                    input_parts.append(data_text)
                stage_image_paths = data_images

            input_text = "\n\n".join(input_parts) if input_parts else "[No input data]"
            sys_text = stage.system_prompt
            if stage.output_schema:
                # Telegraph: instruction attaches here, at assembly — the
                # authored template stays clean and round-trips untouched.
                sys_text = (sys_text.rstrip() + "\n\n"
                            + schema_instruction(stage.output_schema))
            prompt = f"{sys_text}\n\n---\n\n{input_text}"

        # ── Run inference ───────────────────────────────────
        error = None
        output = ""
        gen_tokens = None
        try:
            kwargs = {"thinking": stage.thinking}
            if stage.temperature is not None:
                kwargs["temperature"] = stage.temperature
            # Always pass the effective cap so the job/cycle-level
            # default_max_tokens is honored (the documented contract above),
            # not silently overridden by infer_fn's own build-time default.
            # A per-stage cap still takes precedence when set. Without this,
            # a stage with no cap is generated at the engine default (e.g.
            # 2048) even when the cycle is configured for fewer — which is how
            # a report can show "Max Tokens 576" yet truncate at 2048.
            kwargs["max_new_tokens"] = (
                stage.max_new_tokens if stage.max_new_tokens is not None
                else default_max_tokens
            )
            if resuming_this:
                # Continue this stage from its banked tokens (re-prefill),
                # restoring the sampler RNG for an identical continuation.
                kwargs["resume_tokens"] = resume["resume_tokens"]
                kwargs["resume_rng"] = resume.get("rng_state")
            # Pass image paths for multimodal stages
            if stage_image_paths:
                kwargs["image_paths"] = stage_image_paths
            # Channel A: route this stage to its engine (primary unless the
            # stage names another loaded role and a routing map was supplied).
            stage_infer_fn = select_stage_infer_fn(stage, infer_fn, infer_fns)
            output = stage_infer_fn(prompt, **kwargs)
            # Real engines return (text, generated_token_count); stubs and
            # older engines return bare text. Accept both — the count, when
            # present, replaces the chars//4 estimate on the receipt.
            if isinstance(output, tuple):
                output, gen_tokens = output
        except Exception as e:
            # A genuine inference failure: record it as a failed stage and let
            # the pipeline continue. Operator interrupts (CancelledError /
            # PausedError) subclass BaseException, so they are NOT caught here
            # — they propagate up to the queue worker, by design.
            error = str(e)
            output = f"[Stage failed: {error}]"

        stage_time = time.time() - stage_start
        if resuming_this:
            # This stage was interrupted and re-prefilled. Its clock continues
            # from the time banked at the checkpoint it resumed from, so the
            # recorded time is the stage's full active compute — the dead gap
            # between crash and recovery is excluded, mirroring how the tokens
            # resume from the same checkpoint rather than from scratch.
            stage_time += float(resume.get("active_seconds") or 0.0)

        # ── Record result ───────────────────────────────────
        stage_result = StageResult(
            index=i,
            label=stage.label,
            thinking=stage.thinking,
            system_prompt_preview=stage.system_prompt[:100],
            input_text=input_text,
            input_chars=len(input_text),
            output=output,
            output_chars=len(output),
            output_tokens=gen_tokens,
            time_seconds=stage_time,
            error=error,
            image_paths=stage_image_paths,
        )
        result.stages.append(stage_result)
        prior_outputs.append(stage_result)

        # Persist the stage the moment it finishes — a crash mid-cycle then
        # never loses a completed stage; recovery resumes from the next one.
        if on_stage_complete:
            on_stage_complete(stage_result)

    # ── Collate ─────────────────────────────────────────────
    result.total_time_seconds = time.time() - pipeline_start

    collated_parts = []
    for sr in result.stages:
        collated_parts.append(f"## {sr.label}\n\n{sr.output}")
    result.collated_output = "\n\n---\n\n".join(collated_parts)

    return result
