"""Image file data adapter.

Handles image files for multimodal inference. Unlike text adapters
which render data as markdown, this adapter:

1. Returns a text description placeholder for the pipeline prompt
   (the pipeline assembles text; the image is passed separately)
2. Provides the raw image path for the engine to load pixel data

The pipeline's infer_fn receives both the text prompt and image
paths, and the multimodal engine handles vision encoding.

Supported formats: JPEG, PNG, BMP, TIFF, WebP
"""

import json
import os
from pathlib import Path
from typing import Optional

from data.adapter_base import DataAdapter


class Adapter(DataAdapter):
    """Data adapter for image files.

    When used in a template, the source config should specify:
        {
            "adapter": "image_file",
            "budget_tokens": 50,      // tokens for the text placeholder
            "max_pixels": 1003520,    // optional pixel budget
            "min_pixels": 3136        // optional minimum pixels
        }

    The adapter produces a text placeholder like:
        [Image: field_photo_001.jpg (1280×960, 3.2 MB)]

    The actual image data is passed to the inference engine
    through the pipeline's image_paths mechanism.
    """

    SUPPORTED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif", ".webp"}

    def __init__(self):
        self._source_dir: Optional[Path] = None
        self._max_pixels: int = 1280 * 28 * 28  # ~1M pixels
        self._min_pixels: int = 4 * 28 * 28      # ~3K pixels
        self._image_paths: list[Path] = []

    def connect(self, source_config: dict) -> None:
        """Bind to an image source directory.

        Args:
            source_config: Configuration from template, may include:
                - path: directory containing images
                - max_pixels: maximum pixel budget per image
                - min_pixels: minimum pixel budget per image
        """
        path = source_config.get("path", "data")
        self._source_dir = Path(path)
        self._max_pixels = source_config.get("max_pixels", self._max_pixels)
        self._min_pixels = source_config.get("min_pixels", self._min_pixels)

    def fetch(self, token_budget: int, params: dict) -> str:
        """Return text placeholders for available images.

        Scans the source directory for image files, generates
        descriptive placeholders, and stores paths for later
        retrieval by the engine.

        Args:
            token_budget: Max tokens for the placeholder text
            params: Additional parameters (e.g., filter patterns)

        Returns:
            Formatted text with image metadata placeholders
        """
        if self._source_dir is None:
            return "[No image source configured]"

        if not self._source_dir.exists():
            return f"[Image directory not found: {self._source_dir}]"

        # Collect image files
        images = []
        pattern = params.get("pattern", "*")

        for ext in self.SUPPORTED_EXTENSIONS:
            images.extend(self._source_dir.glob(f"{pattern}{ext}"))
            images.extend(self._source_dir.glob(f"{pattern}{ext.upper()}"))

        images = sorted(set(images))
        if not images:
            return "[No images found in source directory]"

        # Build placeholders within budget
        self._image_paths = []
        lines = []
        budget_chars = token_budget * 4  # rough char-per-token estimate

        for img_path in images:
            size_str = _format_file_size(img_path.stat().st_size)
            dims = _get_image_dims(img_path)
            dim_str = f"{dims[0]}×{dims[1]}" if dims else "unknown"

            placeholder = f"[Image: {img_path.name} ({dim_str}, {size_str})]"

            if sum(len(l) for l in lines) + len(placeholder) > budget_chars:
                break

            lines.append(placeholder)
            self._image_paths.append(img_path)

        if not lines:
            return "[Images too large for token budget]"

        header = f"**{len(lines)} image(s) from {self._source_dir.name}:**\n"
        return header + "\n".join(lines)

    @property
    def image_paths(self) -> list[Path]:
        """Paths to images referenced by the last fetch() call.

        The pipeline passes these to the inference engine for
        vision encoding.
        """
        return self._image_paths

    def render_records(self, records: list[dict], token_budget: int,
                       params: dict = None) -> str:
        """Build image placeholders and image_paths from ledger records.

        Each record is an image row from the ingestion ledger: it carries an
        on-disk `path` (the pixels never live in the DB) and a `content` JSON
        blob with filename/width/height metadata. This is the DB-fed twin of
        fetch(): it produces the same per-image placeholder lines and the same
        ordered image_paths the engine consumes — the order here sets which
        vision-token span each image occupies, so it must be deterministic.
        """
        params = params or {}
        if not records:
            return "[No images found]"

        self._image_paths = []
        lines = []
        budget_chars = token_budget * 4
        seen = set()

        for rec in records:
            p = rec.get("path")
            if not p:
                continue
            img_path = Path(p)
            # Dedupe + existence gate. The same image referenced by two
            # ledger rows must occupy ONE vision-token span, and a row may
            # outlive its file — fetch() only ever sees files that exist on
            # disk, so mirror that here. Either way, never emit a
            # placeholder without its path (or vice versa): the pairing
            # sets which vision-token span each image occupies.
            key = str(img_path)
            if key in seen or not img_path.exists():
                continue
            seen.add(key)
            meta = {}
            try:
                meta = json.loads(rec.get("content") or "{}")
            except (ValueError, TypeError):
                meta = {}

            w, h = meta.get("width"), meta.get("height")
            if (w is None or h is None) and img_path.exists():
                dims = _get_image_dims(img_path)
                if dims:
                    w, h = dims
            dim_str = f"{w}×{h}" if (w and h) else "unknown"

            size_str = "unknown size"
            if img_path.exists():
                size_str = _format_file_size(img_path.stat().st_size)

            name = meta.get("filename") or img_path.name
            placeholder = f"[Image: {name} ({dim_str}, {size_str})]"

            if sum(len(l) for l in lines) + len(placeholder) > budget_chars:
                break

            lines.append(placeholder)
            self._image_paths.append(img_path)

        if not lines:
            return "[No images within token budget]"

        header = f"**{len(lines)} image(s):**\n"
        return header + "\n".join(lines)

    @property
    def max_pixels(self) -> int:
        return self._max_pixels

    @property
    def min_pixels(self) -> int:
        return self._min_pixels


def _format_file_size(size_bytes: int) -> str:
    """Format file size in human-readable units."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    else:
        return f"{size_bytes / (1024 * 1024):.1f} MB"


def _get_image_dims(path: Path) -> Optional[tuple[int, int]]:
    """Get image dimensions without loading the full image.

    Returns (width, height) or None if dimensions can't be read.
    """
    try:
        from PIL import Image
        with Image.open(path) as img:
            return img.size
    except Exception:
        return None
