"""CSV file data adapter.

Reads CSV files, optionally filters columns, and renders as
markdown tables within a token budget.
"""

import csv
from pathlib import Path

from ..adapter_base import DataAdapter


class Adapter(DataAdapter):
    """Reads CSV files and renders as markdown tables."""

    def __init__(self):
        self._path = None
        self._fields = None

    def connect(self, source_config: dict) -> None:
        """Bind to a CSV file.

        source_config:
            - "path": file path
            - "params.fields": list of column names to include (optional)
        """
        self._path = Path(source_config.get("path", ""))
        params = source_config.get("params", {})
        self._fields = params.get("fields", None)

    def fetch(self, token_budget: int, params: dict) -> str:
        """Read CSV from disk and render within budget (file feeder)."""
        if not self._path or not self._path.exists():
            return f"[No data: {self._path} not found]"
        records = self._load_records()
        return self.render_records(records, token_budget, params)

    def render_records(self, records: list[dict], token_budget: int,
                       params: dict = None) -> str:
        """Render already-loaded records as a markdown table within budget.

        This is the single formatter used by BOTH the file feeder (fetch) and
        the DB-fed pipeline path, so the model receives identical tokens
        regardless of where the records came from.
        """
        params = params or {}
        if not records:
            return "[No records found]"
        fields = params.get("fields", self._fields)
        if fields is None:
            fields = list(records[0].keys())
        char_budget = token_budget * 4
        return self._render_table(records, fields, char_budget)

    def _load_records(self, fields=None) -> list[dict]:
        """Load records from CSV file."""
        with open(self._path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            records = []
            for row in reader:
                if fields:
                    row = {k: row.get(k, "") for k in fields}
                records.append(dict(row))
        return records

    def _render_table(self, records: list[dict], fields: list[str],
                      char_budget: int) -> str:
        """Render records as a markdown table within character budget."""
        if not records or not fields:
            return "[No data]"

        header = "| " + " | ".join(fields) + " |"
        separator = "| " + " | ".join("---" for _ in fields) + " |"
        lines = [header, separator]
        used = len(header) + len(separator) + 2

        count = 0
        for rec in records:
            values = [str(rec.get(f, "")) for f in fields]
            row = "| " + " | ".join(values) + " |"

            if used + len(row) + 1 > char_budget:
                remaining = len(records) - count
                if remaining > 0:
                    lines.append(f"| ... {remaining} more records | " +
                                " | ".join("" for _ in fields[1:]) + " |")
                break

            lines.append(row)
            used += len(row) + 1
            count += 1

        return "\n".join(lines)
