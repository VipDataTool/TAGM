"""Verbatim data adapter: pass-through text, truncated to budget."""

from ..adapter_base import DataAdapter


class Adapter(DataAdapter):
    """Passes text through as-is, truncated to fit the token budget."""

    def __init__(self):
        self._text = ""

    def connect(self, source_config: dict) -> None:
        """Accept text from config or a file path.

        source_config may contain:
            - "text": direct text content
            - "path": path to a text file
        """
        if "text" in source_config:
            self._text = source_config["text"]
        elif "path" in source_config:
            with open(source_config["path"], encoding="utf-8") as f:
                self._text = f.read()
        else:
            self._text = ""

    def fetch(self, token_budget: int, params: dict) -> str:
        """Return text truncated to budget."""
        char_budget = token_budget * 4  # rough: 4 chars ≈ 1 token
        if len(self._text) <= char_budget:
            return self._text
        # Truncate at word boundary
        truncated = self._text[:char_budget]
        last_space = truncated.rfind(" ")
        if last_space > char_budget * 0.8:
            truncated = truncated[:last_space]
        return truncated + "\n\n[... truncated to fit token budget]"

    def render_records(self, records: list[dict], token_budget: int,
                       params: dict = None) -> str:
        """Render DB-fed ledger records as verbatim text within budget.

        This adapter only had the file-feeder path (connect/fetch); the
        pipeline's DB-fed path probes for render_records with hasattr, so
        verbatim sources backed by ingested records silently produced no
        text. Single formatter discipline (like csv/json): the content
        field is params['field'] if given, else the first non-empty string
        value — schema-agnostic, since the ledger's column names are the
        ingest adapters' business. Reuses fetch() so truncation behavior
        is byte-identical to the file path.
        """
        params = params or {}
        if not records:
            return "[No records found]"
        # Content resolution order: explicit params['field'] > the ledger's
        # 'content' column (the ingestion schema's actual text field) > the
        # longest string value (so oddly-shaped feeds still surface their
        # payload instead of an ID that happens to sort first).
        field = params.get("field")
        parts = []
        for r in records:
            if field:
                v = r.get(field, "")
            elif isinstance(r.get("content"), str) and r.get("content"):
                v = r["content"]
            else:
                strs = [x for x in r.values() if isinstance(x, str) and x]
                v = max(strs, key=len) if strs else ""
            if v:
                parts.append(str(v))
        self._text = "\n\n".join(parts)
        return self.fetch(token_budget, params)
