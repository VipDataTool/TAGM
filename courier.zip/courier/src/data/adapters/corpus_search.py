"""Corpus search adapter: retrieval-grounded reference text.

Where `verbatim` delivers the first N tokens of a reference document (
relevance-blind truncation), this adapter searches the corpus index
(core.corpus.CorpusStore — FTS5/BM25) at render time and fills the token
budget with the passages that actually bear on this cycle, each carrying a
citation [doc §section · chunk#idx · sha1] so the report's claims are
verifiable against the source documents.

The query is assembled from up to two places:
  - params["query"]: fixed terms the template always cares about
    ("no-wake zone", "vessel exclusion").
  - the cycle's own ledger records (the DB-fed path hands them to
    render_records): salient tokens are extracted from the fresh
    observations, so a vessel name or hull number seen THIS cycle pulls
    its registry entry and the regulations that mention it. Deterministic —
    the same records always derive the same terms.

params:
    query        fixed query terms (string), optional
    top_k        max passages to consider (default 8)
    doc_ids      restrict search to these documents (list), optional
    from_records derive terms from cycle records (default true on the
                 DB-fed path; set false to use only the fixed query)
    max_terms    cap on record-derived query terms (default 24)
    path         corpus.db location; also accepted via source `path`
"""
from __future__ import annotations

import json
import re
from collections import Counter
from pathlib import Path

from ..adapter_base import DataAdapter

_WORD_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9\-_/\.]{2,63}")

# Render-formatting internals — named for visibility, deliberately NOT
# params: they shape presentation, not retrieval.
_MIN_CHAR_BUDGET = 200       # floor so a tiny stage budget still cites something
_MIN_PARTIAL_CHARS = 120     # shortest truncated passage still worth citing

# Minimal stopword set: enough to keep glue words from dominating the OR
# query; intentionally small so domain terms are never eaten.
_STOP = {
    "the", "and", "for", "are", "was", "were", "with", "that", "this",
    "from", "has", "have", "had", "not", "its", "his", "her", "who",
    "you", "all", "can", "may", "will", "shall", "into", "out", "per",
    "true", "false", "null", "none", "nan", "n/a",
    # ledger/envelope plumbing keys that appear in every record's JSON
    "timestamp", "source_id", "source_type", "records", "content",
    "checksum", "value", "type", "id", "name", "time", "date", "data",
}
_DEFAULT_MAX_DERIVED_TERMS = 24


def _derive_terms(records: list[dict],
                  max_terms: int = _DEFAULT_MAX_DERIVED_TERMS) -> list[str]:
    """Salient tokens from the cycle's records, most frequent first.

    Values only (keys are schema, not signal). Tokens containing digits are
    always kept regardless of frequency rank cutoffs' input — hull numbers,
    permit IDs and coordinates are exactly what registry retrieval is for.
    """
    counts: Counter = Counter()
    for r in records or []:
        content = r.get("content") if isinstance(r, dict) else None
        obj = None
        if isinstance(content, str):
            try:
                obj = json.loads(content)
            except (ValueError, TypeError):
                obj = content
        else:
            obj = content or r
        for v in _iter_values(obj):
            for tok in _WORD_RE.findall(str(v)):
                low = tok.lower()
                if low in _STOP:
                    continue
                if low.isdigit() and len(low) < 3:
                    continue
                counts[tok] += 1
    ranked = [t for t, _ in counts.most_common(max_terms * 3)]
    with_digits = [t for t in ranked if any(c.isdigit() for c in t)]
    words = [t for t in ranked if not any(c.isdigit() for c in t)]
    out, seen = [], set()
    for t in with_digits + words:      # identifiers first: they're the point
        if t.lower() in seen:
            continue
        seen.add(t.lower())
        out.append(t)
        if len(out) >= max_terms:
            break
    return out


def _iter_values(obj):
    if isinstance(obj, dict):
        for v in obj.values():
            yield from _iter_values(v)
    elif isinstance(obj, (list, tuple)):
        for v in obj:
            yield from _iter_values(v)
    elif obj is not None:
        yield obj


class Adapter(DataAdapter):
    """Retrieval-grounded reference source."""

    def __init__(self):
        self._path = ""
        self._params = {}

    def connect(self, source_config: dict) -> None:
        params = source_config.get("params") or {}
        self._params = params
        self._path = (params.get("path") or source_config.get("path") or "")

    # ── shared core ──────────────────────────────────────────
    def _merged(self, params: dict | None) -> dict:
        """Template params overlaid on source params — the one merge point."""
        return {**self._params, **(params or {})}

    def _store(self):
        from core.corpus import CorpusStore, DEFAULT_CORPUS_FILENAME
        path = Path(self._path) if self._path else Path(DEFAULT_CORPUS_FILENAME)
        if not path.exists():
            return None, path
        return CorpusStore(path), path

    def _render(self, extra_terms: list[str], token_budget: int,
                params: dict) -> str:
        """Retrieve and format passages. `params` must already be merged
        (callers go through _merged)."""
        store, path = self._store()
        if store is None:
            # Loud, not fatal: the analysis proceeds; the report says why
            # its grounding section is empty.
            return (f"[Corpus not found at {path} — build one with "
                    f"gator's digestor and ingest it]")
        try:
            fixed = str(params.get("query") or "")
            terms = _WORD_RE.findall(fixed) + list(extra_terms or [])
            if not terms:
                return "[Corpus search: no query terms (set params.query " \
                       "or enable from_records)]"
            hits = store.search(terms, top_k=int(params.get("top_k") or 8),
                                doc_ids=params.get("doc_ids"))
            if not hits:
                return ("[Corpus: no passages matched " +
                        ", ".join(terms[:8]) +
                        ("…" if len(terms) > 8 else "") + "]")
            # 4 chars/token is the repo-wide estimate (see DataAdapter docstring)
            char_budget = max(_MIN_CHAR_BUDGET, token_budget * 4)
            parts = ["Reference passages (corpus-retrieved, cited):"]
            used = len(parts[0])
            for h in hits:
                sec = f" §{h['section']}" if h.get("section") else ""
                cite = (f"[{h['doc_id']}{sec} · chunk#{h['chunk_index']}"
                        + (f" · {h['sha1'][:8]}" if h.get("sha1") else "") + "]")
                body = " ".join((h.get("body") or "").split())
                block = f"\n\n{cite}\n{body}"
                if used + len(block) > char_budget:
                    remain = char_budget - used - len(cite) - 20
                    if remain > _MIN_PARTIAL_CHARS:   # partial still worth citing
                        parts.append(f"\n\n{cite}\n{body[:remain]} "
                                     f"[…passage truncated]")
                    break
                parts.append(block)
                used += len(block)
            return "".join(parts)
        finally:
            store.close()

    # ── file-feeder path (no ledger records) ─────────────────
    def fetch(self, token_budget: int, params: dict) -> str:
        return self._render([], token_budget, self._merged(params))

    # ── DB-fed path: records are this cycle's observations ───
    def render_records(self, records: list[dict], token_budget: int,
                       params: dict = None) -> str:
        params = self._merged(params)
        derive = params.get("from_records", True)
        extra = (_derive_terms(records,
                       max_terms=int(params.get("max_terms")
                                     or _DEFAULT_MAX_DERIVED_TERMS))
         if derive else [])
        return self._render(extra, token_budget, params)
