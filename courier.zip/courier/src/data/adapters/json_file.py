"""JSON file data adapter.

Reads local JSON files (objects, arrays, JSONL), extracts specified
fields, and renders as markdown tables within a token budget.
Handles single files, directories, and append-only log files.
"""

import json
from pathlib import Path

from ..adapter_base import DataAdapter


class Adapter(DataAdapter):
    """Reads JSON files and renders as markdown tables."""

    def __init__(self):
        self._path = None
        self._fields = None

    def connect(self, source_config: dict) -> None:
        """Bind to a JSON file or directory.

        source_config:
            - "path": file or directory path
            - "params.fields": list of field names to extract (optional)
        """
        self._path = Path(source_config.get("path", ""))
        params = source_config.get("params", {})
        self._fields = params.get("fields", None)

    def fetch(self, token_budget: int, params: dict) -> str:
        """Read JSON from disk and render within budget (file feeder)."""
        if not self._path or not self._path.exists():
            return f"[No data: {self._path} not found]"
        records = self._load_records()
        return self.render_records(records, token_budget, params)

    def render_records(self, records: list[dict], token_budget: int,
                       params: dict = None) -> str:
        """Render already-loaded records as a markdown table within budget.

        Single formatter shared by the file feeder (fetch) and the DB-fed
        pipeline path, guaranteeing identical tokens regardless of source.
        """
        params = params or {}
        if not records:
            return "[No records found]"
        fields = params.get("fields", self._fields)
        if fields is None:
            fields = list(records[0].keys())
        char_budget = token_budget * 4
        return self._render_table(records, fields, char_budget)

    def _load_records(self) -> list[dict]:
        """Load records from file(s)."""
        if self._path.is_dir():
            records = []
            for f in sorted(self._path.glob("*.json")):
                records.extend(self._load_file(f))
            return records
        return self._load_file(self._path)

    def _load_file(self, path: Path) -> list[dict]:
        """Load records from a single file (array, object, or JSONL)."""
        text = path.read_text(encoding="utf-8").strip()
        if not text:
            return []

        # Try JSON array first
        if text.startswith("["):
            data = json.loads(text)
            if isinstance(data, list):
                return [r for r in data if isinstance(r, dict)]

        # Try single JSON object
        if text.startswith("{") and "\n{" not in text:
            data = json.loads(text)
            if isinstance(data, dict):
                return [data]

        # Try JSONL (newline-delimited)
        records = []
        for line in text.split("\n"):
            line = line.strip()
            if line and line.startswith("{"):
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return records

    def _render_table(self, records: list[dict], fields: list[str],
                      char_budget: int) -> str:
        """Render records as a markdown table within character budget."""
        if not records or not fields:
            return "[No data]"

        # Header
        header = "| " + " | ".join(fields) + " |"
        separator = "| " + " | ".join("---" for _ in fields) + " |"
        lines = [header, separator]
        used = len(header) + len(separator) + 2  # +2 for newlines

        # Rows (newest first if timestamp-like field exists)
        count = 0
        for rec in records:
            values = [str(rec.get(f, "")) for f in fields]
            row = "| " + " | ".join(values) + " |"

            if used + len(row) + 1 > char_budget:
                remaining = len(records) - count
                if remaining > 0:
                    lines.append(f"| ... {remaining} more records | " +
                                " | ".join("" for _ in fields[1:]) + " |")
                break

            lines.append(row)
            used += len(row) + 1
            count += 1

        return "\n".join(lines)
