"""Data adapters and ingestion."""
