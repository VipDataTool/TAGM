"""Data adapter base class.

Each data source type (JSON API, CSV file, SQLite, etc.) implements
this interface. The adapter connects to the source, queries it,
aggregates the results, and returns model-ready text that fits
within a token budget.
"""

from abc import ABC, abstractmethod


class DataAdapter(ABC):
    """Abstract base for data source adapters."""

    @abstractmethod
    def connect(self, source_config: dict) -> None:
        """Bind to the data source.

        Args:
            source_config: Adapter-specific configuration from the
                template (endpoint, path, credentials, params, etc.)
        """

    @abstractmethod
    def fetch(self, token_budget: int, params: dict) -> str:
        """Query, aggregate, and render data as model-ready text.

        Must return text that fits within token_budget tokens.
        A rough estimate of 4 characters per token is acceptable;
        the pipeline will handle precise tokenization.

        Args:
            token_budget: Maximum tokens the output should consume
            params: Additional parameters from the template

        Returns:
            Formatted text (markdown table, key-value block, etc.)
            that the model can reason about.
        """

    def estimate_tokens(self, text: str) -> int:
        """Rough token count estimate (4 chars ≈ 1 token)."""
        return max(1, len(text) // 4)
