"""Local data ingestion.

Stores records in SQLite, marks consumed records, and takes
snapshots for cycle processing. This module handles the local
(non-HTTP) ingestion path — files, directories, and direct calls.
"""

import csv
import hashlib
import json
import time
from pathlib import Path
from typing import Optional

from core.db import Database


def checksum(content: str) -> str:
    """SHA-256 checksum of content."""
    return hashlib.sha256(content.encode()).hexdigest()


IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif", ".webp"}
_MIME = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
         ".bmp": "image/bmp", ".tiff": "image/tiff", ".tif": "image/tiff",
         ".webp": "image/webp"}


def file_checksum(path: str | Path) -> str:
    """SHA-256 of a file's raw bytes (for image/binary provenance)."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def ingest_image_file(db: Database, path: str | Path,
                      source_id: Optional[str] = None,
                      source_type: str = "inbox") -> int:
    """Record an image in the ledger as a metadata row + on-disk pointer.

    Image pixels are NOT stored in the DB — they must reach the vision encoder
    as a file. The row holds the path, dimensions, size, and checksum so a
    cycle can SELECT which images are in scope; the pixels are dereferenced
    from `path` at inference time.
    """
    path = Path(path)
    if source_id is None:
        source_id = path.stem

    width = height = None
    try:
        from PIL import Image
        with Image.open(path) as im:
            width, height = im.size
    except Exception:
        pass  # dims optional; path is what matters

    meta = {"path": str(path), "filename": path.name,
            "width": width, "height": height}
    content = json.dumps(meta)
    return db.ingest(
        source_id=source_id,
        content=content,
        mime_type=_MIME.get(path.suffix.lower(), "image/jpeg"),
        checksum=file_checksum(path),
        path=str(path),
        source_type=source_type,
    )


def ingest_file(db: Database, path: str | Path,
                source_id: Optional[str] = None,
                source_type: str = "inbox") -> int:
    """Dispatch a single file to the right intake by extension.

    Tabular (.json/.csv) → rows; images → a metadata+pointer row; other text
    files → a single verbatim record. Returns the number of records ingested.
    """
    path = Path(path)
    ext = path.suffix.lower()
    if ext == ".json":
        return ingest_json_file(db, path, source_id, source_type=source_type)
    if ext == ".csv":
        return ingest_csv_file(db, path, source_id, source_type=source_type)
    if ext in IMAGE_EXTENSIONS:
        return 1 if ingest_image_file(db, path, source_id, source_type) else 0
    # Fallback: treat as a single verbatim text record.
    text = path.read_text(encoding="utf-8", errors="replace")
    sid = source_id or path.stem
    return 1 if db.ingest(sid, text, checksum=checksum(text),
                          path=str(path), source_type=source_type) else 0


def ingest_record(db: Database, source_id: str, content: str,
                  timestamp: Optional[float] = None) -> int:
    """Ingest a single text record."""
    return db.ingest(
        source_id=source_id,
        content=content,
        timestamp=timestamp,
        checksum=checksum(content),
    )


def ingest_json_file(db: Database, path: str | Path,
                     source_id: Optional[str] = None,
                     source_type: str = "inbox") -> int:
    """Ingest records from a JSON file (array of objects or single object)."""
    path = Path(path)
    if source_id is None:
        source_id = path.stem

    text = path.read_text(encoding="utf-8")
    data = json.loads(text)

    # Self-describing envelope (the Datagator conduit contract):
    # {"source_type": "feed", "records": [...]} lets a FILE carry its ledger
    # semantics — the import folder cannot otherwise distinguish a polling
    # conduit's drop (overlapping windows; consumed identities must not
    # re-feed) from a hand-uploaded test set (re-upload SHOULD re-feed).
    # Plain arrays and plain objects behave exactly as before.
    if isinstance(data, dict) and isinstance(data.get("records"), list):
        source_type = str(data.get("source_type") or source_type)
        # Corpus envelopes (the digestor contract) are durable knowledge,
        # not perishable observations: they index into corpus.db beside the
        # ledger, never into the ingestion table — reference chunks must be
        # RETRIEVED by relevance at render time, not unioned wholesale into
        # every cycle. Replace-by-doc_id: re-dropping an updated regulation
        # supersedes its old chunks.
        if source_type == "corpus":
            from core.corpus import CorpusStore, ingest_corpus_envelope, \
                DEFAULT_CORPUS_FILENAME
            store = CorpusStore(Path(db.path).parent / DEFAULT_CORPUS_FILENAME)
            try:
                n = ingest_corpus_envelope(store, data,
                                           fallback_doc_id=source_id)
            finally:
                store.close()
            print(f"  Corpus: indexed {n} chunk(s) from "
                  f"'{data.get('doc_id') or source_id}'", flush=True)
            return n
        data = data["records"]

    if isinstance(data, list):
        records = []
        for item in data:
            content = json.dumps(item)
            ts = None
            if isinstance(item, dict) and "timestamp" in item:
                ts = _parse_timestamp(item["timestamp"])
            records.append({
                "source_id": source_id,
                "content": content,
                "timestamp": ts or time.time(),
                "checksum": checksum(content),
                "path": str(path),
                "source_type": source_type,
            })
        return db.ingest_batch(records)
    else:
        content = json.dumps(data) if not isinstance(data, str) else data
        return 1 if db.ingest(source_id, content, checksum=checksum(content),
                              path=str(path), source_type=source_type) else 0


def ingest_csv_file(db: Database, path: str | Path,
                    source_id: Optional[str] = None,
                    source_type: str = "inbox") -> int:
    """Ingest records from a CSV file (one record per row)."""
    path = Path(path)
    if source_id is None:
        source_id = path.stem

    records = []
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            content = json.dumps(dict(row))
            ts = None
            if "timestamp" in row:
                ts = _parse_timestamp(row["timestamp"])
            records.append({
                "source_id": source_id,
                "content": content,
                "timestamp": ts or time.time(),
                "checksum": checksum(content),
                "path": str(path),
                "source_type": source_type,
            })

    return db.ingest_batch(records)


def ingest_directory(db: Database, path: str | Path,
                     source_id: Optional[str] = None,
                     source_type: str = "inbox") -> int:
    """Ingest all JSON, CSV, and image files from a directory."""
    path = Path(path)
    count = 0
    for f in sorted(path.iterdir()):
        if not f.is_file():
            continue
        sid = source_id or f.stem
        if f.suffix.lower() in (".json", ".csv") or f.suffix.lower() in IMAGE_EXTENSIONS:
            count += ingest_file(db, f, sid, source_type=source_type)
    return count


def snapshot_data(db: Database, cycle_id: str) -> tuple[int, str]:
    """Snapshot unconsumed data for a cycle.

    Returns (record_count, formatted_text) where formatted_text
    is the records rendered as a data block for the pipeline.
    """
    count = db.snapshot(cycle_id)
    if count == 0:
        return 0, ""

    records = db.get_snapshot_records(cycle_id)

    # Render as a simple text block (the pipeline's data adapters
    # handle more sophisticated formatting)
    lines = []
    for r in records:
        lines.append(r["content"])

    text = "\n".join(lines)
    return count, text


def _parse_timestamp(value) -> Optional[float]:
    """Try to parse a timestamp value to epoch float."""
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        # ISO 8601
        try:
            from datetime import datetime, timezone
            dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
            return dt.timestamp()
        except (ValueError, TypeError):
            pass
    return None
