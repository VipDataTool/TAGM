"""Courier — Edge Inference Framework for Large Language Models."""

__version__ = "0.2.7"
