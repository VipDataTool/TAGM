"""GGUF layout transforms — undoing what convert_hf_to_gguf.py did.

llama.cpp's converter rewrites some tensors' memory layout for
llama-architecture models: Q and K projection weights are permuted from
HF's split-half rotary layout to gguf's interleaved layout. A GGUF
loader that hands such weights to HF-convention code unchanged produces
scrambled attention — no error, just garbage. This module holds the
forward permutation (for reference and testing) and its inverse (what a
loader must apply).

Which tensors need which transform is FAMILY knowledge, so it is
declared by the model adapters (`ModelAdapter.gguf_load_transforms`)
and applied blindly by GGUFShardManager — the shard manager never
learns family names. Qwen3/Qwen3.5 declare nothing: their converter
path does not permute (validated bit-for-bit against the gguf-py
oracle, Tier 2).

Torch-free on purpose: the math is pure reshape/swapaxes, so it works
identically on torch tensors and numpy arrays, which lets the cold
probes pin it without torch (see tests/probe_gguf_layout.py).
Duplicated nowhere — tools/gguf_diff_harness.py imports from here.
"""


def llama_permute(w, n_head: int):
    """convert_hf_to_gguf.py's permute(): HF split-half → gguf interleaved.

    w: (n_head * head_dim, in_features) — torch tensor or numpy array.
    """
    out_dim, in_dim = w.shape
    head_dim = out_dim // n_head
    return (w.reshape(n_head, 2, head_dim // 2, in_dim)
             .swapaxes(1, 2)
             .reshape(out_dim, in_dim))


def inverse_llama_permute(w, n_head: int):
    """Inverse of llama_permute: what a GGUF loader must apply to Q/K
    weights of llama-architecture files to recover HF layout."""
    out_dim, in_dim = w.shape
    head_dim = out_dim // n_head
    return (w.reshape(n_head, head_dim // 2, 2, in_dim)
             .swapaxes(1, 2)
             .reshape(out_dim, in_dim))
