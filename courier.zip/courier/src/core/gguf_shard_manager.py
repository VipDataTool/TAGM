"""GGUF shard manager: on-disk quantized weight loading with layer caching.

Drop-in replacement for ShardManager when the model is in GGUF format.
The engine calls the same methods (get_tensor, load_layer, load_embedding,
etc.) and receives the same torch.Tensor outputs. The dequantization from
quantized GGUF types (Q4_K, Q6_K, Q8_0, etc.) to float32/bfloat16 is
transparent to the caller.

Layer caching (§4.1, revised per courier-performance-design-spec §2–§4): the
decode loop touches layers 0..N-1 cyclically, every token. LRU is pathological
for a cyclic scan — with budget C < N layers, the wrap-around access to layer 0
arrives just after layer 0 was evicted, so the hit rate is exactly 0% and the
eviction churn is pure overhead. The caches here therefore PIN: layers are
cached in first-touch order until the budget is full, then later layers stream
forever. Hit rate becomes C/N instead of 0.

Two tiers, each with its own budget, each PIN-not-evict:

  Tier 1 — dequantized tensors (COURIER_CACHE_MB, existing knob).
      Fastest: a hit costs nothing. Most expensive per layer: bf16 is
      ~3.5x the Q4_K bytes (fp32 ~7x).
  Tier 2 — raw quantized bytes (COURIER_QCACHE_MB, new knob).
      A hit pays one in-RAM dequantize but no disk read. Bytes are stored
      at GGUF density, so a given budget pins ~3.5x (Q4_K->bf16) to ~7x
      (Q4_K->fp32) more layers than tier 1 — the lever that makes a
      bigger-than-tier-1 model mostly resident.

A layer lives in exactly one tier (first tier with room wins). Hot non-layer
tensors (the streamed LM head, re-read every token on untied GGUF models) are
byte-cached on their SECOND access, so load-once tensors (embedding, final
norm — already pinned dequantized by the engine) never spend tier-2 budget.
"""

from collections import OrderedDict
from pathlib import Path
from typing import Optional

import torch

from core.adapter.base import ModelAdapter
from core.gguf_reader import read_gguf, GGUFFile, GGUFTensorInfo
from core.gguf_name_map import gguf_to_hf_key, build_gguf_to_hf_index
from core.dequantize import dequantize


def _auto_cache_budget_mb() -> int:
    """Determine layer cache budget in MB.

    Defaults to 0 (no caching) for safety. Set COURIER_CACHE_MB to
    enable caching on machines with sufficient RAM. The right value
    depends on available memory after embedding + tokenizer + PyTorch:

        16 GB total, ~5 GB available → COURIER_CACHE_MB=0    (8B barely fits)
        32 GB total, ~20 GB available → COURIER_CACHE_MB=8000 (cache all 8B layers)
        64 GB total → COURIER_CACHE_MB=16000                  (cache all 14B layers)
    """
    import os
    override = os.environ.get("COURIER_CACHE_MB")
    if override is not None:
        return max(0, int(override))
    return 0


def _auto_qcache_budget_mb() -> int:
    """Tier-2 (raw quantized bytes) budget in MB. Default 0 = off.

    Set COURIER_QCACHE_MB to pin quantized layer bytes in RAM beyond what
    the dequantized tier-1 cache holds. A tier-2 hit trades one in-RAM
    dequantize for a disk read — a win whenever the disk is the bottleneck
    (SATA-era SSDs, network-backed volumes). Example for a 32 GB box
    running a ~42 GB 70B Q4_K_M:

        COURIER_CACHE_MB=2000  COURIER_QCACHE_MB=22000

    pins ~24 GB — a couple of layers dequantized, ~half the model as
    quantized bytes — cutting streamed disk I/O per token by ~55%.
    Whether tier-2 RAM beats leaving the same RAM to the OS page cache is
    box-dependent; measure per the spec's §12 protocol before committing
    a box's config.
    """
    import os
    override = os.environ.get("COURIER_QCACHE_MB")
    if override is not None:
        return max(0, int(override))
    return 0


class GGUFShardManager:
    """Manages weight loading from a GGUF file with optional layer caching.

    Provides the same interface as ShardManager so the inference engine
    can use either format transparently.
    """

    def __init__(
        self,
        gguf_path: str | Path,
        adapter: ModelAdapter,
        cache_budget_mb: int | None = None,
        qcache_budget_mb: int | None = None,
    ):
        """
        Args:
            gguf_path: Path to the .gguf file
            adapter: Model adapter (provides weight key mappings)
            cache_budget_mb: RAM budget for the dequantized layer cache
                (tier 1) in MB. None = read COURIER_CACHE_MB (default 0).
                0 = disable tier 1.
            qcache_budget_mb: RAM budget for the raw quantized-bytes cache
                (tier 2) in MB. None = read COURIER_QCACHE_MB (default 0).
                0 = disable tier 2 (anything tier 1 can't hold streams).

        Raises:
            FileNotFoundError: If the GGUF file doesn't exist
            ValueError: If multiple split GGUF shards are found
        """
        self.gguf_path = Path(gguf_path)
        self.adapter = adapter

        # Family-declared layout transforms (HF-name suffix → callable),
        # applied blindly at every materialization point in _materialize.
        # getattr for backward compatibility with adapter objects (test
        # fakes included) that predate the hook.
        self._load_transforms: dict = dict(
            getattr(adapter, "gguf_load_transforms", dict)() or {}
        )

        if not self.gguf_path.exists():
            raise FileNotFoundError(f"GGUF file not found: {self.gguf_path}")

        # Check for split GGUF files (not yet supported — §8.1)
        parent = self.gguf_path.parent
        shard_files = [f for f in parent.glob("*.gguf") if "-of-" in f.name]
        if len(shard_files) > 1:
            raise ValueError(
                f"Found {len(shard_files)} split GGUF shards in {parent}. "
                f"Split GGUF is not yet supported. Use llama-gguf-split --merge "
                f"to combine them, or download a non-split version."
            )

        # Parse the GGUF header and tensor index
        self._header: GGUFFile = read_gguf(self.gguf_path)

        # Open persistent file handle for tensor data reads
        self._file = open(self.gguf_path, "rb")

        # Build HF-key → GGUF TensorInfo mapping
        layer_prefix = self._detect_layer_prefix()
        hf_to_gguf_names = build_gguf_to_hf_index(
            list(self._header.tensors.keys()),
            layer_prefix=layer_prefix,
        )
        self._hf_to_info: dict[str, GGUFTensorInfo] = {}
        for hf_key, gguf_name in hf_to_gguf_names.items():
            self._hf_to_info[hf_key] = self._header.tensors[gguf_name]

        # Also keep a reverse mapping for debugging
        self._gguf_to_hf: dict[str, str] = {v: k for k, v in hf_to_gguf_names.items()}

        # ── Layer caches (spec §3–§4): PIN, never evict ───────
        if cache_budget_mb is None:
            cache_budget_mb = _auto_cache_budget_mb()
        if qcache_budget_mb is None:
            qcache_budget_mb = _auto_qcache_budget_mb()

        # Tier 1: layer_idx -> {role: dequantized tensor}
        self._cache_budget_bytes = cache_budget_mb * 1024 * 1024
        self._layer_cache: OrderedDict[int, dict[str, torch.Tensor]] = OrderedDict()
        self._cache_bytes = 0
        self._cache_hits = 0
        self._cache_misses = 0

        # Tier 2: layer_idx -> {role: (hf_key, raw quantized bytes)}
        self._qcache_budget_bytes = qcache_budget_mb * 1024 * 1024
        self._qcache: dict[int, dict[str, tuple[str, bytes]]] = {}
        self._qcache_bytes = 0
        self._qcache_hits = 0

        # Hot non-layer tensors (e.g. the streamed LM head, re-read every
        # token on untied models): hf_key -> raw bytes, cached on SECOND
        # access so load-once tensors (embedding, final norm — pinned
        # dequantized by the engine already) never spend tier-2 budget.
        # Counted against the tier-2 budget.
        self._misc_qcache: dict[str, bytes] = {}
        self._misc_seen: set[str] = set()
        self._misc_qhits = 0

    def _detect_layer_prefix(self) -> str:
        """Detect the HF layer prefix for this model."""
        try:
            sample_keys = self.adapter.layer_weight_keys(0)
            first_key = next(iter(sample_keys.values()))
            if ".layers.0." in first_key:
                prefix = first_key.split(".layers.0.")[0] + ".layers"
                return prefix
        except Exception:
            pass
        return "model.layers"

    def _read_raw(self, info: GGUFTensorInfo) -> bytes:
        """Read raw tensor bytes from the GGUF file."""
        offset = self._header.tensor_data_offset + info.offset
        self._file.seek(offset)
        return self._file.read(info.nbytes)

    @staticmethod
    def _layer_bytes(layer_dict: dict[str, torch.Tensor]) -> int:
        """Compute total bytes of a cached layer dict."""
        return sum(t.nelement() * t.element_size() for t in layer_dict.values())

    @staticmethod
    def _ram_headroom_ok() -> bool:
        """Refuse to grow any cache when system RAM runs low, even if the
        static budget says there's room — catches embedding/LM head/KV
        consuming more than the budget anticipated (spec §2 principle 3)."""
        try:
            import psutil
            avail = psutil.virtual_memory().available
            return avail >= 1.5 * 1024 * 1024 * 1024  # keep >= 1.5 GB free
        except ImportError:
            return True

    def _cache_put(self, layer_idx: int, layer_dict: dict[str, torch.Tensor]) -> bool:
        """PIN a layer's dequantized tensors in tier 1 if the budget allows.

        No eviction — ever. The decode loop's access pattern is a cyclic
        scan over all layers, for which LRU yields a 0% hit rate the moment
        budget < model (the wrap-around access always lands on the
        just-evicted entry). Pinning first-touch — which under a cyclic
        scan is layer order — converts the same budget into a stable C/N
        hit rate. Returns True iff stored (spec §3).
        """
        if self._cache_budget_bytes <= 0:
            return False

        layer_size = self._layer_bytes(layer_dict)
        if self._cache_bytes + layer_size > self._cache_budget_bytes:
            return False  # tier full — the layer belongs to a lower tier
        if not self._ram_headroom_ok():
            return False

        self._layer_cache[layer_idx] = layer_dict
        self._cache_bytes += layer_size
        return True

    def _cache_get(self, layer_idx: int) -> Optional[dict[str, torch.Tensor]]:
        """Look up a layer in tier 1. Returns None on miss."""
        if layer_idx in self._layer_cache:
            self._cache_hits += 1
            return self._layer_cache[layer_idx]
        self._cache_misses += 1
        return None

    def _qcache_put(self, layer_idx: int, raw_map: dict[str, tuple[str, bytes]]) -> bool:
        """PIN a layer's raw quantized bytes in tier 2 if the budget allows.

        Same PIN-not-evict policy and reasoning as tier 1. Bytes stay at
        GGUF density, so a tier-2 GB pins ~3.5x (->bf16) to ~7x (->fp32)
        the layers a tier-1 GB does (spec §4). Returns True iff stored.
        """
        if self._qcache_budget_bytes <= 0:
            return False

        size = sum(len(raw) for _, raw in raw_map.values())
        if self._qcache_bytes + size > self._qcache_budget_bytes:
            return False
        if not self._ram_headroom_ok():
            return False

        self._qcache[layer_idx] = raw_map
        self._qcache_bytes += size
        return True

    def _materialize(self, hf_key: str, raw: bytes, info,
                     dtype: Optional[torch.dtype]) -> torch.Tensor:
        """Raw bytes → usable tensor: dequantize, then apply any
        family-declared layout transform (adapter.gguf_load_transforms,
        suffix-matched). EVERY tensor materialization goes through here
        — fresh disk reads and tier-2 dequantize-from-RAM alike — so the
        tier-1 cache only ever stores transformed tensors and the two
        roads cannot disagree. Tier 2 stores raw (untransformed) bytes;
        re-materializing on a tier-2 hit re-applies the transform, which
        keeps its byte-identical-to-disk contract intact."""
        t = dequantize(raw, info.ggml_type, info.shape, dtype=dtype)
        for suffix, fn in self._load_transforms.items():
            if hf_key.endswith(suffix):
                t = fn(t)
                break
        return t

    def get_tensor(
        self,
        key: str,
        dtype: Optional[torch.dtype] = None,
    ) -> torch.Tensor:
        """Load a single tensor by HF state dict key.

        Args:
            key: HuggingFace state dict key
            dtype: Optional dtype to cast to. If None, returns as dequantized
                   (float32). This preserves the double-load pattern in
                   HybridStreamer (§8.2) where norm weights need native precision.

        Returns:
            Dequantized tensor
        """
        if key not in self._hf_to_info:
            raise KeyError(f"Tensor key '{key}' not found in GGUF file")

        info = self._hf_to_info[key]

        # Hot-tensor byte cache (spec §4): serve from RAM if pinned.
        raw = self._misc_qcache.get(key)
        if raw is not None:
            self._misc_qhits += 1
            return self._materialize(key, raw, info, dtype)

        raw = self._read_raw(info)

        # Second-access rule: the FIRST direct read of a key is free (load-
        # once tensors — embedding, final norm — never spend budget); a
        # SECOND read marks the tensor hot (the streamed LM head is read
        # every token) and pins its bytes, within the tier-2 budget.
        if key in self._misc_seen:
            if (self._qcache_budget_bytes > 0
                    and self._qcache_bytes + len(raw) <= self._qcache_budget_bytes
                    and self._ram_headroom_ok()):
                self._misc_qcache[key] = raw
                self._qcache_bytes += len(raw)
        else:
            self._misc_seen.add(key)

        return self._materialize(key, raw, info, dtype)

    def has_key(self, key: str) -> bool:
        """Check if a tensor key exists in the GGUF file."""
        return key in self._hf_to_info

    def load_embedding(self, dtype: torch.dtype = torch.bfloat16) -> torch.Tensor:
        """Load the token embedding matrix."""
        return self.get_tensor(self.adapter.embedding_key(), dtype)

    def load_final_norm(self, dtype: torch.dtype = torch.bfloat16) -> torch.Tensor:
        """Load the final RMSNorm weight."""
        return self.get_tensor(self.adapter.final_norm_key(), dtype)

    def load_lm_head(self, dtype: torch.dtype = torch.bfloat16) -> Optional[torch.Tensor]:
        """Load the LM head weight, or None if tied to embedding."""
        key = self.adapter.lm_head_key()
        if key is None:
            return None
        if not self.has_key(key):
            return None
        return self.get_tensor(key, dtype)

    def load_layer(
        self,
        layer_idx: int,
        dtype: torch.dtype = torch.bfloat16,
    ) -> dict[str, torch.Tensor]:
        """Load all weight tensors for a single layer.

        Uses the layer cache when available. On cache hit, returns the
        cached dict directly (no disk I/O or dequantization). On miss,
        loads from disk, caches the result, and returns it.

        Args:
            layer_idx: Layer index (0-based)
            dtype: Dtype to cast all tensors to

        Returns:
            Dict mapping weight role names to tensors, e.g.:
            {"q_proj": tensor, "k_proj": tensor, ...}
        """
        # Tier 1: dequantized tensors — free hit.
        cached = self._cache_get(layer_idx)
        if cached is not None:
            return dict(cached)  # shallow copy; tensors shared, dict private

        # Tier 2: raw quantized bytes — dequantize from RAM, no disk read.
        raw_map = self._qcache.get(layer_idx)
        from_disk = raw_map is None
        if from_disk:
            key_map = self.adapter.layer_weight_keys(layer_idx)
            raw_map = {}
            for role, hf_key in key_map.items():
                if self.has_key(hf_key):
                    raw_map[role] = (hf_key, self._read_raw(self._hf_to_info[hf_key]))
        else:
            self._qcache_hits += 1

        result = {}
        for role, (hf_key, raw) in raw_map.items():
            info = self._hf_to_info[hf_key]
            result[role] = self._materialize(hf_key, raw, info, dtype)

        if from_disk:
            # Place the layer in the first tier with room. Exactly one tier
            # owns a layer: tensors in tier 1 OR bytes in tier 2, never
            # both. Once both tiers are full, later layers stream from disk
            # every token — the PIN policy's deliberate steady state.
            if not self._cache_put(layer_idx, result):
                self._qcache_put(layer_idx, raw_map)

        return result

    def all_keys(self) -> list[str]:
        """Return all mapped HF tensor keys."""
        return list(self._hf_to_info.keys())

    @property
    def header(self) -> GGUFFile:
        """Access the parsed GGUF header (for metadata inspection)."""
        return self._header

    def tensor_info(self, key: str) -> Optional[GGUFTensorInfo]:
        """Get the GGUF tensor info for an HF key (for debugging)."""
        return self._hf_to_info.get(key)

    def cache_stats(self) -> dict:
        """Cache statistics for monitoring and probes.

        Keeps the original tier-1 keys, adds tier-2 / misc keys, and adds
        ShardManager-compatible aliases (resident / resident_bytes /
        resident_max_bytes / layers_cached) so the dashboard's residency
        panel — which reads those names — lights up for GGUF models too.
        """
        total = self._cache_hits + self._cache_misses
        hit_rate = self._cache_hits / total if total > 0 else 0.0
        resident_bytes = self._cache_bytes + self._qcache_bytes
        resident_max = self._cache_budget_bytes + self._qcache_budget_bytes
        return {
            # Tier 1 (original keys, unchanged meaning)
            "cached_layers": len(self._layer_cache),
            "cache_bytes": self._cache_bytes,
            "cache_mb": self._cache_bytes / (1024 * 1024),
            "budget_mb": self._cache_budget_bytes / (1024 * 1024),
            "hits": self._cache_hits,
            "misses": self._cache_misses,
            "hit_rate": hit_rate,
            # Tier 2 + hot-tensor byte cache
            "qcached_layers": len(self._qcache),
            "qcache_bytes": self._qcache_bytes,
            "qbudget_mb": self._qcache_budget_bytes / (1024 * 1024),
            "qhits": self._qcache_hits,
            "misc_qcached": len(self._misc_qcache),
            "misc_qhits": self._misc_qhits,
            # ShardManager-compatible aliases (dashboard residency panel)
            "resident": resident_max > 0,
            "resident_bytes": resident_bytes,
            "resident_max_bytes": resident_max,
            "layers_cached": len(self._layer_cache) + len(self._qcache),
        }

    def close(self):
        """Close the GGUF file handle and clear all caches."""
        self._layer_cache.clear()
        self._cache_bytes = 0
        self._qcache.clear()
        self._qcache_bytes = 0
        self._misc_qcache.clear()
        self._misc_seen.clear()
        if self._file and not self._file.closed:
            self._file.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def __repr__(self) -> str:
        arch = self._header.architecture
        n_tensors = len(self._hf_to_info)
        size_mb = self.gguf_path.stat().st_size / (1024 * 1024)
        cached = len(self._layer_cache)
        return (
            f"GGUFShardManager({self.gguf_path.name}, "
            f"arch={arch}, tensors={n_tensors}, size={size_mb:.0f}MB, "
            f"cached_layers={cached})"
        )
