"""Security: token authentication and TLS.

Token authentication
────────────────────
Generates API tokens on first start. Tokens are stored hashed in
the database. Bearer token required for write operations. Read
operations are open (ops mode dashboard works without auth).

TLS certificate generation (dormant)
─────────────────────────────────────
The functions below (ensure_tls_cert, get_cert_paths, has_tls_certs)
generate a self-signed EC P-256 certificate suitable for HTTPS.
They are NOT currently wired into the server or startup — they exist
as base machinery for a future TLS implementation.

To activate TLS when ready:

1. GENERATE CERT AT STARTUP
   In server.py lifespan, after token setup:

       from core.security import ensure_tls_cert
       import socket
       app_root = Path(__file__).parent.parent
       ensure_tls_cert(app_root, hostname=socket.gethostname())

   This is idempotent — only generates if certs don't exist yet.
   Certs are written to <app_root>/certs/courier.pem and
   <app_root>/certs/courier-key.pem. Key file is chmod 600.

2. PASS CERTS TO UVICORN
   In start.sh, add to the uvicorn launch:

       --ssl-certfile certs/courier.pem --ssl-keyfile certs/courier-key.pem

   Or in cli.py's uvicorn.run() call:

       ssl_certfile="certs/courier.pem", ssl_keyfile="certs/courier-key.pem"

3. MAKE IT CONFIGURABLE
   Add "tls_enabled" to FACTORY_DEFAULTS (bool, default False).
   Gate the uvicorn SSL flags on that config value.
   Surface a toggle in the dashboard Security section.
   TLS changes require a server restart to take effect.

4. CUSTOM CERTS
   For production deployments with a real CA cert, skip
   ensure_tls_cert() and point uvicorn at the custom cert/key
   directly via CLI flags or config.

The cryptography library is already in requirements.txt.
"""

import hashlib
import os
import secrets
import sqlite3
import time
from pathlib import Path
from typing import Optional


TOKENS_SCHEMA = """
CREATE TABLE IF NOT EXISTS api_tokens (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE,
    token_hash  TEXT NOT NULL,
    role        TEXT NOT NULL DEFAULT 'readwrite',
    created_at  REAL NOT NULL,
    last_used   REAL
);
"""


class TokenManager:
    """Manage API authentication tokens."""

    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(TOKENS_SCHEMA)
        self._conn.commit()

    def _hash(self, token: str) -> str:
        return hashlib.sha256(token.encode()).hexdigest()

    def create_token(self, name: str, read_only: bool = False) -> str:
        """Create a new API token. Returns the plaintext token (shown once)."""
        token = secrets.token_urlsafe(32)
        role = "readonly" if read_only else "readwrite"
        self._conn.execute(
            "INSERT INTO api_tokens (name, token_hash, role, created_at) "
            "VALUES (?, ?, ?, ?)",
            (name, self._hash(token), role, time.time())
        )
        self._conn.commit()
        return token

    def verify(self, token: str) -> Optional[dict]:
        """Verify a token. Returns token info or None."""
        token_hash = self._hash(token)
        row = self._conn.execute(
            "SELECT * FROM api_tokens WHERE token_hash = ?",
            (token_hash,)
        ).fetchone()
        if row is None:
            return None
        self._conn.execute(
            "UPDATE api_tokens SET last_used = ? WHERE id = ?",
            (time.time(), row["id"])
        )
        self._conn.commit()
        return dict(row)

    def can_write(self, token: str) -> bool:
        """Check if a token has write access."""
        info = self.verify(token)
        if info is None:
            return False
        return info["role"] == "readwrite"

    def list_tokens(self) -> list[dict]:
        """List all tokens (without hashes)."""
        rows = self._conn.execute(
            "SELECT name, role, created_at, last_used FROM api_tokens "
            "ORDER BY created_at"
        ).fetchall()
        return [dict(r) for r in rows]

    def revoke(self, name: str) -> bool:
        """Revoke a token by name."""
        cur = self._conn.execute(
            "DELETE FROM api_tokens WHERE name = ?", (name,)
        )
        self._conn.commit()
        return cur.rowcount > 0

    def has_tokens(self) -> bool:
        """Check if any tokens exist."""
        row = self._conn.execute("SELECT COUNT(*) FROM api_tokens").fetchone()
        return row[0] > 0

    def ensure_default_token(self) -> Optional[str]:
        """Create a default token if none exist. Returns token or None."""
        if self.has_tokens():
            return None
        token = self.create_token("default", read_only=False)
        return token

    def close(self):
        self._conn.close()


# ── TLS certificate generation (dormant — see module docstring) ──

CERT_DIR_NAME = "certs"
CERT_FILE = "courier.pem"
KEY_FILE = "courier-key.pem"


def get_cert_paths(base_dir: str | Path) -> tuple[Path, Path]:
    """Return (cert_path, key_path) for the standard cert location."""
    cert_dir = Path(base_dir) / CERT_DIR_NAME
    return cert_dir / CERT_FILE, cert_dir / KEY_FILE


def has_tls_certs(base_dir: str | Path) -> bool:
    """Check if TLS certs exist at the standard location."""
    cert, key = get_cert_paths(base_dir)
    return cert.exists() and key.exists()


def ensure_tls_cert(
    base_dir: str | Path,
    hostname: str = "localhost",
) -> tuple[Path, Path]:
    """Generate a self-signed TLS certificate if one doesn't exist.

    Uses the cryptography library (already in requirements.txt).
    Produces an ECDSA P-256 key and a cert valid for 10 years,
    with SANs for localhost, 127.0.0.1, 0.0.0.0, and the
    provided hostname.

    Idempotent — returns existing paths if certs already exist.
    Key file is written with mode 0600 (owner read-only).

    NOT called by any startup code. See module docstring for
    wiring instructions.

    Args:
        base_dir: Application root (certs/ directory created inside)
        hostname: Additional SAN hostname (e.g. machine hostname)

    Returns:
        (cert_path, key_path) tuple
    """
    import datetime
    import ipaddress

    cert_path, key_path = get_cert_paths(base_dir)
    if cert_path.exists() and key_path.exists():
        return cert_path, key_path

    from cryptography import x509
    from cryptography.x509.oid import NameOID
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec

    private_key = ec.generate_private_key(ec.SECP256R1())

    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Courier"),
        x509.NameAttribute(NameOID.COMMON_NAME, hostname),
    ])

    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(private_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(now + datetime.timedelta(days=3650))
        .add_extension(
            x509.SubjectAlternativeName([
                x509.DNSName("localhost"),
                x509.DNSName(hostname),
                x509.IPAddress(ipaddress.IPv4Address("127.0.0.1")),
                x509.IPAddress(ipaddress.IPv4Address("0.0.0.0")),
            ]),
            critical=False,
        )
        .sign(private_key, hashes.SHA256())
    )

    cert_path.parent.mkdir(parents=True, exist_ok=True)
    key_path.write_bytes(
        private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
    )
    key_path.chmod(0o600)
    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))

    return cert_path, key_path


# ── Write-authorization posture ──────────────────────────────
# Pure and dependency-free so cold probes can exercise every mode; the
# server calls this for the startup banner and /api/node, and enforces the
# same precedence in require_write.

def write_posture(env=None) -> dict:
    """The node's effective write-authorization posture, from environment.

    Precedence — on conflicting settings, the SAFEST always wins:

      1. COURIER_REQUIRE_TOKEN=1 → "token-required": every write needs a
         valid bearer token; the tokenless local path is disabled. Set this
         whenever the node is reachable through any proxy or shared port
         whose callers you do not fully control. Beats COURIER_INSECURE.
      2. COURIER_INSECURE=1 → "insecure-bypass": all write auth waived
         (dev escape hatch). LOUD.
      3. CODESPACES set (unless COURIER_TRUST_PROXY=0), or
         COURIER_TRUST_PROXY=1 → "proxy-trusted": the TCP-peer loopback
         check is skipped because an authenticating proxy fronts the node.
         LOUD, because it is safe only while that assumption holds — e.g.
         a Codespaces forwarded port left PRIVATE. A port flipped to
         PUBLIC silently breaks it: the proxy forwards anyone, with a
         rewritten local Host.
      4. otherwise → "local-origin": the turnkey default. Tokenless writes
         only from a loopback TCP peer with a local Host and no cross-site
         fetch marker; remote writes need the bearer token.

    Returns {"mode", "summary", "loud", "note"} — `loud` marks postures the
    UI and startup banner must warn about, `note` says exactly why and what
    to do about it.
    """
    env = os.environ if env is None else env
    if env.get("COURIER_REQUIRE_TOKEN") == "1":
        return {"mode": "token-required",
                "summary": "bearer token required for ALL writes "
                           "(COURIER_REQUIRE_TOKEN=1)",
                "loud": False, "note": ""}
    if env.get("COURIER_INSECURE") == "1":
        return {"mode": "insecure-bypass",
                "summary": "ALL write authorization bypassed "
                           "(COURIER_INSECURE=1)",
                "loud": True,
                "note": "Every client that can reach this port can write. "
                        "Use only on a fully trusted, isolated machine."}
    explicit = env.get("COURIER_TRUST_PROXY") == "1"
    auto = bool(env.get("CODESPACES")) and         env.get("COURIER_TRUST_PROXY") != "0"
    if explicit or auto:
        why = "COURIER_TRUST_PROXY=1" if explicit else "CODESPACES detected"
        return {"mode": "proxy-trusted",
                "summary": f"tokenless local writes; proxy trusted ({why})",
                "loud": True,
                "note": "Tokenless writes are accepted from ANY client the "
                        "proxy forwards, because the proxy rewrites Host and "
                        "peer address. Safe only while the proxy "
                        "authenticates callers — e.g. a Codespaces forwarded "
                        "port kept PRIVATE. If the port is ever made public, "
                        "set COURIER_REQUIRE_TOKEN=1 (or opt out of proxy "
                        "trust with COURIER_TRUST_PROXY=0)."}
    return {"mode": "local-origin",
            "summary": "tokenless writes from loopback only; remote writes "
                       "need a bearer token; cross-site + non-local Hosts "
                       "blocked",
            "loud": False, "note": ""}
