"""Dequantization kernels for GGUF quantized tensors.

Each kernel takes raw bytes and returns a flat float32 numpy array.
The dispatcher reshapes and converts to a torch.Tensor.

Supported types (sufficient for Q4_K_M files):
    F32  (type 0):  passthrough
    F16  (type 1):  cast to float32
    BF16 (type 30): bit-shift to float32
    Q8_0 (type 8):  block of 32, fp16 scale + 32 int8 quants
    Q4_K (type 12): super-block of 256, packed 6-bit scales, 4-bit quants
    Q6_K (type 14): super-block of 256, 6-bit quants with 8-bit scales

Reference implementations: ggml-quants.c (C) and gguf-py/gguf/quants.py (Python).
Validate against gguf-py during development (see strategy doc §8.8).
"""

import numpy as np

from core.gguf_reader import (
    GGML_TYPE_F32, GGML_TYPE_F16, GGML_TYPE_BF16,
    GGML_TYPE_Q8_0, GGML_TYPE_Q4_K, GGML_TYPE_Q6_K,
    GGML_TYPE_NAMES, GGML_BLOCK_INFO,
)

# Threshold for chunked dequantization: if FP32 intermediate would exceed
# this, process in row-batches to cap the memory spike (§8.4).
_CHUNK_THRESHOLD_BYTES = 512 * 1024 * 1024  # 512 MB


def _dispatch_kernel(raw: bytes, ggml_type: int, n_elements: int) -> np.ndarray:
    """Dispatch to the appropriate dequantization kernel. Returns flat FP32 array."""
    if ggml_type == GGML_TYPE_F32:
        return _dequantize_f32(raw, n_elements)
    elif ggml_type == GGML_TYPE_F16:
        return _dequantize_f16(raw, n_elements)
    elif ggml_type == GGML_TYPE_BF16:
        return _dequantize_bf16(raw, n_elements)
    elif ggml_type == GGML_TYPE_Q8_0:
        return _dequantize_q8_0(raw, n_elements)
    elif ggml_type == GGML_TYPE_Q4_K:
        return _dequantize_q4_k(raw, n_elements)
    elif ggml_type == GGML_TYPE_Q6_K:
        return _dequantize_q6_k(raw, n_elements)
    else:
        type_name = GGML_TYPE_NAMES.get(ggml_type, f"UNKNOWN({ggml_type})")
        raise ValueError(
            f"Unsupported quantization type: {type_name}. "
            f"Supported types: F32, F16, BF16, Q8_0, Q4_K, Q6_K."
        )


def dequantize(
    raw: bytes,
    ggml_type: int,
    shape: tuple[int, ...],
    dtype=None,
) -> "torch.Tensor":
    """Dequantize raw GGUF tensor bytes to a torch.Tensor.

    For large tensors with a non-float32 target dtype, uses chunked
    processing to avoid the FP32 memory spike (strategy doc §8.4).
    The embedding matrix (151936×4096 at Q4_K) would need 2.5 GB FP32
    plus 1.2 GB BF16 simultaneously — chunked processing caps the
    FP32 intermediate at ~40 MB per batch.

    Args:
        raw: Raw bytes from the GGUF file for this tensor
        ggml_type: The ggml_type enum value for this tensor
        shape: Target tensor shape (PyTorch convention)
        dtype: Optional output dtype (torch.dtype). If None, returns float32.
               If specified (e.g., torch.bfloat16), casts after dequantization.

    Returns:
        torch.Tensor with the given shape and dtype
    """
    import torch

    n_elements = 1
    for d in shape:
        n_elements *= d

    fp32_bytes = n_elements * 4
    need_cast = dtype is not None and dtype != torch.float32

    # Chunked path for large 2D tensors that need casting
    if (need_cast and fp32_bytes > _CHUNK_THRESHOLD_BYTES
            and len(shape) == 2 and ggml_type in GGML_BLOCK_INFO):
        return _dequantize_chunked(raw, ggml_type, shape, dtype)

    # Standard path: dequantize entire tensor at once
    arr = _dispatch_kernel(raw, ggml_type, n_elements)
    tensor = torch.from_numpy(arr.reshape(shape))

    if need_cast:
        tensor = tensor.to(dtype)

    return tensor


def _dequantize_chunked(
    raw: bytes,
    ggml_type: int,
    shape: tuple[int, ...],
    dtype,
) -> "torch.Tensor":
    """Dequantize a large 2D tensor in row-batches to cap FP32 memory spike.

    Processes groups of rows, dequantizing each group to FP32 then
    immediately casting to the target dtype. The FP32 intermediate
    for each chunk is freed before the next chunk starts.
    """
    import torch

    rows, cols = shape
    bytes_per_block, elements_per_block = GGML_BLOCK_INFO[ggml_type]

    blocks_per_row = cols // elements_per_block
    bytes_per_row = blocks_per_row * bytes_per_block

    # Target ~64 MB FP32 per chunk
    target_chunk_bytes = 64 * 1024 * 1024
    chunk_rows = max(1, target_chunk_bytes // (cols * 4))

    output = torch.empty(shape, dtype=dtype)
    raw_mv = memoryview(raw)

    for start in range(0, rows, chunk_rows):
        end = min(start + chunk_rows, rows)
        n_rows = end - start

        raw_start = start * bytes_per_row
        raw_end = end * bytes_per_row
        chunk_raw = bytes(raw_mv[raw_start:raw_end])

        chunk_elements = n_rows * cols
        arr = _dispatch_kernel(chunk_raw, ggml_type, chunk_elements)
        chunk_tensor = torch.from_numpy(arr.reshape(n_rows, cols)).to(dtype)
        output[start:end] = chunk_tensor
        del arr, chunk_tensor  # free FP32 intermediate immediately

    return output


# ── Passthrough kernels ───────────────────────────────────────

def _dequantize_f32(raw: bytes, n_elements: int) -> np.ndarray:
    """F32: no conversion needed."""
    return np.frombuffer(raw, dtype=np.float32).copy()


def _dequantize_f16(raw: bytes, n_elements: int) -> np.ndarray:
    """F16: cast float16 → float32."""
    return np.frombuffer(raw, dtype=np.float16).astype(np.float32)


def _dequantize_bf16(raw: bytes, n_elements: int) -> np.ndarray:
    """BF16: reconstruct float32 from bfloat16 by left-shifting 16 bits.

    BF16 is the upper 16 bits of a float32. Padding with 16 zero bits
    on the right reconstructs the float32 value.
    """
    bf16 = np.frombuffer(raw, dtype=np.uint16)
    f32_bits = bf16.astype(np.uint32) << 16
    return f32_bits.view(np.float32).copy()


# ── Q8_0: 8-bit quantization ─────────────────────────────────
#
# Block layout (34 bytes per 32 elements):
#   Offset 0:  fp16 d       — scale factor
#   Offset 2:  int8[32] qs  — quantized values
#
# Dequantization: value[i] = d * qs[i]

def _dequantize_q8_0(raw: bytes, n_elements: int) -> np.ndarray:
    """Q8_0: 8-bit quantization with fp16 block scale."""
    BLOCK_ELEMENTS = 32
    BLOCK_BYTES = 34
    n_blocks = n_elements // BLOCK_ELEMENTS

    data = np.frombuffer(raw, dtype=np.uint8).reshape(n_blocks, BLOCK_BYTES)

    # Extract fp16 scales (first 2 bytes of each block)
    # .copy() is needed because the slice may not be aligned for fp16 view
    scales = data[:, :2].copy().view(np.float16).astype(np.float32)  # (n_blocks, 1)

    # Extract int8 quantized values (bytes 2-33)
    qs = data[:, 2:].view(np.int8).astype(np.float32)  # (n_blocks, 32)

    # Dequantize: value = scale * quant
    return (scales * qs).ravel()


# ── Q4_K: 4-bit K-quant ──────────────────────────────────────
#
# Super-block layout (144 bytes per 256 elements):
#   Offset 0:   fp16 d              — super-block scale
#   Offset 2:   fp16 dmin           — super-block minimum
#   Offset 4:   uint8[12] scales    — packed 6-bit scales and mins for 8 sub-blocks
#   Offset 16:  uint8[128] qs       — 4-bit quantized values (2 per byte)
#
# The 256 elements are organized as 8 sub-blocks of 32 elements.
# Sub-blocks are stored in pairs: each pair of 32-byte qs entries
# contributes low nibbles (sub-block 2j) and high nibbles (sub-block 2j+1).
#
# Dequantization per sub-block j:
#   value = d * scale[j] * nibble - dmin * min[j]
#
# Scale/min packing in the 12-byte scales array:
#   scales[0..3] = bytes[0..3] & 0x3F                                    (low 6 bits)
#   mins[0..3]   = bytes[4..7] & 0x3F                                    (low 6 bits)
#   scales[4..7] = (bytes[8..11] & 0x0F) | ((bytes[0..3] >> 6) << 4)    (4+2 bits)
#   mins[4..7]   = (bytes[8..11] >> 4)   | ((bytes[4..7] >> 6) << 4)    (4+2 bits)
#
# Reference: dequantize_row_q4_K() in ggml-quants.c

def _dequantize_q4_k(raw: bytes, n_elements: int) -> np.ndarray:
    """Q4_K: 4-bit K-quantization with 6-bit packed sub-block scales."""
    BLOCK_ELEMENTS = 256
    BLOCK_BYTES = 144
    n_blocks = n_elements // BLOCK_ELEMENTS

    data = np.frombuffer(raw, dtype=np.uint8).reshape(n_blocks, BLOCK_BYTES)

    # ── Extract d and dmin (fp16 → float32) ───────────────
    d = data[:, 0:2].copy().view(np.float16).astype(np.float32).ravel()       # (n_blocks,)
    dmin = data[:, 2:4].copy().view(np.float16).astype(np.float32).ravel()    # (n_blocks,)

    # ── Unpack 8 scales and 8 mins from 12-byte array ─────
    sb = data[:, 4:16]  # (n_blocks, 12)  — "scales bytes"

    sc = np.zeros((n_blocks, 8), dtype=np.float32)
    mn = np.zeros((n_blocks, 8), dtype=np.float32)

    # Low scales [0..3]: bytes[0..3] & 0x3F
    sc[:, 0] = sb[:, 0] & 0x3F
    sc[:, 1] = sb[:, 1] & 0x3F
    sc[:, 2] = sb[:, 2] & 0x3F
    sc[:, 3] = sb[:, 3] & 0x3F

    # Low mins [0..3]: bytes[4..7] & 0x3F
    mn[:, 0] = sb[:, 4] & 0x3F
    mn[:, 1] = sb[:, 5] & 0x3F
    mn[:, 2] = sb[:, 6] & 0x3F
    mn[:, 3] = sb[:, 7] & 0x3F

    # High scales [4..7]: (bytes[8..11] & 0x0F) | ((bytes[0..3] >> 6) << 4)
    sc[:, 4] = (sb[:, 8]  & 0x0F) | ((sb[:, 0] >> 6) << 4)
    sc[:, 5] = (sb[:, 9]  & 0x0F) | ((sb[:, 1] >> 6) << 4)
    sc[:, 6] = (sb[:, 10] & 0x0F) | ((sb[:, 2] >> 6) << 4)
    sc[:, 7] = (sb[:, 11] & 0x0F) | ((sb[:, 3] >> 6) << 4)

    # High mins [4..7]: (bytes[8..11] >> 4) | ((bytes[4..7] >> 6) << 4)
    mn[:, 4] = (sb[:, 8]  >> 4) | ((sb[:, 4] >> 6) << 4)
    mn[:, 5] = (sb[:, 9]  >> 4) | ((sb[:, 5] >> 6) << 4)
    mn[:, 6] = (sb[:, 10] >> 4) | ((sb[:, 6] >> 6) << 4)
    mn[:, 7] = (sb[:, 11] >> 4) | ((sb[:, 7] >> 6) << 4)

    # ── Extract and dequantize 256 nibbles ────────────────
    qs = data[:, 16:144]  # (n_blocks, 128)
    result = np.zeros((n_blocks, BLOCK_ELEMENTS), dtype=np.float32)

    # Process 4 pairs of sub-blocks (each pair shares 32 qs bytes)
    # Pair j uses qs[:, j*32:(j+1)*32]:
    #   low nibble  → sub-block 2j   (32 elements)
    #   high nibble → sub-block 2j+1 (32 elements)
    for j in range(4):
        qs_chunk = qs[:, j * 32:(j + 1) * 32]  # (n_blocks, 32)

        q_low = (qs_chunk & 0x0F).astype(np.float32)   # low nibbles  → sub-block 2j
        q_high = (qs_chunk >> 4).astype(np.float32)     # high nibbles → sub-block 2j+1

        # Sub-block 2j
        s_idx = 2 * j
        d_sc = (d * sc[:, s_idx])[:, None]         # (n_blocks, 1)
        dmin_mn = (dmin * mn[:, s_idx])[:, None]    # (n_blocks, 1)
        result[:, j * 64:j * 64 + 32] = d_sc * q_low - dmin_mn

        # Sub-block 2j+1
        s_idx = 2 * j + 1
        d_sc = (d * sc[:, s_idx])[:, None]
        dmin_mn = (dmin * mn[:, s_idx])[:, None]
        result[:, j * 64 + 32:j * 64 + 64] = d_sc * q_high - dmin_mn

    return result.ravel()


# ── Q6_K: 6-bit K-quant ──────────────────────────────────────
#
# Super-block layout (210 bytes per 256 elements):
#   Offset 0:    uint8[128] ql      — low 4 bits of 6-bit quants (2 per byte)
#   Offset 128:  uint8[64]  qh      — high 2 bits of 6-bit quants (4 per byte)
#   Offset 192:  int8[16]   scales  — per-sub-block scales (16 sub-blocks of 16 elements)
#   Offset 208:  fp16 d             — super-block scale
#
# Reconstruction of 6-bit quant:
#   q6 = (ql_nibble) | ((qh_2bits) << 4)  — gives unsigned 0..63
#   q_signed = q6 - 32                    — gives signed -32..31
#
# Dequantization:
#   value = d * scales[sub_block] * q_signed
#
# The 256 elements are processed in 2 halves of 128. Each half uses
# 64 ql bytes, 32 qh bytes, and 8 scale values.
#
# Reference: dequantize_row_q6_K() in ggml-quants.c

def _dequantize_q6_k(raw: bytes, n_elements: int) -> np.ndarray:
    """Q6_K: 6-bit K-quantization with int8 sub-block scales."""
    BLOCK_ELEMENTS = 256
    BLOCK_BYTES = 210
    n_blocks = n_elements // BLOCK_ELEMENTS

    data = np.frombuffer(raw, dtype=np.uint8).reshape(n_blocks, BLOCK_BYTES)

    # ── Extract fields ────────────────────────────────────
    ql_all = data[:, 0:128]                                                    # (n_blocks, 128)
    qh_all = data[:, 128:192]                                                  # (n_blocks, 64)
    scales = data[:, 192:208].view(np.int8).astype(np.float32)                 # (n_blocks, 16)
    d = data[:, 208:210].copy().view(np.float16).astype(np.float32).ravel()    # (n_blocks,)

    result = np.zeros((n_blocks, BLOCK_ELEMENTS), dtype=np.float32)

    # Process in 2 halves of 128 elements each
    for half in range(2):
        ql = ql_all[:, half * 64:(half + 1) * 64]    # (n_blocks, 64)
        qh = qh_all[:, half * 32:(half + 1) * 32]    # (n_blocks, 32)
        sc = scales[:, half * 8:(half + 1) * 8]       # (n_blocks, 8)
        out_offset = half * 128

        # Within each half, 128 elements are arranged as 4 groups of 32.
        # Each group of 32 shares a contiguous block of ql bytes
        # but draws qh bits from the same 32 qh bytes at different bit positions.
        #
        # Group 0: elements [0..31]   — ql[0:32] low nibble,  qh[0:32] bits 0-1
        # Group 1: elements [32..63]  — ql[32:64] low nibble, qh[0:32] bits 2-3
        # Group 2: elements [64..95]  — ql[0:32] high nibble, qh[0:32] bits 4-5
        # Group 3: elements [96..127] — ql[32:64] high nibble,qh[0:32] bits 6-7

        ql_lo_0 = (ql[:, 0:32] & 0x0F).astype(np.int32)     # low nibble of first 32 bytes
        ql_lo_1 = (ql[:, 32:64] & 0x0F).astype(np.int32)    # low nibble of second 32 bytes
        ql_hi_0 = (ql[:, 0:32] >> 4).astype(np.int32)       # high nibble of first 32 bytes
        ql_hi_1 = (ql[:, 32:64] >> 4).astype(np.int32)      # high nibble of second 32 bytes

        qh_0 = ((qh >> 0) & 0x03).astype(np.int32)  # bits 0-1
        qh_1 = ((qh >> 2) & 0x03).astype(np.int32)  # bits 2-3
        qh_2 = ((qh >> 4) & 0x03).astype(np.int32)  # bits 4-5
        qh_3 = ((qh >> 6) & 0x03).astype(np.int32)  # bits 6-7

        # Reconstruct 6-bit values and subtract zero-point (32)
        q0 = (ql_lo_0 | (qh_0 << 4)) - 32   # (n_blocks, 32)
        q1 = (ql_lo_1 | (qh_1 << 4)) - 32   # (n_blocks, 32)
        q2 = (ql_hi_0 | (qh_2 << 4)) - 32   # (n_blocks, 32)
        q3 = (ql_hi_1 | (qh_3 << 4)) - 32   # (n_blocks, 32)

        # Apply per-sub-block scales.
        # Each group of 32 elements spans 2 sub-blocks of 16 elements each.
        # Group 0 uses sc[0] for elements 0-15, sc[1] for elements 16-31.
        # Group 1 uses sc[2] for elements 0-15, sc[3] for elements 16-31.
        # Group 2 uses sc[4], sc[5].
        # Group 3 uses sc[6], sc[7].
        d_col = d[:, None]  # (n_blocks, 1)

        for g, q in enumerate([q0, q1, q2, q3]):
            sc_lo = (d_col * sc[:, 2 * g:2 * g + 1])       # (n_blocks, 1) — scale for first 16
            sc_hi = (d_col * sc[:, 2 * g + 1:2 * g + 2])   # (n_blocks, 1) — scale for second 16
            q_f = q.astype(np.float32)
            out_start = out_offset + g * 32
            result[:, out_start:out_start + 16] = sc_lo * q_f[:, :16]
            result[:, out_start + 16:out_start + 32] = sc_hi * q_f[:, 16:]

    return result.ravel()
