"""GGUF binary format reader.

Parses a GGUF file header, metadata key-value pairs, and tensor info
to build an in-memory index. No external dependencies beyond struct.

Reference: https://github.com/ggml-org/ggml/blob/master/docs/gguf.md
"""

import struct
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# ── GGUF magic and version ────────────────────────────────────

GGUF_MAGIC = 0x46554747  # "GGUF" as little-endian uint32

# ── gguf_metadata_value_type enum ─────────────────────────────

GGUF_TYPE_UINT8   = 0
GGUF_TYPE_INT8    = 1
GGUF_TYPE_UINT16  = 2
GGUF_TYPE_INT16   = 3
GGUF_TYPE_UINT32  = 4
GGUF_TYPE_INT32   = 5
GGUF_TYPE_FLOAT32 = 6
GGUF_TYPE_BOOL    = 7
GGUF_TYPE_STRING  = 8
GGUF_TYPE_ARRAY   = 9
GGUF_TYPE_UINT64  = 10
GGUF_TYPE_INT64   = 11
GGUF_TYPE_FLOAT64 = 12

# Struct format + size for scalar metadata types (little-endian)
_SCALAR_FORMATS = {
    GGUF_TYPE_UINT8:   ("<B",  1),
    GGUF_TYPE_INT8:    ("<b",  1),
    GGUF_TYPE_UINT16:  ("<H",  2),
    GGUF_TYPE_INT16:   ("<h",  2),
    GGUF_TYPE_UINT32:  ("<I",  4),
    GGUF_TYPE_INT32:   ("<i",  4),
    GGUF_TYPE_FLOAT32: ("<f",  4),
    GGUF_TYPE_BOOL:    ("<B",  1),  # stored as uint8, 0=false 1=true
    GGUF_TYPE_UINT64:  ("<Q",  8),
    GGUF_TYPE_INT64:   ("<q",  8),
    GGUF_TYPE_FLOAT64: ("<d",  8),
}

# ── ggml_type enum — quantization types ───────────────────────

GGML_TYPE_F32     = 0
GGML_TYPE_F16     = 1
GGML_TYPE_Q4_0    = 2
GGML_TYPE_Q4_1    = 3
GGML_TYPE_Q5_0    = 6
GGML_TYPE_Q5_1    = 7
GGML_TYPE_Q8_0    = 8
GGML_TYPE_Q8_1    = 9
GGML_TYPE_Q2_K    = 10
GGML_TYPE_Q3_K    = 11
GGML_TYPE_Q4_K    = 12
GGML_TYPE_Q5_K    = 13
GGML_TYPE_Q6_K    = 14
GGML_TYPE_Q8_K    = 15
GGML_TYPE_BF16    = 30

# Block size table: ggml_type → (bytes_per_block, elements_per_block)
# Used to compute the total byte size of a quantized tensor.
GGML_BLOCK_INFO = {
    GGML_TYPE_F32:  (4,   1),     # 4 bytes per float32
    GGML_TYPE_F16:  (2,   1),     # 2 bytes per float16
    GGML_TYPE_BF16: (2,   1),     # 2 bytes per bfloat16
    GGML_TYPE_Q8_0: (34,  32),    # 2 (fp16 scale) + 32 (int8 quants) = 34 per 32 elements
    GGML_TYPE_Q4_0: (18,  32),    # 2 (fp16 scale) + 16 (4-bit packed) = 18 per 32 elements
    GGML_TYPE_Q4_1: (20,  32),    # 2+2 (fp16 scale+min) + 16 = 20 per 32 elements
    GGML_TYPE_Q5_0: (22,  32),    # 2 + 4 (5th bits) + 16 = 22 per 32 elements
    GGML_TYPE_Q5_1: (24,  32),    # 2+2 + 4 + 16 = 24 per 32 elements
    GGML_TYPE_Q8_1: (40,  32),    # 4+4 (float scale+sum) + 32 = 40 per 32 elements
    GGML_TYPE_Q2_K: (84,  256),   # fp16 + fp16 + 16 + 64 = 84 per 256
    GGML_TYPE_Q3_K: (110, 256),   # fp16 + 64 + 32 + 12 = 110 per 256
    GGML_TYPE_Q4_K: (144, 256),   # 2*fp16 + 12 (scales) + 128 (qs) = 144 per 256
    GGML_TYPE_Q5_K: (176, 256),   # 2*fp16 + 12 + 128 + 32 = 176 per 256
    GGML_TYPE_Q6_K: (210, 256),   # 128 (ql) + 64 (qh) + 16 (scales) + fp16 = 210 per 256
    GGML_TYPE_Q8_K: (292, 256),   # float + 256 + 16*int16 = 292 per 256
}

GGML_TYPE_NAMES = {v: k for k, v in globals().items() if k.startswith("GGML_TYPE_")}


# ── Data structures ───────────────────────────────────────────

@dataclass
class GGUFTensorInfo:
    """Metadata for a single tensor in the GGUF file."""
    name: str
    n_dims: int
    shape: tuple[int, ...]     # PyTorch convention: (rows, cols) — reversed from GGUF storage
    ggml_type: int             # enum value from ggml_type
    offset: int                # byte offset from start of tensor data section
    nbytes: int                # total bytes of quantized data for this tensor

    @property
    def type_name(self) -> str:
        return GGML_TYPE_NAMES.get(self.ggml_type, f"UNKNOWN({self.ggml_type})")

    @property
    def n_elements(self) -> int:
        result = 1
        for d in self.shape:
            result *= d
        return result


@dataclass
class GGUFFile:
    """Parsed GGUF file header and tensor index."""
    version: int
    tensor_count: int
    metadata_kv_count: int
    metadata: dict[str, Any] = field(default_factory=dict)
    tensors: dict[str, GGUFTensorInfo] = field(default_factory=dict)
    tensor_data_offset: int = 0    # byte position where tensor data begins
    alignment: int = 32            # from metadata "general.alignment", default 32
    path: str = ""

    @property
    def architecture(self) -> str:
        """Return the model architecture string (e.g., 'llama', 'qwen2')."""
        return self.metadata.get("general.architecture", "unknown")


# ── Reader ────────────────────────────────────────────────────

class _Reader:
    """Sequential binary reader with position tracking."""

    def __init__(self, f):
        self.f = f

    def read_bytes(self, n: int) -> bytes:
        data = self.f.read(n)
        if len(data) < n:
            raise EOFError(f"Expected {n} bytes, got {len(data)}")
        return data

    def read_u8(self) -> int:
        return struct.unpack("<B", self.read_bytes(1))[0]

    def read_i8(self) -> int:
        return struct.unpack("<b", self.read_bytes(1))[0]

    def read_u16(self) -> int:
        return struct.unpack("<H", self.read_bytes(2))[0]

    def read_i16(self) -> int:
        return struct.unpack("<h", self.read_bytes(2))[0]

    def read_u32(self) -> int:
        return struct.unpack("<I", self.read_bytes(4))[0]

    def read_i32(self) -> int:
        return struct.unpack("<i", self.read_bytes(4))[0]

    def read_u64(self) -> int:
        return struct.unpack("<Q", self.read_bytes(8))[0]

    def read_i64(self) -> int:
        return struct.unpack("<q", self.read_bytes(8))[0]

    def read_f32(self) -> float:
        return struct.unpack("<f", self.read_bytes(4))[0]

    def read_f64(self) -> float:
        return struct.unpack("<d", self.read_bytes(8))[0]

    def read_bool(self) -> bool:
        return self.read_u8() != 0

    def read_string(self) -> str:
        length = self.read_u64()
        return self.read_bytes(length).decode("utf-8")

    def read_metadata_value(self, value_type: int) -> Any:
        """Read a metadata value of the given type."""
        if value_type == GGUF_TYPE_STRING:
            return self.read_string()
        if value_type == GGUF_TYPE_ARRAY:
            return self._read_array()
        if value_type == GGUF_TYPE_BOOL:
            return self.read_bool()

        fmt_info = _SCALAR_FORMATS.get(value_type)
        if fmt_info is None:
            raise ValueError(f"Unknown GGUF metadata value type: {value_type}")
        fmt, size = fmt_info
        return struct.unpack(fmt, self.read_bytes(size))[0]

    def _read_array(self) -> list:
        """Read a GGUF array value (type + count + elements)."""
        elem_type = self.read_u32()
        count = self.read_u64()

        # Fast path for large arrays of scalars (e.g., tokenizer token lists)
        if elem_type in _SCALAR_FORMATS:
            fmt, size = _SCALAR_FORMATS[elem_type]
            raw = self.read_bytes(size * count)
            return list(struct.unpack(f"<{count}{fmt[1]}", raw))
        if elem_type == GGUF_TYPE_STRING:
            return [self.read_string() for _ in range(count)]
        if elem_type == GGUF_TYPE_BOOL:
            return [self.read_bool() for _ in range(count)]
        if elem_type == GGUF_TYPE_ARRAY:
            return [self._read_array() for _ in range(count)]

        raise ValueError(f"Unknown GGUF array element type: {elem_type}")

    def tell(self) -> int:
        return self.f.tell()


def _align_offset(offset: int, alignment: int) -> int:
    """Round offset up to the next multiple of alignment."""
    remainder = offset % alignment
    if remainder == 0:
        return offset
    return offset + (alignment - remainder)


def _compute_tensor_nbytes(ggml_type: int, shape: tuple[int, ...]) -> int:
    """Compute the on-disk byte size of a tensor given its type and shape."""
    n_elements = 1
    for d in shape:
        n_elements *= d

    block_info = GGML_BLOCK_INFO.get(ggml_type)
    if block_info is None:
        raise ValueError(
            f"Unsupported ggml_type {ggml_type} "
            f"({GGML_TYPE_NAMES.get(ggml_type, 'UNKNOWN')}). "
            f"Cannot compute tensor byte size."
        )

    bytes_per_block, elements_per_block = block_info

    if n_elements % elements_per_block != 0:
        raise ValueError(
            f"Tensor with {n_elements} elements is not divisible by "
            f"block size {elements_per_block} for type "
            f"{GGML_TYPE_NAMES.get(ggml_type, str(ggml_type))}"
        )

    n_blocks = n_elements // elements_per_block
    return n_blocks * bytes_per_block


def read_gguf(path: str | Path) -> GGUFFile:
    """Parse a GGUF file and return the header, metadata, and tensor index.

    Args:
        path: Path to the .gguf file

    Returns:
        GGUFFile with all metadata and tensor info parsed.
        The file is closed after parsing — only the index is kept in memory.

    Raises:
        ValueError: If the file is not a valid GGUF file
        EOFError: If the file is truncated
    """
    path = Path(path)

    with open(path, "rb") as f:
        r = _Reader(f)

        # ── Header ────────────────────────────────────────────
        magic = r.read_u32()
        if magic != GGUF_MAGIC:
            raise ValueError(
                f"Not a GGUF file: magic 0x{magic:08X}, expected 0x{GGUF_MAGIC:08X}"
            )

        version = r.read_u32()
        if version < 2:
            raise ValueError(
                f"GGUF version {version} is too old (minimum supported: 2)"
            )

        tensor_count = r.read_u64()
        metadata_kv_count = r.read_u64()

        # ── Metadata KV pairs ─────────────────────────────────
        metadata: dict[str, Any] = {}
        for _ in range(metadata_kv_count):
            key = r.read_string()
            value_type = r.read_u32()
            value = r.read_metadata_value(value_type)
            metadata[key] = value

        alignment = int(metadata.get("general.alignment", 32))

        # ── Tensor info array ─────────────────────────────────
        tensors: dict[str, GGUFTensorInfo] = {}
        for _ in range(tensor_count):
            name = r.read_string()
            n_dims = r.read_u32()

            # GGUF stores dimensions in reverse order (innermost first).
            # Reverse to get PyTorch convention (outermost first).
            dims_reversed = tuple(r.read_u64() for _ in range(n_dims))
            shape = tuple(reversed(dims_reversed))

            ggml_type = r.read_u32()
            offset = r.read_u64()

            nbytes = _compute_tensor_nbytes(ggml_type, shape)

            tensors[name] = GGUFTensorInfo(
                name=name,
                n_dims=n_dims,
                shape=shape,
                ggml_type=ggml_type,
                offset=offset,
                nbytes=nbytes,
            )

        # ── Compute tensor data section offset ────────────────
        # Tensor data starts after the header, aligned to `alignment`.
        tensor_data_offset = _align_offset(r.tell(), alignment)

    return GGUFFile(
        version=version,
        tensor_count=tensor_count,
        metadata_kv_count=metadata_kv_count,
        metadata=metadata,
        tensors=tensors,
        tensor_data_offset=tensor_data_offset,
        alignment=alignment,
        path=str(path),
    )


def print_gguf_info(path: str | Path) -> None:
    """Print a human-readable summary of a GGUF file (for debugging)."""
    header = read_gguf(path)

    print(f"GGUF File: {header.path}")
    print(f"  Version:       {header.version}")
    print(f"  Architecture:  {header.architecture}")
    print(f"  Tensors:       {header.tensor_count}")
    print(f"  Metadata keys: {header.metadata_kv_count}")
    print(f"  Alignment:     {header.alignment}")
    print(f"  Data offset:   0x{header.tensor_data_offset:X}")
    print()

    # Print key metadata
    arch = header.architecture
    interesting_keys = [
        "general.architecture", "general.name", "general.file_type",
        f"{arch}.block_count", f"{arch}.embedding_length",
        f"{arch}.feed_forward_length", f"{arch}.attention.head_count",
        f"{arch}.attention.head_count_kv", f"{arch}.attention.key_length",
        f"{arch}.vocab_size", f"{arch}.context_length",
        f"{arch}.rope.freq_base",
    ]
    print("  Key metadata:")
    for key in interesting_keys:
        if key in header.metadata:
            print(f"    {key}: {header.metadata[key]}")
    print()

    # Print first/last few tensors
    tensor_list = list(header.tensors.values())
    show = min(len(tensor_list), 5)
    print(f"  Tensors (first {show} of {len(tensor_list)}):")
    for t in tensor_list[:show]:
        print(f"    {t.name}: shape={t.shape} type={t.type_name} "
              f"offset=0x{t.offset:X} size={t.nbytes:,} bytes")
    if len(tensor_list) > show:
        print(f"    ... ({len(tensor_list) - show} more)")
