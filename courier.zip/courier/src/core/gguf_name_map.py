"""GGUF ↔ HuggingFace tensor name mapping.

GGUF uses standardized tensor names (e.g., blk.0.attn_q.weight) while
HuggingFace safetensors uses model-specific names (e.g.,
model.layers.0.self_attn.q_proj.weight). This module translates between
the two conventions so the existing Courier adapters (which speak HF names)
can work with GGUF files unchanged.

The mapping is based on llama.cpp's gguf-py/gguf/tensor_mapping.py.
"""

# ── Global (non-layer) tensor name mappings ───────────────────
# GGUF name → HuggingFace name

GGUF_TO_HF_GLOBAL = {
    "token_embd.weight":     "model.embed_tokens.weight",
    "output_norm.weight":    "model.norm.weight",
    "output_norm.bias":      "model.norm.bias",
    "output.weight":         "lm_head.weight",
    "output.bias":           "lm_head.bias",
}

# Reverse mapping for global tensors
HF_TO_GGUF_GLOBAL = {v: k for k, v in GGUF_TO_HF_GLOBAL.items()}

# Tensors some GGUFs carry that Courier DELIBERATELY does not map.
# These are derivable data, and the adapter is the authoritative source
# for them — mapping the file's copy would create two sources of truth.
# Skipped silently (a warning would cry wolf on every llama GGUF);
# genuinely unknown names still warn below.
KNOWN_UNMAPPED = {
    # Precomputed RoPE inverse frequencies (llama-family GGUFs).
    # Courier computes these in the adapter (build_rope_inv_freq, which
    # also owns the Llama 3.x piecewise scaling) — see llama3.py:
    # "the adapter's authoritative source for inv_freq".
    "rope_freqs.weight",
}

# ── Per-layer tensor name mappings ────────────────────────────
# GGUF suffix (after "blk.{i}.") → HF suffix (after "model.layers.{i}.")

GGUF_TO_HF_LAYER = {
    # Attention (standard GQA — Qwen3, Llama3, Qwen3.5 full-attn layers)
    "attn_norm.weight":      "input_layernorm.weight",
    "attn_norm.bias":        "input_layernorm.bias",
    "attn_q.weight":         "self_attn.q_proj.weight",
    "attn_q.bias":           "self_attn.q_proj.bias",
    "attn_k.weight":         "self_attn.k_proj.weight",
    "attn_k.bias":           "self_attn.k_proj.bias",
    "attn_v.weight":         "self_attn.v_proj.weight",
    "attn_v.bias":           "self_attn.v_proj.bias",
    "attn_output.weight":    "self_attn.o_proj.weight",
    "attn_output.bias":      "self_attn.o_proj.bias",
    # QK-LayerNorm (Qwen3, Qwen3.5)
    "attn_q_norm.weight":    "self_attn.q_norm.weight",
    "attn_k_norm.weight":    "self_attn.k_norm.weight",
    # Post-attention norm
    "ffn_norm.weight":       "post_attention_layernorm.weight",
    "ffn_norm.bias":         "post_attention_layernorm.bias",
    # MLP (SwiGLU)
    "ffn_gate.weight":       "mlp.gate_proj.weight",
    "ffn_gate.bias":         "mlp.gate_proj.bias",
    "ffn_up.weight":         "mlp.up_proj.weight",
    "ffn_up.bias":           "mlp.up_proj.bias",
    "ffn_down.weight":       "mlp.down_proj.weight",
    "ffn_down.bias":         "mlp.down_proj.bias",
    # ── Gated DeltaNet / linear attention (Qwen3.5 SSM layers) ──
    # These use llama.cpp's SSM naming convention (shared with Mamba).
    # The "split" form matches Qwen3.5 HF checkpoints which ship
    # separate in_proj_qkv / in_proj_z / in_proj_a / in_proj_b.
    "ssm_in.weight":         "linear_attn.in_proj_qkv.weight",   # fused QKVZ form (qwen3next)
    "ssm_a":                 "linear_attn.A_log",                 # log-space decay
    "ssm_conv1d.weight":     "linear_attn.conv1d.weight",         # causal 1D conv
    "ssm_dt.bias":           "linear_attn.dt_bias",               # time-step bias
    "ssm_norm.weight":       "linear_attn.norm.weight",           # gated RMSNorm
    "ssm_out.weight":        "linear_attn.out_proj.weight",       # output projection
    "ssm_alpha.weight":      "linear_attn.in_proj_a.weight",      # delta-rule scaling a
    "ssm_beta.weight":       "linear_attn.in_proj_b.weight",      # delta-rule scaling b
    "ssm_ba.weight":         "linear_attn.in_proj_ba.weight",     # fused b+a form
    # Split QKV/Z for linear-attention layers (the "qwen3.5" path in
    # tensor_mapping.py). NOTE: attn_qkv/attn_gate are ALSO used by
    # gated full-attention layers with a different semantic (fused Q/K/V
    # + output gate). The flat mapping here resolves to the linear-attn
    # form; the GGUF shard manager handles disambiguation by checking
    # the adapter's layer_type() for each layer index.
    "attn_qkv.weight":       "linear_attn.in_proj_qkv.weight",   # split Q/K/V
    "attn_gate.weight":      "linear_attn.in_proj_z.weight",      # output gate Z
}

# Reverse mapping for layer tensors
HF_TO_GGUF_LAYER = {v: k for k, v in GGUF_TO_HF_LAYER.items()}


def gguf_to_hf_key(gguf_name: str, layer_prefix: str = "model.layers") -> str:
    """Convert a GGUF tensor name to a HuggingFace state dict key.

    Args:
        gguf_name: GGUF tensor name (e.g., "blk.0.attn_q.weight")
        layer_prefix: HF layer prefix (e.g., "model.layers" or
                      "model.language_model.layers" for Qwen3.5)

    Returns:
        HF state dict key (e.g., "model.layers.0.self_attn.q_proj.weight")

    Examples:
        >>> gguf_to_hf_key("blk.0.attn_q.weight")
        'model.layers.0.self_attn.q_proj.weight'
        >>> gguf_to_hf_key("token_embd.weight")
        'model.embed_tokens.weight'
        >>> gguf_to_hf_key("token_embd.weight", "model.language_model.layers")
        'model.language_model.embed_tokens.weight'
        >>> gguf_to_hf_key("output.weight", "model.language_model.layers")
        'lm_head.weight'
    """
    # Global tensors (no layer index)
    if gguf_name in GGUF_TO_HF_GLOBAL:
        hf_name = GGUF_TO_HF_GLOBAL[gguf_name]
        # For composite models (e.g. Qwen3.5 with layer prefix
        # "model.language_model.layers"), adjust the base prefix for
        # embedding and norm tensors. The LM head stays top-level
        # (HuggingFace *ForConditionalGeneration convention).
        if layer_prefix != "model.layers" and hf_name.startswith("model."):
            # Derive base from layer_prefix: "model.language_model.layers"
            # → base = "model.language_model"
            base = layer_prefix.rsplit(".layers", 1)[0]
            # Replace "model." prefix with the composite base
            hf_name = base + hf_name[len("model"):]
        return hf_name

    # Layer tensors: "blk.{i}.{suffix}" → "{layer_prefix}.{i}.{hf_suffix}"
    if gguf_name.startswith("blk."):
        parts = gguf_name.split(".", 2)  # ["blk", "0", "attn_q.weight"]
        if len(parts) == 3:
            layer_idx = parts[1]
            gguf_suffix = parts[2]
            if gguf_suffix in GGUF_TO_HF_LAYER:
                hf_suffix = GGUF_TO_HF_LAYER[gguf_suffix]
                return f"{layer_prefix}.{layer_idx}.{hf_suffix}"

    # Unrecognized — return as-is (caller logs a warning)
    return gguf_name


def hf_to_gguf_key(hf_key: str, layer_prefix: str = "model.layers") -> str:
    """Convert a HuggingFace state dict key to a GGUF tensor name.

    Args:
        hf_key: HF state dict key (e.g., "model.layers.0.self_attn.q_proj.weight")
        layer_prefix: HF layer prefix to match

    Returns:
        GGUF tensor name (e.g., "blk.0.attn_q.weight")
    """
    # Global tensors
    if hf_key in HF_TO_GGUF_GLOBAL:
        return HF_TO_GGUF_GLOBAL[hf_key]

    # Layer tensors: strip the prefix and map
    lp = layer_prefix + "."
    if hf_key.startswith(lp):
        rest = hf_key[len(lp):]         # "0.self_attn.q_proj.weight"
        dot = rest.index(".")
        layer_idx = rest[:dot]           # "0"
        hf_suffix = rest[dot + 1:]       # "self_attn.q_proj.weight"
        if hf_suffix in HF_TO_GGUF_LAYER:
            gguf_suffix = HF_TO_GGUF_LAYER[hf_suffix]
            return f"blk.{layer_idx}.{gguf_suffix}"

    return hf_key


def build_gguf_to_hf_index(
    gguf_tensor_names: list[str],
    layer_prefix: str = "model.layers",
) -> dict[str, str]:
    """Build a complete GGUF→HF name mapping for all tensors in a file.

    Args:
        gguf_tensor_names: List of tensor names from GGUFFile.tensors.keys()
        layer_prefix: HF layer prefix for this model type

    Returns:
        Dict mapping HF keys → GGUF names (for all successfully mapped tensors)
    """
    hf_to_gguf = {}
    unmapped = []

    for gguf_name in gguf_tensor_names:
        if gguf_name in KNOWN_UNMAPPED:
            continue  # deliberately unused — see the set's comment
        hf_key = gguf_to_hf_key(gguf_name, layer_prefix)
        if hf_key == gguf_name and gguf_name not in GGUF_TO_HF_GLOBAL:
            # Failed to map — the name was returned unchanged
            unmapped.append(gguf_name)
        else:
            hf_to_gguf[hf_key] = gguf_name

    if unmapped:
        import warnings
        warnings.warn(
            f"GGUF name mapping: {len(unmapped)} tensor(s) could not be mapped "
            f"to HuggingFace keys: {unmapped[:5]}{'...' if len(unmapped) > 5 else ''}"
        )

    return hf_to_gguf
