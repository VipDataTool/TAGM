"""Qwen3 model family adapter.

Covers Qwen3-0.6B through Qwen3-14B. Architecture: decoder-only
transformer with GQA, QK-LayerNorm, SwiGLU MLP, RoPE, RMSNorm.

Key Qwen3-specific details:
- head_dim is decoupled from hidden_size (head_dim=128 even when
  hidden_size=1024, so q_proj output is num_heads×head_dim=2048≠1024)
- QK-LayerNorm: per-head RMSNorm on q and k after projection,
  before RoPE. Weight shape is (head_dim,), not (hidden_size,).
- RoPE uses split-half layout (not interleaved pairs)
- tie_word_embeddings may be true, but lm_head.weight can still
  exist in the shard — HuggingFace saves both, ties at load time
"""

import json
from pathlib import Path
from typing import Optional

from .base import ModelAdapter, ModelConfig


class Qwen3Adapter(ModelAdapter):
    """Adapter for the Qwen3 model family."""

    MODEL_TYPE = "qwen3"
    FAMILY_DISPLAY_NAME = "Qwen3"

    # ── Model-family defaults ────────────────────────────────
    # Qwen3 recommended sampling: temperature=0.7 for non-thinking,
    # 0.6 for thinking mode. Standard RMSNorm (weight init = ones).
    # Presence penalty helps prevent repetition loops on small models.

    def recommended_defaults(self) -> dict:
        return {
            "temperature": {
                "value": 0.7,
                "tip": "Qwen3 recommends 0.7 for non-thinking tasks, 0.6 for thinking mode. Do not use 0 — causes repetition loops.",
            },
            "top_p": {
                "value": 0.8,
                "tip": "Nucleus sampling cutoff. Qwen3 recommends 0.8. Lower values produce more conservative output.",
            },
            "top_k": {
                "value": 20,
                "tip": "Limits candidate pool to the top K tokens. 20 is the Qwen3 default.",
            },
            "presence_penalty": {
                "value": 1.5,
                "tip": "Penalizes repeated tokens. Qwen3 text-only models need this (1.0–2.0) to prevent repetition loops. Higher values push harder against repeats.",
            },
            "enable_thinking": {
                "value": False,
                "tip": "When ON, the model reasons step-by-step in a <think> block before answering. Produces better analysis but uses more tokens and time.",
            },
            "max_new_tokens": {
                "value": 2048,
                "tip": "Maximum tokens generated per pipeline stage. Qwen3 supports up to 32K; 2048 is a practical default for edge hardware.",
            },
        }

    # Per-layer weight roles and their key suffixes
    LAYER_WEIGHT_ROLES = {
        "input_layernorm":          "input_layernorm.weight",
        "post_attention_layernorm": "post_attention_layernorm.weight",
        "q_proj":                   "self_attn.q_proj.weight",
        "k_proj":                   "self_attn.k_proj.weight",
        "v_proj":                   "self_attn.v_proj.weight",
        "o_proj":                   "self_attn.o_proj.weight",
        "q_norm":                   "self_attn.q_norm.weight",
        "k_norm":                   "self_attn.k_norm.weight",
        "gate_proj":                "mlp.gate_proj.weight",
        "up_proj":                  "mlp.up_proj.weight",
        "down_proj":                "mlp.down_proj.weight",
    }

    def _load_config(self) -> ModelConfig:
        config_path = self.model_path / "config.json"
        with open(config_path, encoding="utf-8") as f:
            raw = json.load(f)

        # Parse eos_token_id: can be int or list
        eos = raw.get("eos_token_id", [151645, 151643])
        if isinstance(eos, int):
            eos = [eos]

        return ModelConfig(
            model_type=raw["model_type"],
            num_hidden_layers=raw["num_hidden_layers"],
            hidden_size=raw["hidden_size"],
            intermediate_size=raw["intermediate_size"],
            num_attention_heads=raw["num_attention_heads"],
            num_key_value_heads=raw["num_key_value_heads"],
            head_dim=raw.get("head_dim", raw["hidden_size"] // raw["num_attention_heads"]),
            vocab_size=raw["vocab_size"],
            rope_theta=raw.get("rope_theta", 1000000.0),
            rms_norm_eps=raw.get("rms_norm_eps", 1e-6),
            tie_word_embeddings=raw.get("tie_word_embeddings", False),
            max_position_embeddings=raw.get("max_position_embeddings", 40960),
            bos_token_id=raw.get("bos_token_id", 151643),
            eos_token_id=eos,
        )

    def embedding_key(self) -> str:
        return "model.embed_tokens.weight"

    def final_norm_key(self) -> str:
        return "model.norm.weight"

    def lm_head_key(self) -> Optional[str]:
        """Returns 'lm_head.weight' if not tied, else None.

        Note: even with tie_word_embeddings=true, the shard may contain
        lm_head.weight. The engine should prefer embed_tokens.weight
        when tied, falling back to lm_head.weight if embed_tokens is absent.
        """
        if self.config.tie_word_embeddings:
            return None
        return "lm_head.weight"

    def layer_keys(self, layer_idx: int) -> list[str]:
        prefix = f"model.layers.{layer_idx}."
        return [prefix + suffix for suffix in self.LAYER_WEIGHT_ROLES.values()]

    def layer_weight_keys(self, layer_idx: int) -> dict[str, str]:
        prefix = f"model.layers.{layer_idx}."
        return {role: prefix + suffix for role, suffix in self.LAYER_WEIGHT_ROLES.items()}

    # ── Qwen3-specific properties ────────────────────────────

    @property
    def has_qk_norm(self) -> bool:
        """Qwen3 has per-head QK-LayerNorm, unlike Qwen2/Llama."""
        return True

    @property
    def rope_layout(self) -> str:
        """RoPE embedding layout: 'split_half' (GPT-NeoX style)."""
        return "split_half"

    def expected_shapes(self) -> dict[str, tuple]:
        """Expected weight shapes for validation."""
        c = self.config
        return {
            "embedding":     (c.vocab_size, c.hidden_size),
            "final_norm":    (c.hidden_size,),
            "q_proj":        (c.num_attention_heads * c.head_dim, c.hidden_size),
            "k_proj":        (c.num_key_value_heads * c.head_dim, c.hidden_size),
            "v_proj":        (c.num_key_value_heads * c.head_dim, c.hidden_size),
            "o_proj":        (c.hidden_size, c.num_attention_heads * c.head_dim),
            "q_norm":        (c.head_dim,),
            "k_norm":        (c.head_dim,),
            "input_norm":    (c.hidden_size,),
            "post_attn_norm":(c.hidden_size,),
            "gate_proj":     (c.intermediate_size, c.hidden_size),
            "up_proj":       (c.intermediate_size, c.hidden_size),
            "down_proj":     (c.hidden_size, c.intermediate_size),
        }
