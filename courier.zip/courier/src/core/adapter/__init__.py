"""Model family adapters."""
