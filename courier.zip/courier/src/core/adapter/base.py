"""Model family adapter base class.

Each model family (Qwen3, Qwen3.5, Llama3, etc.) implements this interface.
The adapter declares architecture details that the engine needs to
load weights, run the forward pass, and manage the KV cache.
The engine never inspects model internals directly.

Multimodal models extend this with vision-specific configuration
via VisionConfig and override is_multimodal / vision-related methods.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class VisionConfig:
    """Configuration for a vision encoder (ViT).

    Present only in multimodal adapters. The engine uses this to
    load, stream, and run the vision tower.
    """
    depth: int = 24                     # number of ViT layers
    hidden_size: int = 1024             # ViT hidden dimension
    intermediate_size: int = 4096       # ViT MLP intermediate size
    num_heads: int = 16                 # ViT attention heads
    patch_size: int = 16                # spatial patch size in pixels
    temporal_patch_size: int = 2        # temporal patch size (for video frames)
    in_channels: int = 3                # input image channels
    spatial_merge_size: int = 2         # downsampling factor for spatial tokens
    out_hidden_size: int = 2560         # output projection to LLM hidden size
    num_position_embeddings: int = 2304 # number of position embedding entries
    hidden_act: str = "gelu_pytorch_tanh"  # ViT activation function


@dataclass
class ModelConfig:
    """Parsed model configuration."""
    model_type: str
    num_hidden_layers: int
    hidden_size: int
    intermediate_size: int
    num_attention_heads: int
    num_key_value_heads: int
    head_dim: int
    vocab_size: int
    rope_theta: float
    rms_norm_eps: float
    tie_word_embeddings: bool
    max_position_embeddings: int
    bos_token_id: int
    eos_token_id: list[int]

    # ── Multimodal fields (None for text-only models) ─────────
    vision: Optional[VisionConfig] = None

    # Special token IDs for vision segments
    image_token_id: Optional[int] = None
    video_token_id: Optional[int] = None
    vision_start_token_id: Optional[int] = None
    vision_end_token_id: Optional[int] = None

    # ── Hybrid attention fields (None for uniform-attention) ──
    layer_types: Optional[list[str]] = None  # per-layer: "full_attention" or "linear_attention"

    # Linear attention (Gated DeltaNet) parameters
    linear_key_head_dim: Optional[int] = None
    linear_num_key_heads: Optional[int] = None
    linear_value_head_dim: Optional[int] = None
    linear_num_value_heads: Optional[int] = None
    linear_conv_kernel_dim: Optional[int] = None

    # Multimodal RoPE sections (e.g. [11, 11, 10] for temporal/height/width)
    mrope_section: Optional[list[int]] = None
    partial_rotary_factor: Optional[float] = None

    # ── RoPE scaling (None = standard RoPE, no scaling) ───────
    # Stored as the raw dict from config.json since formats vary
    # by model family (e.g. Llama 3.1 "llama3" piecewise, YaRN).
    # Keys typically include: rope_type, factor,
    # original_max_position_embeddings, low_freq_factor, high_freq_factor.
    rope_scaling: Optional[dict] = None

    # ── Sliding-window attention fields (None = no windowing) ─
    # Gemma 3: 5 local (sliding, window=1024, rope_local_base_freq)
    # : 1 global (full, rope_theta with linear scaling) interleave.
    sliding_window: Optional[int] = None
    query_pre_attn_scalar: Optional[float] = None
    rope_local_base_freq: Optional[float] = None


class ModelAdapter(ABC):
    """Abstract base for model family adapters."""

    def __init__(self, model_path: Path):
        self.model_path = model_path
        self.config = self._load_config()
        self._tokenizer = None

    @abstractmethod
    def _load_config(self) -> ModelConfig:
        """Parse config.json into a ModelConfig."""

    @property
    def tokenizer(self):
        """Lazy-loaded tokenizer."""
        if self._tokenizer is None:
            from transformers import AutoTokenizer
            self._tokenizer = AutoTokenizer.from_pretrained(
                str(self.model_path), trust_remote_code=False
            )
            # Some checkpoints (Meta's Llama 3.x among them) ship
            # clean_up_tokenization_spaces=true in tokenizer_config.json.
            # That post-processing is a WordPiece-ism: on the BPE and
            # SentencePiece tokenizers every Courier family uses, it
            # strips spaces before punctuation — corrupting receipt
            # text. Newer transformers refuses to apply it to BPE and
            # warns on every decode; OLDER versions silently apply it.
            # Pinning False here (the single construction site) fixes
            # both: no warning, no corruption, on any transformers.
            self._tokenizer.clean_up_tokenization_spaces = False
        return self._tokenizer

    # ── Multimodal capabilities ───────────────────────────────

    @property
    def is_multimodal(self) -> bool:
        """Whether this model supports image/video input."""
        return self.config.vision is not None

    @property
    def has_hybrid_attention(self) -> bool:
        """Whether this model uses mixed layer types (e.g. linear + full)."""
        return self.config.layer_types is not None

    @property
    def rmsnorm_uses_residual_weight(self) -> bool:
        """Whether RMSNorm uses (1 + weight) instead of weight.

        Standard RMSNorm (Qwen3, Llama, etc.) initializes weight to ones
        and multiplies directly: output * weight.

        Some models (Qwen3.5) initialize weight to zeros and use an
        offset: output * (1 + weight). Adapters for such models must
        override this to return True.
        """
        return False

    @property
    def has_qk_norm(self) -> bool:
        """Whether the model applies per-head RMSNorm to Q and K.

        True for Qwen3/Qwen3.5 (QK-LayerNorm), False for Llama 3 and
        most other families. When True, layer weights include q_norm
        and k_norm tensors, and the engine must apply them before RoPE.
        """
        return False

    def gguf_load_transforms(self) -> dict:
        """Layout transforms GGUFShardManager must apply at load time.

        llama.cpp's convert_hf_to_gguf.py rewrites some tensors' layout
        for some families (canonically: the Q/K rotary permutation on
        llama-architecture models). Whether a GGUF tensor needs undoing
        is family knowledge, so it lives here, next to the rest of the
        family knowledge — the shard manager applies whatever is
        declared, blindly, and never learns a family name.

        Returns a dict mapping an HF tensor-name SUFFIX to a callable
        tensor → tensor, e.g.::

            {"self_attn.q_proj.weight": lambda w: inverse_llama_permute(w, n_head)}

        Matched with str.endswith against the full HF key, so one entry
        covers the tensor in every layer. Applied at every
        materialization point (fresh disk read, tier-2 dequantize-from-
        RAM) and therefore BEFORE the tier-1 cache stores the tensor.
        Default: no transforms — correct for Qwen3/Qwen3.5, whose
        converter path does not permute (oracle-validated, Tier 2).
        """
        return {}

    @property
    def rope_layout(self) -> str:
        """RoPE embedding layout.

        'split_half': GPT-NeoX style — first half of dim, second half.
            Used by Qwen3, Qwen3.5, Llama 3.
        'interleaved': GPT-J style — alternating pairs.
            Not currently used by any supported family.
        """
        return "split_half"

    def build_rope_inv_freq(self, device: str = "cpu"):
        """Build RoPE inverse frequency tensor for this model.

        Default implementation: standard RoPE from rope_theta and head_dim.
        Adapters with non-standard RoPE scaling (e.g. Llama 3.1's
        piecewise scheme) override this to apply their scaling.

        The engine should call this instead of computing inv_freq
        directly, so model-specific scaling is handled transparently.

        Returns:
            torch.Tensor of shape (head_dim // 2,)
        """
        import torch
        dim = self.config.head_dim
        theta = self.config.rope_theta
        inv_freq = 1.0 / (theta ** (torch.arange(0, dim, 2, dtype=torch.float32) / dim))
        return inv_freq.to(device)

    def recommended_defaults(self) -> dict:
        """Model-family-specific default inference parameters.

        Adapters override this to return sampling and generation
        parameters tuned for their model family. Each key maps to a
        dict with 'value' and 'tip' — the recommended default and a
        human-readable tooltip explaining WHY this value suits the
        model family. These are served to the dashboard via
        /api/config/defaults so tooltips update when the model changes.

        Keys should match FACTORY_DEFAULTS in server.py.
        """
        return {}

    def encode_prompt(self, prompt: str) -> list[int]:
        """Encode a prompt string to token IDs for generation.

        Default preserves the engine's historical behavior exactly:
        no special tokens. Families that REQUIRE a special token (Gemma
        needs a leading <bos>; quality collapses without it) override
        this. generate() and speculative_generate() call this hook
        instead of encoding directly, so the requirement is honored on
        every entry path, including resume re-prefill.
        """
        return self.tokenizer.encode(prompt, add_special_tokens=False)

    def layer_type(self, layer_idx: int) -> str:
        """Return the attention type for a given layer.

        Returns 'full_attention' for standard transformers,
        or the per-layer type from layer_types for hybrid models.
        """
        if self.config.layer_types is None:
            return "full_attention"
        return self.config.layer_types[layer_idx]

    # ── Weight key resolution ────────────────────────────────

    @abstractmethod
    def embedding_key(self) -> str:
        """State dict key for the token embedding matrix."""

    @abstractmethod
    def final_norm_key(self) -> str:
        """State dict key for the final RMSNorm weight."""

    @abstractmethod
    def lm_head_key(self) -> Optional[str]:
        """State dict key for the LM head, or None if tied to embedding."""

    @abstractmethod
    def layer_keys(self, layer_idx: int) -> list[str]:
        """All state dict keys for a given layer index."""

    @abstractmethod
    def layer_weight_keys(self, layer_idx: int) -> dict[str, str]:
        """Named mapping of weight roles to state dict keys for a layer.

        Returns a dict like:
            {
                "input_layernorm": "model.layers.0.input_layernorm.weight",
                "q_proj": "model.layers.0.self_attn.q_proj.weight",
                ...
            }

        For hybrid models, this returns the correct keys based on
        whether the layer is full_attention or linear_attention.
        """

    # ── Vision encoder keys (override in multimodal adapters) ─

    def vision_keys(self) -> list[str]:
        """All state dict keys for the vision encoder.

        Returns empty list for text-only models.
        """
        return []

    def vision_layer_keys(self, layer_idx: int) -> dict[str, str]:
        """Weight keys for a single ViT layer.

        Returns empty dict for text-only models.
        """
        return {}

    def vision_embedding_keys(self) -> dict[str, str]:
        """Weight keys for vision patch embedding + projection.

        Returns empty dict for text-only models.
        """
        return {}

    # ── Memory estimates ─────────────────────────────────────

    def kv_cache_bytes_per_token_per_layer(self, dtype_bytes: int = 2) -> int:
        """KV cache size per token per layer in bytes.

        For GQA: 2 (K+V) × num_kv_heads × head_dim × dtype_bytes
        """
        return 2 * self.config.num_key_value_heads * self.config.head_dim * dtype_bytes

    def total_layers(self) -> int:
        return self.config.num_hidden_layers

    def gqa_group_size(self) -> int:
        """Number of query heads per KV head."""
        return self.config.num_attention_heads // self.config.num_key_value_heads
