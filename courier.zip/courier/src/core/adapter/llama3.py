"""Llama 3.x model family adapter.

Covers text-only instruct-tuned Llama 3 variants:
- Llama 3 (8B, 70B)                 — 8K context, standard RoPE
- Llama 3.1 (8B, 70B, 405B)         — 128K context, "llama3" piecewise RoPE scaling
- Llama 3.2 (1B, 3B)                — 128K context, piecewise scaling, tied embeddings

Architecture: pre-norm decoder-only transformer with GQA, SwiGLU MLP,
RoPE, standard RMSNorm (eps=1e-5). Structurally very similar to Qwen3
but with no QK-norm, no attention biases, different tokenizer (tiktoken
BPE, vocab=128256), and the Meta "header_id" chat template.

Key differences from the Qwen3 adapter:
- No q_norm / k_norm — Q and K go straight to RoPE after projection
- No attention or MLP biases (attention_bias=false, mlp_bias=false)
- RoPE theta is 500,000 (not 1,000,000)
- RoPE scaling: Llama 3.1/3.2 use "llama3" piecewise frequency
  interpolation (NOT NTK-aware, NOT YaRN)
- tie_word_embeddings: true only on 3.2-1B and 3.2-3B (lm_head.weight
  absent from safetensors — alias to embed_tokens.weight)
- No thinking mode (no <think> / enable_thinking support)
- Sampling defaults: temperature=0.6, top_p=0.9 (per Meta's reference)

Weight key layout is identical to Qwen3 minus the norms:
    model.embed_tokens.weight
    model.layers.{i}.input_layernorm.weight
    model.layers.{i}.self_attn.{q,k,v,o}_proj.weight
    model.layers.{i}.post_attention_layernorm.weight
    model.layers.{i}.mlp.{gate,up,down}_proj.weight
    model.norm.weight
    lm_head.weight  (absent when tie_word_embeddings=true)
"""

import json
import math
from pathlib import Path
from typing import Optional

import torch

from .base import ModelAdapter, ModelConfig


def build_llama3_rope_inv_freq(
    head_dim: int,
    rope_theta: float,
    rope_scaling: Optional[dict],
    device: str = "cpu",
) -> torch.Tensor:
    """Build RoPE inverse frequencies, applying Llama 3.1/3.2 piecewise scaling.

    This implements Meta's "llama3" rope_type: a piecewise frequency
    interpolation that smoothly transitions between leaving high
    frequencies unchanged and dividing low frequencies by `factor`.

    For models without rope_scaling (Llama 3.0), returns standard inv_freq.

    Args:
        head_dim: Attention head dimension (determines frequency count)
        rope_theta: Base frequency (500000.0 for all Llama 3.x)
        rope_scaling: The rope_scaling dict from config.json, or None
        device: Target device

    Returns:
        inv_freq tensor of shape (head_dim // 2,)
    """
    dim = head_dim
    inv_freq = 1.0 / (rope_theta ** (torch.arange(0, dim, 2, dtype=torch.float32) / dim))

    if rope_scaling is None:
        return inv_freq.to(device)

    rope_type = rope_scaling.get("rope_type", "")
    if rope_type != "llama3":
        # Unknown scaling type — fall back to unscaled.
        # Future: add YaRN, NTK-aware, etc.
        return inv_freq.to(device)

    factor = float(rope_scaling["factor"])
    low_freq_factor = float(rope_scaling.get("low_freq_factor", 1.0))
    high_freq_factor = float(rope_scaling.get("high_freq_factor", 4.0))
    orig_max_pos = int(rope_scaling.get("original_max_position_embeddings", 8192))

    low_freq_wavelen = orig_max_pos / low_freq_factor
    high_freq_wavelen = orig_max_pos / high_freq_factor

    scaled = []
    for freq in inv_freq:
        wavelen = 2.0 * math.pi / freq.item()
        if wavelen < high_freq_wavelen:
            # High frequency — leave unchanged
            scaled.append(freq.item())
        elif wavelen > low_freq_wavelen:
            # Low frequency — divide by factor
            scaled.append(freq.item() / factor)
        else:
            # Medium frequency — smooth interpolation
            smooth = (orig_max_pos / wavelen - low_freq_factor) / (
                high_freq_factor - low_freq_factor
            )
            scaled.append((1 - smooth) * freq.item() / factor + smooth * freq.item())

    return torch.tensor(scaled, dtype=torch.float32).to(device)


class Llama3Adapter(ModelAdapter):
    """Adapter for the Llama 3.x model family (model_type == 'llama')."""

    MODEL_TYPE = "llama"
    FAMILY_DISPLAY_NAME = "Llama 3.x"

    # ── Model-family defaults ────────────────────────────────
    # Llama 3 Instruct: temperature=0.6, top_p=0.9 per Meta's
    # reference generation.py and HF generation_config.json.
    # No repetition penalty needed — RLHF is well-tuned.
    # No thinking mode (no <think> token support).

    def recommended_defaults(self) -> dict:
        return {
            "temperature": {
                "value": 0.6,
                "tip": "Meta's recommended default for Llama 3 Instruct. Lower than Qwen3's 0.7 — the model's RLHF tuning expects this range.",
            },
            "top_p": {
                "value": 0.9,
                "tip": "Nucleus sampling cutoff. Llama 3 Instruct default per Meta's generation_config.json.",
            },
            "top_k": {
                "value": 0,
                "tip": "Llama 3 does not use top-k by default (set to 0 = disabled). Rely on top_p for distribution shaping.",
            },
            "presence_penalty": {
                "value": 0.0,
                "tip": "Llama 3 Instruct's RLHF is well-calibrated — repetition penalty > 1.1 visibly degrades output quality on 8B. Leave at 0.",
            },
            "enable_thinking": {
                "value": False,
                "tip": "Llama 3 has no native thinking mode. This setting is ignored. Use prompt-engineered chain-of-thought if needed.",
            },
            "max_new_tokens": {
                "value": 2048,
                "tip": "Maximum tokens per pipeline stage. Llama 3.1/3.2 support up to 128K context; 2048 is a practical default for edge hardware.",
            },
        }

    # Per-layer weight roles and their key suffixes.
    # No q_norm / k_norm (unlike Qwen3).
    # No biases on any projection (attention_bias=false, mlp_bias=false).
    LAYER_WEIGHT_ROLES = {
        "input_layernorm":          "input_layernorm.weight",
        "post_attention_layernorm": "post_attention_layernorm.weight",
        "q_proj":                   "self_attn.q_proj.weight",
        "k_proj":                   "self_attn.k_proj.weight",
        "v_proj":                   "self_attn.v_proj.weight",
        "o_proj":                   "self_attn.o_proj.weight",
        "gate_proj":                "mlp.gate_proj.weight",
        "up_proj":                  "mlp.up_proj.weight",
        "down_proj":                "mlp.down_proj.weight",
    }

    def _load_config(self) -> ModelConfig:
        config_path = self.model_path / "config.json"
        with open(config_path, encoding="utf-8") as f:
            raw = json.load(f)

        # Parse eos_token_id: int for Llama 3.0, list for 3.1/3.2
        eos = raw.get("eos_token_id", [128001, 128008, 128009])
        if isinstance(eos, int):
            eos = [eos]

        # head_dim: explicit in 3.2-1B config, implicit elsewhere
        head_dim = raw.get(
            "head_dim",
            raw["hidden_size"] // raw["num_attention_heads"],
        )

        # rope_scaling: None for Llama 3.0, dict for 3.1/3.2
        rope_scaling = raw.get("rope_scaling", None)

        return ModelConfig(
            model_type=raw["model_type"],
            num_hidden_layers=raw["num_hidden_layers"],
            hidden_size=raw["hidden_size"],
            intermediate_size=raw["intermediate_size"],
            num_attention_heads=raw["num_attention_heads"],
            num_key_value_heads=raw.get("num_key_value_heads", raw["num_attention_heads"]),
            head_dim=head_dim,
            vocab_size=raw["vocab_size"],
            rope_theta=raw.get("rope_theta", 500000.0),
            rms_norm_eps=raw.get("rms_norm_eps", 1e-5),
            tie_word_embeddings=raw.get("tie_word_embeddings", False),
            max_position_embeddings=raw.get("max_position_embeddings", 131072),
            bos_token_id=raw.get("bos_token_id", 128000),
            eos_token_id=eos,
            rope_scaling=rope_scaling,
        )

    # ── Weight key resolution ────────────────────────────────

    def embedding_key(self) -> str:
        return "model.embed_tokens.weight"

    def final_norm_key(self) -> str:
        return "model.norm.weight"

    def lm_head_key(self) -> Optional[str]:
        """Returns 'lm_head.weight' if untied, else None.

        Llama 3.2 1B/3B have tie_word_embeddings=true and do NOT ship
        lm_head.weight in the safetensors. The engine must use
        embed_tokens.weight for the unembedding step.
        """
        if self.config.tie_word_embeddings:
            return None
        return "lm_head.weight"

    def layer_keys(self, layer_idx: int) -> list[str]:
        prefix = f"model.layers.{layer_idx}."
        return [prefix + suffix for suffix in self.LAYER_WEIGHT_ROLES.values()]

    def layer_weight_keys(self, layer_idx: int) -> dict[str, str]:
        prefix = f"model.layers.{layer_idx}."
        return {role: prefix + suffix for role, suffix in self.LAYER_WEIGHT_ROLES.items()}

    # ── Llama 3-specific properties ──────────────────────────

    @property
    def has_qk_norm(self) -> bool:
        """Llama 3 does NOT have QK-LayerNorm (unlike Qwen3)."""
        return False

    def gguf_load_transforms(self) -> dict:
        """Undo convert_hf_to_gguf.py's llama Q/K rotary permutation.

        The converter stores llama-architecture Q/K projection weights
        in gguf-interleaved layout; Courier's engine (and rope_layout
        'split_half') expects HF layout, so the loader must apply the
        inverse per-head permute — n_head rows-groups for Q, n_kv for K.
        Without this the weights load without error and attention is
        silently scrambled: tools/gguf_diff_harness.py exists to catch
        exactly this, and names inverse_llama_permute() as the fix.
        Llama 3 has no Q/K biases, so weights are the whole story.
        """
        from core.gguf_layout import inverse_llama_permute
        c = self.config
        n_head, n_kv = c.num_attention_heads, c.num_key_value_heads
        return {
            "self_attn.q_proj.weight":
                lambda w, _n=n_head: inverse_llama_permute(w, _n),
            "self_attn.k_proj.weight":
                lambda w, _n=n_kv: inverse_llama_permute(w, _n),
        }

    @property
    def rope_layout(self) -> str:
        """RoPE embedding layout: 'split_half' (same as Qwen3)."""
        return "split_half"

    def build_rope_inv_freq(self, device: str = "cpu") -> torch.Tensor:
        """Build RoPE inverse frequencies with Llama 3.x piecewise scaling.

        This is the adapter's authoritative source for inv_freq
        computation. The engine should call this instead of computing
        its own, to pick up the "llama3" piecewise scaling automatically.

        For Llama 3.0 (rope_scaling=None): standard inv_freq.
        For Llama 3.1/3.2 (rope_scaling.rope_type="llama3"): piecewise.
        """
        return build_llama3_rope_inv_freq(
            head_dim=self.config.head_dim,
            rope_theta=self.config.rope_theta,
            rope_scaling=self.config.rope_scaling,
            device=device,
        )

    def expected_shapes(self) -> dict[str, tuple]:
        """Expected weight shapes for validation."""
        c = self.config
        return {
            "embedding":      (c.vocab_size, c.hidden_size),
            "final_norm":     (c.hidden_size,),
            "q_proj":         (c.num_attention_heads * c.head_dim, c.hidden_size),
            "k_proj":         (c.num_key_value_heads * c.head_dim, c.hidden_size),
            "v_proj":         (c.num_key_value_heads * c.head_dim, c.hidden_size),
            "o_proj":         (c.hidden_size, c.num_attention_heads * c.head_dim),
            "input_norm":     (c.hidden_size,),
            "post_attn_norm": (c.hidden_size,),
            "gate_proj":      (c.intermediate_size, c.hidden_size),
            "up_proj":        (c.intermediate_size, c.hidden_size),
            "down_proj":      (c.hidden_size, c.intermediate_size),
        }

    # ── Chat template info ───────────────────────────────────

    @property
    def chat_format(self) -> str:
        """Identifier for the chat template format.

        Llama 3 uses Meta's "header_id" format:
            <|begin_of_text|><|start_header_id|>role<|end_header_id|>\\n\\n
            content<|eot_id|>

        NOT ChatML (<|im_start|>/<|im_end|>).
        The tokenizer's apply_chat_template handles this automatically.
        """
        return "header_id"

    @property
    def stop_token_ids(self) -> set[int]:
        """Token IDs that should terminate generation.

        Llama 3.1/3.2: stop on <|end_of_text|> (128001),
        <|eom_id|> (128008), or <|eot_id|> (128009).
        Llama 3.0: only <|eot_id|> (128009) in the config, but
        stopping on all three is safe and forward-compatible.
        """
        return {128001, 128008, 128009}
