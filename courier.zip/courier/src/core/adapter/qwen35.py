"""Qwen3.5 model family adapter.

Covers Qwen3.5-0.8B through Qwen3.5-9B (dense variants).
Architecture: natively multimodal (early-fusion ViT + hybrid-attention LLM).

Key Qwen3.5-specific details vs Qwen3:

COMPOSITE MODEL
- Top-level class: Qwen3_5ForConditionalGeneration (vision + language)
- Weight prefix: model.language_model.layers.{i} (not model.layers.{i})
- Vision encoder: model.visual.* (~3300 tensors, Qwen3-VL ViT)
- Embeddings: model.language_model.embed_tokens.weight

HYBRID ATTENTION (3:1 Gated DeltaNet / Full Attention)
- layer_types: per-layer list of "linear_attention" or "full_attention"
- Full attention layers: standard GQA with QK-norm (like Qwen3)
- Linear attention layers (Gated DeltaNet):
    - in_proj_qkv: fused QKV projection
    - in_proj_z: gate projection (output gate)
    - in_proj_a, in_proj_b: delta rule scaling projections
    - out_proj: output projection
    - conv1d: causal 1D convolution (short-range state mixing)
    - dt_bias: time-step bias
    - A_log: log-space decay parameter

MULTIMODAL ROPE
- 3-component mRoPE: sections [11, 11, 10] = temporal/height/width
- partial_rotary_factor: 0.25 (only 25% of head_dim gets RoPE)
- mrope_interleaved: True
- rope_theta: 10,000,000 (same as Qwen3)

VISION ENCODER (Qwen3-VL ViT)
- 24 transformer layers, hidden_size=1024, 16 heads
- Patch size: 16×16 spatial, 2 temporal
- Spatial merge: 2×2 (4 patches → 1 token after merger)
- Output projects to out_hidden_size matching LLM hidden_size

SPECIAL TOKENS
- image_token_id: 248056
- video_token_id: 248057
- vision_start_token_id: 248053
- vision_end_token_id: 248054
"""

import json
from pathlib import Path
from typing import Optional

from .base import ModelAdapter, ModelConfig, VisionConfig


class Qwen35Adapter(ModelAdapter):
    """Adapter for the Qwen3.5 model family (multimodal, hybrid attention)."""

    MODEL_TYPE = "qwen3_5"
    FAMILY_DISPLAY_NAME = "Qwen3.5"

    # ── Model-family defaults ────────────────────────────────
    # Qwen3.5 uses (1+weight) RMSNorm, Gated DeltaNet recurrent
    # attention (no repetition penalty needed — decay gate handles
    # forgetting), and recommends temperature=1.0 / top_p=1.0 for
    # non-thinking text tasks. The 0.8B model is the instruct variant
    # (no "-Instruct" suffix); base model is "Qwen3.5-0.8B-Base".

    @property
    def rmsnorm_uses_residual_weight(self) -> bool:
        """Qwen3.5 RMSNorm uses (1 + weight) with weight init = zeros."""
        return True

    def recommended_defaults(self) -> dict:
        return {
            "temperature": {
                "value": 1.0,
                "tip": "Qwen3.5 recommends 1.0 for non-thinking text tasks. The Gated DeltaNet decay gate provides natural diversity control — lower temperatures cause degenerate output.",
            },
            "top_p": {
                "value": 1.0,
                "tip": "Qwen3.5 recommends 1.0 (disabled) for text tasks. The model's hybrid attention already constrains the distribution effectively.",
            },
            "top_k": {
                "value": 20,
                "tip": "Limits candidate pool to the top K tokens. 20 is the Qwen3.5 default.",
            },
            "presence_penalty": {
                "value": 0.0,
                "tip": "Qwen3.5's DeltaNet layers have a built-in decay gate that handles forgetting natively. No presence penalty needed — adding one pushes the model away from common English tokens.",
            },
            "enable_thinking": {
                "value": False,
                "tip": "When ON, the model reasons step-by-step in a <think> block before answering. Produces better analysis but uses more tokens and time.",
            },
            "max_new_tokens": {
                "value": 2048,
                "tip": "Maximum tokens generated per pipeline stage. Qwen3.5 supports up to 262K context; 2048 is a practical default for edge hardware.",
            },
        }

    # ── Full attention layer weight roles ─────────────────────
    FULL_ATTN_ROLES = {
        "input_layernorm":          "input_layernorm.weight",
        "post_attention_layernorm": "post_attention_layernorm.weight",
        "q_proj":                   "self_attn.q_proj.weight",
        "k_proj":                   "self_attn.k_proj.weight",
        "v_proj":                   "self_attn.v_proj.weight",
        "o_proj":                   "self_attn.o_proj.weight",
        "q_norm":                   "self_attn.q_norm.weight",
        "k_norm":                   "self_attn.k_norm.weight",
        "gate_proj":                "mlp.gate_proj.weight",
        "up_proj":                  "mlp.up_proj.weight",
        "down_proj":                "mlp.down_proj.weight",
    }

    # ── Linear attention (Gated DeltaNet) layer weight roles ──
    LINEAR_ATTN_ROLES = {
        "input_layernorm":          "input_layernorm.weight",
        "post_attention_layernorm": "post_attention_layernorm.weight",
        "in_proj_qkv":              "linear_attn.in_proj_qkv.weight",
        "in_proj_z":                "linear_attn.in_proj_z.weight",
        "in_proj_a":                "linear_attn.in_proj_a.weight",
        "in_proj_b":                "linear_attn.in_proj_b.weight",
        "out_proj":                 "linear_attn.out_proj.weight",
        "conv1d":                   "linear_attn.conv1d.weight",
        "dt_bias":                  "linear_attn.dt_bias",
        "A_log":                    "linear_attn.A_log",
        "norm":                     "linear_attn.norm.weight",
        "gate_proj":                "mlp.gate_proj.weight",
        "up_proj":                  "mlp.up_proj.weight",
        "down_proj":                "mlp.down_proj.weight",
    }

    # ── ViT layer weight roles ────────────────────────────────
    VIT_LAYER_ROLES = {
        "ln1":       "norm1.weight",
        "ln1_bias":  "norm1.bias",
        "ln2":       "norm2.weight",
        "ln2_bias":  "norm2.bias",
        "qkv":       "attn.qkv.weight",
        "qkv_bias":  "attn.qkv.bias",
        "proj":      "attn.proj.weight",
        "proj_bias": "attn.proj.bias",
        "fc1":       "mlp.linear_fc1.weight",
        "fc1_bias":  "mlp.linear_fc1.bias",
        "fc2":       "mlp.linear_fc2.weight",
        "fc2_bias":  "mlp.linear_fc2.bias",
    }

    def _load_config(self) -> ModelConfig:
        config_path = self.model_path / "config.json"
        with open(config_path, encoding="utf-8") as f:
            raw = json.load(f)

        # Qwen3.5 uses nested text_config + vision_config
        text = raw.get("text_config", raw)
        vis_raw = raw.get("vision_config", {})

        # Parse eos_token_id
        eos = text.get("eos_token_id", [248044])
        if isinstance(eos, int):
            eos = [eos]

        # Parse vision config
        vision = None
        if vis_raw:
            vision = VisionConfig(
                depth=vis_raw.get("depth", 24),
                hidden_size=vis_raw.get("hidden_size", 1024),
                intermediate_size=vis_raw.get("intermediate_size", 4096),
                num_heads=vis_raw.get("num_heads", 16),
                patch_size=vis_raw.get("patch_size", 16),
                temporal_patch_size=vis_raw.get("temporal_patch_size", 2),
                in_channels=vis_raw.get("in_channels", 3),
                spatial_merge_size=vis_raw.get("spatial_merge_size", 2),
                out_hidden_size=vis_raw.get("out_hidden_size", text.get("hidden_size", 2560)),
                num_position_embeddings=vis_raw.get("num_position_embeddings", 2304),
                hidden_act=vis_raw.get("hidden_act", "gelu_pytorch_tanh"),
            )

        # Parse layer_types
        layer_types = text.get("layer_types", None)

        # Parse mRoPE sections
        rope_params = text.get("rope_parameters", {})
        mrope_section = rope_params.get("mrope_section", None)
        partial_rotary_factor = rope_params.get("partial_rotary_factor", None)

        return ModelConfig(
            model_type=raw.get("model_type", "qwen3_5"),
            num_hidden_layers=text["num_hidden_layers"],
            hidden_size=text["hidden_size"],
            intermediate_size=text["intermediate_size"],
            num_attention_heads=text["num_attention_heads"],
            num_key_value_heads=text["num_key_value_heads"],
            head_dim=text.get("head_dim", text["hidden_size"] // text["num_attention_heads"]),
            vocab_size=text["vocab_size"],
            rope_theta=rope_params.get("rope_theta", text.get("rope_theta", 10000000.0)),
            rms_norm_eps=text.get("rms_norm_eps", 1e-6),
            tie_word_embeddings=raw.get("tie_word_embeddings",
                                       text.get("tie_word_embeddings", True)),
            max_position_embeddings=text.get("max_position_embeddings", 262144),
            bos_token_id=text.get("bos_token_id", 0),
            eos_token_id=eos,
            # Multimodal fields
            vision=vision,
            image_token_id=raw.get("image_token_id", 248056),
            video_token_id=raw.get("video_token_id", 248057),
            vision_start_token_id=raw.get("vision_start_token_id", 248053),
            vision_end_token_id=raw.get("vision_end_token_id", 248054),
            # Hybrid attention fields
            layer_types=layer_types,
            linear_key_head_dim=text.get("linear_key_head_dim", 128),
            linear_num_key_heads=text.get("linear_num_key_heads", 16),
            linear_value_head_dim=text.get("linear_value_head_dim", 128),
            linear_num_value_heads=text.get("linear_num_value_heads", 32),
            linear_conv_kernel_dim=text.get("linear_conv_kernel_dim", 4),
            # mRoPE
            mrope_section=mrope_section,
            partial_rotary_factor=partial_rotary_factor,
        )

    # ── Weight prefix ─────────────────────────────────────────
    # Qwen3.5 nests the LLM under model.language_model

    def _layer_prefix(self, layer_idx: int) -> str:
        return f"model.language_model.layers.{layer_idx}."

    # ── Weight key resolution ─────────────────────────────────

    def embedding_key(self) -> str:
        return "model.language_model.embed_tokens.weight"

    def final_norm_key(self) -> str:
        return "model.language_model.norm.weight"

    def lm_head_key(self) -> Optional[str]:
        if self.config.tie_word_embeddings:
            return None
        # Qwen3.5 is a composite VLM (Qwen3_5ForConditionalGeneration).
        # In HuggingFace's *ForConditionalGeneration convention, the LM
        # head lives at the TOP level of the state dict, not nested
        # under the base model:
        #   model.language_model.embed_tokens.weight  (nested)
        #   model.language_model.layers.*              (nested)
        #   model.language_model.norm.weight           (nested)
        #   lm_head.weight                             (TOP LEVEL)
        #
        # This matters for the 9B (tie_word_embeddings=false): using
        # the wrong key silently falls through to tied-embedding logits,
        # producing garbage output. The 4B (tie=true) is unaffected
        # because this method returns None for tied models.
        return "lm_head.weight"

    def layer_keys(self, layer_idx: int) -> list[str]:
        prefix = self._layer_prefix(layer_idx)
        roles = self._roles_for_layer(layer_idx)
        return [prefix + suffix for suffix in roles.values()]

    def layer_weight_keys(self, layer_idx: int) -> dict[str, str]:
        prefix = self._layer_prefix(layer_idx)
        roles = self._roles_for_layer(layer_idx)
        return {role: prefix + suffix for role, suffix in roles.items()}

    def _roles_for_layer(self, layer_idx: int) -> dict[str, str]:
        """Return the correct weight role mapping based on layer type."""
        lt = self.layer_type(layer_idx)
        if lt == "linear_attention":
            return self.LINEAR_ATTN_ROLES
        return self.FULL_ATTN_ROLES

    # ── Vision encoder keys ───────────────────────────────────

    def vision_embedding_keys(self) -> dict[str, str]:
        """Patch embedding, learned position embedding, and spatial merger."""
        return {
            "patch_embed_proj":  "model.visual.patch_embed.proj.weight",
            "patch_embed_bias":  "model.visual.patch_embed.proj.bias",
            "pos_embed":         "model.visual.pos_embed.weight",
            "merger_norm":       "model.visual.merger.norm.weight",
            "merger_norm_bias":  "model.visual.merger.norm.bias",
            "merger_fc1":        "model.visual.merger.linear_fc1.weight",
            "merger_fc1_bias":   "model.visual.merger.linear_fc1.bias",
            "merger_fc2":        "model.visual.merger.linear_fc2.weight",
            "merger_fc2_bias":   "model.visual.merger.linear_fc2.bias",
        }

    def vision_layer_keys(self, layer_idx: int) -> dict[str, str]:
        """Weight keys for a single ViT transformer layer."""
        prefix = f"model.visual.blocks.{layer_idx}."
        return {role: prefix + suffix for role, suffix in self.VIT_LAYER_ROLES.items()}

    # ── Qwen3.5-specific properties ──────────────────────────

    @property
    def has_qk_norm(self) -> bool:
        """Full attention layers in Qwen3.5 have QK-norm (like Qwen3)."""
        return True

    @property
    def rope_layout(self) -> str:
        """RoPE embedding layout: 'split_half' (GPT-NeoX style)."""
        return "split_half"

    def expected_shapes(self) -> dict[str, tuple]:
        """Expected weight shapes for validation of full-attention layers."""
        c = self.config
        return {
            "embedding":     (c.vocab_size, c.hidden_size),
            "final_norm":    (c.hidden_size,),
            "q_proj":        (c.num_attention_heads * c.head_dim, c.hidden_size),
            "k_proj":        (c.num_key_value_heads * c.head_dim, c.hidden_size),
            "v_proj":        (c.num_key_value_heads * c.head_dim, c.hidden_size),
            "o_proj":        (c.hidden_size, c.num_attention_heads * c.head_dim),
            "q_norm":        (c.head_dim,),
            "k_norm":        (c.head_dim,),
            "input_norm":    (c.hidden_size,),
            "post_attn_norm": (c.hidden_size,),
            "gate_proj":     (c.intermediate_size, c.hidden_size),
            "up_proj":       (c.intermediate_size, c.hidden_size),
            "down_proj":     (c.hidden_size, c.intermediate_size),
        }

    def linear_attention_shapes(self) -> dict[str, tuple]:
        """Expected weight shapes for linear attention (Gated DeltaNet) layers."""
        c = self.config
        key_dim = c.linear_num_key_heads * c.linear_key_head_dim
        value_dim = c.linear_num_value_heads * c.linear_value_head_dim
        return {
            "in_proj_qkv": (key_dim * 2 + value_dim, c.hidden_size),
            "in_proj_z":   (value_dim, c.hidden_size),
            "in_proj_a":   (c.linear_num_value_heads, c.hidden_size),
            "in_proj_b":   (c.linear_num_value_heads, c.hidden_size),
            "out_proj":    (c.hidden_size, value_dim),
            "conv1d":      (value_dim, 1, c.linear_conv_kernel_dim),
            "dt_bias":     (c.linear_num_value_heads,),
            "A_log":       (c.linear_num_value_heads,),
        }

    def vision_shapes(self) -> dict[str, tuple]:
        """Expected weight shapes for vision encoder layers."""
        v = self.config.vision
        if v is None:
            return {}
        return {
            "patch_embed": (v.hidden_size, v.in_channels * v.temporal_patch_size,
                           v.patch_size, v.patch_size),
            "qkv":   (v.hidden_size * 3, v.hidden_size),
            "proj":  (v.hidden_size, v.hidden_size),
            "fc1":   (v.intermediate_size, v.hidden_size),
            "fc2":   (v.hidden_size, v.intermediate_size),
            "ln":    (v.hidden_size,),
        }
