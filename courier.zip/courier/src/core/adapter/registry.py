"""Model adapter auto-detection.

Reads config.json from a model directory, inspects model_type,
and returns the appropriate adapter instance.
"""

import json
from pathlib import Path

from .base import ModelAdapter
from .qwen3 import Qwen3Adapter
from .qwen35 import Qwen35Adapter
from .llama3 import Llama3Adapter
from .gemma3 import Gemma3Adapter


# Registry of known adapters by model_type
ADAPTERS: dict[str, type[ModelAdapter]] = {
    "qwen3": Qwen3Adapter,
    "qwen3_5": Qwen35Adapter,
    "llama": Llama3Adapter,
    "gemma3": Gemma3Adapter,
    "gemma3_text": Gemma3Adapter,
}


def detect_adapter(model_path: str | Path) -> ModelAdapter:
    """Auto-detect and instantiate the correct adapter for a model.

    Reads config.json, looks up model_type in the registry, and
    returns an initialized adapter.

    For composite models (e.g. Qwen3.5), model_type is at the
    top level of config.json. For text-only models (e.g. Qwen3),
    it's a flat config.

    Args:
        model_path: Path to the model directory containing config.json

    Returns:
        An initialized ModelAdapter instance

    Raises:
        FileNotFoundError: if config.json doesn't exist
        ValueError: if model_type is not recognized
    """
    model_path = Path(model_path)
    config_path = model_path / "config.json"

    if not config_path.exists():
        raise FileNotFoundError(f"config.json not found at {config_path}")

    with open(config_path, encoding="utf-8") as f:
        config = json.load(f)

    model_type = config.get("model_type")
    if model_type is None:
        raise ValueError(f"No model_type field in {config_path}")

    adapter_cls = ADAPTERS.get(model_type)
    if adapter_cls is None:
        known = ", ".join(sorted(ADAPTERS.keys()))
        raise ValueError(
            f"Unknown model_type '{model_type}'. "
            f"Supported: {known}"
        )

    return adapter_cls(model_path)
