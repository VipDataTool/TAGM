"""Gemma 3 model family adapter.

Covers google/gemma-3-{1b,4b,12b,27b}-{pt,it}. See
GEMMA3_ADAPTER_BUILD_PLAN.md for the grounded architecture facts and
phase gates. Structural summary the engine relies on:

- 5 local (sliding window, default 1024) : 1 global attention interleave,
  derived from config `layer_types` or `sliding_window_pattern` (default 6:
  layer i is global iff (i+1) % pattern == 0).
- Dual RoPE: global layers use rope_theta (1M) with linear scaling
  (rope_scaling {"rope_type": "linear", "factor": 8}); local layers use
  rope_local_base_freq (10k), unscaled.
- Zero-centered (1+weight) RMSNorm everywhere, sandwich placement:
  input / post_attention / pre_feedforward / post_feedforward.
- Per-head QK-norm ((1+weight) variant) before RoPE.
- Attention scale = query_pre_attn_scalar ** -0.5 (NOT head_dim; they
  differ on 27B).
- GeGLU MLP: gelu_pytorch_tanh(gate) * up -> down.
- Embedding output scaled by sqrt(hidden_size) at input only; lm_head is
  tied to the UNSCALED embedding. No softcapping anywhere in Gemma 3.
- <bos> is required at the start of every prompt (encode_prompt override).

Checkpoint key prefixes vary by vintage: text-only 1B checkpoints use
`model.layers.*`; composite (4B+) checkpoints use `model.language_model.*`
(current transformers) or `language_model.model.*` (early 2025 saves).
The prefix is detected from the safetensors index at load time.

Vision (Phase C, not yet wired): SigLIP @ 896x896, pan-and-scan, 256 soft
tokens per image via the multi-modal projector; image spans attend
bidirectionally. The adapter parses nothing vision-side yet and reports
vision=None so 4B+ checkpoints run text-only through Gemma3Streamer.
"""

import json
import struct
from pathlib import Path
from typing import Optional

from .base import ModelAdapter, ModelConfig


def _safetensors_header_keys(path: Path) -> list[str]:
    """Read tensor names from a .safetensors file header (stdlib only).

    The format is: 8-byte little-endian header length, then that many
    bytes of JSON mapping tensor names to metadata. No torch needed.
    """
    with open(path, "rb") as f:
        (n,) = struct.unpack("<Q", f.read(8))
        header = json.loads(f.read(n))
    return [k for k in header.keys() if k != "__metadata__"]


class Gemma3Adapter(ModelAdapter):
    """Adapter for the Gemma 3 family (text path; vision is Phase C)."""

    FAMILY_DISPLAY_NAME = "Gemma 3"

    # Weight roles for every decoder layer. Sandwich norms and QK-norm
    # are always present in Gemma 3.
    LAYER_ROLES = {
        "input_layernorm":            "input_layernorm.weight",
        "q_proj":                     "self_attn.q_proj.weight",
        "k_proj":                     "self_attn.k_proj.weight",
        "v_proj":                     "self_attn.v_proj.weight",
        "o_proj":                     "self_attn.o_proj.weight",
        "q_norm":                     "self_attn.q_norm.weight",
        "k_norm":                     "self_attn.k_norm.weight",
        "post_attention_layernorm":   "post_attention_layernorm.weight",
        "pre_feedforward_layernorm":  "pre_feedforward_layernorm.weight",
        "post_feedforward_layernorm": "post_feedforward_layernorm.weight",
        "gate_proj":                  "mlp.gate_proj.weight",
        "up_proj":                    "mlp.up_proj.weight",
        "down_proj":                  "mlp.down_proj.weight",
    }

    # ── Family flags ──────────────────────────────────────────

    @property
    def rmsnorm_uses_residual_weight(self) -> bool:
        """Gemma RMSNorm is zero-centered: output * (1 + weight)."""
        return True

    @property
    def has_qk_norm(self) -> bool:
        return True

    @property
    def rope_layout(self) -> str:
        return "split_half"

    def encode_prompt(self, prompt: str) -> list[int]:
        """Gemma requires a leading <bos>; quality collapses without it."""
        ids = self.tokenizer.encode(prompt, add_special_tokens=False)
        bos = self.config.bos_token_id
        if not ids or ids[0] != bos:
            ids = [bos] + ids
        return ids

    def recommended_defaults(self) -> dict:
        return {
            "temperature": {
                "value": 1.0,
                "tip": "Gemma 3 IT is tuned for T=1.0; lower values dull it "
                       "more than they steady it.",
            },
            "top_p": {
                "value": 0.95,
                "tip": "Gemma team's published IT sampling setting.",
            },
            "top_k": {
                "value": 64,
                "tip": "Gemma team's published IT sampling setting.",
            },
            "presence_penalty": {
                "value": 0.0,
                "tip": "Gemma 3 IT does not need repetition suppression at "
                       "its recommended sampling settings.",
            },
        }

    # ── Config parsing ────────────────────────────────────────

    def _load_config(self) -> ModelConfig:
        config_path = self.model_path / "config.json"
        with open(config_path, encoding="utf-8") as f:
            raw = json.load(f)

        # gemma3_text (1B) is flat; gemma3 (4B+) nests under text_config.
        text = raw.get("text_config", raw)

        eos = raw.get("eos_token_id", text.get("eos_token_id", [1, 106]))
        if isinstance(eos, int):
            eos = [eos]

        n_layers = text["num_hidden_layers"]

        # Per-layer attention types: explicit list, else derived from
        # sliding_window_pattern (default 6): global iff (i+1) % p == 0.
        layer_types = text.get("layer_types")
        if layer_types is None:
            pattern = int(text.get("sliding_window_pattern", 6))
            layer_types = [
                "full_attention" if (i + 1) % pattern == 0 else "sliding_attention"
                for i in range(n_layers)
            ]

        # Gemma 3 removed all softcapping; if a config disagrees, the
        # forward pass would be wrong silently. Fail loud instead.
        for cap_field in ("attn_logit_softcapping", "final_logit_softcapping"):
            if text.get(cap_field) not in (None, 0, 0.0):
                raise ValueError(
                    f"{cap_field}={text[cap_field]} in config.json — this "
                    f"looks like a Gemma 2 checkpoint. Gemma3Adapter has no "
                    f"softcapping path; Gemma 2 is not supported."
                )

        head_dim = text.get("head_dim", 256)

        cfg = ModelConfig(
            model_type=raw.get("model_type", "gemma3"),
            num_hidden_layers=n_layers,
            hidden_size=text["hidden_size"],
            intermediate_size=text["intermediate_size"],
            num_attention_heads=text["num_attention_heads"],
            num_key_value_heads=text["num_key_value_heads"],
            head_dim=head_dim,
            vocab_size=text["vocab_size"],
            rope_theta=text.get("rope_theta", 1_000_000.0),
            rms_norm_eps=text.get("rms_norm_eps", 1e-6),
            tie_word_embeddings=raw.get(
                "tie_word_embeddings", text.get("tie_word_embeddings", True)),
            max_position_embeddings=text.get("max_position_embeddings", 131072),
            bos_token_id=text.get("bos_token_id", raw.get("bos_token_id", 2)),
            eos_token_id=eos,
            # Vision: parsed in Phase C. None here means is_multimodal is
            # False, so 4B+ checkpoints run text-only through
            # Gemma3Streamer instead of mis-routing to HybridStreamer.
            vision=None,
            image_token_id=raw.get("image_token_index", 262144),
            layer_types=layer_types,
            rope_scaling=text.get("rope_scaling"),
            sliding_window=text.get("sliding_window", 1024),
            query_pre_attn_scalar=float(
                text.get("query_pre_attn_scalar", head_dim)),
            rope_local_base_freq=float(
                text.get("rope_local_base_freq", 10_000.0)),
        )
        self._prefix = self._detect_prefix(cfg)
        return cfg

    # ── Checkpoint prefix detection ───────────────────────────

    _PREFIX_CANDIDATES = (
        "model.language_model.",   # composite, current transformers
        "language_model.model.",   # composite, early-2025 checkpoints
        "model.",                  # text-only (gemma3_text, 1B)
    )

    def _detect_prefix(self, cfg: ModelConfig) -> str:
        """Find which key prefix this checkpoint uses, from the shard index.

        Reads model.safetensors.index.json if present, else the header of
        the first .safetensors file (stdlib only). Falls back by
        model_type if no shard files exist yet (e.g. pre-download config
        inspection): gemma3_text -> "model.", else composite new-style.
        """
        keys: list[str] = []
        index_path = self.model_path / "model.safetensors.index.json"
        if index_path.exists():
            with open(index_path, encoding="utf-8") as f:
                keys = list(json.load(f).get("weight_map", {}).keys())
        else:
            shards = sorted(self.model_path.glob("*.safetensors"))
            if shards:
                keys = _safetensors_header_keys(shards[0])

        if keys:
            probe = "embed_tokens.weight"
            for cand in self._PREFIX_CANDIDATES:
                if any(k == cand + probe for k in keys):
                    return cand
            raise ValueError(
                f"Could not locate '{probe}' under any known Gemma 3 prefix "
                f"in {self.model_path}. First keys: {sorted(keys)[:5]}"
            )
        return "model." if cfg.model_type == "gemma3_text" else "model.language_model."

    # ── Weight key resolution ─────────────────────────────────

    def _layer_prefix(self, layer_idx: int) -> str:
        return f"{self._prefix}layers.{layer_idx}."

    def embedding_key(self) -> str:
        return f"{self._prefix}embed_tokens.weight"

    def final_norm_key(self) -> str:
        return f"{self._prefix}norm.weight"

    def lm_head_key(self) -> Optional[str]:
        if self.config.tie_word_embeddings:
            return None
        # *ForConditionalGeneration convention: top-level lm_head.
        return "lm_head.weight"

    def layer_keys(self, layer_idx: int) -> list[str]:
        prefix = self._layer_prefix(layer_idx)
        return [prefix + suffix for suffix in self.LAYER_ROLES.values()]

    def layer_weight_keys(self, layer_idx: int) -> dict[str, str]:
        prefix = self._layer_prefix(layer_idx)
        return {role: prefix + suffix for role, suffix in self.LAYER_ROLES.items()}

    # ── RoPE ──────────────────────────────────────────────────

    def build_rope_inv_freq(self, device: str = "cpu"):
        """Global-layer inv_freq: rope_theta with linear scaling.

        Linear scaling divides inv_freq by the factor (equivalently,
        scales positions down). Local layers use
        build_rope_inv_freq_local(); Gemma3Streamer builds both.
        """
        import torch
        dim = self.config.head_dim
        theta = self.config.rope_theta
        inv_freq = 1.0 / (theta ** (torch.arange(0, dim, 2, dtype=torch.float32) / dim))
        scaling = self.config.rope_scaling or {}
        if scaling.get("rope_type", scaling.get("type")) == "linear":
            inv_freq = inv_freq / float(scaling.get("factor", 1.0))
        return inv_freq.to(device)

    def build_rope_inv_freq_local(self, device: str = "cpu"):
        """Local-layer inv_freq: rope_local_base_freq, no scaling."""
        import torch
        dim = self.config.head_dim
        theta = self.config.rope_local_base_freq or 10_000.0
        inv_freq = 1.0 / (theta ** (torch.arange(0, dim, 2, dtype=torch.float32) / dim))
        return inv_freq.to(device)

    # ── Validation shapes ─────────────────────────────────────

    def expected_shapes(self) -> dict[str, tuple]:
        c = self.config
        return {
            "embedding":                  (c.vocab_size, c.hidden_size),
            "final_norm":                 (c.hidden_size,),
            "q_proj":                     (c.num_attention_heads * c.head_dim, c.hidden_size),
            "k_proj":                     (c.num_key_value_heads * c.head_dim, c.hidden_size),
            "v_proj":                     (c.num_key_value_heads * c.head_dim, c.hidden_size),
            "o_proj":                     (c.hidden_size, c.num_attention_heads * c.head_dim),
            "q_norm":                     (c.head_dim,),
            "k_norm":                     (c.head_dim,),
            "input_layernorm":            (c.hidden_size,),
            "post_attention_layernorm":   (c.hidden_size,),
            "pre_feedforward_layernorm":  (c.hidden_size,),
            "post_feedforward_layernorm": (c.hidden_size,),
            "gate_proj":                  (c.intermediate_size, c.hidden_size),
            "up_proj":                    (c.intermediate_size, c.hidden_size),
            "down_proj":                  (c.hidden_size, c.intermediate_size),
        }
