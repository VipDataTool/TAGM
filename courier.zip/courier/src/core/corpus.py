"""Corpus store: the durable-knowledge index (regulations, registries,
reference documents) that grounds Courier's analyses.

The ledger (courier.db) holds *perishable* observations; the corpus
(corpus.db, a separate SQLite file beside it) holds *durable* text a template
can retrieve from at render time. Separate file by design:

  - Different lifecycle: a corpus is built offline (Datagator's digestor),
    can be hashed and verified as one artifact, and dropped onto a field
    unit wholesale. The ledger is live operational state.
  - No lock contention with the ledger's writer.
  - Verifiability: every chunk carries its document id, section label,
    character span and content hash — a retrieved passage is a citation,
    not a paraphrase.

Retrieval is lexical: SQLite FTS5 with BM25 ranking. Deterministic,
dependency-free, CPU-trivial, and exact-token strong — which is what
registry lookups (vessel IDs, names, permit numbers) actually need. A
similarity model can be layered on later; it is not required to be useful.
"""
from __future__ import annotations

import re
import sqlite3
import threading
import time
from pathlib import Path
from typing import Optional

DEFAULT_CORPUS_FILENAME = "corpus.db"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS documents (
    doc_id      TEXT PRIMARY KEY,
    title       TEXT,
    path        TEXT,
    sha1        TEXT,
    chunk_count INTEGER DEFAULT 0,
    ingested_at REAL
);
CREATE TABLE IF NOT EXISTS chunks (
    id          INTEGER PRIMARY KEY,
    doc_id      TEXT NOT NULL,
    chunk_index INTEGER NOT NULL,
    section     TEXT,
    span_start  INTEGER,
    span_end    INTEGER,
    sha1        TEXT,
    body        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_chunks_doc ON chunks(doc_id);
CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(
    body, content='chunks', content_rowid='id'
);
"""

# Keep the FTS index in lockstep with chunks via triggers so no code path
# can insert a chunk the index doesn't know about.
_TRIGGERS = """
CREATE TRIGGER IF NOT EXISTS chunks_ai AFTER INSERT ON chunks BEGIN
  INSERT INTO chunks_fts(rowid, body) VALUES (new.id, new.body);
END;
CREATE TRIGGER IF NOT EXISTS chunks_ad AFTER DELETE ON chunks BEGIN
  INSERT INTO chunks_fts(chunks_fts, rowid, body) VALUES ('delete', old.id, old.body);
END;
CREATE TRIGGER IF NOT EXISTS chunks_au AFTER UPDATE ON chunks BEGIN
  INSERT INTO chunks_fts(chunks_fts, rowid, body) VALUES ('delete', old.id, old.body);
  INSERT INTO chunks_fts(rowid, body) VALUES (new.id, new.body);
END;
"""

_TOKEN_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9\-_/\.]{1,63}")


def sanitize_query(terms) -> str:
    """Build a safe FTS5 MATCH expression from free text or a term list.

    Every term is double-quoted so user/observation text can never inject
    FTS5 syntax (NEAR, AND, column filters, unbalanced quotes → sqlite
    error). Terms are OR'd: retrieval is recall-oriented; BM25 ranks.
    """
    if isinstance(terms, str):
        terms = _TOKEN_RE.findall(terms)
    seen, out = set(), []
    for t in terms:
        t = str(t).strip().strip('"')
        if not t:
            continue
        key = t.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append('"' + t.replace('"', '') + '"')
    return " OR ".join(out)


class CorpusStore:
    """Thread-safe wrapper over the corpus SQLite file."""

    def __init__(self, path: str | Path = DEFAULT_CORPUS_FILENAME):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        with self._lock:
            self._conn.executescript(_SCHEMA)
            self._conn.executescript(_TRIGGERS)
            self._conn.commit()

    # ── write side (ingest) ──────────────────────────────────
    def add_document(self, doc_id: str, chunks: list[dict],
                     title: str = "", path: str = "",
                     sha1: str = "") -> int:
        """Insert a document's chunks, replacing any prior version.

        Replace-by-doc_id keeps re-ingesting an updated regulation a
        one-step operation with no stale chunks left behind. Each chunk
        dict: {"body" (required), "section", "chunk_index", "span_start",
        "span_end", "sha1"}.
        """
        with self._lock:
            cur = self._conn.cursor()
            cur.execute("DELETE FROM chunks WHERE doc_id = ?", (doc_id,))
            n = 0
            for i, ch in enumerate(chunks):
                body = (ch.get("body") or ch.get("text") or "").strip()
                if not body:
                    continue
                cur.execute(
                    "INSERT INTO chunks (doc_id, chunk_index, section, "
                    "span_start, span_end, sha1, body) VALUES (?,?,?,?,?,?,?)",
                    (doc_id, ch.get("chunk_index", i), ch.get("section") or "",
                     ch.get("span_start"), ch.get("span_end"),
                     ch.get("sha1") or "", body))
                n += 1
            cur.execute(
                "INSERT INTO documents (doc_id, title, path, sha1, "
                "chunk_count, ingested_at) VALUES (?,?,?,?,?,?) "
                "ON CONFLICT(doc_id) DO UPDATE SET title=excluded.title, "
                "path=excluded.path, sha1=excluded.sha1, "
                "chunk_count=excluded.chunk_count, "
                "ingested_at=excluded.ingested_at",
                (doc_id, title, path, sha1, n, time.time()))
            self._conn.commit()
            return n

    # ── read side (retrieval) ────────────────────────────────
    def search(self, query, top_k: int = 8,
               doc_ids: Optional[list[str]] = None) -> list[dict]:
        """BM25-ranked chunks matching the query. Empty query → []. Each hit:
        {doc_id, title, section, chunk_index, sha1, body, score}."""
        match = sanitize_query(query)
        if not match:
            return []
        sql = ("SELECT c.doc_id, d.title, c.section, c.chunk_index, c.sha1, "
               "c.body, bm25(chunks_fts) AS score "
               "FROM chunks_fts JOIN chunks c ON c.id = chunks_fts.rowid "
               "LEFT JOIN documents d ON d.doc_id = c.doc_id "
               "WHERE chunks_fts MATCH ?")
        params: list = [match]
        if doc_ids:
            sql += " AND c.doc_id IN (%s)" % ",".join("?" * len(doc_ids))
            params.extend(doc_ids)
        sql += " ORDER BY score LIMIT ?"   # bm25(): lower = better
        params.append(int(top_k))
        with self._lock:
            rows = self._conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    def stats(self) -> dict:
        with self._lock:
            docs = self._conn.execute(
                "SELECT COUNT(*) FROM documents").fetchone()[0]
            chunks = self._conn.execute(
                "SELECT COUNT(*) FROM chunks").fetchone()[0]
            listing = [dict(r) for r in self._conn.execute(
                "SELECT doc_id, title, chunk_count, ingested_at "
                "FROM documents ORDER BY doc_id").fetchall()]
        return {"path": str(self.path), "documents": docs,
                "chunks": chunks, "listing": listing}

    def close(self):
        with self._lock:
            self._conn.close()


def ingest_corpus_envelope(store: CorpusStore, data: dict,
                           fallback_doc_id: str = "corpus") -> int:
    """Index a corpus envelope produced by the digestor:
    {"source_type": "corpus", "doc_id": ..., "title": ..., "sha1": ...,
     "records": [chunk, ...]}. Returns chunks indexed."""
    doc_id = str(data.get("doc_id") or fallback_doc_id)
    return store.add_document(
        doc_id, list(data.get("records") or []),
        title=str(data.get("title") or doc_id),
        path=str(data.get("path") or ""),
        sha1=str(data.get("sha1") or ""))
