"""Shard manager for on-disk model weight loading.

Manages persistent safetensors file handles (mmap-backed) and provides
per-layer weight loading on demand. Transparently handles INT8
quantized tensors: when a tensor is stored as int8 with a companion
_scale tensor, it dequantizes to the requested dtype on the fly.

For single-shard models (like Qwen3-0.6B), one handle serves the
entire session. For multi-shard models, the manager resolves which
shard contains each layer's weights via model.safetensors.index.json.
"""

import json
from pathlib import Path
from typing import Optional

import torch
from safetensors import safe_open

from core.adapter.base import ModelAdapter


def _dequant_int8(q: torch.Tensor, scale: torch.Tensor,
                  out_dtype: torch.dtype) -> torch.Tensor:
    """Per-channel INT8 → out_dtype dequant, chunked over rows.

    The one-shot form `q.float() * scale.float().unsqueeze(-1)` materializes
    TWO full fp32 copies (4× the int8 bytes, both alive at the multiply)
    before the cast — a ~4.3 GB transient on a 152k-vocab embedding, which
    hard-OOM'd engine init on small boxes the moment a model went INT8.
    Chunking bounds the fp32 working set (~64 MB per block); the scale is
    per-row, so the math is row-local and the result is bit-identical.
    Engine is CPU-resident, so the output is allocated on the default device.
    """
    if q.ndim != 2:
        # Quantized tensors are 2D by construction (should_quantize); keep a
        # one-shot fallback for anything unexpected rather than mis-slicing.
        return (q.float() * scale.float().unsqueeze(-1)).to(out_dtype)
    rows, cols = q.shape
    out = torch.empty((rows, cols), dtype=out_dtype)
    s = scale.float()
    block = max(1, (64 << 20) // (cols * 4))  # ~64 MB of fp32 per block
    for r0 in range(0, rows, block):
        out[r0:r0 + block] = (
            q[r0:r0 + block].float() * s[r0:r0 + block].unsqueeze(-1)
        ).to(out_dtype)
    return out


class ShardManager:
    """Manages on-disk model shards for demand loading.

    INT8 dequantization is transparent: if a tensor is stored as int8
    and a corresponding {name}_scale tensor exists, dequantization
    (int8 × scale → target dtype) happens automatically on load.
    """

    def __init__(self, model_path: str | Path, adapter: ModelAdapter,
                 resident: bool = False, resident_max_bytes: int = 0,
                 qresident_max_bytes: int = 0):
        self.model_path = Path(model_path)
        self.adapter = adapter
        self._handles: dict[str, object] = {}  # shard_path → safe_open handle
        self._key_to_shard: dict[str, Path] = {}  # tensor_key → shard_path
        self._scale_keys: set[str] = set()  # keys that are _scale companions
        # ── Resident-RAM mode (opt-in, additive; streaming stays the default
        #    and the fallback). When on, the dequantized result of load_layer /
        #    load_lm_head is cached so subsequent forwards reuse already-loaded,
        #    already-dequantized bf16 tensors instead of re-reading+re-dequant-
        #    izing off disk every token. Output-identical by construction (same
        #    tensors, dequant done once). Gated by resident_max_bytes (0 =
        #    unlimited): once the cap is hit, further layers silently stream, so
        #    a box with too little RAM degrades to streaming rather than OOMs.
        self._resident = bool(resident)
        self._resident_max_bytes = int(resident_max_bytes)
        self._layer_cache: dict = {}   # (layer_idx, dtype) -> {role: tensor}
        self._misc_cache: dict = {}    # ("lm_head", dtype) -> tensor
        self._resident_bytes = 0
        self._raw_reads = 0            # count of underlying mmap reads (probe)
        # ── Tier 2: raw at-rest tensors, PIN, no eviction ──────────────────
        # Pins each role AS STORED (int8+scale pairs, or the raw tensor for
        # unquantized roles like fp32 norms) and materializes to the caller's
        # dtype on every hit. For INT8 models a tier-2 GB pins 2x (->bf16)
        # to 4x (->fp32) the layers a tier-1 GB does; a hit pays one chunked
        # dequant instead of a disk read. Keyed by layer index only, so a
        # mid-run dtype change still hits. One tier owns a layer: tier 1
        # first, then tier 2, then stream forever (same policy as the GGUF
        # manager; see courier-performance-design-spec §4).
        self._qresident_max_bytes = int(qresident_max_bytes)
        self._qlayer_cache: dict = {}  # layer_idx -> {role: (raw, scale|None)}
        self._qresident_bytes = 0
        self._qhits = 0
        self._build_index()

    def _build_index(self):
        """Build the mapping from tensor keys to shard files."""
        index_path = self.model_path / "model.safetensors.index.json"

        if index_path.exists():
            # Multi-shard model
            with open(index_path, encoding="utf-8") as f:
                index = json.load(f)
            weight_map = index.get("weight_map", {})
            for key, shard_name in weight_map.items():
                self._key_to_shard[key] = self.model_path / shard_name
                if key.endswith("_scale"):
                    self._scale_keys.add(key)
        else:
            # Single-shard model
            shard_files = sorted(self.model_path.glob("*.safetensors"))
            if not shard_files:
                raise FileNotFoundError(
                    f"No .safetensors files found in {self.model_path}"
                )
            shard_path = shard_files[0]
            handle = safe_open(str(shard_path), framework="pt")
            self._handles[str(shard_path)] = handle
            for key in handle.keys():
                self._key_to_shard[key] = shard_path
                if key.endswith("_scale"):
                    self._scale_keys.add(key)

    def _get_handle(self, shard_path: Path) -> object:
        """Get or create a persistent handle for a shard file."""
        key = str(shard_path)
        if key not in self._handles:
            self._handles[key] = safe_open(key, framework="pt")
        return self._handles[key]

    def _load_raw(self, key: str) -> torch.Tensor:
        """Load a tensor from the mmap-backed shard without any conversion."""
        self._raw_reads += 1
        shard_path = self._key_to_shard[key]
        handle = self._get_handle(shard_path)
        return handle.get_tensor(key)

    def get_tensor(self, key: str, dtype: Optional[torch.dtype] = None,
                   _cache: bool = True) -> torch.Tensor:
        """Load a single tensor by key, dequantizing INT8 if needed.

        If the tensor is stored as int8 and a {key}_scale tensor exists,
        dequantizes via: (int8_tensor.float() × scale) → target dtype.
        Otherwise returns the tensor as stored, optionally cast to dtype.

        Args:
            key: State dict key (e.g., "model.layers.0.self_attn.q_proj.weight")
            dtype: Optional dtype to cast to. If None, returns at native
                   precision (FP32 for norms, BF16 after INT8 dequant).
        """
        if key not in self._key_to_shard:
            raise KeyError(f"Tensor key '{key}' not found in any shard")

        ck = (key, dtype)
        if self._resident and ck in self._misc_cache:
            return self._misc_cache[ck]

        tensor = self._load_raw(key)

        # INT8 dequantization
        scale_key = key + "_scale"
        if tensor.dtype == torch.int8 and scale_key in self._key_to_shard:
            scale = self._load_raw(scale_key)
            # Per-channel dequant: int8 (rows, cols) × scale (rows,) → float.
            # Chunked over rows — see _dequant_int8 for why the one-shot form
            # OOM-killed engine init on small boxes.
            tensor = _dequant_int8(
                tensor, scale,
                dtype if dtype is not None else torch.bfloat16)

        # Non-quantized tensor (norms, biases)
        elif dtype is not None and tensor.dtype != dtype:
            tensor = tensor.to(dtype)

        # Resident mode: cache standalone tensors (embedding, final norm,
        # ViT weights) WITH budget accounting. Before this, the INT8 branch
        # returned before any caching — on INT8 models the embedding and
        # every ViT tensor were re-read and re-DEQUANTIZED per use — and the
        # embedding never counted toward _resident_bytes, leaving the budget
        # blind to ~0.8 GB of pinned weights (the ledger asymmetry).
        # load_layer passes _cache=False: its per-layer dict cache owns
        # those bytes, and caching here too would double-count the budget.
        if _cache and self._resident:
            nbytes = tensor.numel() * tensor.element_size()
            if self._room_for(nbytes):
                self._misc_cache[ck] = tensor
                self._resident_bytes += nbytes

        return tensor

    def has_key(self, key: str) -> bool:
        """Check if a tensor key exists (excludes _scale companion keys)."""
        return key in self._key_to_shard and key not in self._scale_keys

    def load_embedding(self, dtype: torch.dtype = torch.bfloat16) -> torch.Tensor:
        """Load the token embedding matrix."""
        return self.get_tensor(self.adapter.embedding_key(), dtype)

    def load_final_norm(self, dtype: torch.dtype = torch.bfloat16) -> torch.Tensor:
        """Load the final RMSNorm weight."""
        return self.get_tensor(self.adapter.final_norm_key(), dtype)

    def load_lm_head(self, dtype: torch.dtype = torch.bfloat16) -> Optional[torch.Tensor]:
        """Load the LM head weight, or None if tied to embedding."""
        key = self.adapter.lm_head_key()
        if key is None:
            return None
        if not self.has_key(key):
            return None
        # Delegates to get_tensor, whose resident cache now does the
        # accounting — a second ("lm_head", dtype) entry here would cache
        # the same tensor twice and double-count the budget.
        return self.get_tensor(key, dtype)

    def load_layer(self, layer_idx: int, dtype: torch.dtype = torch.bfloat16) -> dict[str, torch.Tensor]:
        """Load all weight tensors for a single layer.

        Args:
            layer_idx: Layer index (0-based)
            dtype: Dtype to cast all tensors to

        Returns:
            Dict mapping weight role names to tensors.

        In resident mode the dequantized result is cached and reused on later
        calls (a shallow dict copy is returned so callers can't mutate the
        cache); streaming mode re-reads every call as before.
        """
        ck = (layer_idx, dtype)
        if self._resident and ck in self._layer_cache:
            return dict(self._layer_cache[ck])   # shallow copy; tensors shared

        # Tier 2: raw at-rest pairs — materialize from RAM, no disk read.
        raw_map = self._qlayer_cache.get(layer_idx)
        from_disk = raw_map is None
        if from_disk:
            key_map = self.adapter.layer_weight_keys(layer_idx)
            raw_map = {}
            for role, key in key_map.items():
                if key in self._key_to_shard and key not in self._scale_keys:
                    raw = self._load_raw(key)
                    scale_key = key + "_scale"
                    scale = (self._load_raw(scale_key)
                             if raw.dtype == torch.int8
                             and scale_key in self._key_to_shard else None)
                    raw_map[role] = (raw, scale)
        else:
            self._qhits += 1

        result = {}
        for role, (raw, scale) in raw_map.items():
            if scale is not None:
                result[role] = _dequant_int8(
                    raw, scale, dtype if dtype is not None else torch.bfloat16)
            elif dtype is not None and raw.dtype != dtype:
                result[role] = raw.to(dtype)
            else:
                result[role] = raw

        if from_disk:
            if self._resident:
                nbytes = sum(t.numel() * t.element_size() for t in result.values())
                if self._room_for(nbytes):
                    self._layer_cache[ck] = result
                    self._resident_bytes += nbytes
                    return result
            # Tier 1 off or full -> pin the raw pairs in tier 2 if room.
            qbytes = sum(
                r.numel() * r.element_size()
                + (s.numel() * s.element_size() if s is not None else 0)
                for r, s in raw_map.values())
            if (self._qresident_max_bytes > 0
                    and self._qresident_bytes + qbytes <= self._qresident_max_bytes):
                # PIN means RAM, not a promise: _load_raw returns mmap-backed
                # tensors whose pages the OS may evict, so caching those
                # would quietly degrade a "tier-2 hit" into a disk read under
                # the exact memory pressure the tier exists to survive.
                # Clone into anonymous memory so residency is real.
                self._qlayer_cache[layer_idx] = {
                    role: (r.clone(), s.clone() if s is not None else None)
                    for role, (r, s) in raw_map.items()
                }
                self._qresident_bytes += qbytes
            # else: both tiers full/off -> this layer streams every call.
        return result

    def _room_for(self, nbytes: int) -> bool:
        """Whether caching nbytes more stays within the resident cap (0=∞)."""
        if self._resident_max_bytes <= 0:
            return True
        return (self._resident_bytes + nbytes) <= self._resident_max_bytes

    def cache_stats(self) -> dict:
        """Resident-cache telemetry (also used by the cold equivalence probe)."""
        return {
            "resident": self._resident,
            "raw_reads": self._raw_reads,
            "layers_cached": len(self._layer_cache),
            "misc_cached": len(self._misc_cache),
            "resident_bytes": self._resident_bytes + self._qresident_bytes,
            "resident_max_bytes": self._resident_max_bytes + self._qresident_max_bytes,
            "qlayers_cached": len(self._qlayer_cache),
            "qresident_bytes": self._qresident_bytes,
            "qresident_max_bytes": self._qresident_max_bytes,
            "qhits": self._qhits,
        }

    def set_resident_budget(self, resident: bool, max_bytes: int) -> None:
        """Live-adjust resident mode without a model reload.

        Additive and safe to call mid-forward: load_layer reads these fields
        fresh, so enabling (or raising the cap) takes effect as subsequent
        layers load. Disabling stops new caching but does NOT clear layers
        already resident — clearing mid-run would race the worker thread that
        is reading/writing the cache; a full reclaim happens at the next model
        load. Only attribute writes here (GIL-atomic), no structure mutation.
        """
        self._resident = bool(resident)
        self._resident_max_bytes = int(max_bytes)

    def all_keys(self) -> list[str]:
        """Return all tensor keys (excluding _scale companions)."""
        return [k for k in self._key_to_shard.keys() if k not in self._scale_keys]

    def close(self):
        """Close all shard handles and drop any resident cache."""
        self._handles.clear()
        self._layer_cache.clear()
        self._misc_cache.clear()
        self._resident_bytes = 0
        self._qlayer_cache.clear()
        self._qresident_bytes = 0

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
