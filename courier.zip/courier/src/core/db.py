"""SQLite persistence layer.

Single database file holds ingestion records, cycle history, stage
outputs, and checkpoint journals. Created on first access.

Thread safety: one connection is shared across the HTTP threads, the
SSE polling thread, and the background worker thread. A SQLite
connection is not safe for concurrent use, so every method that
touches the connection runs under a reentrant lock (`self._lock`).
The lock is reentrant because some methods call others (e.g.
`ingestion_stats` calls `unconsumed_count`). Code that reaches the
connection directly (`db._conn`) must hold `db._lock` itself.
"""

import functools
import json
import sqlite3
import threading
import time
import uuid
from pathlib import Path
from typing import Optional


SCHEMA = """
CREATE TABLE IF NOT EXISTS ingestion (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    source_id   TEXT NOT NULL,
    timestamp   REAL NOT NULL,
    content     TEXT NOT NULL,
    mime_type   TEXT DEFAULT 'text/plain',
    byte_size   INTEGER,
    checksum    TEXT,
    ingested_at REAL NOT NULL,
    consumed    INTEGER DEFAULT 0,
    cycle_id    TEXT,
    path        TEXT,
    source_type TEXT DEFAULT 'inbox'
);

CREATE INDEX IF NOT EXISTS idx_ingestion_unconsumed
    ON ingestion(consumed) WHERE consumed = 0;
CREATE INDEX IF NOT EXISTS idx_ingestion_source
    ON ingestion(source_id, timestamp);

CREATE TABLE IF NOT EXISTS cycles (
    id              TEXT PRIMARY KEY,
    cycle_number    INTEGER NOT NULL,
    status          TEXT NOT NULL,
    config          TEXT NOT NULL,
    template_id     TEXT NOT NULL,
    created_at      REAL NOT NULL,
    infer_started   REAL,
    completed_at    REAL,
    progress        TEXT,
    result_path     TEXT,
    error           TEXT,
    tokens_generated INTEGER DEFAULT 0,
    disk_writes_mb  REAL DEFAULT 0,
    energy_j        REAL,
    energy_method   TEXT
);

CREATE TABLE IF NOT EXISTS cycle_stages (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    cycle_id    TEXT NOT NULL,
    stage_index INTEGER NOT NULL,
    label       TEXT NOT NULL,
    thinking    INTEGER DEFAULT 0,
    input_tokens INTEGER,
    output_tokens INTEGER,
    output_text TEXT,
    time_seconds REAL,
    status      TEXT NOT NULL,
    error       TEXT,
    FOREIGN KEY (cycle_id) REFERENCES cycles(id)
);

CREATE TABLE IF NOT EXISTS checkpoints (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    cycle_id        TEXT NOT NULL,
    stage_index     INTEGER NOT NULL,
    generation_step INTEGER NOT NULL,
    tokens_json     TEXT NOT NULL,
    position        INTEGER NOT NULL,
    rng_state       BLOB,
    timestamp       REAL NOT NULL,
    active_seconds  REAL DEFAULT 0,
    kv_cache_dir    TEXT,
    prompt          TEXT,
    FOREIGN KEY (cycle_id) REFERENCES cycles(id)
);

CREATE TABLE IF NOT EXISTS meta (
    key     TEXT PRIMARY KEY,
    value   TEXT
);
"""


def _locked(method):
    """Run a Database method while holding the instance lock.

    Serializes all access to the shared SQLite connection so the
    worker, SSE, and HTTP threads cannot interleave on the cursor.
    """
    @functools.wraps(method)
    def wrapper(self, *args, **kwargs):
        with self._lock:
            return method(self, *args, **kwargs)
    return wrapper


class Database:
    """SQLite database for Courier persistence."""

    def __init__(self, path: str | Path = "courier.db"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        # Reentrant: methods like ingestion_stats() call other methods.
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._create_tables()
        self._migrate()

    @_locked
    def _create_tables(self):
        self._conn.executescript(SCHEMA)
        self._conn.commit()

    @_locked
    def _migrate(self):
        """Apply idempotent schema migrations to a pre-existing database.

        CREATE TABLE IF NOT EXISTS never alters a table that already
        exists, so a column added to SCHEMA after a database was first
        created must be backfilled here. ALTER TABLE ADD COLUMN raises if
        the column is already present, which makes each migration a safe
        no-op on every run after the first.
        """
        migrations = [
            "ALTER TABLE checkpoints ADD COLUMN prompt TEXT",
            "ALTER TABLE checkpoints ADD COLUMN active_seconds REAL DEFAULT 0",
            "ALTER TABLE ingestion ADD COLUMN path TEXT",
            "ALTER TABLE ingestion ADD COLUMN source_type TEXT DEFAULT 'inbox'",
            # joules-per-verdict: the cost line every receipt should carry
            "ALTER TABLE cycles ADD COLUMN energy_j REAL",
            "ALTER TABLE cycles ADD COLUMN energy_method TEXT",
        ]
        for ddl in migrations:
            try:
                self._conn.execute(ddl)
                self._conn.commit()
            except sqlite3.OperationalError:
                pass  # already applied

    @_locked
    def close(self):
        self._conn.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    # ── Ingestion ────────────────────────────────────────────

    def _merge_insert(self, source_id, timestamp, content, mime_type,
                      checksum, path, source_type, now, mergeable):
        """Insert one record, deduplicated on (source_id, timestamp, checksum)
        within the PENDING set only: re-ingesting a record that is already
        waiting (same source, same instant, same content) replaces it instead
        of duplicating it, so re-running an ingest is idempotent. Distinct
        readings that share a timestamp (e.g. several sensors in one CSV) are
        all kept — content is part of the key. Nothing is skipped — records
        without a usable timestamp (mergeable=False) go straight in, and a
        reading for an instant a past cycle already consumed is ingested as
        new pending work (the consumed row stays as history). Caller holds
        the lock and commits. Returns the new row id.

        EXCEPTION — source_type "feed" (polling conduits like Datagator): a
        record identity seen EVER — pending OR consumed — is not new work.
        Overlapping fetch windows re-deliver mostly-identical records each
        run; under the windowed-inbox rule above, every already-consumed
        reading would re-enter as fresh pending and cycles would re-chew old
        data forever. Pending duplicates are still replaced (idempotent);
        consumed identities are skipped (returns None, nothing written).
        """
        if mergeable and source_type == "feed":
            row = self._conn.execute(
                "SELECT id FROM ingestion WHERE source_id=? AND timestamp=? "
                "AND checksum IS ? AND consumed=1 LIMIT 1",
                (source_id, timestamp, checksum)).fetchone()
            if row:
                return None
        if mergeable:
            self._conn.execute(
                "DELETE FROM ingestion WHERE source_id=? AND timestamp=? "
                "AND checksum IS ? AND consumed=0",
                (source_id, timestamp, checksum))
        cur = self._conn.execute(
            "INSERT INTO ingestion (source_id, timestamp, content, mime_type, "
            "byte_size, checksum, ingested_at, path, source_type) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (source_id, timestamp, content, mime_type,
             len(content.encode()), checksum, now, path, source_type))
        return cur.lastrowid

    @_locked
    def ingest(self, source_id: str, content: str, timestamp: Optional[float] = None,
               mime_type: str = "text/plain", checksum: Optional[str] = None,
               path: Optional[str] = None, source_type: str = "inbox") -> int:
        """Store an ingestion record, merged on (source_id, timestamp).

        source_type: 'inbox' (windowed — consumed once per cycle),
        'feed' (windowed like inbox, but an identity the ledger has EVER
        seen — even consumed — is never re-fed; see _merge_insert), or
        'reference' (persistent companion data — never consumed, returned to
        every cycle). path: for image/file records, the on-disk location whose
        pixels/bytes are dereferenced at inference time (content holds metadata).
        """
        now = time.time()
        mergeable = timestamp is not None
        ts = timestamp if mergeable else now
        rid = self._merge_insert(source_id, ts, content, mime_type, checksum,
                                 path, source_type, now, mergeable)
        self._conn.commit()
        return rid

    @_locked
    def ingest_batch(self, records: list[dict]) -> int:
        """Ingest every record, each merged on (source_id, timestamp) against
        the pending set. Returns the number of rows actually written —
        feed-type identities the ledger has already consumed are skipped
        (see _merge_insert), so "N records" stays truthful for conduits."""
        now = time.time()
        written = 0
        for r in records:
            ts = r.get("timestamp")
            mergeable = ts is not None
            rid = self._merge_insert(
                r["source_id"], ts if mergeable else now, r["content"],
                r.get("mime_type", "text/plain"), r.get("checksum"),
                r.get("path"), r.get("source_type", "inbox"), now, mergeable)
            if rid is not None:
                written += 1
        self._conn.commit()
        return written

    @_locked
    def unconsumed_count(self) -> int:
        """Count of unconsumed windowed (inbox) records.

        Reference rows are persistent and never 'pending', so they are
        excluded — this reflects work waiting for the next cycle.
        """
        row = self._conn.execute(
            "SELECT COUNT(*) FROM ingestion "
            "WHERE consumed = 0 AND source_type IN ('inbox', 'feed')"
        ).fetchone()
        return row[0]

    @_locked
    def snapshot(self, cycle_id: str) -> int:
        """Claim all unconsumed WINDOWED (inbox) records for a cycle.

        Marks them consumed and stamps the cycle_id. Reference rows are
        persistent companion data and are never claimed here — they stay
        available to every cycle (see get_reference_records).
        """
        cur = self._conn.execute(
            "UPDATE ingestion SET consumed = 1, cycle_id = ? "
            "WHERE consumed = 0 AND source_type IN ('inbox', 'feed')",
            (cycle_id,)
        )
        self._conn.commit()
        return cur.rowcount

    @_locked
    def get_snapshot_records(self, cycle_id: str) -> list[dict]:
        """Get all records claimed by a cycle snapshot (windowed scope)."""
        rows = self._conn.execute(
            "SELECT id, source_id, timestamp, content, mime_type, path, source_type "
            "FROM ingestion WHERE cycle_id = ? ORDER BY timestamp, id",
            (cycle_id,)
        ).fetchall()
        return [dict(r) for r in rows]

    @_locked
    def get_reference_records(self) -> list[dict]:
        """Get persistent companion data (source_type='reference').

        Returned to every cycle as standing context; never consumed or moved.
        """
        rows = self._conn.execute(
            "SELECT id, source_id, timestamp, content, mime_type, path, source_type "
            "FROM ingestion WHERE source_type = 'reference' ORDER BY timestamp, id"
        ).fetchall()
        return [dict(r) for r in rows]

    def cycle_image_names(self, cycle_id: str) -> list[dict]:
        """Image files a cycle actually reasoned over, for report links.

        The cycle's image scope is the windowed inbox snapshot ∪ the persistent
        reference images — the same union the engine sees via the worker's
        records-by-source binding. Reference rows are never stamped with a
        cycle_id, so they are absent from get_snapshot_records(); a report built
        from the snapshot alone silently omits any reference image the cycle
        clearly described. Returning the union keeps the report honest.

        Returns ordered, de-duplicated dicts: {"name": basename, "path": path}.
        Order is snapshot images first, then reference images. De-dup is by
        full path, so the same file ingested into both scopes appears once.

        Note: reference scope is the CURRENT reference set. Per-cycle reference
        membership is not persisted, so a historical report reflects today's
        reference images, not necessarily the set present when the cycle ran.
        For a stable reference set (the common case) this is exact.
        """
        scope = self.get_snapshot_records(cycle_id) + self.get_reference_records()
        out: list[dict] = []
        seen: set[str] = set()
        for r in scope:
            p = r.get("path")
            if not p or not (r.get("mime_type") or "").startswith("image/"):
                continue
            if p in seen:
                continue
            seen.add(p)
            out.append({"name": Path(p).name, "path": p})
        return out

    @_locked
    def ingestion_stats(self) -> dict:
        """Buffer statistics."""
        total = self._conn.execute("SELECT COUNT(*) FROM ingestion").fetchone()[0]
        unconsumed = self.unconsumed_count()
        return {
            "total_records": total,
            "unconsumed": unconsumed,
            "consumed": total - unconsumed,
        }

    # ── Cycles ───────────────────────────────────────────────

    @_locked
    def create_cycle(self, cycle_number: int, template_id: str,
                     config: dict) -> str:
        """Create a new cycle record. Returns the cycle ID."""
        cycle_id = str(uuid.uuid4())[:8]
        self._conn.execute(
            "INSERT INTO cycles (id, cycle_number, status, config, "
            "template_id, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            (cycle_id, cycle_number, "created", json.dumps(config),
             template_id, time.time())
        )
        self._conn.commit()
        return cycle_id

    @_locked
    def update_cycle(self, cycle_id: str, **fields):
        """Update cycle fields."""
        sets = ", ".join(f"{k} = ?" for k in fields)
        vals = list(fields.values()) + [cycle_id]
        self._conn.execute(
            f"UPDATE cycles SET {sets} WHERE id = ?", vals
        )
        self._conn.commit()

    @_locked
    def get_cycle(self, cycle_id: str) -> Optional[dict]:
        """Get a cycle record."""
        row = self._conn.execute(
            "SELECT * FROM cycles WHERE id = ?", (cycle_id,)
        ).fetchone()
        return dict(row) if row else None

    @_locked
    def get_latest_cycle(self) -> Optional[dict]:
        """Get the most recent cycle."""
        row = self._conn.execute(
            "SELECT * FROM cycles ORDER BY created_at DESC LIMIT 1"
        ).fetchone()
        return dict(row) if row else None

    @_locked
    def get_interrupted_cycle(self) -> Optional[dict]:
        """Find a cycle that was interrupted (status = inferring or paused)."""
        row = self._conn.execute(
            "SELECT * FROM cycles WHERE status IN ('inferring', 'paused') "
            "ORDER BY created_at DESC LIMIT 1"
        ).fetchone()
        return dict(row) if row else None

    @_locked
    def cycle_count(self) -> int:
        """Total completed cycles."""
        row = self._conn.execute(
            "SELECT COUNT(*) FROM cycles WHERE status = 'complete'"
        ).fetchone()
        return row[0]

    @_locked
    def next_cycle_number(self) -> int:
        """The next lifetime cycle number: MAX(cycle_number) + 1.

        NOT cycle_count() + 1 — that counts only 'complete' rows, so every
        failed / skipped / missed / cancelled cycle consumes a number without
        being counted and the next job reuses it, putting duplicate cycle
        numbers in History. Numbers are spent the moment a row is created,
        whatever becomes of it.
        """
        row = self._conn.execute(
            "SELECT COALESCE(MAX(cycle_number), 0) + 1 FROM cycles"
        ).fetchone()
        return row[0]

    @_locked
    def get_cycles(self, limit: int = 50) -> list[dict]:
        """Get cycle history."""
        rows = self._conn.execute(
            "SELECT * FROM cycles ORDER BY created_at DESC LIMIT ?",
            (limit,)
        ).fetchall()
        return [dict(r) for r in rows]

    @_locked
    def cycle_totals(self) -> dict:
        """Lifetime completed-cycle totals for the node view.

        energy_j is None (not 0) when no completed cycle carries an energy
        reading — an absent measurement must not display as zero cost.
        """
        row = self._conn.execute(
            "SELECT COUNT(*) AS cycles, "
            "COALESCE(SUM(tokens_generated), 0) AS tokens, "
            "SUM(energy_j) AS energy_j "
            "FROM cycles WHERE status = 'complete'"
        ).fetchone()
        return dict(row)

    # ── Meta (node-level key/value: identity, future network state) ──

    @_locked
    def get_meta(self, key: str, default: Optional[str] = None
                 ) -> Optional[str]:
        row = self._conn.execute(
            "SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
        return row["value"] if row else default

    @_locked
    def set_meta(self, key: str, value: str) -> None:
        self._conn.execute(
            "INSERT INTO meta (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, str(value)))
        self._conn.commit()

    # ── Cycle Stages ─────────────────────────────────────────

    @_locked
    def save_stage(self, cycle_id: str, stage_index: int, label: str,
                   thinking: bool, output_text: str, input_tokens: int,
                   output_tokens: int, time_seconds: float,
                   status: str = "complete", error: Optional[str] = None):
        """Save a completed stage result."""
        self._conn.execute(
            "INSERT INTO cycle_stages (cycle_id, stage_index, label, thinking, "
            "input_tokens, output_tokens, output_text, time_seconds, status, error) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (cycle_id, stage_index, label, int(thinking), input_tokens,
             output_tokens, output_text, time_seconds, status, error)
        )
        self._conn.commit()

    @_locked
    def get_stages(self, cycle_id: str) -> list[dict]:
        """Get all stages for a cycle."""
        rows = self._conn.execute(
            "SELECT * FROM cycle_stages WHERE cycle_id = ? ORDER BY stage_index",
            (cycle_id,)
        ).fetchall()
        return [dict(r) for r in rows]

    @_locked
    def completed_stage_count(self, cycle_id: str) -> int:
        """Count completed stages for a cycle."""
        row = self._conn.execute(
            "SELECT COUNT(*) FROM cycle_stages WHERE cycle_id = ? AND status = 'complete'",
            (cycle_id,)
        ).fetchone()
        return row[0]

    # ── Checkpoints ──────────────────────────────────────────

    @_locked
    def save_checkpoint(self, cycle_id: str, stage_index: int,
                        generation_step: int, tokens: list[int],
                        position: int, rng_state: Optional[bytes] = None,
                        kv_cache_dir: Optional[str] = None,
                        prompt: Optional[str] = None,
                        active_seconds: float = 0.0):
        """Write a checkpoint journal entry.

        One atomic row. `prompt` pins the stage prompt the tokens were
        generated against, so a recovery re-feeds it exactly. `active_seconds`
        banks the stage's accumulated *active* compute time as of this row —
        the time half of the same durable progress the token list is the
        count half of — so a resume continues the clock from here, not from
        wall-clock zero and not across the dead gap.
        """
        self._conn.execute(
            "INSERT INTO checkpoints (cycle_id, stage_index, generation_step, "
            "tokens_json, position, rng_state, timestamp, active_seconds, "
            "kv_cache_dir, prompt) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (cycle_id, stage_index, generation_step, json.dumps(tokens),
             position, rng_state, time.time(), active_seconds,
             kv_cache_dir, prompt)
        )
        self._conn.commit()

    @_locked
    def get_latest_checkpoint(self, cycle_id: str,
                              stage_index: Optional[int] = None) -> Optional[dict]:
        """Get the most recent checkpoint for a cycle (optionally for a stage)."""
        if stage_index is not None:
            row = self._conn.execute(
                "SELECT * FROM checkpoints WHERE cycle_id = ? AND stage_index = ? "
                "ORDER BY generation_step DESC LIMIT 1",
                (cycle_id, stage_index)
            ).fetchone()
        else:
            row = self._conn.execute(
                "SELECT * FROM checkpoints WHERE cycle_id = ? "
                "ORDER BY timestamp DESC LIMIT 1",
                (cycle_id,)
            ).fetchone()
        if row is None:
            return None
        d = dict(row)
        d["tokens"] = json.loads(d["tokens_json"])
        return d

    @_locked
    def clear_checkpoints(self, cycle_id: str):
        """Remove all checkpoints for a cycle (after completion)."""
        self._conn.execute(
            "DELETE FROM checkpoints WHERE cycle_id = ?", (cycle_id,)
        )
        self._conn.commit()

    @_locked
    def count_checkpoints(self, cycle_id: str) -> int:
        """Number of checkpoint rows banked for a cycle."""
        row = self._conn.execute(
            "SELECT COUNT(*) FROM checkpoints WHERE cycle_id = ?", (cycle_id,)
        ).fetchone()
        return row[0]

    @_locked
    def count_snapshot_records(self, cycle_id: str) -> int:
        """Number of ingestion records claimed by a cycle's windowed snapshot.

        Counterpart to get_snapshot_records() but COUNT(*) only, so the live
        status read-out doesn't load every content blob just to size the set.
        """
        row = self._conn.execute(
            "SELECT COUNT(*) FROM ingestion WHERE cycle_id = ?", (cycle_id,)
        ).fetchone()
        return row[0]
