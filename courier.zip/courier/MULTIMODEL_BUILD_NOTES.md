# Multi-Model & Speculative Decoding — Build Notes

Implements `courier-multimodel-design-spec.md` (draft v3) against this tree.
The work follows the spec's **dormant-first** build order (§8): every change is
additive and inert by default, so off-path parity (§9) holds **by construction**.

## Dormancy contract

With factory config, the runtime is byte-for-byte a single-model build:

- `config.speculative.enabled = false`, `config.speculative.draft_model = null`
- `config.registry.secondary_model = null`
- No second model is loaded; `STATE["engines"]` holds exactly one entry
  (`primary`) that mirrors the existing `STATE["streamer"]/["infer_fn"]/
  ["model_path"]` fields, which remain the authoritative aliases.
- The speculative decode loop is never entered (`make_infer_fn` only routes to
  it when a draft engine is supplied; default is `None`).
- Stage routing resolves every stage to `primary` (`select_stage_infer_fn`
  returns the single `infer_fn` when no routing map is present, and the worker
  passes `infer_fns=None` whenever the registry is single).
- New per-step `model` and the speculative config block serialize only when
  set, so existing templates and config files round-trip unchanged.

## Build order status (§8)

1. **Engine registry** — `src/engine/registry.py` (new). Pure, torch-free
   role→entry map with a guaranteed `primary`. Wired into the server as an
   additive `STATE["engines"]`, refreshed on every (un)load via
   `_sync_primary_engine()`. Done.
2. **Partition & admission (§5)** — `partition_resident_budget()` in
   `src/engine/sizing.py`. Pure function, no wiring. Done.
3. **Engine primitives (§6)** — `forward(all_positions=…)` on both streamers;
   `snapshot_state()/restore_state()` on both (`KVCacheManager.truncate()` added
   for the KV side; the **hybrid recurrent/conv** snapshot is the load-bearing
   part). Built, unused unless SD is on. Done (logic-complete; on-rig
   losslessness validation pending — see below).
4. **Channel B SD loop (§7)** — `src/engine/speculative.py` (new),
   distribution-preserving draft→verify→accept (modified rejection sampling;
   greedy is its temperature-0 case). Runs at the SAME sampling settings as the
   plain decode — temperature/top_p/top_k/presence_penalty are passed through,
   never overridden. `speculative` config block added. `make_infer_fn` /
   `build_engine` gained optional `draft_streamer` / `speculative_block_k`
   (default `None` ⇒ unchanged). Done.
5. **Channel A stage routing** — `StageConfig.model` (parsed; emitted only when
   set), `select_stage_infer_fn()` + `run_pipeline(infer_fns=…)`, threaded
   through `run_worker` and both `run_pipeline` call sites (main + resume).
   Default `None` preserves today's single-`infer_fn` behavior. Done.
6. **UI** — `static/dashboard.html`: a "Speculative Decoding" section in the
   **Settings drawer** (the ⚙ menu, alongside the other system/infrastructure
   settings — it is not a per-run casual setting), defaulting off, posting the
   nested `speculative` block. The **Draft Model** field is a picker, not a
   free-text box: it lists only *downloaded* models of the **loaded model's
   family** that are **smaller than the loaded model** (via the `family` and
   `size_gb` already on `/api/models`), so the draft shares the verifier's
   tokenizer AND is the cheaper model — a Qwen verifier can't be paired with a
   Llama draft, and a model can't "draft" with something its own size or
   larger. With no model loaded, or no compatible smaller model on disk, it
   shows a hint instead of options. `static/template_builder.html`: per-step **Model
   (override)** field, blank ⇒ primary. Done.
7. **Channel C (self-speculative)** — not started; spec marks it optional/later.

## Acceptance criteria (§9) — verification status

This sandbox has no torch, no models, no GPU/CPU rig, and no pytest run of the
model path, so model-dependent criteria are verified **by construction +
cold probes here**, and the rest are flagged for the target rig.

- **Off-path parity** — *guaranteed by construction here; full suite + tok/s on
  the rig.* All edits are additive supersets with default-off gates; every
  touched module passes `python -m py_compile`. No second model loads under
  default config. The existing test suite and tok/s-within-noise check must
  still be run on the target rig to confirm empirically.
- **Admission** — **cold-verified here.** `tests/probe_partition.py` (19 checks)
  exercises `partition_resident_budget`: non-overlapping caps for a fitting
  pair, `None` for an oversized draft and when the dial is off, `ValueError` on
  negative inputs, primary-floor refusal. The "load refused, primary intact"
  behavior is enforced at the loader and needs the rig to exercise live.
- **Losslessness** — *needs the target rig (4B+0.8B pair).* The SD loop is
  distribution-preserving by construction: at temperature 0 the committed
  stream is the verifier's exact greedy decode (byte-identical), and at
  temperature > 0 it is distributed exactly as the verifier's sampling output
  at those settings (distribution-identical, not seed-identical). The
  accept/reject math is verified torch-free in tests/probe_specsample.py; both
  engines roll back via snapshot/restore at each block boundary. Correctness of
  the **hybrid**
  recurrent/conv rollback can only be proven against the real models; until
  then the path stays dormant (`speculative.enabled` defaults false).
- **Reproduces α** — *needs the rig.* `tests/spec_decode_bench.py` (the
  acceptance-rate bench, relocated here from `tools/` — contents unchanged)
  should still report α≈0.66 for the reference pair.
- **Independent switches** — routing core and SD core are independent and each
  cold-verified (`tests/probe_routing.py`, `tests/probe_registry.py`); full
  on/off-matrix run is a rig step.

## Speculative draft engine — now wired (untested on-rig)

The draft/verify path is now connected end to end. At model load (startup and
`/api/models/load`), `_build_draft_if_configured()` reads `speculative`
{enabled, draft_model, block_k}, and if opted in, builds the draft engine (its
own `ShardManager` per §4) and hands it to the primary's `build_engine(...,
draft_streamer=…, speculative_block_k=…)` so generation routes through
`speculative_generate`. The draft is registered under a `draft` role in
`STATE["engines"]`. Saving the speculative settings re-wires live in a
background thread (`_rewire_speculative()` rebuilds/tears down the draft and
re-wraps the primary's `infer_fn` without re-streaming the primary), so the
toggle takes effect without a model reload. Every step is guarded: a draft
failure logs and falls back to single-model; a failed/restored primary load
clears the draft. infer_fn construction is shared via
`make_primary_infer_fn()` so build-time and live-apply derive defaults
identically.

**This is the piece that could not be exercised in the build sandbox** (no
torch, no models). It compiles and is gated (off ⇒ untouched), but the draft
build, the hybrid snapshot/restore under real weights, and losslessness must be
validated on the target rig.

## Remaining on-rig glue (model-dependent, intentionally not done here)

- **Channel A secondary routing load.** A second *verifier-class* model loaded
  under a non-`primary` role for stage routing (distinct from the SD draft,
  which is wired above). Seams in place: `EngineRegistry.set(role, entry)`,
  `registry.secondary_model`, and the per-stage `model` field.
- **Multimodal stage guard (§8.5).** Static validation + runtime guard that an
  image-source stage only targets a `multimodal:true` engine. Entries already
  carry the `multimodal` flag; the check belongs where secondary engines become
  loadable.
- **On-rig validation** of off-path tok/s parity, SD losslessness, and α.

## Files changed

Moved:
- `tools/spec_decode_bench.py` → `tests/spec_decode_bench.py` — the
  acceptance-rate bench is a standalone verification script the application
  never imports or calls; `tools/` is for inference-time tool modules, so it
  belongs alongside the other `tests/` checks. Contents unchanged; its repo
  bootstrap (`__file__.parent.parent`) resolves identically at the new depth.

New:
- `src/engine/registry.py`
- `src/engine/speculative.py`
- `tests/_probe_util.py` (shared probe harness)
- `tests/probe_partition.py`, `tests/probe_registry.py`, `tests/probe_routing.py`

Edited (additive only):
- `src/engine/sizing.py` — `partition_resident_budget()` + `DEFAULT_PRIMARY_MIN_CAP`
- `src/engine/kv_cache.py` — `truncate()`, `kv_lengths()`
- `src/engine/streamer.py` — `forward(all_positions=…)`, `snapshot_state()/restore_state()`
- `src/engine/hybrid_streamer.py` — same, incl. recurrent/conv snapshot/restore
- `src/engine/inference.py` — `make_infer_fn`/`build_engine` optional draft params + SD routing
- `src/engine/worker.py` — `run_worker(infer_fns=…)` threaded into both `run_pipeline` calls
- `src/pipeline.py` — `select_stage_infer_fn()`, `run_pipeline(infer_fns=…)`
- `src/template.py` — `StageConfig.model` (parse + conditional emit)
- `src/server.py` — `speculative`/`registry` config defaults, deep-merge for
  nested blocks, `STATE["engines"]` + `_sync_primary_engine()`, routing map at
  the `run_worker` call
- `static/dashboard.html` — off-by-default Speculative Decoding section in the
  Settings drawer, with a family-constrained draft-model picker
- `static/template_builder.html` — per-step Model (override) field

## Cold verification run here

`python -m py_compile` passes on every touched/new module.
`tests/probe_partition.py`, `tests/probe_registry.py`, `tests/probe_routing.py`
run green under plain `python3` (no torch needed) — see those files for the
exact assertions.
