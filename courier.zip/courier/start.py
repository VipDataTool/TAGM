#!/usr/bin/env python3
"""
Courier - start.py

Cross-platform launcher (Windows-first). Mirrors start.sh: checks the
environment, resolves/downloads/verifies a model, then starts the FastAPI
server via uvicorn. Safe to run repeatedly.

If launched under a Python that torch has no wheel for (e.g. 3.14), it
automatically re-launches under a supported one (3.10-3.13, preferring 3.12).

Usage:
    python start.py                 # start server on COURIER_PORT (default 8000)
    python start.py --port 9000     # override port
    python start.py --test          # run the test suite first, then start
    python start.py --skip-verify   # skip model verification
    python start.py --no-serve      # do pre-flight only, don't start the server
"""
from __future__ import annotations

import argparse
import importlib
import json
import os
import shutil
import subprocess
import sys
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent          # repo root (where this file lives)
SCRIPT = Path(__file__).resolve()               # this file, for re-launching
PY = sys.executable                             # the interpreter running us
PID_FILE = ROOT / "courier.pid"                 # daemon-mode pidfile
LOG_FILE = ROOT / "logs" / "courier.log"        # daemon-mode log

# Python versions torch ships wheels for. 3.14 has no torch build yet, which is
# why importing torch under it dies with a c10.dll WinError 1114. Stay in range.
PY_MIN = (3, 10)
PY_MAX = (3, 13)
PREFERRED = ["3.12", "3.13", "3.11", "3.10"]     # 3.12 first: the validated target

# Packages the server needs at runtime: (pip name, import name)
REQUIRED = [
    ("torch", "torch"), ("safetensors", "safetensors"),
    ("transformers", "transformers"), ("fastapi", "fastapi"),
    ("uvicorn", "uvicorn"), ("psutil", "psutil"), ("pillow", "PIL"),
    # Server-mode deps the original list missed: FastAPI refuses to START
    # if an upload endpoint exists without python-multipart, so check_deps
    # could pass and serve() still die. aiofiles/cryptography likewise.
    ("python-multipart", "multipart"), ("aiofiles", "aiofiles"),
    ("cryptography", "cryptography"),
]

# dir-name -> HuggingFace repo id, for re-download on a failed verify
HF_IDS = {
    "Qwen3-0.6B": "Qwen/Qwen3-0.6B",
    "Qwen3.5-0.8B": "Qwen/Qwen3.5-0.8B",
    "Qwen3.5-2B": "Qwen/Qwen3.5-2B",
    "Qwen3.5-4B": "Qwen/Qwen3.5-4B",
    "Llama-3.2-1B-Instruct": "meta-llama/Llama-3.2-1B-Instruct",
    "Llama-3.2-3B-Instruct": "meta-llama/Llama-3.2-3B-Instruct",
}
BOOTSTRAP_MODEL = "Qwen3-0.6B"                   # downloaded if nothing is on disk


# ── colored logging (ANSI, auto-disabled when not a real console) ────────────
def _enable_ansi() -> bool:
    if not sys.stdout.isatty():
        return False
    if os.name != "nt":
        return True
    try:  # turn on virtual-terminal processing on modern Windows consoles
        import ctypes
        k = ctypes.windll.kernel32
        h = k.GetStdHandle(-11)
        import ctypes as c
        mode = c.c_uint32()
        if not k.GetConsoleMode(h, c.byref(mode)):
            return False
        k.SetConsoleMode(h, mode.value | 0x0004)  # ENABLE_VIRTUAL_TERMINAL_PROCESSING
        return True
    except Exception:
        return False


_COLOR = _enable_ansi()


def _c(code: str, s: str) -> str:
    return f"\033[{code}m{s}\033[0m" if _COLOR else s


def log(m: str) -> None:  print(f"{_c('0;32', '[courier]')} {m}")
def warn(m: str) -> None: print(f"{_c('0;33', '[courier]')} {m}")
def err(m: str) -> None:  print(f"{_c('0;31', '[courier]')} {m}")
def dim(m: str) -> None:  print(_c('0;90', f'[courier] {m}'))


def run(cmd: list[str]) -> int:
    """Run a child process under the same interpreter; return its exit code."""
    return subprocess.run(cmd, cwd=ROOT).returncode


def run_capture(cmd: list[str]) -> tuple[int, str]:
    p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    return p.returncode, (p.stdout or "") + (p.stderr or "")


# ── interpreter guard: make sure we run under a torch-capable Python ─────────
def _torch_ok(interp: str) -> bool:
    """True if `interp` can import torch cleanly."""
    code, _ = run_capture([interp, "-c", "import torch"])
    return code == 0


def _find_interpreter() -> str | None:
    """Locate a supported Python (prefer one where torch already imports)."""
    found: dict[str, str] = {}        # "3.12" -> full path to its python
    for ver in PREFERRED:
        if os.name == "nt":
            launcher = shutil.which("py")
            if not launcher:
                break
            code, out = run_capture([launcher, f"-{ver}", "-c",
                                     "import sys; print(sys.executable)"])
            path = out.strip().splitlines()[-1] if (code == 0 and out.strip()) else ""
        else:
            path = shutil.which(f"python{ver}") or ""
        if path and Path(path).exists():
            found[ver] = path
    if not found:
        return None
    # prefer (in PREFERRED order) one whose torch already works...
    for ver in PREFERRED:
        if ver in found and _torch_ok(found[ver]):
            return found[ver]
    # ...otherwise the most-preferred that simply exists (deps install later)
    for ver in PREFERRED:
        if ver in found:
            return found[ver]
    return None


def ensure_supported_interpreter(argv: list[str]) -> None:
    """If running under an unsupported Python (e.g. 3.14), re-launch under a
    supported one. A guard env var prevents an infinite relaunch loop."""
    v = sys.version_info[:2]
    if os.environ.get("COURIER_REEXEC") == "1":
        return                                   # already relaunched once
    if PY_MIN <= v <= PY_MAX:
        return                                   # this interpreter is fine
    warn(f"Running under Python {v[0]}.{v[1]} — torch has no build for it.")
    interp = _find_interpreter()
    if not interp:
        err("  No supported Python (3.10-3.13) found on this system.")
        err("  Install Python 3.12 from python.org, then re-run:")
        dim("      py -3.12 start.py")
        sys.exit(1)
    log(f"  Re-launching under {interp}")
    env = {**os.environ, "COURIER_REEXEC": "1"}
    try:
        sys.exit(subprocess.run([interp, str(SCRIPT), *argv], env=env, cwd=ROOT).returncode)
    except KeyboardInterrupt:
        sys.exit(0)


# ── pre-flight steps ─────────────────────────────────────────────────────────
def clear_pycache() -> None:
    for p in ROOT.rglob("__pycache__"):
        shutil.rmtree(p, ignore_errors=True)


def check_python() -> None:
    v = sys.version_info
    log(f"Python {v.major}.{v.minor}.{v.micro}")
    if v < (3, 10):
        err("Python 3.10+ required.")
        sys.exit(1)


def check_deps() -> None:
    log("Checking dependencies...")
    missing, broken = [], []
    for pip_name, import_name in REQUIRED:
        try:
            importlib.import_module(import_name)
        except ImportError:
            missing.append(pip_name)
        except Exception:
            broken.append(pip_name)
            traceback.print_exc()
    if broken:
        err(f"  Installed but failing to import: {', '.join(broken)}")
        if "torch" in broken:
            v = sys.version_info
            err(f"  torch is failing to load under Python {v.major}.{v.minor}.")
            dim("    Likely a Python/arch mismatch or a missing Microsoft VC++ runtime.")
            dim("    Reinstall torch for THIS interpreter, or run under 3.12:")
            dim("        py -3.12 -m pip install -r requirements.txt")
            dim("        py -3.12 start.py")
        else:
            err("  See tracebacks above. A reinstall may not fix this.")
        sys.exit(1)
    if missing:
        warn(f"  Missing: {', '.join(missing)}")
        log("Installing from requirements.txt...")
        if run([PY, "-m", "pip", "install", "-r", "requirements.txt", "--quiet"]) != 0:
            err("  pip install failed.")
            sys.exit(1)
        log("  Dependencies installed.")
    else:
        log("  All dependencies present.")


def resolve_model() -> Path | None:
    """config.default_model -> any ready model on disk -> None."""
    models = ROOT / "models"
    cfg = ROOT / "courier_config.json"
    default = ""
    if cfg.exists():
        try:
            default = json.loads(cfg.read_text(encoding="utf-8")).get("default_model", "")
        except Exception:
            pass
    if default and (models / default / "config.json").exists():
        return models / default
    if models.exists():
        for d in sorted(models.glob("*")):
            ready = (d / "config.json").exists() and (
                any(d.glob("*.safetensors")) or any(d.glob("*.gguf"))
            )
            if ready:
                return d
    return None


def ensure_model() -> Path:
    model = resolve_model()
    if model is None:
        warn("No model found on disk.")
        log(f"Downloading {BOOTSTRAP_MODEL} (~1.5 GB)...")
        run([PY, "scripts/download_model.py"])
        model = ROOT / "models" / BOOTSTRAP_MODEL
    else:
        log(f"Model: {model.name}")
    return model


def verify_model(model: Path) -> None:
    log("Verifying model...")
    code, out = run_capture([PY, "scripts/verify_model.py", str(model)])
    if "VERIFICATION PASSED" in out:
        log("  Model verified.")
        return
    warn("  Model verification failed.")
    hf = HF_IDS.get(model.name)
    if hf:
        warn("  Re-downloading...")
        run([PY, "scripts/download_model.py", "--model", hf, "--dest", str(model)])
        code, out = run_capture([PY, "scripts/verify_model.py", str(model)])
        if "VERIFICATION PASSED" in out:
            log("  Model verified.")
            return
    else:
        warn(f"  Unknown model '{model.name}' - cannot re-download.")
    warn("  Server will attempt to load anyway.")


def run_tests() -> None:
    log("Running tests...")
    # NOTE: tests/probe_*.py inject a stub `torch` into sys.modules at import
    # time. When pytest collects them it clobbers the real torch for the rest of
    # the session, breaking unrelated tests. They are standalone scripts, not
    # pytest tests, so exclude them here.
    code = run([
        PY, "-m", "pytest", "tests/", "-q", "--tb=short",
        "--ignore-glob=tests/probe_*.py",
        "--ignore-glob=tests/*bench*.py",
        "--ignore=tests/profile_cycle.py",
    ])
    (log if code == 0 else warn)(
        "  Tests passed." if code == 0 else "  Some tests failed - see output above."
    )


def banner() -> None:
    b = _c("1;33", "")
    print()
    print(_c("1;33", "  +=======================================+"))
    print(_c("1;33", "  |         COURIER v0.2.7                |"))
    print(_c("1;33", "  |   Edge Inference Framework            |"))
    print(_c("1;33", "  +=======================================+"))
    print()


def _server_env() -> dict:
    """Env for the uvicorn subprocess with CPU thread pools sized to physical
    cores (see the comment in serve()); COURIER_THREADS and pre-existing
    OMP/MKL settings win."""
    env = os.environ.copy()
    threads = env.get("COURIER_THREADS", "").strip()
    if not threads:
        try:
            import psutil
            threads = str(psutil.cpu_count(logical=False) or "")
        except Exception:
            threads = ""
    if threads:
        env.setdefault("OMP_NUM_THREADS", threads)
        env.setdefault("MKL_NUM_THREADS", threads)
        dim(f"  Threads:    {env['OMP_NUM_THREADS']} "
            f"(physical cores; set COURIER_THREADS to override)")
    return env


# ── daemon helpers ───────────────────────────────────────────────────────────
def _pid_alive(pid: int) -> bool:
    try:
        import psutil
        try:
            return psutil.Process(pid).status() != psutil.STATUS_ZOMBIE
        except psutil.NoSuchProcess:
            return False
    except Exception:
        if os.name == "nt":
            return False  # without psutil we can't probe on Windows; assume gone
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False


def _daemon_pid() -> int | None:
    """PID from the pidfile, if that process is still alive."""
    try:
        pid = int(PID_FILE.read_text().strip())
    except Exception:
        return None
    return pid if _pid_alive(pid) else None


def daemon_status() -> int:
    pid = _daemon_pid()
    if pid:
        log(f"Courier daemon running (pid {pid}).")
        dim(f"  Log: {LOG_FILE}")
        return 0
    warn("Courier daemon not running.")
    return 1


def daemon_stop() -> int:
    import time
    pid = _daemon_pid()
    if not pid:
        PID_FILE.unlink(missing_ok=True)
        warn("No running Courier daemon found.")
        return 0
    log(f"Stopping Courier (pid {pid})...")
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                           capture_output=True)
        else:
            os.kill(pid, 15)  # SIGTERM: uvicorn shuts down cleanly
            for _ in range(20):
                if not _pid_alive(pid):
                    break
                time.sleep(0.5)
            if _pid_alive(pid):
                warn("  Still running after 10s; sending SIGKILL.")
                os.kill(pid, 9)
    except OSError as e:
        warn(f"  {e}")
    PID_FILE.unlink(missing_ok=True)
    log("  Stopped.")
    return 0


def serve_daemon(port: int, env: dict) -> int:
    """Start uvicorn fully detached from this terminal: its own session
    (POSIX) / detached process group (Windows), stdio pointed at a logfile.
    Closing the terminal, tab, or SSH/Codespaces connection that launched it
    can then never signal it — this is the mode that makes headless real."""
    existing = _daemon_pid()
    if existing:
        warn(f"Courier daemon already running (pid {existing}). "
             f"Use 'python start.py --stop' first.")
        return 1
    log(f"Starting Courier daemon on port {port}...")
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        PY, "-m", "uvicorn", "src.server:app",
        "--host", "0.0.0.0", "--port", str(port),
        "--log-level", "error", "--app-dir", ".",
    ]
    logf = open(LOG_FILE, "ab")
    kwargs: dict = {"cwd": ROOT, "env": env, "stdin": subprocess.DEVNULL,
                    "stdout": logf, "stderr": logf}
    if os.name == "nt":
        # New process group + detached: survives this console closing.
        kwargs["creationflags"] = (subprocess.DETACHED_PROCESS
                                   | subprocess.CREATE_NEW_PROCESS_GROUP)
    else:
        kwargs["start_new_session"] = True  # setsid(): out of this pty's reach
    proc = subprocess.Popen(cmd, **kwargs)
    PID_FILE.write_text(str(proc.pid))
    import time
    time.sleep(2)
    if _pid_alive(proc.pid):
        log(f"  Daemon running (pid {proc.pid}).")
        dim(f"  Dashboard:  http://localhost:{port}/")
        dim(f"  Log:        {LOG_FILE}")
        dim("  Stop with:  python start.py --stop")
        return 0
    err("  Daemon exited immediately. Check the log:")
    dim(f"    {LOG_FILE}")
    PID_FILE.unlink(missing_ok=True)
    return 1


def serve(port: int) -> int:
    print()
    existing = _daemon_pid()
    if existing:
        # Same guard the daemon path has: a raw bind error AFTER printing
        # the dashboard URL misleads; say what's true instead.
        warn(f"Courier is already running (pid {existing}) and holding port {port}.")
        warn(f"It's serving now at http://localhost:{port}/ — or 'python start.py --stop' first.")
        sys.exit(1)
    log(f"Starting Courier server on port {port}...")
    dim(f"  Dashboard:  http://localhost:{port}/")
    dim(f"  API:        http://localhost:{port}/api/status")
    dim("  Press Ctrl+C to stop.")
    print()
    cmd = [
        PY, "-m", "uvicorn", "src.server:app",
        "--host", "0.0.0.0", "--port", str(port),
        "--log-level", "error", "--app-dir", ".",
    ]
    # ── CPU thread sizing for the server process ─────────────────────────
    # Torch (and numpy's BLAS) size their pools from the LOGICAL CPU count
    # at import. Inference GEMM on CPU is memory-bandwidth-bound, so threads
    # beyond the PHYSICAL core count buy nothing on hyperthreaded machines
    # and add scheduling noise the CpuBrake then has to fight. Seed the
    # subprocess env with physical cores; an operator-set COURIER_THREADS
    # wins, and any pre-existing OMP/MKL setting is respected (setdefault).
    # build_engine() applies the same policy in-process for non-server
    # entry points — this env path exists so the pools are sized correctly
    # from torch import time, before build_engine runs.
    env = _server_env()
    try:
        return subprocess.run(cmd, cwd=ROOT, env=env).returncode
    except KeyboardInterrupt:
        print()
        log("Stopped.")
        return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="Start the Courier server.")
    ap.add_argument("-t", "--test", action="store_true", help="run the test suite first")
    ap.add_argument("--port", type=int, default=int(os.environ.get("COURIER_PORT", "8000")))
    ap.add_argument("--skip-verify", action="store_true", help="skip model verification")
    ap.add_argument("--no-serve", action="store_true", help="pre-flight only; don't start the server")
    ap.add_argument("-d", "--daemon", action="store_true",
                    help="run detached: survives closed terminals/tabs/SSH sessions")
    ap.add_argument("--stop", action="store_true", help="stop a daemonized server")
    ap.add_argument("--status", action="store_true", help="check the daemonized server")
    args = ap.parse_args()

    os.chdir(ROOT)

    if args.stop:
        return daemon_stop()
    if args.status:
        return daemon_status()
    try:
        sys.stdout.reconfigure(encoding="utf-8")  # tidy output on Windows consoles
    except Exception:
        pass

    # If we're on an unsupported Python (e.g. 3.14, no torch wheel), relaunch
    # under a supported one before doing any real work.
    ensure_supported_interpreter(sys.argv[1:])

    banner()
    clear_pycache()
    check_python()
    check_deps()
    model = ensure_model()
    if not args.skip_verify:
        verify_model(model)
    if args.test:
        run_tests()
    if args.no_serve:
        log("Pre-flight complete (--no-serve).")
        return 0
    if args.daemon:
        return serve_daemon(args.port, _server_env())
    return serve(args.port)


if __name__ == "__main__":
    sys.exit(main())
