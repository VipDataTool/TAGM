"""GGUF vs safetensors layout forensics for Courier.

Loads the SAME model from a safetensors directory and an F16 GGUF file,
compares every tensor role, and for mismatches identifies WHAT transform
relates them (row permutation, llama Q/K permute, transpose, or
within-row scrambling). Use an F16 GGUF so there is no quantization
confound — F16->F32 conversion is deterministic, so matching layouts
mean bit-identical tensors.

Usage (from the courier repo root, venv with torch active):

    python tools/gguf_diff_harness.py \
        --safetensors models/Qwen3-0.6B \
        --gguf models/qwen3-0.6b-f16.gguf \
        --layers 0 1

Reads layers' role dicts through BOTH shard managers via the same
adapter, so it exercises the exact code path inference uses (name map
included). Exit code 0 = layouts identical; 1 = mismatches found.

Interpreting output:
    IDENTICAL          - this role is byte-equal; layout fine.
    ROW-PERMUTED       - same rows, different order; mapping summarized.
                         If 'llama-permute' is reported, the standard
                         convert_hf_to_gguf Q/K permutation explains it
                         and inverse_llama_permute() is your fix.
    TRANSPOSED         - stored transposed; fix is a .T at load.
    SCRAMBLED          - rows don't match as units; element order inside
                         rows differs (fused-projection interleaving).
                         The harness then tries to match SUB-row chunks
                         to recover the interleave pattern.
"""

import argparse
import sys
from pathlib import Path

import numpy as np
import torch

# Allow running from repo root
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from core.adapter.registry import detect_adapter, ADAPTERS  # noqa: E402
from core.shard_manager import ShardManager              # noqa: E402
from core.gguf_shard_manager import GGUFShardManager     # noqa: E402


# ── The known llama.cpp Q/K permutation ──────────────────────
# One source of truth: the loader (via the llama3 adapter\'s
# gguf_load_transforms) and this harness use the SAME functions, so the
# harness can never "confirm" math the loader doesn\'t actually run.
from core.gguf_layout import llama_permute, inverse_llama_permute  # noqa: E402


# ── Diagnostics ──────────────────────────────────────────────

def row_hash_map(t: torch.Tensor) -> dict:
    """Map row-bytes -> list of row indices (handles duplicate rows)."""
    m: dict[bytes, list[int]] = {}
    arr = t.detach().cpu().numpy()
    for i in range(arr.shape[0]):
        m.setdefault(arr[i].tobytes(), []).append(i)
    return m


def summarize_mapping(perm: list[int]) -> str:
    """Human summary of a row mapping gguf_row -> hf_row."""
    n = len(perm)
    head = ", ".join(str(p) for p in perm[: min(16, n)])
    # Detect simple block structure: constant stride runs
    strides = {perm[i + 1] - perm[i] for i in range(min(64, n - 1))}
    return f"first rows map to HF rows [{head}...], strides seen {sorted(strides)[:8]}"


def diagnose_pair(name: str, hf: torch.Tensor, gg: torch.Tensor,
                  n_head: int | None) -> str:
    """Return one of IDENTICAL / ROW-PERMUTED / TRANSPOSED / SCRAMBLED /
    SHAPE-MISMATCH with detail."""
    if hf.shape != gg.shape:
        if hf.ndim == 2 and gg.ndim == 2 and hf.shape == gg.shape[::-1] \
                and torch.equal(hf, gg.T):
            return "TRANSPOSED (gguf stores the transpose; fix: .T at load)"
        return f"SHAPE-MISMATCH hf={tuple(hf.shape)} gguf={tuple(gg.shape)}"

    if torch.equal(hf, gg):
        return "IDENTICAL"

    # Value-equality gate, BEFORE any layout forensics. When the HF
    # checkpoint is BF16 and the GGUF is F16 (the common community-quant
    # case: Meta ships BF16, converters store F16), tiny weights below
    # F16's normal range round during conversion — elementwise diffs of
    # O(1e-8) on otherwise identical tensors. That is a storage-rounding
    # artifact, not a layout problem: a real permutation/scramble puts
    # DIFFERENT weights at each position, giving diffs of O(weight
    # magnitude). The exact-hash row matching below cannot see this
    # distinction (any rounded element defeats the hash), so without
    # this gate epsilon noise falls through to the scariest verdict.
    # Norms are stored F32 in GGUF, which is why they still say
    # IDENTICAL while every F16 tensor of a BF16-sourced model doesn't.
    _VALUE_ATOL = 1e-6  # >> f16-subnormal rounding (~3e-8), << any real weight
    mx = (hf - gg).abs().max().item()
    if mx <= _VALUE_ATOL:
        return (f"MATCH (values equal within float-storage rounding, "
                f"max|diff|={mx:.3e}; bit-inequality is the bf16→f16 "
                f"conversion, not layout)")

    if hf.ndim != 2:
        mx = (hf - gg).abs().max().item()
        return f"MISMATCH (non-2D), max|diff|={mx:.3e}"

    # llama-permute hypothesis (only meaningful for q/k projections).
    # allclose, not equal: on a BF16-sourced model the permuted rows
    # carry the same storage rounding as everything else, and exact
    # equality would blind this check to the exact bug it exists for.
    if n_head is not None and hf.shape[0] % n_head == 0:
        if torch.allclose(inverse_llama_permute(gg, n_head), hf,
                          atol=_VALUE_ATOL, rtol=0.0):
            return ("ROW-PERMUTED: llama-permute — apply "
                    "inverse_llama_permute() at load to fix")

    # General row-permutation recovery via exact row matching
    hf_map = row_hash_map(hf)
    perm, unmatched = [], 0
    gg_np = gg.detach().cpu().numpy()
    for i in range(gg_np.shape[0]):
        cands = hf_map.get(gg_np[i].tobytes())
        if cands:
            perm.append(cands[0])
        else:
            unmatched += 1
            perm.append(-1)
    if unmatched == 0:
        return f"ROW-PERMUTED: {summarize_mapping(perm)}"

    # Rows don't match as units -> within-row scrambling (fused interleave).
    # Try sub-row chunk matching at a few plausible granularities to expose
    # the interleave (e.g. per-head q/gate or qkvz packing).
    for chunk in (256, 128, 64):
        if hf.shape[1] % chunk:
            continue
        hf_c = hf.reshape(-1, chunk)
        gg_c = gg.reshape(-1, chunk)
        cmap = row_hash_map(hf_c)
        hits = sum(1 for i in range(gg_c.shape[0])
                   if gg_c[i].numpy().tobytes() in cmap)
        if hits == gg_c.shape[0]:
            return (f"SCRAMBLED-WITHIN-ROWS but all {chunk}-wide chunks match "
                    f"-> a chunk-level interleave; rerun with --dump-perm "
                    f"{name} to print the full chunk mapping")
    mx = (hf - gg).abs().max().item()
    return (f"SCRAMBLED: {unmatched}/{gg.shape[0]} rows unmatched and no "
            f"chunk granularity explains it; max|diff|={mx:.3e} — values may "
            f"genuinely differ (wrong tensor mapped?)")


# ── Main ─────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--safetensors", required=True)
    ap.add_argument("--gguf", required=True)
    ap.add_argument("--adapter", default=None,
                    help="adapter name for registry; default: autodetect "
                         "from the safetensors config")
    ap.add_argument("--layers", type=int, nargs="*", default=[0])
    args = ap.parse_args()

    adapter = detect_adapter(args.safetensors) if args.adapter is None \
        else ADAPTERS[args.adapter](Path(args.safetensors))
    n_head = getattr(adapter.config, "num_attention_heads", None)

    st = ShardManager(args.safetensors, adapter)
    gg = GGUFShardManager(args.gguf, adapter)

    failures = 0

    def compare(name, a, b):
        nonlocal failures
        verdict = diagnose_pair(name, a.float(), b.float(), n_head_for(name))
        # Two pass flavors: bit-identical, and value-identical within
        # float-storage rounding (see the gate in diagnose_pair).
        ok = verdict == "IDENTICAL" or verdict.startswith("MATCH")
        flag = "  " if ok else "**"
        print(f"{flag} {name:42s} {verdict}")
        if not ok:
            failures += 1

    def n_head_for(name):
        return n_head if ("q_proj" in name or "k_proj" in name) else None

    print(f"Model: {args.safetensors}  vs  {args.gguf}")
    print(f"Adapter: {type(adapter).__name__}, n_head={n_head}\n")

    compare("embedding", st.load_embedding(torch.float32),
            gg.load_embedding(torch.float32))
    compare("final_norm", st.load_final_norm(torch.float32),
            gg.load_final_norm(torch.float32))
    st_head, gg_head = st.load_lm_head(torch.float32), gg.load_lm_head(torch.float32)
    if (st_head is None) != (gg_head is None):
        print(f"** lm_head: present in one format only "
              f"(safetensors={st_head is not None}, gguf={gg_head is not None}) "
              f"— tied-embedding handling differs")
        failures += 1
    elif st_head is not None:
        compare("lm_head", st_head, gg_head)

    for li in args.layers:
        wa = st.load_layer(li, torch.float32)
        wb = gg.load_layer(li, torch.float32)
        roles = sorted(set(wa) | set(wb))
        for role in roles:
            if role not in wa or role not in wb:
                print(f"** layer{li}.{role:34s} MISSING in "
                      f"{'gguf' if role in wa else 'safetensors'} path "
                      f"(name-map gap — this is the silent-skip bug surface)")
                failures += 1
                continue
            compare(f"layer{li}.{role}", wa[role], wb[role])

    print(f"\n{'LAYOUTS AGREE (bit-identical or within float-storage rounding) — the GGUF bug, if any, is elsewhere' if failures == 0 else str(failures) + ' mismatching roles — see verdicts above'}")
    sys.exit(0 if failures else 1)


if __name__ == "__main__":
    main()
