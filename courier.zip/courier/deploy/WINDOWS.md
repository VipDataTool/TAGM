# Courier as a Windows service

For field units running Windows (Toughbooks often do), the goal is the same
as the Linux systemd unit: **power on → Courier running**, no login, no
terminal, restart after crashes. Two good ways to get there.

## Option A — NSSM (recommended: real service, auto-restart)

[NSSM](https://nssm.cc) ("Non-Sucking Service Manager") wraps any program as
a proper Windows service with restart-on-failure.

1. Download `nssm.exe` and put it somewhere permanent, e.g. `C:\Tools\nssm.exe`.
2. In an **Administrator** PowerShell, from the Courier repo directory:

```powershell
C:\Tools\nssm.exe install Courier "C:\Path\To\Python312\python.exe" "start.py"
C:\Tools\nssm.exe set Courier AppDirectory  "C:\Path\To\courier"
C:\Tools\nssm.exe set Courier AppStdout     "C:\Path\To\courier\logs\courier.log"
C:\Tools\nssm.exe set Courier AppStderr     "C:\Path\To\courier\logs\courier.log"
C:\Tools\nssm.exe set Courier AppRotateFiles 1
C:\Tools\nssm.exe set Courier AppRotateBytes 10485760   # rotate at 10 MB
# Crash-loop guard: wait 15s before restarting a crashed Courier
C:\Tools\nssm.exe set Courier AppRestartDelay 15000
C:\Tools\nssm.exe start Courier
```

Manage it like any service: `services.msc`, or
`nssm start|stop|restart|status Courier`. It starts automatically on boot.

## Option B — Task Scheduler (no third-party tool)

Built into Windows; starts Courier at boot but does **not** restart it after
a crash (Courier's own checkpoint recovery still handles resume when the
task next runs).

In an Administrator PowerShell:

```powershell
$action  = New-ScheduledTaskAction -Execute "C:\Path\To\Python312\python.exe" `
           -Argument "start.py" -WorkingDirectory "C:\Path\To\courier"
$trigger = New-ScheduledTaskTrigger -AtStartup
$settings = New-ScheduledTaskSettingsSet -RestartCount 5 `
           -RestartInterval (New-TimeSpan -Minutes 1) `
           -ExecutionTimeLimit (New-TimeSpan -Days 3650)
Register-ScheduledTask -TaskName "Courier" -Action $action -Trigger $trigger `
           -Settings $settings -User "SYSTEM" -RunLevel Highest
```

(`-RestartCount/-RestartInterval` give limited crash recovery; NSSM's is
more robust.)

## Notes for both

- Point `-Execute` at the Python 3.10–3.13 interpreter that has Courier's
  dependencies installed (`start.py` will relaunch itself under a supported
  one if it can, but a service should start in the right place).
- Put `HF_TOKEN` in the repo's `.env` file — it's loaded at startup, so the
  service needs no environment configuration.
- The dashboard is at `http://localhost:8000/` on the unit itself; remote
  access follows the same rules as always (see README → Security &
  Networking).
