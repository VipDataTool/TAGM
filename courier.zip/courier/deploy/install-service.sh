#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════
# Courier — install-service.sh
#
# Installs Courier as a systemd service that starts on boot and
# restarts after crashes. Run from anywhere:
#
#   sudo bash deploy/install-service.sh                 # defaults
#   sudo bash deploy/install-service.sh --user pat --port 9000
#   sudo bash deploy/install-service.sh --uninstall
#
# Defaults: the repo this script lives in, the user who invoked
# sudo (not root), port 8000 (or COURIER_PORT if set).
# Safe to re-run: re-installs the unit and restarts the service.
# ═══════════════════════════════════════════════════════════════
set -euo pipefail

GREEN='\033[0;32m'; AMBER='\033[0;33m'; RED='\033[0;31m'; DIM='\033[0;90m'; NC='\033[0m'
log()  { echo -e "${GREEN}[courier]${NC} $1"; }
warn() { echo -e "${AMBER}[courier]${NC} $1"; }
err()  { echo -e "${RED}[courier]${NC} $1"; }
dim()  { echo -e "${DIM}$1${NC}"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
COURIER_DIR="$(dirname "$SCRIPT_DIR")"
UNIT_NAME="courier.service"
UNIT_DEST="/etc/systemd/system/${UNIT_NAME}"

# Help works without root.
for a in "$@"; do
    if [ "$a" = "-h" ] || [ "$a" = "--help" ]; then
        sed -n '2,15p' "$0"; exit 0
    fi
done

# ── Preconditions ────────────────────────────────────────────
if ! command -v systemctl &> /dev/null; then
    err "systemd not found on this system."
    dim "  For non-systemd setups see deploy/WINDOWS.md (Windows) or use"
    dim "  tmux/cron @reboot as a fallback."
    exit 1
fi
if [ "$(id -u)" -ne 0 ]; then
    err "This installer writes to /etc/systemd/system — run it with sudo:"
    dim "  sudo bash deploy/install-service.sh"
    exit 1
fi

# ── Args ─────────────────────────────────────────────────────
COURIER_USER="${SUDO_USER:-root}"
COURIER_PORT="${COURIER_PORT:-8000}"
UNINSTALL=0
while [ $# -gt 0 ]; do
    case "$1" in
        --user)  COURIER_USER="$2"; shift 2 ;;
        --port)  COURIER_PORT="$2"; shift 2 ;;
        --uninstall) UNINSTALL=1; shift ;;
        -h|--help)
            sed -n '2,15p' "$0"; exit 0 ;;
        *) err "Unknown option: $1"; exit 1 ;;
    esac
done

# ── Uninstall ────────────────────────────────────────────────
if [ "$UNINSTALL" = "1" ]; then
    log "Uninstalling ${UNIT_NAME}..."
    systemctl stop "$UNIT_NAME" 2>/dev/null || true
    systemctl disable "$UNIT_NAME" 2>/dev/null || true
    rm -f "$UNIT_DEST"
    systemctl daemon-reload
    log "  Removed. Courier itself is untouched at $COURIER_DIR"
    exit 0
fi

# ── Sanity checks ────────────────────────────────────────────
if ! id "$COURIER_USER" &> /dev/null; then
    err "User '$COURIER_USER' does not exist. Pass one with --user."
    exit 1
fi
if [ "$COURIER_USER" = "root" ]; then
    warn "Installing to run as root. Prefer a normal user: --user <name>"
fi
if [ ! -f "$COURIER_DIR/start.sh" ]; then
    err "start.sh not found in $COURIER_DIR — is deploy/ inside the Courier repo?"
    exit 1
fi
# The service user must be able to read AND write the repo (DB, exports, logs).
_check_writable() {
    # Try the tools this box actually has; skip the check (with a warning)
    # rather than fail the install on a minimal image.
    if command -v sudo &> /dev/null; then
        sudo -u "$COURIER_USER" test -w "$COURIER_DIR"
    elif command -v runuser &> /dev/null; then
        runuser -u "$COURIER_USER" -- test -w "$COURIER_DIR"
    elif command -v su &> /dev/null; then
        su -s /bin/sh -c "test -w '$COURIER_DIR'" "$COURIER_USER"
    else
        warn "  Cannot verify write access for '$COURIER_USER' (no sudo/runuser/su)."
        warn "  If the service fails, run: chown -R $COURIER_USER: $COURIER_DIR"
        return 0
    fi
}
if ! _check_writable; then
    err "User '$COURIER_USER' cannot write to $COURIER_DIR."
    dim "  Fix ownership first:  sudo chown -R $COURIER_USER: $COURIER_DIR"
    exit 1
fi

# ── Install ──────────────────────────────────────────────────
log "Installing ${UNIT_NAME}"
dim "  Repo:  $COURIER_DIR"
dim "  User:  $COURIER_USER"
dim "  Port:  $COURIER_PORT"

sed -e "s|@COURIER_DIR@|${COURIER_DIR}|g" \
    -e "s|@COURIER_USER@|${COURIER_USER}|g" \
    -e "s|@COURIER_PORT@|${COURIER_PORT}|g" \
    "$SCRIPT_DIR/courier.service" > "$UNIT_DEST"

systemctl daemon-reload
systemctl enable "$UNIT_NAME" >/dev/null 2>&1   # start on every boot
systemctl restart "$UNIT_NAME"                  # start (or restart) now

sleep 2
if systemctl is-active --quiet "$UNIT_NAME"; then
    log "  Service is running."
else
    warn "  Service did not report active yet (model load can take a while on"
    warn "  SATA disks). Watch it come up with:"
    dim  "      journalctl -u courier -f"
fi

echo ""
log "Done. Courier now starts on every boot and restarts after crashes."
echo ""
dim "  Cheatsheet:"
dim "    systemctl status courier      # is it running, recent log lines"
dim "    journalctl -u courier -f      # live logs (Ctrl+C to stop watching)"
dim "    journalctl -u courier -e      # jump to the end of the full log"
dim "    sudo systemctl restart courier"
dim "    sudo systemctl stop courier   # until next boot or manual start"
dim "    sudo bash deploy/install-service.sh --uninstall"
