# Courier — Throughput Program Design Spec

**Status:** Draft / proposed
**Scope:** Six methods that raise tokens/sec on the same hardware — residency policy
(PIN), quantized-byte residency (tier 2), dtype autotune, KV cache preallocation +
true append-only spill, layer prefetch, and speculative-decode pass fusion — plus one
declined avenue (iGPU) with its rationale recorded. Changes touch `src/core/`
(`gguf_shard_manager.py`), `src/engine/` (`kv_cache.py`, `streamer.py`,
`hybrid_streamer.py`, `speculative.py`, `inference.py`), and nothing else. No new
tab, no schema change, no template change. Every method is additive and gated;
streaming remains the default and the fallback.
**Audience:** Maintainer/engineer extending Courier.

---

## 1. Purpose

Courier's promise is *a slow answer beats no answer*. This program shortens the slow
answer without spending anything the promise depends on: durability, SSD wear
discipline, output fidelity, or the ability to degrade to plain streaming on a box
with less of everything.

Two reference boxes anchor the design, because they sit at opposite ends of the
bottleneck spectrum:

| | **CF-31 MK6 (field)** | **Codespace (dev)** |
|---|---|---|
| CPU | i5-7300U (Kaby Lake): 2C/4T, 15 W ULV, 3 MB cache — **AVX2 + FMA, no AVX-512** | 4 modern cores, AVX2 (likely AVX-512) |
| RAM | 32 GB DDR4 | 16 GB |
| Disk | 1 TB SATA **III** SSD (~550 MB/s ceiling, confirmed for all CF-31 marks) | network-backed volume, latency-heavy |
| OS | Windows 11 Pro | Linux |
| Regime | **disk-bound** for >RAM models; GEMM dtype decided by measurement (§5) | compute-bound small models; slow cold reads |

Beyond the two reference boxes, the fleet ambition is hardware-agnostic in every
sense — an Inspiron quad-core tower (Linux x86), a MacBook, a Raspberry Pi
(arm64), and whatever replaces them in a year. §2's principle 7 turns that from
an aspiration into rules the code must obey.

The token-time budget for a streamed model decomposes as:

```
t_token ≈ t_read(streamed bytes) + t_dequant(streamed bytes) + t_gemm + t_kv_traffic
```

Every method below attacks exactly one term, and they compound because they attack
different terms. The marquee target — 70B Q4_K_M (~42 GB) on the CF-31 — is today
~80–90 s/token of raw SATA reads alone (42 GB at ~500 MB/s effective), before
dequant and GEMM. The stack in §10 brings the estimate to tens of seconds/token. Estimates are labeled as such throughout; §12 defines the
measurement that replaces them with numbers.

---

## 2. Design principles

1. **Bitwise or bust — and say which.** Every method is classified **Class I**
   (output-identical by construction: same tensors, same math, different plumbing) or
   **Class N** (numerics-affecting: different dtype or kernel, distribution-equivalent
   but not bit-equal). Class I methods are validated by byte-identical greedy decode
   before/after on the 0.6B prototype. Class N methods are opt-in via config, never
   silently defaulted, and validated with the parity harness (`tools/gguf_diff_harness.py`
   discipline: eliminate confounds, then compare).
2. **PIN, don't juggle.** The decode loop's access pattern is a cyclic scan
   (layers 0→N−1, every token, forever). LRU under a cyclic scan yields a **0% hit
   rate** the moment budget < model — the wrap-around access always lands on the
   just-evicted entry (verified by simulation: 24/36-layer budget under LRU = 0.0%
   hits; under PIN = 65.3%). All residency in this program pins in first-touch order
   until the budget is full, then stops. No eviction, anywhere. Deterministic,
   stable, and already the (correct) behavior of `ShardManager`'s resident mode —
   this program extends that policy to the two places still running LRU:
   `GGUFShardManager._cache_put` and `KVCacheManager.write`.
3. **The budget is a cap, not a target.** Every cache honors its byte budget *and*
   a live headroom check (≥1.5 GB free, the existing psutil guard). A box with too
   little RAM degrades to streaming, never to swap — swapping thrashes the SSD the
   design exists to protect.
4. **Bytes at rest stay quantized.** RAM spent on residency buys most when it holds
   GGUF-density bytes (Q4_K ≈ 4.5 bits/weight) rather than dequantized bf16 (16) or
   fp32 (32). Dequantizing from RAM costs CPU; reading from a SATA SSD costs more.
   Where that trade could invert (two slow cores), it is measured, not assumed (§12).
5. **Append means append.** `kv_cache.py`'s docstring promises append-only disk
   writes; `torch.save` of the whole tensor per spill is not that. The KV rework
   makes the docstring true, because write volume is a first-class constraint here,
   not a footnote.
6. **One method per phase, one number per method.** Each phase lands alone, behind
   its own knob, with a before/after measurement on both reference boxes recorded in
   `MULTIMODEL_BUILD_NOTES.md` style. No compound landings; a regression must be
   attributable by construction.
7. **Portability doctrine.** The fleet is heterogeneous by design (Windows/Linux/
   macOS on x86-64; Linux/macOS on arm64), so the engine hot path obeys: stdlib +
   torch + numpy only; no OS-specific syscalls (the prefetch thread *is* the
   readahead everywhere — `posix_fadvise` never enters); every budget derived from
   psutil at runtime, never assumed; every per-node tunable (threads, dtype)
   decided by measurement at engine build, never by hardcoded platform detection.
   Rules already implicit in Courier's design — written down because the public
   release makes them promises.

---

## 3. Method A — PIN residency for the GGUF layer cache (Class I)

**Problem.** `GGUFShardManager` caches dequantized layers under LRU with budget
`COURIER_CACHE_MB` (default 0). Whenever the model exceeds the budget, principle 2's
pathology applies: 0% hits, plus eviction churn, plus the layer is re-read *and
re-dequantized* every token. The cache is inert exactly when it matters.

**Change.** `_cache_put` stops evicting: if the layer fits in remaining budget (and
headroom holds), pin it; otherwise return without storing. `_cache_get` drops
`move_to_end` (meaningless without eviction). First-touch order under a cyclic scan
is layer order, so the resident set is layers `0..C−1` — stable across the run and
across tokens.

**Effect.** Hit rate goes from 0% to C/N for any budget C < N. A model that fits
entirely keeps today's behavior (LRU never evicted in that case either). ~15-line
diff, no API change, no new knob.

---

## 4. Method B — Tier-2 quantized-byte residency (Class I)

**Problem.** Tier 1 stores dequantized tensors: on the CF-31's fp32 path (see
Method C) each resident gigabyte of Q4_K weights costs ~7 GB of RAM. 32 GB of RAM
holds ~14% of a 70B dequantized — but ~55%+ of it at GGUF density.

**Change.** A second cache in `GGUFShardManager`, budget `COURIER_QCACHE_MB`
(default 0), storing `layer_idx → {role: (hf_key, raw_bytes)}`. A tier-2 hit
dequantizes from RAM — no disk read. PIN policy, same headroom guard. **One tier
owns a layer:** on a disk miss, try tier 1 (tensors); only if tier 1 is full, try
tier 2 (bytes); if both full, the layer streams forever. No promotion, no
duplication, no churn.

**Streamed LM head.** On untied GGUF models the LM head is re-read and re-dequantized
from disk *every token* (`LayerStreamer._stream_lm_head`). A small misc byte-cache in
`get_tensor` fixes this generally: cache a tensor's raw bytes **on its second
access**. Load-once tensors (embedding, final norm — already pinned dequantized by
the engine) are touched once and never spend budget; anything re-read per token
self-identifies and gets pinned. Counted against the tier-2 budget.

**Budget math, 70B Q4_K_M (~42 GB) on the 32 GB CF-31** (illustrative split;
operator-tunable):

| Allocation | Bytes | Holds |
|---|---|---|
| OS + Python + KV + headroom | ~6 GB | — |
| Tier 1 `COURIER_CACHE_MB=2000` | 2 GB | ~2 layers dequantized (fp32) + LM head bytes |
| Tier 2 `COURIER_QCACHE_MB=22000` | 22 GB | ~52% of layers as Q4 bytes |
| Streamed per token | — | ~19 GB read instead of ~42 GB |

Disk term of §1's budget drops ~55%. The dequant term *rises* (tier-2 hits still
dequantize); §12's bench decides whether tier-2 GB on this CPU are better spent
letting the OS page cache hold raw file pages instead (open question, §11).

**Dashboard.** `cache_stats()` keeps its existing keys and adds
`ShardManager`-compatible aliases (`resident`, `resident_bytes`, `layers_cached`),
so the Monitor's residency panel — which today reads only the safetensors manager's
keys and shows GGUF models as "off" — lights up for both formats for free.

---

## 5. Method C — dtype autotune (Class N, opt-in)

**Problem.** `build_engine` defaults to bf16. PyTorch's CPU bf16 GEMM is fast only
with AVX-512-BF16/AMX; the CF-31's Kaby Lake has AVX2+FMA (better than feared) but
no AVX-512, so bf16 is upconverted rather than native — whether fp32 wins there is
a genuine measurement question, not a foregone conclusion. On arm64 nodes (Pi,
Apple Silicon) torch's bf16 support is inconsistent — which upgrades this method
from a per-box favor into the fleet's portability mechanism: every node benches
itself at engine build and picks its own dtype. One constant cannot serve the
fleet.

**Change.** `dtype: auto` in config (explicit dtypes still honored verbatim). At
engine build, time one representative GEMM (e.g. 4096×4096 @ 4096×1) per candidate
dtype {bf16, fp32}, pick the winner, log the choice and the ratio. Ten lines next to
the existing thread-sizing block in `build_engine`, same guarded/never-fatal style.

**Class N honesty.** Changing dtype changes numerics — outputs are *not* bitwise
comparable across dtypes. `auto` is therefore opt-in; the default stays bf16.
Validation is the parity discipline: greedy decode per dtype is internally
deterministic, and cross-dtype outputs are compared for semantic parity, not bytes.
RAM interaction: fp32 doubles tier-1 cost per layer — the CF-31 wants fp32 GEMM
*and* tier-2 (Method B) precisely because of this.

---

## 6. Method D — KV cache: preallocate, PIN, and truly append (Class I)

Three defects, one file (`kv_cache.py` + call sites in both streamers):

1. **O(seq²) RAM traffic.** Both streamers `torch.cat([past_k, k], dim=2)` per layer
   per token — reallocating and copying the whole cache every step. Fix: preallocate
   per-layer `(batch, heads, max_seq, head_dim)` buffers once (max_seq from the
   stage's token budget), write the new position in place, hand attention a view
   `[:, :, :seq_len, :]`. `truncate()` becomes a length-counter decrement — SD
   rollback (Method F) gets cheaper as a side effect.
2. **LRU spill under a cyclic scan.** Same pathology, same fix as Method A: when
   `max_kv_ram_layers < n_layers`, PIN layers `0..C−1` in RAM permanently; layers
   `C..N−1` live on disk permanently. Today every read is a disk miss *and* every
   write spills; after, the disk share is exactly (N−C)/N.
3. **"Append-only" that rewrites everything.** `_spill_to_disk` serializes the full
   tensor per spill, and `flush()` rewrites every resident layer at every checkpoint
   — write volume grows quadratically over a generation, on the subsystem whose
   header promises append-only behavior. For the unattended-deployment endgame
   (a solar-powered node visited yearly), this is not a slowdown but a mission
   killer: quadratic writes on consumer flash is how a year of duty ends as a
   bricked drive. Fix: store spilled KV **seq-major**
   (`(seq, heads, head_dim)` on disk) in a raw file with a tiny header; a flush
   appends only positions `[flushed_len, seq_len)` — a contiguous tail write.
   `restore()` reads the header + length. `torch.save` disappears from the hot path.

**Effect.** Decode-loop memcpy drops from O(seq²) to O(seq); checkpoint-boundary
write volume drops from O(seq) per flush to O(Δseq); spilled-KV configurations go
from unusable (every-token full-file rewrites) to viable. Wear counters
(`disk_bytes_written`) stay and now report numbers worth reading.

---

## 7. Method E — layer prefetch (Class I)

**Problem.** The loop is strictly serial: read layer *i* (SATA stall), dequantize,
GEMM, then read layer *i+1*. On the CF-31 the two dominant terms — `t_read` and
`t_dequant + t_gemm` — take turns idling.

**Change.** One background thread, prefetch depth 1. While layer *i* computes, the
thread reads (and dequantizes — both `file.read` and NumPy kernels release the GIL)
layer *i+1* **if it is non-resident**, depositing into a one-slot handoff the main
loop consumes. Resident layers are skipped — prefetch exists to hide streaming, not
to duplicate the caches. Memory cost: exactly one extra layer in flight. Ordering
comes from the engine (it knows the next index, including the wrap to layer 0 of the
next token/stage); the brake's inter-layer rest is prefetch's friend — I/O proceeds
while the CPU deliberately sleeps.

**Effect.** `t_token` moves from `t_read + t_compute` toward `max(t_read,
t_compute)` for the streamed fraction — up to 2×, and it multiplies with A/B (which
shrink the streamed fraction) and C (which shrinks `t_compute`).

**Interactions.** `set_resident_budget` live-adjust and cancellation must not race
the handoff slot: the slot is a `queue.Queue(maxsize=1)`; cancel drains it; the
thread is owned by the streamer and joined in `close()`. Single-writer discipline
matches the existing worker-thread model.

---

## 8. Method F — speculative decoding: one verifier pass per block (Class I)

**Problem.** `speculative_generate` step 4 rolls both engines back and **re-runs the
verifier over the committed tokens** to obtain next-block logits — a second full
weight-streaming pass per block. In the disk-bound regime a verifier pass costs the
same whether it carries 1 token or k, so SD currently pays 2× its floor.

**Change (full-attention verifiers only).** Two observations make the re-advance
unnecessary for `LayerStreamer`:

- KV written during the verify sweep at slot *j* is a function of the prefix
  `prompt + generated + draft[:j]`, which for every **accepted** slot equals the
  committed prefix — those KV entries are already exactly correct. Rollback is
  `truncate(base + len(generated) + accepted)` — with Method D, a counter decrement.
- The one missing piece — logits after the block's final/correction token — is
  obtained by **folding that token into the front of the next verify sweep**:
  input `[final_token, draft_1..draft_k]`, `all_positions=True`. `block_logits[0]`
  is the `v_logits` the code currently recomputes; slots shift by one; the bonus
  slot is `block_logits[k]`.

Net: one verifier streaming pass per block instead of two. The accept/reject math is
untouched — same `distribution()`, same residual rule — so the distribution-
preservation argument in the module docstring carries over verbatim; greedy off-vs-on
byte-identity remains the acceptance gate.

**Scope guard.** `HybridStreamer`'s recurrent/conv state cannot be truncated; hybrids
keep the snapshot + re-advance path unchanged. Dispatch on the same
capability the snapshot API already encodes.

---

## 9. Declined: the iGPU

Recorded so it isn't re-litigated: HD-4000-era graphics has no viable PyTorch
backend (IPEX targets newer silicon; no Vulkan path in torch). Using it means a
llama.cpp-class backend — a different engine, not a Courier optimization. The CF-31's
assets are its RAM and its SSD; this program spends those.

Also deferred, not declined: SDPA-based attention (`F.scaled_dot_product_attention`)
to replace the hand-rolled path — it removes the fp32 score materialization
(prefill memory), the `repeat_kv` copies, and the Python-loop causal mask. It is
Class N (different kernel), matters most on compute-bound boxes and long prefills,
and belongs after C proves out the Class-N validation loop. Same for
`torch.inference_mode()` (small, free, Class I — ride along with any phase).

---

## 10. Build order

Each phase: land, measure per §12 on both boxes, record, then next. Gates are
byte-identity for Class I, parity for Class N.

| Phase | Method | Files | Risk | Gate |
|---|---|---|---|---|
| 1 | A — PIN tier 1 | `gguf_shard_manager.py` | minimal | greedy byte-identity; hit-rate probe |
| 2 | B — tier 2 + misc bytes + stats aliases | `gguf_shard_manager.py`, `server.py` (0 lines — aliases suffice) | low | byte-identity; probe proves 1 disk read per layer |
| 3 | C — dtype autotune | `inference.py` | low (opt-in) | per-dtype determinism; parity check; logged pick per box |
| 4 | D — KV prealloc + PIN + append | `kv_cache.py`, both streamers | **medium** (touches hot state) | byte-identity incl. resume + SD rollback; wear counters ↓ |
| 5 | E — prefetch | `gguf_shard_manager.py` or a small `engine/prefetch.py` | medium (threading) | byte-identity; tok/s ↑ on streamed config |
| 6 | F — SD pass fusion | `speculative.py` | medium (correctness argument) | `test_sd_lossless` greedy byte-identity; `spec_decode_bench` passes/block = 1 |

Phase 4 before 5 because prefetch's value is largest when the streamed set is
stable (A/B) and its correctness is easiest to reason about before adding a second
thread. Phase 6 last: it leans on D's cheap truncate.

**Expected stack (estimates, CF-31, 70B Q4_K_M, to be replaced by §12 numbers):**
raw ~2–3 min/token → A+B (~55% resident) → ~half the read time → C (fp32 GEMM)
shrinks compute → E hides the smaller term → **rough order 40–80 s/token**, and F
halves verifier sweeps on top when a draft model is configured. The point of §12 is
to retire these words.

---

## 11. Risks & open questions

- **Tier 2 vs the OS page cache.** Pinned quantized bytes compete with the page
  cache holding the same bytes as file pages. If the page cache would have kept them
  anyway, tier 2 buys only the syscall + copy; if memory pressure evicts file pages
  (it will, at 42 GB streamed per token), tier 2 wins outright. Phase-2 measurement
  runs both configurations; if page cache wins on some box, the knob stays at 0
  there — the design costs nothing when off.
- **Dequant cost on two slow cores.** Tier-2 hits trade a SATA read (~2–3 s/GB) for
  an in-RAM dequant. If NumPy Q4_K dequant on Ivy Bridge lands slower than the read
  it replaces, tier 2 inverts. Measured in Phase 2 before the budget advice in §4 is
  written into the README.
- **Prefetch thread vs live throttle.** `set_resident_budget` mutates fields the
  prefetch thread reads. Field reads are GIL-atomic and the handoff is a bounded
  queue, but the interaction gets a probe, not an assumption.
- **Append-format KV and recovery.** The new spill format changes what `restore()`
  parses. Old-format files from an interrupted pre-upgrade run must be detected
  (magic header) and treated as absent — re-prefill recovery (the existing path)
  covers the gap; no migration code.
- **RNG discipline in F.** Pass fusion must not change the *number or order* of RNG
  draws in the accept/reject loop, or seed-identical repro breaks. The change only
  relocates a forward pass (no RNG); asserted in the probe.
- **`max_seq` sizing in D.** Preallocation needs a ceiling: stage `max_new_tokens`
  + prompt budget, already known to the pipeline. A stage exceeding its own declared
  budget is a bug today; D makes it a loud one.

---

## 12. Measurement protocol

One benchmark, run per phase, per box, recorded in the build notes:

- Fixed prompt (~1 K tokens), fixed 64-token greedy generation, 0.6B for identity
  gates, the box's real target model for throughput numbers.
- Report: tokens/sec (steady-state, excluding prefill), bytes read and written
  (psutil disk counters, before/after deltas), peak RSS, cache hit rates from
  `cache_stats()`.
- Class I gates diff the generated token IDs byte-for-byte against the pre-phase
  run at the same commit's config.
- Torch-free probes accompany every phase in the existing style
  (`tests/probe_*.py`): the cache policies, the append-format framing, the fusion
  slot arithmetic, and the LRU-vs-PIN hit-rate demonstration are all pure-Python
  provable without weights.

---

## 13. Test plan

- **Phase 1–2:** `probe_gguf_residency.py` — fake GGUF I/O layer (the
  `probe_resident_cache.py` pattern): cyclic access with budget < model asserts
  hit-rate = C/N, exactly one disk read per layer ever, one-tier ownership, misc
  cache ignores first access and pins the second, budgets never exceeded, headroom
  guard trips. `test_gguf.py` extended: tiny synthetic GGUF, byte-identical
  `load_layer` results cached vs streamed vs tier-2.
- **Phase 3:** unit test that `auto` resolves, logs, and honors explicit override;
  determinism test per dtype.
- **Phase 4:** `probe_kv_append.py` — framing, tail-append math, old-format
  detection, truncate-as-counter; `test_resilience.py` extended for resume over the
  new format; byte-identity of a full generate with spill forced on.
- **Phase 5:** probe for the handoff queue (cancel mid-prefetch, wrap at layer N−1,
  resident-layer skip); throughput A/B in the bench.
- **Phase 6:** `probe_specsample.py` extended with the slot-shift arithmetic;
  `test_sd_lossless.py` greedy byte-identity unchanged; `spec_decode_bench.py`
  asserts verifier passes per block == 1 and reports the tok/s delta.
