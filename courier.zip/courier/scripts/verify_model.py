#!/usr/bin/env python3
"""Verify a downloaded model is intact and loadable.

Supports both safetensors and GGUF formats.

Usage:
    python scripts/verify_model.py [MODEL_PATH]

Defaults to models/Qwen3-0.6B/.
"""

import json
import sys
from pathlib import Path

# Ensure src/ is on the path for GGUF reader imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


def _safetensors_key_map(model_path: Path, safetensor_files: list) -> tuple[set, dict]:
    """Build (available_keys, key_to_shard) across ALL shards.

    Mirrors ShardManager._build_index so verification sees exactly what the
    loader will: prefer model.safetensors.index.json (authoritative for
    multi-shard models), otherwise union the keys from every shard file.

    The previous implementation opened only safetensor_files[0] and checked
    every layer against that single shard's keys — so any layer living in a
    second shard was falsely reported missing. That assumption only holds for
    single-file models (e.g. Qwen3-0.6B), which is why it passed in tests and
    failed on the first multi-shard model (Qwen3.5-4B, 2 shards).
    """
    index_path = model_path / "model.safetensors.index.json"
    key_to_shard: dict[str, Path] = {}

    if index_path.exists():
        # Authoritative for multi-shard models — pure JSON, no file open needed.
        with open(index_path) as f:
            weight_map = json.load(f).get("weight_map", {})
        for key, shard_name in weight_map.items():
            key_to_shard[key] = model_path / shard_name

    if not key_to_shard:
        # No index (single shard) or empty weight_map: union keys on disk.
        from safetensors import safe_open
        for shard_path in safetensor_files:
            with safe_open(str(shard_path), framework="pt") as f:
                for key in f.keys():
                    key_to_shard[key] = shard_path

    return set(key_to_shard.keys()), key_to_shard


def verify_safetensors(model_path: Path, config: dict) -> list[str]:
    """Verify safetensors model files. Returns list of errors."""
    errors = []
    text_config = config.get("text_config", config)

    n_layers = text_config.get("num_hidden_layers", 0)
    hidden_size = text_config.get("hidden_size", 0)
    vocab_size = text_config.get("vocab_size", 0)
    head_dim = text_config.get("head_dim", hidden_size // max(text_config.get("num_attention_heads", 1), 1))
    n_heads = text_config.get("num_attention_heads", 0)

    safetensor_files = sorted(model_path.glob("*.safetensors"))
    if not safetensor_files:
        return ["No .safetensors files found"]

    print(f"Shard files: {len(safetensor_files)}")
    for f in safetensor_files:
        size_mb = f.stat().st_size / (1024 ** 2)
        print(f"  {f.name}: {size_mb:.1f} MB")

    index_path = model_path / "model.safetensors.index.json"
    if index_path.exists():
        print(f"  Index: model.safetensors.index.json ({len(safetensor_files)} shards)")
    print()

    try:
        from safetensors import safe_open
    except ImportError:
        return ["safetensors not installed (pip install safetensors)"]

    # Collect tensor keys across ALL shards (via index when present).
    keys, key_to_shard = _safetensors_key_map(model_path, safetensor_files)
    print(f"Tensor count (all shards): {len(keys)}")

    def _fetch(key: str):
        """Read a single tensor from whichever shard actually holds it."""
        with safe_open(str(key_to_shard[key]), framework="pt") as fh:
            return fh.get_tensor(key)

    # Detect key prefix: standard models use "model.layers.{i}",
    # Qwen3.5 multimodal uses "model.language_model.layers.{i}"
    layer_prefix = "model.layers"
    embed_key = "model.embed_tokens.weight"
    if any(k.startswith("model.language_model.") for k in keys):
        layer_prefix = "model.language_model.layers"
        embed_key = "model.language_model.embed_tokens.weight"

    # Check embedding
    if embed_key in keys:
        embed = _fetch(embed_key)
        expected = (vocab_size, hidden_size)
        print(f"  {embed_key}: {tuple(embed.shape)} dtype={embed.dtype}")
        if tuple(embed.shape) != expected:
            errors.append(f"Embedding shape: got {tuple(embed.shape)}, expected {expected}")
        else:
            print(f"  OK: shape matches config")
    else:
        errors.append(f"Missing {embed_key}")

    # Check q_proj on the FIRST layer that actually has one. Qwen3.5 is hybrid:
    # ~75% of layers are Gated DeltaNet (linear_attn.*, no self_attn.q_proj), and
    # layer 0 may be one of them — so hardcoding layer 0 would skip the shape
    # check entirely on those models.
    q_key = next(
        (f"{layer_prefix}.{i}.self_attn.q_proj.weight"
         for i in range(n_layers)
         if f"{layer_prefix}.{i}.self_attn.q_proj.weight" in keys),
        None,
    )
    if q_key is not None:
        q = _fetch(q_key)
        # Qwen3.5 full-attention layers use a GATED q_proj: output is q_dim*2
        # (Q interleaved with the attention gate, split in forward_full_attention).
        # Standard models (Qwen3, Llama3) use the plain q_dim width. Accept both.
        q_dim = n_heads * head_dim
        accepted = {(q_dim, hidden_size), (q_dim * 2, hidden_size)}
        gated = tuple(q.shape) == (q_dim * 2, hidden_size)
        print(f"  {q_key}: {tuple(q.shape)}{'  (gated Q+attn_gate)' if gated else ''}")
        if tuple(q.shape) not in accepted:
            errors.append(
                f"Q shape: got {tuple(q.shape)}, expected {(q_dim, hidden_size)} "
                f"or gated {(q_dim * 2, hidden_size)}")
        else:
            print(f"  OK: Q projection shape matches")

    # Check all layers present. input_layernorm.weight exists on BOTH full and
    # linear-attention layers, so it's a safe per-layer presence sentinel.
    missing = [i for i in range(n_layers)
               if f"{layer_prefix}.{i}.input_layernorm.weight" not in keys]
    if missing:
        shown = missing[:5]
        errors.append(f"Missing layers: {shown}{'...' if len(missing) > 5 else ''}")
    else:
        print(f"  OK: All {n_layers} layers present")

    return errors


def verify_gguf(model_path: Path, config: dict) -> list[str]:
    """Verify GGUF model file. Returns list of errors."""
    errors = []
    text_config = config.get("text_config", config)

    n_layers = text_config.get("num_hidden_layers", 0)
    hidden_size = text_config.get("hidden_size", 0)
    vocab_size = text_config.get("vocab_size", 0)
    head_dim = text_config.get("head_dim", hidden_size // max(text_config.get("num_attention_heads", 1), 1))
    n_heads = text_config.get("num_attention_heads", 0)
    n_kv_heads = text_config.get("num_key_value_heads", 0)

    gguf_files = sorted(model_path.glob("*.gguf"))
    if not gguf_files:
        return ["No .gguf files found"]

    gguf_path = gguf_files[0]
    size_mb = gguf_path.stat().st_size / (1024 ** 2)
    print(f"GGUF file: {gguf_path.name} ({size_mb:.1f} MB)")
    print()

    try:
        from core.gguf_reader import read_gguf, GGML_TYPE_NAMES
    except ImportError as e:
        return [f"Could not import gguf_reader: {e}"]

    try:
        header = read_gguf(gguf_path)
    except Exception as e:
        return [f"Failed to parse GGUF: {e}"]

    print(f"  Version:      {header.version}")
    print(f"  Architecture: {header.architecture}")
    print(f"  Tensors:      {header.tensor_count}")
    print(f"  Alignment:    {header.alignment}")
    print()

    # Verify tensor count
    # Expected: embedding + final_norm + lm_head + n_layers * tensors_per_layer
    # Rough check: at least n_layers * 7 (norm, q, k, v, o, up, gate, down) + 2 (embed, norm)
    min_expected = n_layers * 7 + 2
    if header.tensor_count < min_expected:
        errors.append(
            f"Too few tensors: {header.tensor_count} (expected at least {min_expected} "
            f"for {n_layers} layers)"
        )
    else:
        print(f"  OK: Tensor count ({header.tensor_count}) ≥ minimum ({min_expected})")

    # Check critical tensors exist
    critical = ["token_embd.weight", "output_norm.weight"]
    for name in critical:
        if name not in header.tensors:
            errors.append(f"Missing critical tensor: {name}")
        else:
            t = header.tensors[name]
            print(f"  {name}: shape={t.shape} type={t.type_name}")

    # Check all layers present
    missing_layers = []
    for i in range(n_layers):
        q_key = f"blk.{i}.attn_q.weight"
        if q_key not in header.tensors:
            missing_layers.append(i)
    if missing_layers:
        errors.append(f"Missing layers: {missing_layers[:5]}{'...' if len(missing_layers) > 5 else ''}")
    else:
        print(f"  OK: All {n_layers} layers present")

    # Verify shape of first layer's Q projection
    q0_key = "blk.0.attn_q.weight"
    if q0_key in header.tensors:
        t = header.tensors[q0_key]
        expected_q = (n_heads * head_dim, hidden_size)
        if t.shape != expected_q:
            errors.append(f"Q projection shape: got {t.shape}, expected {expected_q}")
        else:
            print(f"  OK: Q projection shape matches ({n_heads}×{head_dim}, {hidden_size})")

    # Print quantization type summary
    from collections import Counter
    type_counts = Counter(t.type_name for t in header.tensors.values())
    print()
    print("  Quantization types:")
    for type_name, count in type_counts.most_common():
        print(f"    {type_name}: {count} tensors")

    # Print GGUF metadata highlights
    arch = header.architecture
    print()
    print("  GGUF metadata:")
    for key in [f"{arch}.block_count", f"{arch}.embedding_length",
                f"{arch}.attention.head_count", f"{arch}.attention.head_count_kv",
                f"{arch}.vocab_size", f"{arch}.context_length",
                f"{arch}.rope.freq_base", "general.name", "general.file_type"]:
        if key in header.metadata:
            print(f"    {key}: {header.metadata[key]}")

    # Test name mapping
    try:
        from core.gguf_name_map import gguf_to_hf_key
        hf_key = gguf_to_hf_key("blk.0.attn_q.weight")
        print()
        print(f"  Name mapping: blk.0.attn_q.weight → {hf_key}")
    except Exception as e:
        errors.append(f"Name mapping failed: {e}")

    return errors


def verify(model_path: Path) -> bool:
    """Verify a model at the given path."""
    config_path = model_path / "config.json"
    if not config_path.exists():
        print(f"FAIL: config.json not found at {config_path}")
        print()
        print("If this is a GGUF model, download the config from the base model:")
        print(f"  python scripts/download_model.py --model <base_model> --dest {model_path}")
        return False

    config = json.load(open(config_path))
    text_config = config.get("text_config", config)
    model_type = config.get("model_type", "unknown")

    print(f"Config loaded: {model_type}")
    print(f"  Layers:          {text_config.get('num_hidden_layers', '?')}")
    print(f"  Hidden size:     {text_config.get('hidden_size', '?')}")
    print(f"  Vocab size:      {text_config.get('vocab_size', '?')}")
    print(f"  Attention heads: {text_config.get('num_attention_heads', '?')}")
    print(f"  KV heads:        {text_config.get('num_key_value_heads', '?')}")
    print(f"  Head dim:        {text_config.get('head_dim', '?')}")
    print(f"  Tied embeddings: {text_config.get('tie_word_embeddings', '?')}")
    print()

    # Detect format and verify
    gguf_files = list(model_path.glob("*.gguf"))
    safetensor_files = list(model_path.glob("*.safetensors"))

    if gguf_files and not safetensor_files:
        print("Format: GGUF")
        print()
        errors = verify_gguf(model_path, config)
    elif safetensor_files:
        print("Format: safetensors")
        print()
        errors = verify_safetensors(model_path, config)
    else:
        print("FAIL: No weight files (.safetensors or .gguf) found")
        return False

    print()
    if errors:
        print(f"VERIFICATION FAILED — {len(errors)} error(s):")
        for e in errors:
            print(f"  ✗ {e}")
        return False
    else:
        print("VERIFICATION PASSED")
        print(f"  Model {model_type} at {model_path} is intact and loadable.")
        return True


def main():
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("models/Qwen3-0.6B")
    if not path.exists():
        print(f"Model path not found: {path}")
        print(f"Run: python scripts/download_model.py")
        sys.exit(1)
    ok = verify(path)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
