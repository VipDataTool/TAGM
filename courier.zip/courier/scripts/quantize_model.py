#!/usr/bin/env python3
"""Quantize a BF16/FP16 safetensors model to INT8 with per-channel scales.

Cuts disk and memory footprint by ~50% while preserving mmap speed.
Norm weights and biases stay at full precision. Everything else
becomes INT8 + FP16 scale, dequantized to BF16 on the fly during
inference by the ShardManager.

Usage:
    python scripts/quantize_model.py models/Qwen3-8B

    # Or specify output directory (default: overwrites in-place)
    python scripts/quantize_model.py models/Qwen3-8B --output models/Qwen3-8B-INT8

The original safetensors files are replaced. Config, tokenizer, and
other non-weight files are preserved unchanged.
"""

import argparse
import json
import shutil
import sys
import time
from pathlib import Path

import torch
from safetensors.torch import save_file


def should_quantize(name: str, tensor: torch.Tensor) -> bool:
    """Decide whether a tensor should be quantized to INT8.

    Quantize: 2D weight matrices (projections, embeddings, LM head)
    Keep full precision: norms, biases, 1D tensors, anything tiny
    """
    if tensor.ndim != 2:
        return False
    if tensor.numel() < 512:
        return False
    # Skip norm weights, biases, and other precision-sensitive tensors.
    # in_proj_a / in_proj_b are Qwen3.5 Gated DeltaNet decay/beta projections:
    # they feed g = -exp(A_log)*softplus(a+dt_bias) and beta = sigmoid(b), where
    # exp(softplus(.)) amplifies quantization noise. They're tiny (~80 KB each),
    # so keeping them in full precision costs ~nothing and protects the recurrence.
    # No effect on Qwen3/Llama3 (no in_proj_* tensors).
    skip_patterns = ["layernorm", "norm.weight", "norm.bias", "bias",
                     "inv_freq", "rotary", "rope",
                     "in_proj_a", "in_proj_b"]
    name_lower = name.lower()
    for pattern in skip_patterns:
        if pattern in name_lower:
            return False
    return True


def quantize_tensor(tensor: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    """Per-channel symmetric INT8 quantization.

    For a (rows, cols) matrix, computes one scale per row.

    scale = max(abs(row)) / 127
    quantized = round(tensor / scale).clamp(-128, 127)

    Processed in row blocks so the fp32 working set is bounded (~64 MB per
    block) no matter how large the tensor. The whole-tensor version this
    replaces materialized the full matrix in fp32 PLUS two or three chained
    intermediates — a multi-GB transient on a 150k-vocab embedding, which is
    what OOM-killed the in-server conversion on small boxes. The scale is
    per-row, so the math is row-local and blocking changes nothing
    numerically.

    Returns (int8_tensor, fp16_scale).
    """
    rows, cols = tensor.shape
    quantized = torch.empty((rows, cols), dtype=torch.int8)
    scale = torch.empty(rows, dtype=torch.float16)
    block_rows = max(1, (64 << 20) // (cols * 4))  # ~64 MB of fp32 per block

    for r0 in range(0, rows, block_rows):
        block = tensor[r0:r0 + block_rows].float()
        absmax = block.abs().amax(dim=-1, keepdim=True)  # (b, 1)
        s = (absmax / 127.0).clamp(min=1e-10)            # avoid div-by-zero
        quantized[r0:r0 + block_rows] = (
            (block / s).round().clamp(-128, 127).to(torch.int8)
        )
        scale[r0:r0 + block_rows] = s.squeeze(-1).to(torch.float16)

    return quantized, scale


def _part_path(final_path: Path, n: int) -> Path:
    """Name for the n-th flushed part of a shard, beside its final file.

    model-00001-of-00002.safetensors → model-00001-of-00002.part000.safetensors
    Ends in .safetensors on purpose: the index rebuild, ShardManager, and
    _model_ready all discover shards by that suffix, so parts are first-class
    shards downstream with no special handling.
    """
    name = final_path.name
    if name.endswith(".safetensors"):
        name = name[: -len(".safetensors")]
    return final_path.with_name(f"{name}.part{n:03d}.safetensors")


def _is_part(path: Path) -> bool:
    """True if path is a .partNNN.safetensors chunk of another shard."""
    import re
    return re.search(r"\.part\d{3}\.safetensors$", path.name) is not None


def _parts_of(final_path: Path) -> list[Path]:
    """Existing part files of a shard, in order (contiguous from 000)."""
    out = []
    while _part_path(final_path, len(out)).exists():
        out.append(_part_path(final_path, len(out)))
    return out


def _keys_overlap(a: Path, b: Path) -> bool:
    """True if two shard files share any tensor key (two header reads).

    `b` is always the part under judgment. If it cannot be opened, that
    IS the verdict, not an error: a truncated part (ENOSPC or power
    loss mid-write) is precisely the orphan this test routes to
    deletion, and raising here turns one bad write into a permanent
    boot-loop of failed quantize-then-load attempts — observed live on
    the field box, 2026-07-03. An unreadable `a` (the source shard)
    still raises: recovery must never bless a damaged source.
    """
    from safetensors import safe_open
    with safe_open(str(a), framework="pt") as fa:
        ka = set(fa.keys())
    try:
        with safe_open(str(b), framework="pt") as fb:
            return any(k in ka for k in fb.keys())
    except Exception:
        return True  # unreadable part → overlaps by decree → stale-part cleanup


def _shard_is_quantized(path: Path) -> bool:
    """True if a shard already carries INT8 _scale companions.

    Guards reruns after an interruption: re-quantizing an already-INT8
    shard silently corrupts it (int8 in, garbage out), and a run killed
    between shards leaves exactly that trap — converted shards on disk
    with no marker yet.
    """
    from safetensors import safe_open
    with safe_open(str(path), framework="pt") as f:
        return any(k.endswith("_scale") for k in f.keys())


def quantize_shard(input_path: Path, output_path: Path,
                   part_base: Path | None = None,
                   part_budget: int = 512 << 20) -> dict:
    """Quantize a single safetensors shard.

    Streams tensors one at a time via safe_open AND flushes the converted
    output in parts of ~part_budget bytes. safetensors has no incremental
    writer, so without flushing the converted tensors accumulate to the full
    output-shard size in RAM before one byte hits disk (~2.7 GB for a 5.3 GB
    input) — enough to draw a memory-pressure watchdog's SIGTERM on a small
    box even running standalone. Peak RAM is now ~(part_budget) + (one row
    block in fp32), independent of shard size.

    Parts are written beside the shard as <name>.partNNN.safetensors (named
    from part_base — the FINAL shard path — so in-place tmp files don't leak
    into part names); the last chunk goes to output_path itself, preserving
    the caller's tmp-then-replace dance. The index rebuild scans actual
    output files, so multi-part output needs nothing else downstream.

    Returns stats dict with counts and sizes.
    """
    from safetensors import safe_open

    base = part_base if part_base is not None else output_path
    output_tensors = {}
    acc = 0          # bytes accumulated in output_tensors since last flush
    stats = {"quantized": 0, "kept": 0, "input_bytes": 0, "output_bytes": 0,
             "parts": 0, "protected_gates": []}

    # Every path this shard writes, recorded BEFORE the write begins.
    # Part files match the engine's weight glob (model*.safetensors), so
    # a write interrupted mid-part (ENOSPC, OOM-kill, Ctrl+C) strands a
    # truncated file the engine will try to load — poisoning every model
    # load until something deletes it. On ANY failure, remove our own
    # wreckage and re-raise; the input shard is never written here, so
    # this restores the exact pre-run state. (Power loss can still
    # strand a part — the unreadable-part handling in _keys_overlap is
    # the backstop for that.)
    _written: list[Path] = []

    try:
        with safe_open(str(input_path), framework="pt") as f:
            keys = list(f.keys())
            last = len(keys) - 1
            for i, name in enumerate(keys):
                tensor = f.get_tensor(name)
                stats["input_bytes"] += tensor.nelement() * tensor.element_size()
                before = stats["output_bytes"]

                if should_quantize(name, tensor):
                    q, scale = quantize_tensor(tensor)
                    output_tensors[name] = q
                    output_tensors[name + "_scale"] = scale
                    stats["quantized"] += 1
                    stats["output_bytes"] += q.nelement() * q.element_size()
                    stats["output_bytes"] += scale.nelement() * scale.element_size()
                else:
                    output_tensors[name] = tensor
                    stats["kept"] += 1
                    stats["output_bytes"] += tensor.nelement() * tensor.element_size()
                    # Note DeltaNet decay/beta gate projections we deliberately spared.
                    if "in_proj_a" in name or "in_proj_b" in name:
                        stats["protected_gates"].append(name)

                acc += stats["output_bytes"] - before
                del tensor  # release the bf16 input before reading the next one

                # Flush a part once the budget is hit — except on the last key,
                # which always lands in output_path so the final file is never
                # empty and the caller's replace always has something to move.
                if acc >= part_budget and i < last:
                    part = _part_path(base, stats["parts"])
                    _written.append(part)
                    save_file(output_tensors, str(part))
                    stats["parts"] += 1
                    output_tensors = {}
                    acc = 0

        _written.append(output_path)
        save_file(output_tensors, str(output_path))
    except BaseException:
        for p in _written:
            try:
                p.unlink(missing_ok=True)
            except OSError:
                pass  # best effort; _keys_overlap recovery is the backstop
        raise
    return stats


def quantize_model(model_dir: Path, output_dir: Path | None = None,
                   part_budget: int = 512 << 20):
    """Quantize all safetensors shards in a model directory."""
    if output_dir is None:
        output_dir = model_dir  # in-place
    else:
        output_dir.mkdir(parents=True, exist_ok=True)
        # Copy non-weight files
        for f in model_dir.iterdir():
            if f.suffix != ".safetensors" and f.name != "model.safetensors.index.json":
                dest = output_dir / f.name
                if f.is_file() and not dest.exists():
                    shutil.copy2(f, dest)

    # A completed conversion left a marker. Re-quantizing INT8 shards
    # corrupts them, so refuse rather than guess. Delete the marker to
    # force a redo on purpose.
    marker_path = output_dir / "quantization_config.json"
    if marker_path.exists():
        print(f"Already quantized ({marker_path.name} present) — nothing to do.")
        print(f"Delete the marker to force a re-run.")
        return

    shard_files = sorted(model_dir.glob("*.safetensors"))
    if not shard_files:
        print(f"ERROR: No .safetensors files found in {model_dir}")
        sys.exit(1)

    # Disk preflight: the INT8 output is ~0.51× the BF16 input (int8
    # weights + fp16 per-row scales) plus kept-precision tensors; 0.6×
    # is a safe ceiling. In-place mode holds original and output
    # simultaneously until the atomic replace, so the full estimate
    # must fit in FREE space. Refusing here costs nothing; ENOSPC
    # mid-shard costs a cleanup pass — and on the field SSDs this
    # project is built for, avoidable writes are the point.
    _real_shards = [f for f in shard_files if not _is_part(f)]
    _total_in = sum(f.stat().st_size for f in _real_shards)
    _need = int(_total_in * 0.6) + (256 << 20)  # + margin for headers/index
    _free = shutil.disk_usage(str(output_dir)).free
    if _free < _need:
        print(f"ERROR: Not enough free disk space to quantize safely.")
        print(f"  Input {_total_in / 2**30:.2f} GB → needs ~{_need / 2**30:.2f} GB "
              f"free (est. output + margin); {_free / 2**30:.2f} GB available "
              f"on {output_dir}.")
        print(f"  Free up space and re-run — or skip quantization entirely; "
              f"the engine loads BF16 safetensors directly, just larger.")
        sys.exit(1)

    print(f"Quantizing {len(shard_files)} shard(s) in {model_dir}")
    print()

    total_stats = {"quantized": 0, "kept": 0, "input_bytes": 0, "output_bytes": 0,
                   "parts": 0, "protected_gates": []}

    for shard_path in shard_files:
        # Part files are never (re)processed directly — their fate is
        # decided by their parent shard below.
        if _is_part(shard_path):
            if output_dir != model_dir:
                shutil.copy2(shard_path, output_dir / shard_path.name)
            continue

        parts = _parts_of(output_dir / shard_path.name)
        if parts:
            # Parts exist for this shard. Two possible histories:
            #   TAIL:   an earlier run finished this shard — the original was
            #           atomically replaced by its final chunk, whose keys are
            #           DISJOINT from the parts' keys.
            #   ORPHAN: an earlier run was killed mid-shard — the original is
            #           intact and still contains every key, so it OVERLAPS
            #           the parts. (Parts are only ever written from their
            #           source, so a true orphan always overlaps.)
            # The overlap test distinguishes them with two header reads and
            # no sentinel file; _scale sniffing cannot, because a tail of
            # kept-precision tensors carries no _scale keys.
            if _keys_overlap(shard_path, parts[0]):
                for p in parts:
                    p.unlink()
                print(f"  {shard_path.name}: removed {len(parts)} stale "
                      f"part(s) from an interrupted run")
            else:
                if output_dir != model_dir:
                    shutil.copy2(shard_path, output_dir / shard_path.name)
                    print(f"  {shard_path.name}... already converted "
                          f"(tail + {len(parts)} part(s)), copied")
                else:
                    print(f"  {shard_path.name}... already converted "
                          f"(tail + {len(parts)} part(s)), skipped")
                continue

        elif _shard_is_quantized(shard_path):
            # No parts, but _scale companions present: converted whole by an
            # earlier (interrupted) run. Re-quantizing would corrupt it.
            if output_dir != model_dir:
                shutil.copy2(shard_path, output_dir / shard_path.name)
                print(f"  {shard_path.name}... already INT8, copied")
            else:
                print(f"  {shard_path.name}... already INT8, skipped")
            continue

        out_path = output_dir / shard_path.name
        # If in-place, write to a temp file then replace
        if output_dir == model_dir:
            tmp_path = shard_path.with_suffix(".safetensors.tmp")
            print(f"  {shard_path.name}...", end=" ", flush=True)
            t0 = time.time()
            stats = quantize_shard(shard_path, tmp_path, part_base=shard_path,
                                   part_budget=part_budget)
            tmp_path.replace(shard_path)
        else:
            print(f"  {shard_path.name}...", end=" ", flush=True)
            t0 = time.time()
            stats = quantize_shard(shard_path, out_path, part_base=out_path,
                                   part_budget=part_budget)

        elapsed = time.time() - t0
        ratio = stats["output_bytes"] / max(stats["input_bytes"], 1)
        parts_note = f", {stats['parts']} part(s)" if stats["parts"] else ""
        print(f"{stats['quantized']} quantized, {stats['kept']} kept, "
              f"{ratio:.1%} size{parts_note}, {elapsed:.1f}s")

        for k in total_stats:
            total_stats[k] += stats[k]

    # Update index.json if multi-shard
    index_path = model_dir / "model.safetensors.index.json"
    out_index_path = output_dir / "model.safetensors.index.json"
    if index_path.exists():
        with open(index_path) as f:
            index = json.load(f)

        # Add _scale entries to weight_map
        weight_map = index.get("weight_map", {})
        new_entries = {}
        for key, shard_name in weight_map.items():
            # Check if this tensor was quantized by opening the output shard
            new_entries[key] = shard_name

        # Rebuild weight_map from actual shard contents
        new_weight_map = {}
        for shard_path in sorted(output_dir.glob("*.safetensors")):
            from safetensors import safe_open
            with safe_open(str(shard_path), framework="pt") as f:
                for key in f.keys():
                    new_weight_map[key] = shard_path.name

        index["weight_map"] = new_weight_map
        with open(out_index_path, "w") as f:
            json.dump(index, f, indent=2)
        print(f"  Updated {out_index_path.name}")

    # Write quantization marker
    marker = {
        "quantization": "int8_per_channel",
        "tensors_quantized": total_stats["quantized"],
        "tensors_kept": total_stats["kept"],
        "deltanet_gates_protected": len(total_stats["protected_gates"]),
        "compression_ratio": round(total_stats["output_bytes"] / max(total_stats["input_bytes"], 1), 3),
    }
    with open(output_dir / "quantization_config.json", "w") as f:
        json.dump(marker, f, indent=2)

    print()
    in_gb = total_stats["input_bytes"] / (1024 ** 3)
    out_gb = total_stats["output_bytes"] / (1024 ** 3)
    ratio = total_stats["output_bytes"] / max(total_stats["input_bytes"], 1)
    print(f"Done.")
    print(f"  Tensors: {total_stats['quantized']} quantized, {total_stats['kept']} kept at full precision")
    gates = total_stats["protected_gates"]
    if gates:
        print(f"  Gates:   {len(gates)} Qwen3.5 DeltaNet decay/beta projections "
              f"kept at full precision (in_proj_a/in_proj_b)")
    print(f"  Size:    {in_gb:.2f} GB → {out_gb:.2f} GB ({ratio:.1%})")
    print(f"  Saved:   {in_gb - out_gb:.2f} GB")


def main():
    parser = argparse.ArgumentParser(description="Quantize model to INT8 safetensors")
    parser.add_argument("model_dir", type=Path, help="Path to model directory")
    parser.add_argument("--output", type=Path, default=None,
                        help="Output directory (default: overwrite in-place)")
    parser.add_argument("--part-mb", type=int, default=512,
                        help="Flush converted output every N MB so peak RAM is "
                             "bounded regardless of shard size (default: 512)")
    args = parser.parse_args()

    if not args.model_dir.exists():
        print(f"ERROR: {args.model_dir} not found")
        sys.exit(1)

    quantize_model(args.model_dir, args.output,
                   part_budget=max(1, args.part_mb) << 20)


if __name__ == "__main__":
    main()
