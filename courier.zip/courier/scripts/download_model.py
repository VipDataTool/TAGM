#!/usr/bin/env python3
"""Download model shards from HuggingFace.

Usage:
    python scripts/download_model.py [--model MODEL_ID] [--dest PATH]
    python scripts/download_model.py --gguf QUANT_TYPE [--model MODEL_ID]

Supports safetensors (default) and GGUF quantized models.

Examples:
    # Default: Qwen3-0.6B safetensors (~1.5 GB)
    python scripts/download_model.py

    # GGUF: Qwen3-8B Q4_K_M (~5 GB)
    python scripts/download_model.py --model Qwen/Qwen3-8B-GGUF --gguf q4_k_m

    # GGUF: Llama 3.1-8B Q4_K_M (community quantization)
    python scripts/download_model.py --model bartowski/Meta-Llama-3.1-8B-Instruct-GGUF --gguf q4_k_m

    # GGUF with explicit base model for config/tokenizer
    python scripts/download_model.py --model Qwen/Qwen3-8B-GGUF --gguf q4_k_m --base Qwen/Qwen3-8B
"""

import argparse
import sys
from pathlib import Path


# Patterns for config and tokenizer files (used by both paths)
CONFIG_PATTERNS = [
    "config.json", "tokenizer.json", "tokenizer_config.json",
    "generation_config.json", "special_tokens_map.json",
    "chat_template.jinja", "merges.txt", "vocab.json",
    "tokenizer.model", "preprocessor_config.json",
]

# Patterns for safetensors weight files
SAFETENSORS_PATTERNS = [
    "model.safetensors", "model.safetensors.index.json",
    "model.safetensors-*.safetensors", "model-*.safetensors",
]


def download_safetensors(model_id: str, dest: Path) -> None:
    """Download a safetensors model."""
    from huggingface_hub import snapshot_download

    dest.mkdir(parents=True, exist_ok=True)
    print(f"Downloading {model_id} (safetensors) → {dest}")
    print()

    snapshot_download(
        repo_id=model_id,
        local_dir=str(dest),
        allow_patterns=CONFIG_PATTERNS + SAFETENSORS_PATTERNS,
    )

    _print_summary(dest, "safetensors")


def download_gguf(model_id: str, quant: str, dest: Path, base_model: str | None = None) -> None:
    """Download a GGUF quantized model.

    Downloads the GGUF weight file from model_id, and config/tokenizer
    files from the base model repo (auto-detected or explicitly provided).
    """
    from huggingface_hub import hf_hub_download, snapshot_download, list_repo_files

    dest.mkdir(parents=True, exist_ok=True)
    quant_lower = quant.lower().replace("-", "_")

    # ── Find the GGUF file in the repo ────────────────────
    print(f"Scanning {model_id} for GGUF files matching '{quant_lower}'...")
    try:
        files = list_repo_files(model_id)
    except Exception as e:
        print(f"ERROR: Could not list files in {model_id}: {e}")
        sys.exit(1)

    gguf_files = [f for f in files if f.endswith(".gguf")]
    if not gguf_files:
        print(f"ERROR: No .gguf files found in {model_id}")
        print(f"  Available files: {', '.join(files[:10])}...")
        sys.exit(1)

    # Match by quant type (case-insensitive)
    matching = [f for f in gguf_files if quant_lower in f.lower()]
    if not matching:
        print(f"ERROR: No GGUF file matching '{quant_lower}' in {model_id}")
        print(f"  Available GGUF files:")
        for f in gguf_files:
            print(f"    {f}")
        sys.exit(1)

    if len(matching) > 1:
        print(f"  Multiple matches found, using first: {matching[0]}")
        print(f"  All matches: {matching}")

    gguf_filename = matching[0]
    print(f"  Downloading: {gguf_filename}")
    print()

    hf_hub_download(
        repo_id=model_id,
        filename=gguf_filename,
        local_dir=str(dest),
    )

    # ── Download config/tokenizer from base model ─────────
    # Check if the GGUF repo has config.json
    has_config = "config.json" in files

    if has_config:
        print(f"Downloading config/tokenizer from {model_id}...")
        snapshot_download(
            repo_id=model_id,
            local_dir=str(dest),
            allow_patterns=CONFIG_PATTERNS,
        )
    else:
        # Auto-detect base model repo
        if base_model is None:
            # Try stripping common GGUF suffixes
            for suffix in ["-GGUF", "-gguf", "_GGUF", "_gguf"]:
                if model_id.endswith(suffix):
                    base_model = model_id[:-len(suffix)]
                    break
            if base_model is None:
                print(f"ERROR: {model_id} does not contain config.json and")
                print(f"  no --base model was specified. Provide the base model:")
                print(f"  --base Qwen/Qwen3-8B")
                sys.exit(1)

        print(f"Downloading config/tokenizer from base model {base_model}...")
        snapshot_download(
            repo_id=base_model,
            local_dir=str(dest),
            allow_patterns=CONFIG_PATTERNS,
        )

    # A GGUF directory without config.json is unloadable: adapter
    # detection, the dashboard's family field, and the diff harness all
    # read it. snapshot_download does NOT raise on a missing repo (it
    # returns the local dir with a warning), so the auto-derived base
    # can quietly 404 — community quants live in the quantizer's
    # namespace (bartowski/...-GGUF), where stripping "-GGUF" yields a
    # repo that doesn't exist. Fail loud with the way out.
    if not (dest / "config.json").exists():
        print(f"ERROR: no config.json in {dest} — the weights downloaded, "
              f"but the model cannot be loaded without it.")
        print(f"  The config source tried was '{base_model or model_id}', "
              f"which did not provide one (wrong or missing repo).")
        print(f"  Re-run with the true base model, e.g.:")
        print(f"    python scripts/download_model.py --model {model_id} "
              f"--gguf {quant} --base <org>/<base-model>")
        print(f"  (Or copy config.json + tokenizer files from an existing "
              f"safetensors twin of the same model into {dest}.)")
        sys.exit(1)

    _print_summary(dest, "gguf")


def _print_summary(dest: Path, format_type: str) -> None:
    """Print download summary."""
    import json

    config_path = dest / "config.json"
    if not config_path.exists():
        print(f"WARNING: config.json not found at {config_path}")
        return

    config = json.load(open(config_path))
    model_type = config.get("model_type", "unknown")
    text_config = config.get("text_config", config)
    layers = text_config.get("num_hidden_layers", "?")
    hidden = text_config.get("hidden_size", "?")
    vocab = text_config.get("vocab_size", "?")
    is_multimodal = "vision_config" in config

    if format_type == "gguf":
        weight_files = list(dest.glob("*.gguf"))
        total_size = sum(f.stat().st_size for f in weight_files)
        file_desc = "GGUF"
    else:
        weight_files = list(dest.glob("*.safetensors"))
        total_size = sum(f.stat().st_size for f in weight_files)
        file_desc = "Safetensor"

    print()
    print(f"Download complete.")
    print(f"  Model type:   {model_type}")
    print(f"  Format:       {format_type}")
    print(f"  Multimodal:   {'yes' if is_multimodal else 'no'}")
    print(f"  Layers:       {layers}")
    print(f"  Hidden size:  {hidden}")
    print(f"  Vocab size:   {vocab}")
    if is_multimodal:
        vis = config.get("vision_config", {})
        print(f"  ViT depth:    {vis.get('depth', '?')}")
        layer_types = text_config.get("layer_types", [])
        if layer_types:
            n_full = sum(1 for lt in layer_types if lt == "full_attention")
            n_linear = sum(1 for lt in layer_types if lt == "linear_attention")
            print(f"  Attention:    {n_full} full + {n_linear} linear (hybrid)")
    print(f"  Weight files: {len(weight_files)} ({file_desc})")
    print(f"  Total size:   {total_size / (1024**3):.2f} GB")
    print(f"  Location:     {dest}")


def main():
    parser = argparse.ArgumentParser(description="Download model from HuggingFace")
    parser.add_argument(
        "--model", default="Qwen/Qwen3-0.6B",
        help="HuggingFace model ID (default: Qwen/Qwen3-0.6B)"
    )
    parser.add_argument(
        "--dest", default=None,
        help="Destination directory (default: models/<model_name>)"
    )
    parser.add_argument(
        "--gguf", default=None, metavar="QUANT",
        help="Download GGUF format with specified quantization (e.g., q4_k_m, q8_0)"
    )
    parser.add_argument(
        "--base", default=None, metavar="MODEL_ID",
        help="Base model repo for config/tokenizer (auto-detected from --model if omitted)"
    )
    args = parser.parse_args()

    try:
        from huggingface_hub import snapshot_download
    except ImportError:
        print("ERROR: huggingface_hub not installed.")
        print("  pip install huggingface_hub")
        sys.exit(1)

    if args.dest:
        dest = Path(args.dest)
    else:
        name = args.model.split("/")[-1]
        dest = Path("models") / name

    if args.gguf:
        download_gguf(args.model, args.gguf, dest, base_model=args.base)
    else:
        download_safetensors(args.model, dest)


if __name__ == "__main__":
    main()
