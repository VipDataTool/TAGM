# Courier — Build & Operations Guide

Edge inference framework for large language models on resource-constrained hardware.
Runs models by streaming weight shards through memory one layer at a time. Designed
for field deployment where network access is unavailable and cycle latency is measured
in minutes or hours, not milliseconds.

**Current version:** 0.1.0  
**Prototype model:** Qwen3-0.6B (28 layers, 1.5 GB BF16)  
**Test suite:** 106 tests passing

---

## Contents

1. [Hardware requirements](#1-hardware-requirements)
2. [Software requirements](#2-software-requirements)
3. [Installation](#3-installation)
4. [Model download](#4-model-download)
5. [Running tests](#5-running-tests)
6. [Starting the server](#6-starting-the-server)
7. [Dashboard walkthrough](#7-dashboard-walkthrough)
8. [CLI reference](#8-cli-reference)
9. [Data ingestion](#9-data-ingestion)
10. [Template authoring](#10-template-authoring)
11. [Configuration reference](#11-configuration-reference)
12. [Project structure](#12-project-structure)

---

## 1. Hardware requirements

| Resource   | Minimum         | Reference (Codespace) |
|------------|-----------------|------------------------|
| RAM        | 8 GB            | 16 GB                  |
| Disk       | 8 GB free       | 32 GB                  |
| Disk type  | SSD             | SSD                    |
| CPU        | 4 cores         | 4 cores                |
| GPU        | None required   | None                   |
| Network    | Required once   | LAN only after setup   |

**Memory guidance by model:**

| Model         | Q4 Size  | RAM needed | CPU tok/s (16 GB DDR4) |
|---------------|----------|------------|------------------------|
| Qwen3-0.6B    | ~400 MB  | 2 GB       | 50–100+                |
| Qwen3-2B      | ~1.2 GB  | 3 GB       | 20–40                  |
| Qwen3-8B      | ~4.5 GB  | 7 GB       | 5–12                   |
| Qwen3-14B     | ~8 GB    | 11 GB      | 3–6                    |

Inference throughput is memory-bandwidth bound. More CPU cores beyond 5–6 threads
provides no benefit on dual-channel DDR4. RAM frequency matters more than core count.

---

## 2. Software requirements

**Runtime:**
- Python 3.10 or higher (3.12 recommended)
- pip

**Python packages** (installed automatically by `start.sh` or `pip install -r requirements.txt`):

```
torch>=2.2.0           # CPU inference
safetensors>=0.4.0     # mmap-backed weight loading
transformers>=4.51.0   # tokenizer (Qwen3 support added in 4.51.0)
psutil>=5.9.0          # resource monitoring
fastapi>=0.110.0       # HTTP server
uvicorn>=0.29.0        # ASGI server
cryptography>=42.0.0   # TLS, token hashing
aiofiles>=23.2.0       # async file I/O
```

**Development extras:**
```
pytest>=8.0.0
httpx>=0.27.0          # test HTTP client
```

**For model download only** (not needed at runtime):
```
huggingface_hub        # pip install huggingface_hub
```

---

## 3. Installation

### GitHub Codespace (recommended for development)

```bash
# Clone and enter the project
git clone <repo>
cd Edge-LLM/courier

# Run the start script — checks deps, downloads model, runs tests, starts server
bash start.sh
```

The start script is idempotent. Run it again after any interruption.

### Local installation

```bash
cd courier

# Install dependencies
pip install -r requirements.txt

# Download the prototype model (requires internet, ~1.5 GB)
python scripts/download_model.py

# Verify the download
python scripts/verify_model.py

# Run the test suite
pytest tests/ -s -q

# Start the server
bash start.sh
```

### Development mode (no model required)

The template, pipeline, data adapter, and persistence tests all run without a model.
Only the inference tests skip if the model is absent.

```bash
pytest tests/test_scaffold.py tests/test_pipeline.py tests/test_persistence.py -s -q
```

---

## 4. Model download

The download script pulls the model from HuggingFace. It requires internet access and
approximately 1.5 GB of disk space for Qwen3-0.6B BF16.

```bash
# Default: Qwen3-0.6B into models/Qwen3-0.6B/
python scripts/download_model.py

# Specify a different model
python scripts/download_model.py --model Qwen/Qwen3-8B --dest models/Qwen3-8B
```

Files downloaded:
- `config.json` — model architecture
- `tokenizer.json`, `tokenizer_config.json` — BPE tokenizer
- `generation_config.json` — default generation parameters
- `model.safetensors` — weight shard (single file for 0.6B)

After downloading, verify integrity:

```bash
python scripts/verify_model.py models/Qwen3-0.6B
```

Expected output confirms: correct layer count (28), hidden size (1024), vocab size (151936),
QK-norm weights present, all layers present in the shard.

---

## 5. Running tests

```bash
# Full suite (requires model to be downloaded)
pytest tests/ -s -q

# Without model (faster, skips inference tests)
pytest tests/test_scaffold.py tests/test_pipeline.py \
       tests/test_persistence.py tests/test_server.py -s -q

# Single phase
pytest tests/test_engine.py -s -q     # Phase 1A: inference engine
pytest tests/test_pipeline.py -s -q   # Phase 1B: templates + pipeline
pytest tests/test_persistence.py -s   # Phase 3: DB, ingestion, cycle worker
pytest tests/test_server.py -s -q     # Phase 4: API endpoints
```

**Expected output (all tests):**
```
106 passed, 4 warnings in 86.00s
```

The warnings are FastAPI lifecycle deprecations (`on_event` → `lifespan`). They do not
affect functionality.

**Test structure:**

| File | Phase | What it tests |
|---|---|---|
| `test_scaffold.py` | 0 | Package imports, directory structure, model shard shapes |
| `test_engine.py` | 1A | Adapter, shard manager, KV cache, forward pass, generation |
| `test_pipeline.py` | 1B | Template loading, data adapters, pipeline execution, token budgets |
| `test_integration.py` | 2 | Engine wired into pipeline end-to-end |
| `test_persistence.py` | 3 | Database CRUD, ingestion, checkpointing, cycle worker, session recovery |
| `test_server.py` | 4 | All API endpoints, authentication, dashboard |

---

## 6. Starting the server

### Via start.sh (recommended)

```bash
bash start.sh
```

Runs pre-flight checks (Python version, dependencies, model verification, test suite),
then starts the server on port 8000.

Override the port:
```bash
COURIER_PORT=9000 bash start.sh
```

### Via uvicorn directly

```bash
# Development (no auth required)
python -m uvicorn src.server:app --host 0.0.0.0 --port 8000 --app-dir .

# Insecure mode (same as development, explicit flag)
python -c "
import sys; sys.path.insert(0,'src')
from server import create_app
import uvicorn
app = create_app(insecure=True)
uvicorn.run(app, host='0.0.0.0', port=8000)
"
```

### Via CLI

```bash
python -m src.cli start --insecure --port 8000
```

### First-run authentication

On first start, the server generates an API token and prints it once:

```
API token (save this): 46RvVrRA4U3pl_4zZIIsi_xhS7nOosnexhRJb0jiCX8
```

Save this token. The dashboard prompts for it on first access. Store in
`localStorage` via the dashboard auth screen.

The `--insecure` flag bypasses all authentication. Use it for development
and closed-network deployments only.

---

## 7. Dashboard walkthrough

Navigate to `http://localhost:8000/` after starting the server.

The dashboard has two tab groups:

**Ops (read-only):** MONITOR · DATA · RESULTS · HISTORY  
**Config (write, requires auth):** RUN · CONFIG

### MONITOR

Live system status. Refreshes every 2 seconds during inference, 5 seconds at idle.

- **Active Cycle** — current stage, generation/layer progress bars, tokens/hour, ETA
- **Data Ingestion** — total records in buffer, unconsumed count, sources breakdown
- **System** — RAM, disk, CPU gauges; SSD write tracking; KV cache stats; auto-resume state
- **Model** — loaded model name, params, dtype, adapter, file size
- **Template** — active template name, stage count, version

### DATA

Ingestion buffer viewer. Upload data files here.

- **Upload zone** — drag JSON or CSV files in; records land in the ingestion buffer
- **Filter bar** — filter by source, consumed/unconsumed state, or search content
- **Record list** — click any record to expand and inspect raw content

### RESULTS

Stage-by-stage output from completed cycles. Select a cycle in the left panel to
view all stage outputs. Download as Markdown or JSON with the export buttons.

### HISTORY

Chronological cycle log. Click any completed cycle to jump to its results.
Failed cycles show the error message inline.

### RUN

Configure and launch an inference cycle.

- **Template** — select from loaded templates or upload a `.json` file
- **Model** — select from models in the `models/` directory
- **Cycles** — number of cycles to run (0 = unlimited)
- **Temperature / Top-p** — sampling parameters (Qwen3: 0.6/0.95 for thinking, 0.7/0.8 non-thinking)
- **Max Tokens** — per-stage generation limit
- **Checkpoint Interval** — save state every N tokens
- **Throttle %** — yield CPU to data collection during inference
- **Available Data** — unconsumed record count by source

Click **▶ Run Cycle** to start. Monitor progress in the MONITOR tab.

**Workflow:** Upload data in DATA → configure in RUN → watch in MONITOR → read in RESULTS.

### CONFIG

Persistent system defaults. Changes are saved to `courier_config.json` at the
project root. The RUN tab inherits these defaults.

---

## 8. CLI reference

```bash
# Server
python -m src.cli start [--insecure] [--port PORT]
python -m src.cli status

# Authentication
python -m src.cli token create --name NAME [--read-only]
python -m src.cli token list
python -m src.cli token revoke NAME

# Models
python -m src.cli model list
python -m src.cli model verify ID

# Templates
python -m src.cli template list
python -m src.cli template show ID

# Data ingestion
python -m src.cli ingest FILE_OR_DIR [--source-id ID]
python -m src.cli data status

# Cycle control
python -m src.cli run TEMPLATE_ID --model MODEL_ID [--cycles N] [--output PATH]
python -m src.cli cycle status
python -m src.cli cycle pause
python -m src.cli cycle resume
python -m src.cli cycle cancel

# Results
python -m src.cli result latest
python -m src.cli result list
python -m src.cli result CYCLE_ID
python -m src.cli export CYCLE_ID -o report.md
python -m src.cli export CYCLE_ID --json -o report.json
```

---

## 9. Data ingestion

Courier accepts JSON and CSV files. Records land in a SQLite buffer and are marked
consumed when a cycle processes them.

### From the dashboard

1. Open the **DATA** tab
2. Click **Browse...** or drag a file onto the upload zone
3. Accepted formats: `.json` (array of objects), `.csv` (one row per record)
4. The file is saved to `data/` and records are ingested into the buffer
5. The MONITOR tab and RUN tab show the updated unconsumed count

### From the CLI

```bash
# Ingest a single file
python -m src.cli ingest data/co2_readings.json

# Ingest a directory (all .json and .csv files)
python -m src.cli ingest data/sensor_logs/ --source-id co2_north

# Check buffer state
python -m src.cli data status
```

### JSON format

Arrays of objects are recommended. Each object becomes one record.

```json
[
  {"timestamp": "2026-05-24T18:00:00Z", "sensor": "CO2-N1", "ppm": 412.3, "temp_c": 14.1},
  {"timestamp": "2026-05-24T18:30:00Z", "sensor": "CO2-N1", "ppm": 415.7, "temp_c": 14.3}
]
```

Single objects and JSONL are also accepted.

### CSV format

Standard CSV with a header row. Each data row becomes one record.

```csv
timestamp,sensor,ppm,temp_c
2026-05-24T18:00:00Z,CO2-N1,412.3,14.1
2026-05-24T18:30:00Z,CO2-N1,415.7,14.3
```

### Source naming

The source ID is derived from the filename stem (`co2_readings.json` → `co2_readings`).
Override with `--source-id`. Templates reference sources by this ID in their
`data.sources` configuration.

---

## 10. Template authoring

A template is a JSON file that fully specifies an inference workflow. It defines
the model, data sources, and a sequential chain of inference stages.

### Minimal template

```json
{
  "template": {
    "id": "my_template",
    "name": "My Analysis"
  },
  "model": {
    "id": "Qwen/Qwen3-0.6B"
  },
  "data": {
    "sources": {
      "default": {
        "adapter": "json_file",
        "budget_tokens": 1500
      }
    }
  },
  "stages": [
    {
      "label": "Summary",
      "system_prompt": "You are a field analyst. Summarize the data concisely.",
      "input": { "sources": ["default"] }
    }
  ]
}
```

Save to `templates/builtin/my_template.json` or upload via the RUN tab.

### Full template structure

```json
{
  "template": {
    "id": "eruption_risk_v2",
    "name": "Volcanic Eruption Risk Assessment",
    "description": "Multi-stage CoT pipeline for eruption risk",
    "version": "2.0.0",
    "author": { "name": "J. Ostrander", "organization": "Field Research Group" },
    "project": { "id": "volcan-norte-2026", "name": "Volcán Norte Monitoring" },
    "software": { "min_courier_version": "0.1.0" },
    "notes": { "docnotes": "Stages 1-2 run independently. Stage 3 integrates." }
  },
  "model": {
    "id": "Qwen/Qwen3-8B",
    "dtype": "bfloat16",
    "max_new_tokens": 2048,
    "temperature": 0.3,
    "top_p": 0.9
  },
  "data": {
    "sources": {
      "co2": {
        "adapter": "json_file",
        "budget_tokens": 800
      },
      "seismic": {
        "adapter": "json_file",
        "budget_tokens": 400
      },
      "weather": {
        "adapter": "json_file",
        "budget_tokens": 200
      }
    }
  },
  "stages": [
    {
      "label": "CO₂ Analysis",
      "system_prompt": "You are a geochemist. Analyze CO₂ readings for anomalies.",
      "input": { "sources": ["co2"] }
    },
    {
      "label": "Seismic Analysis",
      "system_prompt": "You are a seismologist. Analyze seismic events.",
      "input": { "sources": ["seismic"] }
    },
    {
      "label": "Risk Integration",
      "thinking": true,
      "system_prompt": "You are a volcanologist. Integrate all signals into a risk assessment.",
      "input": { "prior": "all", "sources": ["weather"] }
    },
    {
      "label": "Critical Review",
      "system_prompt": "You are a critical reviewer. Identify gaps, uncertainties, and caveats.",
      "input": { "prior": "last" }
    }
  ]
}
```

### Stage input modes

| `input` field | What the stage receives |
|---|---|
| `{"sources": ["co2", "seismic"]}` | Data from named sources only |
| `{"prior": "last"}` | Output from the immediately preceding stage |
| `{"prior": "all"}` | Outputs from all preceding stages, labelled |
| `{"prior": "all", "sources": ["weather"]}` | All prior outputs + named source data |

### Thinking mode

Set `"thinking": true` on any stage to enable Qwen3's reasoning chain. The model
works through the problem explicitly before writing its answer. Produces higher-quality
output at the cost of more tokens and time. Recommended for integration and
review stages.

Sampling parameters for thinking mode: `temperature: 0.6, top_p: 0.95`.  
Non-thinking: `temperature: 0.7, top_p: 0.8`.

### Data adapters

| Adapter | Description |
|---|---|
| `json_file` | Reads JSON files; renders records as a markdown table |
| `csv_file` | Reads CSV files; renders as a markdown table |
| `verbatim` | Passes text through as-is, truncated to budget |

The pipeline resolves source files by matching the source name to files in the `data/`
directory. A source named `co2` matches `data/co2.json` or `data/co2.csv`. The
`default` source matches any JSON file.

### Token budget

Each source has a `budget_tokens` limit. The pipeline allocates up to that many tokens
for that source. If total budgets exceed the available context window, they are scaled
proportionally. A rough estimate of 4 characters per token is used.

---

## 11. Configuration reference

All settings are persisted in `courier_config.json` at the project root. Set them
via the CONFIG tab or via `POST /api/config`.

| Parameter | Default | Description |
|---|---|---|
| `max_cycles` | `0` | Cycles to run per trigger. 0 = unlimited until data runs out |
| `trigger_threshold` | `0` | Minimum unconsumed records before a cycle starts. 0 = any data |
| `auto_resume` | `true` | Automatically resume interrupted cycles on restart |
| `checkpoint_interval` | `10` | Save checkpoint to DB every N tokens generated |
| `temperature` | `0.3` | Default sampling temperature |
| `top_p` | `0.9` | Default nucleus sampling threshold |
| `top_k` | `20` | Default top-k filter (Qwen3 default) |
| `max_new_tokens` | `2048` | Default maximum tokens per stage |
| `max_kv_ram_layers` | `-1` | KV cache layers in RAM. -1 = all; lower values spill to disk |
| `kv_cache_dir` | `""` | Spillover directory for KV cache. Empty = RAM only |
| `export_dir` | `./export/` | Output directory for completed cycle markdown files |

Template-level `model` settings override the system defaults for that run.
Stage-level `temperature` and `max_new_tokens` override template defaults for that stage.

---

## 12. Project structure

```
courier/
├── src/
│   ├── __init__.py               # version string (0.1.0)
│   ├── engine/
│   │   ├── streamer.py           # Layer-streaming forward pass + generate()
│   │   ├── kv_cache.py           # RAM-first KV cache with LRU disk spillover
│   │   ├── sampler.py            # Temperature / top-p / top-k sampling
│   │   ├── checkpoint.py         # Token-level checkpoint callbacks
│   │   ├── inference.py          # Chat template formatting + make_infer_fn()
│   │   └── worker.py             # Cycle loop: collect → infer → report → repeat
│   ├── core/
│   │   ├── adapter/
│   │   │   ├── base.py           # ModelAdapter ABC + ModelConfig dataclass
│   │   │   ├── registry.py       # Auto-detection via config.json model_type
│   │   │   └── qwen3.py          # Qwen3 adapter (0.6B–14B)
│   │   ├── shard_manager.py      # Persistent safe_open handle + demand loading
│   │   ├── db.py                 # SQLite schema + all CRUD operations
│   │   └── security.py           # Token management, TLS helpers
│   ├── data/
│   │   ├── adapter_base.py       # DataAdapter ABC
│   │   ├── adapters/
│   │   │   ├── json_file.py      # JSON → markdown table
│   │   │   ├── csv_file.py       # CSV → markdown table
│   │   │   └── verbatim.py       # Pass-through text
│   │   └── ingest.py             # File ingestion into SQLite buffer
│   ├── pipeline.py               # Stage execution, input assembly, token budgets
│   ├── template.py               # JSON template loading, validation, defaults
│   ├── server.py                 # FastAPI app, SSE push, all /api/* endpoints
│   └── cli.py                    # CLI entry point
├── static/
│   ├── dashboard.html            # Production dashboard (served by FastAPI)
│   └── dashboard-dev.html        # Development dashboard (fixture data, offline)
├── templates/
│   └── builtin/
│       ├── field_report_summary.json   # 1-stage summarization
│       ├── sensor_anomaly.json         # 2-stage anomaly detection + review
│       ├── eruption_risk_test.json     # 4-stage CoT with thinking mode
│       └── test_analysis.json          # 2-stage test template
├── models/                       # Downloaded model shards (gitignored)
├── data/                         # Ingested data files
├── export/                       # Cycle output files (Markdown)
├── scripts/
│   ├── download_model.py         # HuggingFace snapshot download
│   └── verify_model.py           # Shard integrity check
├── tests/
│   ├── test_scaffold.py          # Phase 0
│   ├── test_engine.py            # Phase 1A
│   ├── test_pipeline.py          # Phase 1B
│   ├── test_integration.py       # Phase 2
│   ├── test_persistence.py       # Phase 3
│   └── test_server.py            # Phase 4
├── requirements.txt
├── start.sh                      # One-command setup and launch
├── courier_config.json           # Persistent config (created on first save)
└── courier.db                    # SQLite database (created on first start)
```

### Key data flows

**Inference path:**  
`input_ids` → `LayerStreamer.forward()` → 28× `forward_layer()` (load weights → attention → MLP → residual) → `rmsnorm` → `logits @ embed.T` → `sample()` → token

**Pipeline path:**  
`Template` + `data_paths` + `infer_fn` → stage 1: fetch sources → format prompt → `infer_fn` → stage result → stage 2: prior output + sources → format prompt → `infer_fn` → ... → collate → write Markdown

**Cycle path:**  
`run_worker()` → check unconsumed records → `db.snapshot()` → `run_pipeline()` → `db.save_stage()` × N → write export file → `db.update_cycle(complete)` → repeat if data remains

**SSE path:**  
`_build_full_state()` every 2–5s → JSON diff → `data: {...}\n\n` → `EventSource` → `D = state; render()`

---

## Appendix: Qwen3 architecture notes

The forward pass implements the Qwen3 architecture exactly. Key details that differ
from Llama-family models and are common sources of bugs:

- **`head_dim = 128`** is independent of `hidden_size = 1024`. `num_attention_heads × head_dim = 2048 ≠ hidden_size`. The `o_proj` weight is `(1024, 2048)`, not `(1024, 1024)`.
- **QK-LayerNorm** — per-head RMSNorm applied to Q and K after projection, before RoPE. Weight shape `(128,)`, not `(hidden_size,)`.
- **RoPE layout** — split-half (GPT-NeoX style): `rotate_half(x)` splits at `D//2` and returns `[-x2, x1]`. Not interleaved pairs.
- **RoPE theta** — `1,000,000` (not 10,000 as in Llama-1, not 500,000 as in Llama-3).
- **Tied embeddings** — `lm_head.weight` is not stored separately. `model.embed_tokens.weight` serves as both embedding lookup and final projection.
- **No biases** — `attention_bias: false`. No `*.bias` keys in the shard.
- **Stop tokens** — `[151645, 151643]` (`<|im_end|>` and `<|endoftext|>`).
- **KV cache geometry** — per layer per token in BF16: `2 × 8 × 128 × 2 = 4,096 bytes`. All 28 layers: 112 KiB/token.
