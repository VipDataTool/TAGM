# Llama 3 Adapter — Build Report

Adapter implementation for the Meta Llama 3 model family in Courier's
layer-streaming inference engine. Covers instruct-tuned text-only
variants: Llama 3 (8B, 70B), Llama 3.1 (8B, 70B, 405B), and
Llama 3.2 (1B, 3B).

**Status:** Adapter complete. Engine generalized. Dashboard wired.
Awaiting end-to-end validation against HuggingFace reference outputs.

**Source material:** The adapter was ported from TAGM's existing
`Llama3Adapter` (analysis-focused, hook-point-based) and rebuilt
against Courier's inference-focused adapter interface. Architecture
details were independently verified against HuggingFace `config.json`
files, Meta's reference `generation.py`, the Llama 3 model cards,
and the `transformers` / `llama.cpp` RoPE scaling implementations.

---

## Contents

1. [Architecture summary](#1-architecture-summary)
2. [Dimensional reference](#2-dimensional-reference)
3. [Differences from Qwen3](#3-differences-from-qwen3)
4. [Differences across the 3.0 / 3.1 / 3.2 line](#4-differences-across-the-30--31--32-line)
5. [Changeset](#5-changeset)
6. [RoPE scaling implementation](#6-rope-scaling-implementation)
7. [Tokenizer and chat template](#7-tokenizer-and-chat-template)
8. [Sampling defaults](#8-sampling-defaults)
9. [Engine generalization](#9-engine-generalization)
10. [Dashboard integration](#10-dashboard-integration)
11. [Validation plan](#11-validation-plan)
12. [Known edge cases](#12-known-edge-cases)
13. [Memory budget](#13-memory-budget)

---

## 1. Architecture summary

Llama 3 is a pre-norm decoder-only transformer. The forward pass
through each layer is: RMSNorm → Q/K/V projection → RoPE → GQA
attention → output projection → residual add → RMSNorm → SwiGLU
MLP → residual add. This is structurally identical to Qwen3, with
two subtractions (no QK-norm, no attention biases) and one addition
(piecewise RoPE scaling on 3.1/3.2).

The entire Llama 3.x text-only family uses the same HuggingFace
architecture class (`LlamaForCausalLM`, `model_type: "llama"`).
A single Courier adapter class serves all variants, branching on
three config-driven knobs: `rope_scaling`, `tie_word_embeddings`,
and the `eos_token_id` list.

Key architectural facts:

- Standard RMSNorm with `eps = 1e-5`. No `(1 + weight)` variant.
  Uses the same code path as Qwen3 (not Qwen3.5).
- GQA with `num_key_value_heads = 8` for every text-only model from
  1B through 405B. KV heads are always 8; query heads vary by size.
- SwiGLU MLP: `down_proj(silu(gate_proj(x)) * up_proj(x))`. No
  biases on any projection.
- RoPE with `theta = 500,000` universally. Split-half layout (same
  as Qwen3). No partial rotary factor.
- No QK-norm. Q and K go straight from projection to RoPE.
- No attention biases (`attention_bias: false`). No MLP biases.
- head_dim = 128 for all models except 3.2-1B (head_dim = 64).
- Vocabulary: 128,256 tokens (tiktoken-based BPE).

---

## 2. Dimensional reference

All values are verbatim from HuggingFace `config.json` files
(NousResearch and alpindale mirrors), cross-validated against Meta's
"Llama 3 Herd of Models" paper.

| Field | 3-8B | 3-70B | 3.1-8B | 3.1-70B | 3.1-405B | 3.2-1B | 3.2-3B |
|---|---|---|---|---|---|---|---|
| `num_hidden_layers` | 32 | 80 | 32 | 80 | 126 | 16 | 28 |
| `hidden_size` | 4096 | 8192 | 4096 | 8192 | 16384 | 2048 | 3072 |
| `intermediate_size` | 14336 | 28672 | 14336 | 28672 | 53248 | 8192 | 8192 |
| `num_attention_heads` | 32 | 64 | 32 | 64 | 128 | 32 | 24 |
| `num_key_value_heads` | 8 | 8 | 8 | 8 | 8 | 8 | 8 |
| `head_dim` | 128 | 128 | 128 | 128 | 128 | 64 | 128 |
| `max_position_embeddings` | 8192 | 8192 | 131072 | 131072 | 131072 | 131072 | 131072 |
| `rope_theta` | 500000 | 500000 | 500000 | 500000 | 500000 | 500000 | 500000 |
| `rope_scaling` | null | null | llama3 f=8 | llama3 f=8 | llama3 f=8 | llama3 f=32 | llama3 f=32 |
| `tie_word_embeddings` | false | false | false | false | false | true | true |
| `vocab_size` | 128256 | 128256 | 128256 | 128256 | 128256 | 128256 | 128256 |
| `rms_norm_eps` | 1e-5 | 1e-5 | 1e-5 | 1e-5 | 1e-5 | 1e-5 | 1e-5 |
| `bos_token_id` | 128000 | 128000 | 128000 | 128000 | 128000 | 128000 | 128000 |
| `eos_token_id` | 128009 | 128009 | list | list | list | list | list |

Where "list" = `[128001, 128008, 128009]`.

---

## 3. Differences from Qwen3

The adapter is structurally similar to Qwen3 — same decoder-block
layout, same projection names under `self_attn`/`mlp`, same GQA
mechanism. The differences are specific and enumerable:

**No QK-norm.** Qwen3 applies per-head RMSNorm to Q and K after
projection, before RoPE. Llama 3 does not. The adapter's
`LAYER_WEIGHT_ROLES` omits `q_norm` and `k_norm`, and the adapter
reports `has_qk_norm = False`. The engine was updated to gate the
QK-norm step on this property.

**No attention biases.** Qwen2/Qwen3 retain `q_proj.bias`,
`k_proj.bias`, `v_proj.bias` in some variants. Llama 3 has
`attention_bias: false` and `mlp_bias: false` across all models.
No bias tensors in the weight keys.

**RMSNorm formulation.** Qwen3.5 uses `(1 + weight) * x / RMS(x)`
with weight initialized to zeros. Llama 3 uses standard
`weight * x / RMS(x)` with weight initialized to ones. Same code
path as Qwen3; the adapter inherits `rmsnorm_uses_residual_weight
= False` from the base class.

**RoPE theta.** Llama 3: 500,000. Qwen3: 1,000,000.

**RoPE scaling.** Qwen3 long-context variants use YaRN
(`rope_type: "yarn"`). Llama 3.1/3.2 use a custom piecewise scheme
(`rope_type: "llama3"`). These are mathematically different; the
Llama 3 scheme is implemented in `build_llama3_rope_inv_freq()`.

**Tokenizer.** Qwen3 uses SentencePiece BPE with 151,936 vocabulary.
Llama 3 uses tiktoken-based BPE with 128,256 vocabulary. Both are
HuggingFace "fast" tokenizers; `AutoTokenizer` handles either.

**Chat template.** Qwen3: ChatML (`<|im_start|>role\n...\n<|im_end|>`).
Llama 3: Meta's header_id format
(`<|start_header_id|>role<|end_header_id|>\n\n...<|eot_id|>`).
Different special-token IDs entirely.

**Thinking mode.** Qwen3 supports `enable_thinking=True/False` with
`<think>`/`</think>` tokens. Llama 3 has no native thinking mode.
The adapter exposes `enable_thinking` in its defaults but sets the
value to `False` with a tooltip noting it is ignored.

**Sampling defaults.** Qwen3 recommends temperature 0.7, top_p 0.8,
top_k 20, presence_penalty 1.5. Llama 3 recommends temperature 0.6,
top_p 0.9, top_k disabled (0), presence_penalty 0.

---

## 4. Differences across the 3.0 / 3.1 / 3.2 line

All three releases share the same architecture class and weight key
layout. The differences are config-driven:

**Llama 3 → 3.1:** Same dimensions on 8B and 70B. Added the
`rope_scaling` dict with `rope_type: "llama3"` and `factor: 8.0` for
128K context. Added the 405B model. Added the `<|eom_id|>` (128008)
and `<|python_tag|>` (128011) tokens for tool calling. Changed
`eos_token_id` in config from integer 128009 to list
`[128001, 128008, 128009]`. Zero structural changes — same adapter
code, RoPE scaling activates when `rope_scaling` is present in config.

**Llama 3.1 → 3.2 (text):** Added 1B and 3B sizes with new
dimensions (GQA 32:8 and 24:8 respectively). Same piecewise scaling
type but `factor: 32.0` instead of 8.0. Tied embeddings on 1B/3B
(`tie_word_embeddings: true`; `lm_head.weight` absent from
safetensors). Explicit `head_dim: 64` on 1B. The 11B and 90B
Llama 3.2 models are vision-language
(`MllamaForConditionalGeneration`) — out of scope for this adapter.

**Conclusion:** One adapter class serves all three versions. Branch
only on `rope_scaling`, `tie_word_embeddings`, and the stop-token set.

---

## 5. Changeset

### New file

| File | Lines | Purpose |
|---|---|---|
| `src/core/adapter/llama3.py` | 295 | Adapter class + piecewise RoPE function |

### Modified files

| File | +/- | What changed |
|---|---|---|
| `src/engine/streamer.py` | +20 / −13 | QK-norm conditional; RoPE delegates to adapter; docstring generalized |
| `src/core/adapter/base.py` | +47 / −0 | `rope_scaling` on ModelConfig; `has_qk_norm`, `rope_layout`, `build_rope_inv_freq` on ModelAdapter |
| `src/server.py` | +19 / −3 | Llama 3 models in SUPPORTED_MODELS; `_get_model_info` no longer hardcodes `Qwen/`; `adapter_family` display name in API |
| `static/dashboard.html` | +15 / −10 | Adapter family badge; top_k min=0; zero-safe serialization; adapter name display |
| `src/core/adapter/registry.py` | +2 / −0 | `"llama": Llama3Adapter` |
| `src/core/adapter/qwen3.py` | +1 / −0 | `FAMILY_DISPLAY_NAME = "Qwen3"` |
| `src/core/adapter/qwen35.py` | +1 / −0 | `FAMILY_DISPLAY_NAME = "Qwen3.5"` |

### What was NOT changed

The hybrid streamer (`hybrid_streamer.py`) was not modified. Llama 3
text-only models use the standard `LayerStreamer`, not the
`HybridStreamer`. The `build_engine()` function in `inference.py`
already routes to the correct streamer based on
`adapter.is_multimodal` and `adapter.has_hybrid_attention` — Llama 3
reports both as False, so it takes the `LayerStreamer` path.

The KV cache manager, shard manager, sampler, checkpoint system,
pipeline, and template engine are model-agnostic by design and
required no changes. The adapter's `layer_weight_keys()` output is
the only interface the shard manager reads, and it returns the
correct keys for Llama 3 automatically.

---

## 6. RoPE scaling implementation

Llama 3.0 uses standard RoPE (no scaling). Llama 3.1 and 3.2 extend
context to 128K tokens via Meta's "llama3" piecewise frequency
interpolation. This is NOT NTK-aware scaling and NOT YaRN — it is a
scheme specific to the Llama 3 family.

The implementation lives in `build_llama3_rope_inv_freq()` in
`llama3.py`. The algorithm:

For each inverse frequency in the standard RoPE table, compute its
wavelength `λ = 2π / freq`. Compare against two thresholds derived
from `original_max_position_embeddings` (always 8192 for Llama 3):

- `low_freq_wavelen = 8192 / low_freq_factor` (= 8192 / 1.0 = 8192)
- `high_freq_wavelen = 8192 / high_freq_factor` (= 8192 / 4.0 = 2048)

Then:

- If `λ < high_freq_wavelen`: leave frequency unchanged (high
  frequency — encodes fine-grained positional detail, does not need
  scaling to generalize beyond the training window).
- If `λ > low_freq_wavelen`: divide frequency by `factor`
  (low frequency — encodes coarse positional structure, must be
  compressed to fit the 128K window).
- Otherwise: smooth interpolation between the two regimes via
  `smooth = (8192 / λ − low_freq_factor) / (high_freq_factor − low_freq_factor)`,
  then `freq_scaled = (1 − smooth) * freq / factor + smooth * freq`.

Parameters by model line:

| Line | factor | low_freq_factor | high_freq_factor | original_max_pos |
|---|---|---|---|---|
| 3.1 (8B/70B/405B) | 8.0 | 1.0 | 4.0 | 8192 |
| 3.2 (1B/3B) | 32.0 | 1.0 | 4.0 | 8192 |

The 3.2 models use a higher factor because they were post-trained to
128K from the same 8K base window as the larger family — a wider
compression ratio requires more aggressive scaling of the low
frequencies.

The adapter's `build_rope_inv_freq()` method is the authoritative
source. The engine's `_build_inv_freq()` delegates to it, which
means a future adapter with YaRN or NTK-aware scaling just needs to
override the same method — no engine changes.

**Reference implementations verified against:** HuggingFace
`transformers` `modeling_rope_utils.py` and llama.cpp PR #8676
(`ggml-org/llama.cpp`, "Add llama 3.1 rope scaling factors to llama
conversion and inference" by jmorganca).

---

## 7. Tokenizer and chat template

### Tokenizer

Tiktoken-based BPE, loaded via `AutoTokenizer.from_pretrained()`.
Vocabulary size 128,256: 128,000 BPE merges and 256 reserved special
tokens (IDs 128000–128255).

Canonical special tokens (stable across 3.0/3.1/3.2):

| Token | ID | Role |
|---|---|---|
| `<\|begin_of_text\|>` | 128000 | BOS |
| `<\|end_of_text\|>` | 128001 | Natural EOS |
| `<\|start_header_id\|>` | 128006 | Chat header open |
| `<\|end_header_id\|>` | 128007 | Chat header close |
| `<\|eom_id\|>` | 128008 | End-of-message (tool calling) |
| `<\|eot_id\|>` | 128009 | End-of-turn (assistant stop) |
| `<\|python_tag\|>` | 128011 | Tool-call code block (3.1+) |

The adapter's `stop_token_ids` property returns `{128001, 128008,
128009}` — generation terminates on any of these. This is the
forward-compatible set; Llama 3.0 only used 128009 in its config,
but stopping on all three is safe.

### Chat template

Meta's "header_id" format (not ChatML, not Llama 2's
`[INST]...[/INST]`):

```
<|begin_of_text|><|start_header_id|>system<|end_header_id|>

{system_prompt}<|eot_id|><|start_header_id|>user<|end_header_id|>

{user_message}<|eot_id|><|start_header_id|>assistant<|end_header_id|>

```

Key rule: the literal sequence after `<|end_header_id|>` is two
newline characters (`\n\n`). They are part of the trained format and
are not optional.

Courier uses `tokenizer.apply_chat_template()` which handles this
automatically. The common bug (documented in HuggingFace discussion
#97 on `meta-llama/Llama-3.1-8B-Instruct`) is double-BOS: rendering
the template with `apply_chat_template`, then passing the result
through `tokenizer(...)` without `add_special_tokens=False`. The
Courier inference path avoids this because `apply_chat_template`
returns token IDs directly.

---

## 8. Sampling defaults

Meta's reference `generation.py` and HuggingFace `generation_config.json`
both default to `temperature=0.6, top_p=0.9, do_sample=True`.

The adapter's `recommended_defaults()`:

| Parameter | Value | Rationale |
|---|---|---|
| `temperature` | 0.6 | Meta's default. Lower than Qwen3's 0.7. |
| `top_p` | 0.9 | Meta's default. Higher than Qwen3's 0.8. |
| `top_k` | 0 (disabled) | Meta does not use top_k. Rely on top_p. |
| `presence_penalty` | 0.0 | RLHF is well-calibrated. Penalty > 1.1 degrades 8B output. |
| `enable_thinking` | false | No native thinking mode. Setting is ignored. |
| `max_new_tokens` | 2048 | Same practical edge-hardware default as Qwen3. |

Each parameter carries a tooltip string explaining the reasoning.
These are served to the dashboard via `/api/config/defaults` and
displayed on hover in the Config tab's Inference Defaults section.

When a Llama 3 model is loaded, `apply_adapter_defaults()` merges
these into the system config, overwriting only parameters that the
operator has not manually changed from the generic factory defaults.
When the operator resets config, adapter defaults are re-applied.

---

## 9. Engine generalization

The `LayerStreamer` was originally written for Qwen3 and hardcoded
two Qwen3-specific assumptions. Both were removed:

### QK-norm conditional

Before:

```python
# ── QK-LayerNorm (Qwen3-specific) ───────────────────
q = rmsnorm(q, w["q_norm"], self.eps)
k = rmsnorm(k, w["k_norm"], self.eps)
```

After:

```python
# ── QK-LayerNorm (model-family-specific) ────────────
if self.adapter.has_qk_norm:
    q = rmsnorm(q, w["q_norm"], self.eps)
    k = rmsnorm(k, w["k_norm"], self.eps)
```

Without this, Llama 3 would crash with `KeyError: 'q_norm'` because
its `layer_weight_keys()` does not include q_norm or k_norm.

The `has_qk_norm` property was added to the `ModelAdapter` base
class (default `False`). Qwen3 and Qwen3.5 already had it defined on
their own classes; now they are properly overriding the base default.

### RoPE delegation

Before:

```python
def _build_inv_freq(self) -> torch.Tensor:
    dim = self.config.head_dim
    theta = self.config.rope_theta
    inv_freq = 1.0 / (theta ** (torch.arange(0, dim, 2, ...) / dim))
    return inv_freq.to(self.device)
```

After:

```python
def _build_inv_freq(self) -> torch.Tensor:
    return self.adapter.build_rope_inv_freq(self.device)
```

The `build_rope_inv_freq()` method was added to the base adapter
class with a default implementation that computes standard RoPE from
`rope_theta` and `head_dim`. The Llama3Adapter overrides it to apply
the piecewise scaling when `rope_scaling` is present. The Qwen3 and
Qwen3.5 adapters inherit the default, which is numerically identical
to the old inline computation.

This means any future adapter with non-standard RoPE (YaRN, NTK-aware,
ALiBi, etc.) overrides one method and the engine picks it up with no
further changes.

---

## 10. Dashboard integration

### Adapter family badge

The Config tab's "Inference Defaults" section header now shows a
small badge with the adapter family display name (e.g. "LLAMA 3.X"
or "QWEN3"). This makes the active adapter immediately visible when
tuning parameters — the operator knows which model family's defaults
they're looking at.

The badge is driven by `FAMILY_DISPLAY_NAME` on each adapter class,
served via `/api/config/defaults` as `adapter_family`, and rendered
as a `.fam-badge` span. It re-fetches automatically on model load.

### Model info panel

The model info panel in the Monitor tab now shows the adapter family
display name instead of the raw `model_type` string. The model ID is
derived from `SUPPORTED_MODELS` when available, falling back to the
directory name for models not in the list.

### top_k = 0 fix

Llama 3 disables top_k by default. Two bugs in the dashboard
prevented this from working:

1. The input field had `min="1"` — changed to `min="0"`.
2. The save function used `parseInt(cf.top_k)||20`, which silently
   rewrote 0 to 20 (because `0||20 === 20`). Changed to
   `isNaN(parseInt(cf.top_k))?20:parseInt(cf.top_k)`.

The same zero-safe pattern was applied to `presence_penalty` (Llama 3
default is 0.0).

---

## 11. Validation plan

### Stage 1 — Config parsing

Load `config.json` from each supported variant and verify the adapter
produces the correct `ModelConfig`:

- Llama-3-8B-Instruct: `rope_scaling=None, tie=False, eos=[128009]`
- Llama-3.1-8B-Instruct: `rope_scaling.factor=8.0, tie=False, eos=[128001,128008,128009]`
- Llama-3.2-1B-Instruct: `rope_scaling.factor=32.0, tie=True, head_dim=64, eos=[128001,128008,128009]`
- Llama-3.2-3B-Instruct: `rope_scaling.factor=32.0, tie=True, head_dim=128, eos=[128001,128008,128009]`

### Stage 2 — Weight loading

Verify the shard manager loads all keys for each layer without
errors. Specifically:

- 9 weight tensors per layer (no q_norm/k_norm).
- `lm_head.weight` loads for 8B/70B, returns None for 1B/3B.
- Tied models: `embed_tokens.weight` is used for unembedding.

### Stage 3 — RoPE numerical verification

At `temperature=0` with a fixed prompt, compare the first 100
sampled tokens against HuggingFace `transformers` for:

- Llama-3-8B-Instruct (no scaling — validates base RoPE)
- Llama-3.1-8B-Instruct (piecewise factor=8.0)
- Llama-3.2-1B-Instruct (piecewise factor=32.0 + tied + head_dim=64)
- Llama-3.2-3B-Instruct (piecewise factor=32.0 + tied)

All four must produce byte-identical token sequences to the reference.
The mlx-swift-lm bug report (issue #110) provides a useful canary:
divergence around token ~92 with a long prompt indicates RoPE scaling
is being skipped or misparameterized.

### Stage 4 — Qwen3 regression

Run the existing test suite to confirm the streamer changes (QK-norm
conditional, RoPE delegation) do not affect Qwen3 output. The
`has_qk_norm=True` path and the default `build_rope_inv_freq()`
should produce identical results to the previous inline code.

---

## 12. Known edge cases

### Tied embeddings on 3.2-1B / 3.2-3B

`lm_head.weight` is **absent** from the safetensors. The shard
manager's `load_lm_head()` returns `None`, and the streamer falls
through to `logits = last_hidden @ self._embed.T`. This path already
existed for Qwen3 small models and was exercised there. The critical
thing is that `embed_tokens.weight` must remain resident in RAM for
the entire generation — it is needed at both the embedding step and
the final unembedding step.

See `sgl-project/sglang#2935` and `vllm-project/vllm#5621` for the
crash reports that identified this as the most common loader failure
mode for Llama 3.2.

### head_dim = 64 on 3.2-1B

Llama 3.2-1B has `head_dim: 64` in its config even though
`hidden_size / num_attention_heads = 2048 / 32 = 64` would produce
the same value. The adapter always trusts the explicit `head_dim`
field when present and falls back to the implicit calculation
otherwise. This matters for RoPE frequency computation (half the
frequencies compared to head_dim=128 models) and KV cache allocation.

### `<|python_tag|>` (token 128011)

This token is used for Llama 3.1+ tool calling. It was reported
missing from some tokenizer snapshots (`pytorch/torchtune#2424`).
The adapter does not reference it directly — tool calling is
out of scope for the initial text-only adapter — but downstream
code that processes tool-call outputs should look it up dynamically
via `tokenizer.convert_tokens_to_ids("<|python_tag|>")` rather than
hardcoding the ID.

### Double-BOS

The HuggingFace tokenizer's `apply_chat_template` prepends
`<|begin_of_text|>` automatically. If the rendered string is then
passed through `tokenizer(...)` without `add_special_tokens=False`,
a second BOS is inserted. Courier's inference path uses the token IDs
from `apply_chat_template` directly, avoiding this.

### eos_token_id type variance

Llama 3.0 configs store `eos_token_id` as an integer (128009).
Llama 3.1/3.2 configs store it as a list
(`[128001, 128008, 128009]`). The adapter's `_load_config` normalizes
both to a list. The adapter's `stop_token_ids` property returns the
full three-token set regardless of model line, which is safe and
forward-compatible.

---

## 13. Memory budget

Per-layer parameter cost in BF16 for the streaming sweet spot:

| Model | Layer params | Layer BF16 | Resident (embed + norm + lm_head) |
|---|---|---|---|
| 3.2-1B | ~16M | ~32 MB | ~0.5 GB (tied) |
| 3.2-3B | ~38M | ~76 MB | ~0.8 GB (tied) |
| 3-8B / 3.1-8B | ~109M | ~218 MB | ~2.0 GB |
| 3-70B / 3.1-70B | ~440M | ~880 MB | ~4.0 GB |
| 3.1-405B | ~1.3B | ~2.6 GB | ~8.0 GB |

KV cache per-token-per-layer (BF16):

```
2 (K+V) × 8 (kv_heads) × head_dim × 2 (bytes)
```

- head_dim=128: 4,096 bytes/token/layer
- head_dim=64 (3.2-1B only): 2,048 bytes/token/layer

Full KV cache at 8K context:

| Model | Layers | KV cache (8K) |
|---|---|---|
| 3.2-1B | 16 | 0.26 GB |
| 3.2-3B | 28 | 0.92 GB |
| 3-8B | 32 | 1.07 GB |
| 3-70B | 80 | 2.62 GB |
| 3.1-405B | 126 | 4.13 GB |

The 3.2-1B and 3.2-3B are comfortable streaming targets — total
working memory (one layer + resident + 8K KV cache) stays under 2 GB.
The 8B is the practical ceiling for 16 GB hardware with KV cache
spillover enabled. The 70B and 405B require aggressive KV disk
spillover and are measured in hours per response — firmly in
Courier's design envelope.

---

*Report generated alongside adapter build. Last updated with
changeset described in [section 5](#5-changeset).*
