# Courier — Dashboard Information-Design Spec

**Status:** Draft / proposed
**Scope:** Clarity and hierarchy of the existing dashboard — what the operator sees and how
fast they can read it. Not branding (logo/voice come later), not new features. Re-encoding and
re-grouping what's already there, plus two genuinely new at-a-glance encodings (bullet gauges,
sparklines). Touches `dashboard.html` styling/markup and a little server telemetry; no engine.
**Audience:** Maintainer/engineer; doubles as the rationale for each visual decision.
**Method base:** Tufte (data-ink, small multiples, sparklines), Few (monitoring dashboards,
bullet graphs), Bertin (visual variables), Ware (preattentive processing), Gestalt grouping,
Shneiderman ("overview first, zoom and filter, details on demand").

---

## 1. The core problem

The dashboard is **clean but flat**. It already avoids chartjunk — good — but every element
carries roughly equal visual weight, so nothing wins the eye. When you open the Monitor, there
is no single thing that answers *"is it working, and should I worry?"* in the first 200ms. You
have to read, not glance. For an unattended device you check periodically over months, glanceability
is the whole job.

Three specific failures, in priority order:

1. **No hierarchy.** The live cycle state, a six-cell metric grid, three progress bars, and the
   timer all compete. The most decision-relevant fact (is the run alive and advancing?) isn't
   the most salient thing on screen.
2. **Color without grammar.** Amber, blue, green, and red all appear, but their meaning isn't
   fixed. The CPU bar reads red at ~60% — is red "this metric's color" or "danger"? The operator
   can't know, so color stops being information (Bertin: a variable spent with no rule conveys
   nothing).
3. **Everything is instantaneous; nothing shows trend.** Every number is a scalar snapshot. For
   a courier that runs for weeks, the decision-shaped questions are *trajectories* — is tok/s
   degrading, is RAM creeping toward the budget, how fast is SSD wear accumulating? None of that
   is visible.

---

## 2. Principles (Courier-specific)

1. **One hero per view.** Each screen has exactly one element that's biggest and brightest —
   the thing the operator came to check. Everything else is demoted by size, weight, or value
   (Bertin) so the hero wins preattentively (Ware). On Monitor the hero is cycle state +
   progress; on Data it's the dataset queue; on Run it's the launch control.
2. **Color is semantic, and amber means *in transit*.** Fix the roles and never spend them
   decoratively:
   - **amber (accent)** = active / in-transit / the live thing (the brand color *is* the
     courier-on-the-road state — use it only for that),
   - **green** = healthy / delivered / within budget,
   - **red** = fault / past threshold,
   - **blue** = informational / links / neutral selection,
   - **muted/dim** = idle, secondary, at-rest.
   A gauge is not "red because it's the CPU gauge"; it's red only when it crosses a threshold.
3. **Show the data over time.** A device that runs for months earns trend, not just now.
   Sparklines (Tufte) for tok/s, RAM, and SSD-wear; the current scalar stays as the bold
   right-hand value, the sparkline sits beside it. Small, wordless, high-density.
4. **Gauges carry their own verdict.** A bar with no reference can't be read at a glance.
   Adopt Few's bullet-graph idea: each resource bar gets a qualitative range and a marker, so
   "is this OK?" is answered by the encoding, not by the operator doing arithmetic. RAM's marker
   is the resident budget; SSD's is a wear budget; CPU's is the Max-CPU setpoint.
5. **Group by mental model (common region).** Don't interleave "how hard is it working *now*"
   with "how is it holding up *over time*." Two categories, two regions.
6. **Overview → details on demand (Shneiderman).** Lead with a one-line status banner that
   resolves to a single state + the one number that matters; push the rest down. The popouts we
   just built are already this pattern (dataset queue → window); extend it.
7. **Keep the restraint.** The low-ink aesthetic is right. This pass *redistributes* ink toward
   the hero and trends; it does not add boxes, gradients, or ornament.

---

## 3. Audit + proposal, panel by panel

### 3.1 Active Cycle (the hero panel)
*Now:* "Untitled Project", operator·date, a status badge, "Stage 1/1", a large timer, three
stacked progress bars (Summary / Generation / Layer), then a 2×3 grid (Tokens/Hour,
Tokens/Second, Total Generated, Estimated Remaining, Checkpoints, Data Records). All roughly
equal weight.

*Issues:*
- The **timer** and the **metric grid** out-compete the actual status. The operator's first
  question is "alive and advancing?", which is the *badge* + the *bars* — currently not dominant.
- **Redundant metrics:** Tokens/Hour and Tokens/Second are the same fact in two units. Pick one
  (tok/s as the live rate) and free the cell.
- **The three bars are nested concepts shown as peers.** Stage progress contains generation
  progress contains the layer heartbeat. Equal styling hides the nesting.

*Proposal:*
- Promote a **status line** to hero: state word ("INFERRING") in the semantic color + cycle id +
  the single most useful number (ETA or tok/s). Largest type on the panel.
- Re-rank the bars: **Stage** (coarse, full width, bold) → **Generation** (medium) → **Layer**
  (thin heartbeat rule, dim until it sweeps). Size expresses granularity.
- Collapse the grid from six equal cells to a **primary trio** (tok/s + sparkline, ETA, total
  generated) and a **secondary line** (checkpoints, data records) in smaller, dimmer type.
- Drop Tokens/Hour (or make it the hover detail on tok/s).

### 3.2 System (split into two regions)
*Now:* RAM / Disk / CPU bars, then SSD Wear, Resident, KV Cache, Auto-Resume — all one stack.

*Issues:* mixes **live load** (RAM, CPU) with **durability/longevity** (SSD wear, checkpoints,
resident budget, auto-resume). Two different questions, one undifferentiated column. And the
bars have no thresholds, so their values aren't self-interpreting.

*Proposal:*
- **Region A — "Working" (live load):** CPU, RAM, tok/s — each a **bullet gauge** with a marker.
  RAM's marker = resident budget (so you *see* the ceiling we added); CPU's marker = Max-CPU
  setpoint; the bar turns amber as it approaches, red past it.
- **Region B — "Holding up" (durability):** SSD wear (with a sparkline of the wear trajectory and
  a marker for a wear budget), Resident (held/budget — already good), Auto-Resume, last checkpoint
  age. This is the courier-survival story in one region.
- Disk capacity is a slow scalar — fine as a plain labeled bar, lowest salience.

### 3.3 Data Ingestion / Data tab
*Now:* the dataset table (good, just shipped) and source cards on Monitor.
*Proposal:* minor — align the Monitor source cards to the same dense-table language as the Data
tab so the two views of the same data read identically (consistency = one less thing to learn).
Add a tiny rate sparkline per source (records/hr over time) since ingestion rate is a trend.

### 3.4 Model / Template
*Now:* a clean spec list (Params, Layers, Dtype, Size, Adapter) + template name.
*Proposal:* this is reference data, not monitoring — it should be the **lowest-salience** panel
(dim labels, no accent). Currently it pulls more attention than it deserves. Right call is to
let it recede; the operator reads it once, not every glance.

---

## 4. The encodings to add

Two new reusable encodings, both small and wordless, both house-style:

- **Bullet gauge** — a thin track, a value fill, one or two faint range bands, and a single
  reference marker (the budget/setpoint). Replaces the plain RAM/CPU/SSD bars. Color follows the
  semantic rule against the marker (green within, amber approaching, red past).
- **Sparkline** — a ~80×20px inline line, no axes, last value dotted, optional min/max ghost.
  Fed by a short server-side ring buffer of recent samples. Used for tok/s, RAM, SSD wear,
  ingestion rate. This is the single biggest glanceability win for a long-running device.

Both are pure SVG, theme-token colored, no library.

---

## 5. Tokens (so the system is consistent, not ad hoc)

Promote the loose values already in the CSS into a named scale, then use *only* these:

- **Type scale:** hero / panel-title / metric / label / micro (5 steps, not the current drift).
- **Color roles:** `--active` (amber), `--ok` (green), `--warn` (amber-bright), `--fault`
  (red), `--info` (blue), `--idle` (muted) — semantic names, mapped onto the existing hex.
  Components reference roles, never raw hex, so the grammar in §2.2 is enforced by construction.
- **Salience tiers:** every panel/element tagged primary / secondary / tertiary, driving its
  size + value. The hero is the only primary on a screen.

---

## 6. Out of scope (named on purpose)

- **Branding** — logo, wordmark, voice, full palette identity. Later pass; this one makes the
  structure sound first.
- **New metrics or data** the server doesn't already produce (beyond the small ring buffers the
  sparklines need).
- **Layout/responsive overhaul.** Same panel grid; this is re-encoding within it.
- **Charting libraries.** Bullet gauges and sparklines are hand-rolled SVG.

---

## 7. Suggested build order

1. **Tokens** — type scale, semantic color roles, salience tiers in `:root`; remap existing
   styles onto roles (no visual change yet, just the substrate).
2. **Bullet gauge** component — swap RAM/CPU/SSD bars to it, wire RAM↔resident-budget and
   CPU↔Max-CPU markers (data already in the state).
3. **System panel regroup** — "Working" vs "Holding up" common-region split.
4. **Active Cycle hierarchy** — status hero, bar re-ranking, grid → trio + secondary line,
   drop the redundant rate.
5. **Sparklines** — add a small server ring buffer (tok/s, RAM, SSD wear) to the SSE state;
   render inline beside the scalars.
6. **Recede Model/Template; align Monitor source cards** to the table language.

Steps 1–4 are pure dashboard. Step 5 is the only one touching the server (a bounded in-memory
sample history in `_build_full_state`); cold-probe testable.

---

## Design calls to confirm

- **Amber = "in transit / active" only.** This is the strongest brand-aligned move, but it means
  pulling amber off everything decorative (panel accents, etc.) and reserving it for the live
  state. Big visual shift — worth confirming you want that discipline.
- **Sparkline history is in-memory only** (lost on restart), to honor "don't thrash the SSD."
  If you want wear/throughput trends to *survive* restarts, that's a small persisted table — say
  the word and I'll add it to the durability story instead.
- **Drop Tokens/Hour** in favor of Tokens/Second + sparkline. If field operators actually think
  in tok/hr for multi-day jobs, I'll keep it as the primary and make tok/s the detail.
