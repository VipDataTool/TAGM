# Courier — Pipeline Throttle & Live Layer Progress Design Spec

**Status:** Draft / proposed
**Scope:** Two operator settings — **Max RAM (%)** and **Max CPU (%)** — that let the
same model and code fit and pace inference to whatever box it runs on; plus a **live Layer
progress** read-out so the operator sees within-token motion on hours-long runs. Additive
changes to `src/engine/` and `src/server.py`, two settings-drawer fields, and one status feed.
No new control loop; no new tab; no dashboard render change for the Layer bar.
**Audience:** Maintainer/engineer extending Courier.

---

## 1. Purpose

Courier's lean resident-weight path made inference fast enough that the operator now needs a
way to *spend* the box deliberately rather than accept a fixed profile. Two dials do that,
and they are the only two the hardware actually offers as independent levers:

- **Max RAM (%)** — how much of *total* system RAM inference may claim for resident weights.
  More budget ⇒ more layers held resident in RAM ⇒ fewer streamed from the SSD ⇒ faster.
  The SSD stays the read-store it is meant to be; RAM is the working medium. This is the
  speed lever.
- **Max CPU (%)** — a utilization setpoint the inter-layer rest is sized to hold. Below the
  target, no rest — full speed. As the process presses against the ceiling, timed rests
  appear between layers and grow, bleeding off sustained load so the box (and the always-on
  collector) stays responsive. This is the *dynamic brake*: the existing fixed rest, given a
  target.

And one read-out, not a setting:

- **Live Layer progress** — the Monitor's Layer bar shows the current forward pass sweeping
  its layers (0 → N) for *every* token. On the hours-long runs Courier targets — a few
  thousand characters of meaningful analysis from a capable model — the token-level
  Generation bar can sit nearly still for minutes; the Layer bar ticks underneath it as proof
  the job is alive and advancing. It is the per-token companion to the Generation bar
  (stage-level tokens) and to the checkpoint cadence (durable progress banked every N tokens):
  three views of the same live telemetry, at three grains.

These are settings, not panel knobs. They live in the Settings drawer beside Layer Delay,
Checkpoint Interval, and the rest. The Monitor System panel stays a **read-out** — its
RAM/CPU gauges show the *consequence* of the settings; they are not controls. This matches
the existing separation of Settings (write) from Monitor (read-only). The Layer bar is the
same discipline from the other side: a read-out the engine feeds, never a control.

---

## 2. Design principles

1. **Total RAM is the denominator.** "Max RAM: 90%" means 90% of *total* system RAM — a
   fixed, reproducible number that computes one resident depth every cycle. Available-RAM
   would move under the operator and shrink the budget exactly when the box is busy. A
   percentage of total is a *policy*; a percentage of available is a guess. Consistent with
   the reproducibility discipline (pinned prompts, self-contained checkpoints).
2. **Floored to protect the box.** The computed budget never strands the OS and the
   collector: it is clamped so a hard reserve of real RAM always remains. "90%" cannot
   trigger swapping — which on this system means thrashing the SSD the design exists to
   protect. If the floor would zero the budget, inference falls back to streaming, never to
   an unbounded cap.
3. **Depth is emergent, not computed twice.** The RAM dial resolves to a single
   `resident_max_bytes` cap and reuses the existing shard-manager behavior: it caches layers
   until the cap is hit, then streams the rest. "How many layers fit" is the byte budget
   answering itself — no parallel sizing path to drift from the enforcer.
4. **The brake has a setpoint, not a fixed gap.** Max CPU drives a closed loop that sizes
   each inter-layer rest from how hard the process is running, not a constant delay. One
   mechanism, one number. The fixed `layer_delay` remains as an independent manual floor.
5. **Decode loop logic untouched; only the existing per-layer seam is used.** Unlike the
   tool-calling spec, the brake *does* live inside the layer loop — but it rides the seam
   that is already there (the per-layer `cancel_check` point), adds no new loop, costs one
   measurement + at most one `sleep` per layer boundary, and is a strict no-op when disabled.
   The hot decode *math* is not modified.
6. **Both streamers, one behavior.** The fixed brake today fires only in `LayerStreamer`;
   `HybridStreamer` (Qwen3.5, multimodal) ignores it entirely. The throttle must behave
   identically on both. Closing that gap is part of this work, not a follow-on.
7. **Pure controller, cold-probe testable.** The RAM sizing and the CPU controller are pure
   functions of injected inputs (total bytes, measured load). They test with no torch and no
   weights, in the `tests/probe_*.py` style. Measurement (psutil) sits at the edge.

---

## 3. Module layout

```
src/engine/
  sizing.py     # NEW — pure: resident_budget_bytes(), layers_that_fit() (telemetry)
  brake.py      # NEW — pure: CpuBrake controller; process_load_frac() psutil reader (edge)
```

Integration touch points (existing files, additive changes only):

- `src/engine/inference.py` — `build_engine` resolves `max_ram_percent` → `resident_max_bytes`
  (via `sizing` + one psutil read of total RAM) and `max_cpu_percent` → a `CpuBrake`, and
  passes both into the streamer. The existing `resident_weights`/`resident_max_gb` path is
  preserved as an explicit override.
- `src/engine/streamer.py` — accept an optional `brake`; replace the existing
  `sleep(layer_delay)` with one `_rest_after_layer(compute_s)` that combines the `layer_delay`
  floor with the dynamic brake, timing each layer. Also carry a `current_layer` field, set as
  each layer completes (the Layer-progress heartbeat).
- `src/engine/hybrid_streamer.py` — accept `layer_delay` + `brake` (parity fix) and apply the
  same `_rest_after_layer` in its layer loop; carry the same `current_layer` field.
- `src/server.py` — add config defaults `max_ram_percent` (0 = off), `max_cpu_percent`
  (100 = off), `ram_reserve_gb` (floor); surface the live values in the `_build_full_state`
  system block, plus `_resident_stats()` for the Resident read-out. In `_build_cycle_status`,
  feed the Layer bar from the streamer's `current_layer` (the persistent handle), gated to a
  live generating cycle, and include `layer`/`generation_step` in the `_event_stream` change
  fingerprint so the bar animates during prefill. `POST /api/config` calls
  `_apply_live_throttle` to push the dials onto the running streamer (no model reload). No new
  endpoint — the existing config save carries the settings like every other one.
- `src/core/shard_manager.py` — `set_resident_budget(resident, max_bytes)`: live, additive,
  GIL-atomic attribute writes so the Max RAM dial applies mid-run without clearing the cache.
- `static/dashboard.html` — two textboxes ("Max RAM (%)", "Max CPU (%)") in the existing
  **Memory & Throttling** drawer group; wired through `_ensureConfigForm` / `_saveConfig`;
  shown in the Run-tab config summary; all drawer fields tooltipped. A **Resident** read-out
  in the System panel shows the cache filling toward the budget. **No render change for the
  Layer bar** — it already mounts identically to the Generation bar and calls
  `R.layerG.set(cyc.layer, cyc.total_layers)`; it was only ever starved of data.

---

## 4. Max RAM — sizing (the speed lever)

`sizing.resident_budget_bytes(total_ram_bytes, max_ram_percent, reserve_bytes) -> int`:

```
if max_ram_percent <= 0:        return 0          # off → caller keeps streaming default
budget = total_ram_bytes * max_ram_percent / 100
budget = min(budget, total_ram_bytes - reserve_bytes)   # principle 2: protect the box
return max(int(budget), 0)
```

In `build_engine` (safetensors path only; GGUF streams natively):

```
pct = float(config.get("max_ram_percent", 0) or 0)
if pct > 0:
    total = psutil.virtual_memory().total
    reserve = int(float(config.get("ram_reserve_gb", 1.0)) * 1024**3)
    budget = resident_budget_bytes(total, pct, reserve)
    if budget > 0:
        resident, resident_max_bytes = True, budget      # enable resident with a cap
    # budget == 0 (reserve ate the percentage) → fall through to streaming, never unbounded
```

Note the `budget > 0` guard: shard-manager treats `resident_max_bytes <= 0` as *unlimited*,
so the dial must never hand it a zero — a floored-to-zero budget means "stream," not "cache
everything." `layers_that_fit(budget, per_layer_bytes, n_layers)` is provided for telemetry
(what depth the budget buys) but is not on the enforcement path.

**It's a ceiling, not a fill target.** The percentage *authorizes* up to that many bytes; the
resident cache only holds what the model actually has. A 2 GB model on a 16 GB box fully
caches at ~13% and plateaus — setting 75% there changes nothing visible in total RAM, because
there are no more weights to hold. The dial bites when the model is large relative to RAM (a
9B on a tight box, choosing how many layers fit). So the confirmation signal is the **Resident
read-out and faster tok/s**, not the RAM gauge approaching the percentage. Total RAM is doubly
misleading because the OS already page-caches the streamed model file.

**Live application.** The dials would otherwise resolve only at `build_engine` (model load),
so changing them mid-run looked dead. `POST /api/config` now calls `_apply_live_throttle`,
which pushes the resident budget (and CPU brake target, and `layer_delay`) onto the persistent
streamer — attribute writes the per-load / per-layer paths read fresh, so they take effect over
the next forward passes without a model reload. The resident cache is never *cleared* live
(that would race the worker thread); lowering Max RAM stops new caching, and a full reclaim
happens at the next model load. A **Resident** read-out in the System panel surfaces
`cache_stats()` (held MB / budget, layers cached) so the operator can watch the cache fill —
the honest signal the throttle is engaged, independent of the muddied total-RAM gauge.

---

## 5. Max CPU — the dynamic brake (utilization setpoint)

Borrowed control law (cpulimit, `opsengine/cpulimit`): EMA-smoothed measurement feeding a
multiplicative duty-cycle update, converted to a per-layer rest sized by the layer's own
compute time.

`brake.CpuBrake(target_frac, alpha=0.1, floor=0.05)`:

```
update(compute_s, measured_frac) -> rest_seconds:
    if target_frac <= 0 or target_frac >= 1:  return 0.0       # disabled → full speed
    if measured_frac is None:                  return 0.0       # no reading yet (first layer)
    ema  = measured_frac if ema is None else (1-alpha)*ema + alpha*measured_frac
    workingrate = min(workingrate / max(ema,1e-6) * target_frac, 1.0)   # cpulimit law
    workingrate = max(workingrate, floor)                       # anti-windup clamp
    return compute_s * (1.0/workingrate - 1.0)                  # duty → rest
```

- **Measurement** (edge, in `brake.process_load_frac()`): a primed
  `psutil.Process().cpu_percent(None)` divided by `100 * cpu_count()` → the process's share of
  *total* machine capacity, 0..1. First call returns `None` (psutil's priming 0.0 is
  discarded), so the first layer never rests on noise.
- **Target**: `max_cpu_percent / 100`, 0..1 of total capacity. `>= 100` (the default) ⇒
  disabled ⇒ zero rest ⇒ current behavior exactly. The closed loop self-calibrates the
  wall-time-duty ↔ capacity-fraction relationship via feedback, so the multi-core mapping
  need not be modeled explicitly.
- **Floor** prevents `workingrate` collapsing to zero when the target is briefly unreachable
  (a single layer already exceeds target) — standard saturation/anti-windup. `workingrate` is
  seeded at **full speed (1.0)**, not the target: the brake only engages once the process is
  measured *above* the setpoint, so a workload already under it never rests
  ("below the target, full speed").

Per-layer application (both streamers), at the existing seam:

```
for i in range(n_layers):
    if self._cancel_check: self._cancel_check()      # existing
    t0 = time.perf_counter()
    hidden = self.forward_layer(...)                 # existing
    self.current_layer = i + 1                        # NEW — Layer heartbeat (§6)
    self._rest_after_layer(time.perf_counter() - t0) # NEW

_rest_after_layer(compute_s):
    rest = self.layer_delay                          # fixed manual floor (principle 4)
    if self._brake: rest = max(rest, self._brake.update(compute_s, process_load_frac()))
    if rest > 0: time.sleep(rest)                    # sleep() releases the GIL → yields to collector
```

Granularity is bounded by how often layers complete; on slow edge inference the loop settles
over several layers rather than instantly. Acceptable for a thermal/responsiveness setpoint;
sub-layer yield points are a deferred enhancement if ever needed.

---

## 6. Live Layer progress (the heartbeat)

The Monitor's Layer bar shows the in-flight forward pass advancing through its layers. It was
present in the dashboard but blank: `_build_cycle_status` hard-coded `"layer": 0`, so the
gauge was only ever fed a zero. Everything downstream already worked — the bar mounts exactly
like the Generation bar and each poll calls `R.layerG.set(cyc.layer, cyc.total_layers)`,
filling `(v / mx) * 100%`. The fix is a single live value, server-side.

**Source.** Each streamer carries `current_layer`, set to `i + 1` as layer `i` completes — so
it sweeps `0 → N` once per token. It rides the **persistent streamer handle** the server
already reads for KV-cache stats; no new callback is threaded through `generate()`. An int
write/read across the worker and main threads is GIL-atomic, which is sufficient for a
progress display.

**Feed.** `_build_cycle_status` reads `getattr(streamer, "current_layer", 0)` and exposes it
as `layer`, **gated to a live, generating cycle** — otherwise a stale value from a prior run
could linger on a paused bar. `total_layers` is the adapter's `num_hidden_layers` (24 for the
Qwen3.5-2B reference), so the denominator is always correct per loaded model.

**Push trigger.** The dashboard updates over SSE (`/api/events`), and `_event_stream` only
pushes a full state when a change-fingerprint differs from the last. That fingerprint must
include `layer` (and `generation_step`): during prefill/re-prefill no new tokens are emitted,
so a token-count-only fingerprint stays static and the push never fires — freezing the
heartbeat in exactly the recovery window it exists for. With `layer` in the fingerprint, the
sweep lands as a push, still rate-bounded by the operator's `refresh_interval` sleep.

**Why it matters.** On the hours-long runs Courier targets, a single token streams all N
layers from the SSD and can take minutes; the token-level Generation bar barely moves over a
poll interval. The Layer bar ticking `0 → N` underneath is the operator's live proof the job
is advancing — the per-token grain between the stage-level Generation bar and the checkpoint
cadence that banks durable progress every N tokens. Three views of the same telemetry.

---

## 7. Config keys

| key | default | meaning |
|---|---|---|
| `max_ram_percent` | `0` | % of **total** RAM for resident weights. `0` = off (stream). |
| `max_cpu_percent` | `100` | utilization setpoint for the dynamic brake. `100` = off. |
| `ram_reserve_gb` | `1.0` | hard RAM floor left for OS + collector (principle 2). |

`layer_delay` is retained unchanged as the independent fixed-rest floor.

---

## 8. Out of scope (named on purpose)

- **CPU core/thread capping** (`set_num_threads`, affinity). A coarse, quantized envelope;
  the utilization setpoint covers the stated goal. Could be added later as a coarse outer
  bound under the same Max CPU dial.
- **Temperature targeting.** The operator chose *utilization* as the target; a utilization
  cap is a sound proxy for the thermal goal but not a measured-temperature controller.
- **A second resident path.** Depth stays emergent from the byte cap (principle 3).
- **Sub-layer / sub-token heartbeat.** The Layer bar's grain is one layer; on a fast box it
  sweeps faster than the poll can show, which is fine (the Generation bar carries it then).
  Finer-grained progress within a layer is not pursued.

---

## 9. Suggested build order

1. `sizing.py` — pure budget math + `layers_that_fit`.
2. `brake.py` — `CpuBrake` controller + `process_load_frac` reader.
3. `streamer.py` — `_rest_after_layer`, per-layer timing, accept `brake`, `current_layer`.
4. `hybrid_streamer.py` — accept `layer_delay` + `brake`; apply `_rest_after_layer` (parity);
   `current_layer`.
5. `inference.py` — resolve both dials from config; pass through.
6. `server.py` — config defaults + surface live throttle values in the state snapshot; feed
   the Layer bar from `streamer.current_layer` in `_build_cycle_status` (gated to a live
   cycle) and add `layer`/`generation_step` to the `_event_stream` fingerprint so prefill
   pushes land.
7. `dashboard.html` — two drawer fields + summary line + tooltips. (Layer bar needs no change.)
8. `tests/probe_throttle.py` — cold probes: budget clamps (incl. floor-eats-percentage and
   the zero-is-not-unlimited guard), `layers_that_fit`, and the controller's convergence /
   disabled / first-reading / anti-windup behavior. No torch, no weights.
