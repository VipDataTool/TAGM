# Courier Multi-Model & Engine-Level Acceleration Design Spec

**Status:** draft v2 — design only, no code yet
**Supersedes:** draft v1 ("Multi-Model (primary/secondary)"). v1's stage-routing
design is retained intact; this revision adds speculative decoding as a sibling
and reframes the goal.
**Relationship to other specs:** extends the resident-RAM budget policy in
`courier-throttle-design-spec.md` (§4) and `src/engine/sizing.py`.

---

## 1. North star (revised)

The goal is **the largest standard Qwen/Llama the box can run at tolerable
batch speed** — not a bespoke feature. Streaming already makes a huge model
*run*; the open problem is *speed*. So the centerpiece is now **speculative
decoding** (the only family of trick that attacks Courier's true bottleneck),
with **multi-model stage routing** retained as an independent, useful feature.

Both ride one shared piece of infrastructure: an **engine registry** holding
≥1 model. They are not alternatives and neither replaces the other.

---

## 2. Two layers, three channels, one spine

The features live at different layers and must not be conflated:

- **Pipeline layer — stage routing.** The orchestrator picks which loaded
  engine runs a whole *stage*; the handoff between stages is text
  (`src/pipeline.py:302` already feeds prior stage output forward).
- **Engine layer — speculative decoding.** Lives *inside the generate loop of a
  single inference call* (`infer()` closure in `src/engine/inference.py:130`):
  draft K tokens, verify all K in one forward sweep, accept/reject. The pipeline
  never sees it — it calls `infer_fn(prompt)` and gets text back faster.

Three channels, sharing the registry:

| Channel | Layer | Models | Needs |
|---|---|---|---|
| A · Stage routing | pipeline | N engines, one per stage | registry |
| B · External-draft speculative decoding | engine | 2 (small draft + big verify) | registry + partition |
| C · Self-speculative (LayerSkip) | engine | 1 (early-exit draft from own layers) | early-exit model *or* runtime skip-set |

The **engine registry** (two models resident at once) is the shared spine: A
uses the two engines as independent stage workers; B uses them as a draft/verify
pair within one call; C needs only one. Build the registry once; all three draw
on it.

---

## 3. The performance floor (this picks model sizes)

No decoding trick repeals the physics: **to use a weight you must read it.** For
a streamed model, the per-token cost is dominated by bytes read off the SSD.

Precise model, grounded in how the cache works (§4):

```
RAM used            = (resident layers) × bf16_size        # cache holds bf16 (§5)
per-token disk read = (streamed layers) × quantized_size   # int8/Q4 bytes (§5)
token latency       ≈ per-token disk read / SSD_bandwidth
with speculative decoding:
token latency       ≈ (one verify sweep) / (accepted tokens K)   # amortized
```

Worked floor (laptop NVMe ~4 GB/s sustained, model far exceeding RAM):

- 70B @ Q4 ≈ 35 GB/sweep → ~9 s/token raw; with SD at K≈4 accepted → ~2 s/token.
- 170B @ Q4 ≈ 85 GB/sweep → ~21 s/token raw; SD → ~5 s/token. Overnight-batch.
- 170B @ int8 ≈ 170 GB/sweep → ~40 s/token. Quantization halves the *read*.

Consequences that drive the design:
- **The resident cap is a speed knob, not just a fit knob.** It sets how many
  layers stream, i.e. per-token read volume, i.e. token latency. The partition
  function (§7) literally sets the verifier's speed.
- **Quantization buys read volume, not RAM** (§5). It directly lowers token
  latency for streamed models because you read int8/Q4 bytes per layer.
- **Speculative decoding is the multiplier**, and it is worth more here than on
  the GPUs it was invented on: it amortizes the SSD read — the scarce resource —
  over K tokens per sweep, not just FLOPs.
- "Usable" means **batch speed.** 70B-class @ Q4 is the honest interactive-ish
  target; 170B stays a leave-it-running model.

---

## 4. What already exists (substrate)

- **Stage chain handoff** — `run_pipeline(template, data_paths, infer_fn, …)`
  (`pipeline.py:203`) runs stages in order and feeds each prior stage's output
  into the next (`pipeline.py:302`). Calls a single `infer_fn` at `:350`.
- **Per-engine resident cache** — `ShardManager` (`core/shard_manager.py`) holds
  `_layer_cache` capped by `_resident_max_bytes`; each `build_engine` mints its
  own. **Two engines = two independent caches ⇒ no cross-eviction.**
- **Per-engine cap input** — `build_engine(model_path, config, *, kv_cache_dir,
  max_kv_ram_layers)` (`inference.py:262`) resolves a resident cap from
  `max_ram_percent` via `sizing.resident_budget_bytes`, or explicit
  `resident_weights`/`resident_max_gb`. An explicit per-engine byte cap is
  already a supported input.
- **Quantization, two paths** — safetensors int8 + `{key}_scale` dequantized to
  bf16 on load (`shard_manager.get_tensor`); GGUF Q4_K/Q6_K/Q8_0 via
  `core/dequantize.py` + `GGUFShardManager`. **Both dequantize to bf16 before
  caching.**
- **Image multimodality** — layer-streaming ViT (`engine/vision.py`); `infer_fn`
  takes `image_paths`; gated on `streamer.adapter.is_multimodal`.
- **Single-slot today** — `STATE["streamer"|"infer_fn"|"model_path"]`
  (`server.py:303`), swapped wholesale by `/api/models/load` (`:1938`).
- **Per-engine** KV cache (`engine/kv_cache.py`) and checkpoints
  (`engine/checkpoint.py` + DB `checkpoints`).
- The generate loop SD modifies lives in the `infer()` closure
  (`inference.py:130`), which the streamer's forward feeds.

---

## 5. Quantization reality (corrected from v1)

The cache stores **dequantized bf16** (the "dequant once, not per token"
optimization — `shard_manager.py:41–43`; GGUF likewise). Therefore:

- **Resident footprint is bf16 regardless of int8/Q4 on disk.** Quantization is
  a *disk + streaming-read* win (lower per-token read volume, faster cold
  sweep), **not** a resident-RAM win. Do not let "we quantize" imply "both
  models fit." The partition math (§7) stays in bf16.
- **Two budget authorities exist and must be unified.** `ShardManager` sizes its
  cap from `sizing.resident_budget_bytes`; `GGUFShardManager` uses its own
  `cache_budget_mb` / `COURIER_CACHE_MB`. The partition (§7) must be the *single*
  authority over both, or they double-count RAM and thrash.
- **The real RAM lever is the cache-dtype fork:** cache weights *quantized* and
  dequantize per-forward instead of caching bf16. Halves/quarters resident RAM
  at a per-token compute cost. The int8→bf16 machinery already exists in
  `get_tensor`; today it just stores the bf16 result. **Deliberate
  RAM-for-compute trade, not a freebie** — and on a dual-core box, bf16-resident
  is usually the right default (you dequant a resident layer once, then every
  forward is a clean matmul). Record it; don't take it by default.

---

## 6. The shared spine — engine registry

Replace single-slot `STATE` with `STATE["engines"] = { role: {streamer,
infer_fn, model_path, multimodal: bool, footprint_bytes, resident_cap} }`.
- `primary` is the existing load path; a one-engine registry behaves exactly as
  today (back-compat).
- Loading a second engine does **not** tear down the first; it re-partitions
  (§7) and refuses if it doesn't fit.
- All three channels resolve their engine(s) from this registry.

---

## 7. Make-or-break — partition & admission

A pure function (RAM injected, no torch), home in `engine/sizing.py`, gating
every two-model channel (A and B). Unchanged in spirit from v1, now also the
gate for draft+verify coexistence, and now explicitly the *single* budget
authority over both manager types (§5).

```
def partition_resident_budget(
    total_ram_bytes, max_ram_percent, reserve_bytes,
    secondary_footprint_bytes,        # small model (draft / secondary), pin fully
    primary_kv_headroom_bytes,
    secondary_kv_headroom_bytes,
) -> {"secondary_cap": int, "primary_cap": int} | None:
    budget = resident_budget_bytes(total_ram_bytes, max_ram_percent, reserve_bytes)
    secondary_cap = secondary_footprint_bytes               # fully pinned
    primary_cap   = budget - secondary_cap - primary_kv_headroom - secondary_kv_headroom
    # Refuse (None) if budget<=0, no room for secondary, or primary_cap<PRIMARY_MIN_CAP
```

Properties: static, non-overlapping caps handed to each engine via the existing
`resident_max_bytes` (and the GGUF `cache_budget_mb` derived from the same
number); secondary fully pinned (no hot-path SSD reads, immune to primary
churn); admission refuses rather than degrades. `primary_cap` *is* the verifier's
per-token read volume (§3) — the function sets both fit and speed.

---

## 8. Channel A — pipeline stage routing (retained)

- `StageConfig` gains optional `model: str` (role; default `"primary"`),
  validated in `Template.from_dict`.
- `run_pipeline` takes `infer_fns: dict[str, Callable]`; at `:350` it selects
  `infer_fns[stage.model]`. Prior-output feed-forward unchanged ⇒ text handoff
  automatic. Worker/`_resume_cycle`/`recover_interrupted` carry the map.
- **Multimodal routing constraint:** a stage reading an `image_file` source must
  target a `multimodal: True` engine. Validate statically and guard at runtime.
- Back-compat: no `model` field ⇒ everything on `primary`, identical to today.

---

## 9. Channel B — external-draft speculative decoding (north-star centerpiece)

The acceleration that makes a big standard model usable. Lives in the engine
generate loop, **invisible to the pipeline**.

- **Loop:** draft K tokens with the small resident draft engine (cheap, in RAM);
  run the big streamed verifier once over the K draft tokens (one sweep reads
  each layer once, verifies all K in parallel); accept the longest correct
  prefix, correct the first mismatch, repeat. **Lossless** — accepted tokens are
  exactly what the verifier would have produced, so output distribution is
  unchanged; this is a pure speedup with a clean correctness test.
- **Config:** a `draft_role` attribute on the verifier engine ("draft with engine
  X"), set per engine or per stage — an attribute of an inference call, not a
  third model slot.
- **Pairing:** same family / same tokenizer (no retraining) — e.g. Qwen 0.5B
  drafting for Qwen 72B, Llama 1B for Llama 70B. The same-family pairing we
  already landed on.
- **Where:** the `infer()` token loop (`inference.py:130`) and the streamer's
  forward; the draft engine comes from the registry.

---

## 10. Channel C — self-speculative (LayerSkip), optional/advanced

- One model drafts from its own early layers and verifies with the rest — no
  second model, shares KV between draft and verify (lowest memory).
- Needs a model trained with the early-exit recipe (stock Qwen/Llama are **not**),
  *or* a runtime skip-set search (SWIFT / CLaSp / KNN-SSD) that avoids retraining
  at the cost of a search step. Separate engine code path from B.
- Frees the RAM a draft model would cost — attractive on the tightest boxes — but
  gated on either a special checkpoint or the on-the-fly search landing.

---

## 11. Build order (revised)

1. **Engine registry** (§6) — the shared spine. Back-compat single-engine.
2. **Partition & admission** (§7) — cold pure function + tests: a representative
   draft+verify pair fits a 32 GB box; an oversized draft is refused; dial-off
   returns None. Unifies both budget authorities. *Prove the numbers before
   building on them.*
3. **Channel B — external-draft speculative decoding** (§9) — the north-star win.
   The draft/verify loop + `draft_role` flag. Bench acceptance rate and
   tokens/sec against raw streamed decode; assert losslessness.
4. **Channel A — stage routing** (§8) — `StageConfig.model`, `run_pipeline`
   routing, multimodal constraint, registry threaded through worker/resume.
5. **Channel C — self-speculative** (§10) — on-the-fly skip-set variant; optional.
6. **Builder UI** — per-step model picker (routing) and a draft-pairing control
   (which engine drafts for which); honest, because it selects loaded engines.

Rationale for B before A: B serves the stated goal (big model, usable speed)
directly; A is a retained feature. Both wait on 1–2.

---

## 12. Risks & open questions

- **SSD bandwidth is the hard floor** (§3). SD amortizes it; nothing removes it.
  Pick model sizes from the floor math, not optimism.
- **Acceptance rate** sets SD's real speedup. Same-family draft alignment is the
  lever; measure per model pair, expect task variance.
- **KV headroom estimate** — softest input to §7; conservative first, then
  measure on the CF33.
- **Dual budget authority** (§5) must be unified under §7 or RAM is double-counted.
- **Resume path** — `recover_interrupted` currently takes a lone `infer_fn`; a
  resumed multi-engine run must re-acquire the whole registry, and an in-flight
  SD loop must resume draft+verify state, not just the verifier.
- **Cache-dtype fork** (§5) deferred by default; revisit only if RAM, not
  compute, becomes the binding constraint.
- **Self-speculative** needs a trained model or runtime search — do not assume
  stock checkpoints support it.

---

## 13. Test plan

- **Cold (Phase 2):** pure-function partition tests — fits / refuses / dial-off,
  no torch (mirrors `sizing.py`).
- **SD (Phase 3):** tokens/sec vs raw streamed decode on a real pair; **lossless
  check** — accepted-token stream equals the verifier's own greedy output.
- **Routing (Phase 4):** two-stage template routes stages to intended engines;
  stage 2 input contains stage 1 output; image stage → multimodal only.
- **Registry/admission:** load draft+verify; non-overlapping caps; oversized
  draft refused with primary intact.
- **Back-compat:** existing single-model templates run unchanged on `primary`.
