# Courier

Edge inference framework for large language models. Runs models on
resource-constrained hardware by streaming weight shards through memory
one layer at a time. Designed for field deployment where network access
is unavailable and response latency is measured in hours, not milliseconds.

## Quickstart

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Download a model (requires network)
python scripts/download_model.py
```

> **Gated models (e.g. meta-llama)** need a Hugging Face access token. Provide
> it as the `HF_TOKEN` environment variable, or — for a turnkey local setup —
> copy `.env.example` to `.env` and set `HF_TOKEN=hf_...` there; it's loaded
> automatically at startup. A real exported variable or a Codespaces/CI secret
> always overrides `.env`. See **Security & Networking → Authentication**.

```bash
# 3. Verify the download
python scripts/verify_model.py

# 4. Run tests
pytest tests/

# 5. Start the server
python -m src.server
```

By default the server binds to all interfaces (`0.0.0.0`) and speaks plain
HTTP. The local dashboard works immediately with no token. See
**Security & Networking** below for what that does and does not protect, and
how to lock it down further.

## Running Headless & Field Deployment

`bash start.sh` (or `python start.py`) runs the server in the **foreground of
your terminal** — its lifetime is tied to that terminal session. Closing the
*dashboard* tab is always harmless (the server does not react to clients
disconnecting), but in remote environments (Codespaces, VS Code Remote, SSH)
closing the window that hosts the *terminal* disposes the pty after a grace
period and the server is SIGTERM'd with it. Pick the run mode for the machine:

**Dev machine / Codespaces** — foreground `start.sh` is fine. To survive a
disconnect, run it inside tmux: `tmux new -s courier bash start.sh`
(reattach later with `tmux attach -t courier`), or use daemon mode below.
(Do **not** run the service installer here: a Codespace is a container
without systemd as init, so `systemctl` has nothing to talk to.)

**Field unit / appliance (the designed deployment)** — install Courier as a
system service so the box reaches its designed behavior on its own:
**power on → service starts → Courier resumes any interrupted cycle from its
last checkpoint → the schedule continues.** No login, no terminal, restart
after crashes.

```bash
sudo bash deploy/install-service.sh              # this repo, this user, port 8000
sudo bash deploy/install-service.sh --user pat --port 9000
sudo bash deploy/install-service.sh --uninstall
```

If you haven't worked with services before, the mental model: a *service* is
a program the OS itself starts and supervises — no terminal owns it, so no
tab, SSH drop, or logout can take it down; the supervisor (systemd) restarts
it if it crashes and starts it on every boot. Its output goes to the system
journal instead of a terminal. The commands you'll actually use:

```bash
systemctl status courier        # is it running + recent log lines
journalctl -u courier -f        # watch live logs (Ctrl+C stops watching, not the service)
sudo systemctl restart courier  # e.g. after changing courier_config.json
sudo systemctl stop courier     # stops until next boot or manual start
```

The unit (see `deploy/courier.service`, commented) restarts on failure with
a 15s delay and gives up after 5 attempts in 10 minutes — a crash-loop guard
so a broken install doesn't reload a 4B model from a slow disk forever. It
pairs with Courier's checkpoint recovery: a power cut mid-cycle resumes from
the last banked token on the next boot.

**Windows field unit / PC** — same appliance behavior, different supervisor.
`start.sh` and `deploy/install-service.sh` are Linux-only (bash + systemd);
the Windows equivalents are `python start.py` and `deploy/WINDOWS.md`.
Everyday commands, in PowerShell:

```powershell
python start.py              # foreground (dies with this window)
python start.py --daemon     # detached; survives closing the window
python start.py --status
python start.py --stop
```

Use plain `python`, not `python3` — Windows creates no `python3` alias, and
a fresh machine may carry a Microsoft Store stub under that name that opens
the Store instead of running anything. `python --version` should print
3.10–3.13 before you trust it.

For the boot-to-running appliance path, `deploy/WINDOWS.md` walks through
two routes: **NSSM** (recommended — a real Windows service with
restart-on-failure, a 15s crash-loop delay, and log rotation, mirroring the
systemd unit) and **Task Scheduler** (built in, starts at boot, weaker crash
recovery). Checkpoint recovery is identical under either: a power cut
mid-cycle resumes from the last banked token when the service next starts.

One Windows-specific behavior to expect: energy metering reads Linux sysfs
(RAPL counters, battery telemetry), so on Windows every receipt uses the
labeled `estimate` method — CPU-time × the **Watts per core** setting
(Settings → System → Energy Metering; tune to the rig). The method is
printed at startup and stamped on every receipt, so the estimate never
passes as a measurement.

**Daemon mode (no systemd needed)** — a middle option for one-off headless
runs: detaches from the terminal but does not survive reboots.

```bash
bash start.sh --daemon     # or: python start.py --daemon
bash start.sh status       # or: python start.py --status
bash start.sh stop         # or: python start.py --stop
```

It runs the same pre-flight, then launches uvicorn in its own session
(`setsid` on POSIX, a detached process group on Windows) with stdio in
`logs/courier.log` and its PID in `courier.pid`.

## Security & Networking

Courier is built to be **turnkey for local, single-operator use**: drop the
folder, start the server, open the dashboard — no token, no certificate, no
setup. The security model is sized for that reality, not for a public-facing
service.

### What's protected

Every state-changing route (`POST` / `PUT` / `DELETE`) passes through a single
`require_write` check; read-only routes are open. With no token presented, a
write is accepted only when both of these hold:

- the request is **not a cross-site browser request** (judged by the
  `Sec-Fetch-Site` header), and
- the `Host` is **local** — loopback, an IP literal, or `localhost`.

That combination blocks the two attacks that can actually reach a machine-local
app:

- A malicious page you happen to open in your browser cannot `POST` to
  `localhost:8000` to drive your instance — cross-site requests are rejected.
- A DNS-rebinding page (an attacker domain re-pointed at `127.0.0.1`) is
  rejected, because its `Host` is a domain name rather than a local address.

Separately, any route that takes a file or model name validates it against
directory traversal, so a crafted request cannot read or delete outside the
intended folders.

### Authentication (optional)

A default read-write API token is created on first boot and written to
`data/default_token.txt` with owner-only permissions (`0600`). It is **never
printed to the console**. You do not need it for the local dashboard, but
presenting it as `Authorization: Bearer <token>` authorizes a write from *any*
origin — useful for scripts, automation, or another machine. Manage tokens with
`courier token {create|list|revoke}`. Delete `data/default_token.txt` once
you've copied the value if you don't want it resting on disk.

### Environment & secrets (`.env`)

Configuration secrets are supplied through environment variables. On startup
Courier also loads a project-root `.env` file (copy `.env.example` to `.env`),
so a laptop run is as turnkey as the Codespaces secret it replaces. Real
environment variables take precedence — an exported value or a Codespaces/CI
secret always overrides `.env`, which is only a local fallback. `.env` and
`data/default_token.txt` are gitignored so neither is ever committed.

Recognized variables:

| Variable | Purpose |
| --- | --- |
| `HF_TOKEN` | Hugging Face access token, used for downloading gated models. Passed explicitly to the download call, so gated repos work whenever it's set. |
| `COURIER_INSECURE` | Set to `1` to bypass all write authorization (see **Escape hatch**). Overridden by `COURIER_REQUIRE_TOKEN=1` — on conflict, safest wins. |
| `COURIER_REQUIRE_TOKEN` | Set to `1` to require the bearer token for **every** write, disabling the tokenless local path. The setting for any node reachable through a proxy or shared/public port. Beats every other auth setting. |
| `COURIER_TRUST_PROXY` | `1` skips the loopback-peer check because an *authenticating* proxy fronts the node; `0` opts a Codespace out of the automatic proxy trust it otherwise gets from the `CODESPACES` env. See **Proxies & forwarded ports**. |
| `COURIER_MAX_UPLOAD_MB` | Size ceiling for `/api/ingest/file` and `/api/templates` uploads, in MB (default `256`). Enforced while the body is read, so an oversized upload is refused with `413` instead of exhausting a field unit's RAM. |

### Proxies & forwarded ports

The tokenless local path authenticates by *transport facts*: the TCP peer
must be loopback and the `Host` local. **Any reverse proxy destroys both
facts** — it connects from wherever it runs and rewrites `Host` — so behind
a proxy the gate can only work by trusting the proxy to authenticate
callers. Courier does that in exactly two cases: automatically inside a
GitHub Codespace (`CODESPACES` env; forwarded ports are private to your
account by default), or when you set `COURIER_TRUST_PROXY=1` for another
authenticated proxy.

That trust is stated, not hidden: startup prints the effective posture and
a `⚠ AUTH WARNING` whenever trust is broad, and the dashboard's NETWORK
tab shows the same posture in amber with the hazard note. The failure mode
to respect: a Codespaces port flipped from **Private** to **Public** makes
GitHub forward *anyone*, with a rewritten local `Host` — and tokenless
writes would sail through. If a forwarded port ever becomes public or
shared, set `COURIER_REQUIRE_TOKEN=1` (every write then needs the bearer
token, no exceptions — it beats even `COURIER_INSECURE`), or opt out of
proxy trust entirely with `COURIER_TRUST_PROXY=0`.

The four postures, safest-wins on conflict: `token-required` →
`insecure-bypass` → `proxy-trusted` → `local-origin` (the turnkey
default). `core/security.py::write_posture` is the single decision point;
`GET /api/node` reports it.

### HTTPS / TLS

The server speaks plain HTTP, and for same-machine use over `localhost` /
`127.0.0.1` that is correct: the traffic never leaves the machine, and browsers
treat `http://localhost` as a secure context, so TLS would add nothing. (A
self-signed certificate generator exists in `core/security.py` but is dormant
and not wired into startup.) HTTPS only becomes relevant once requests cross a
network — see the caveat below.

### The one caveat — the `0.0.0.0` bind

The launcher binds to all interfaces, so the server is also reachable from
other devices via this machine's LAN IP. The origin checks above stop
*browser-based* attacks, but they do not stop a *person* on the same network: a
request from another device to `http://<this-machine-ip>:8000` is not
cross-site and carries a valid IP `Host`, so it passes — and because local
writes require no token, that person could drive your instance. On a trusted
home network this is a non-issue; on shared or public Wi-Fi it is a real gap.
To close it, either:

- **Stay fully local:** bind to `127.0.0.1` instead of `0.0.0.0` (change the
  `--host` flag in `start.sh`, or the `uvicorn` host in your launcher). This
  removes all network access.
- **Allow the network, but require auth:** keep `0.0.0.0`, leave
  `COURIER_INSECURE` unset (the default), and have LAN clients send the bearer
  token. Add TLS if the traffic crosses an untrusted network.

### Escape hatch

Setting the environment variable `COURIER_INSECURE=1` bypasses **all** write
authorization — no origin check, no token. Use it only on a fully trusted,
isolated machine.

## Project Structure

```
courier/
├── src/                    Python library + server
│   ├── engine/             Inference engine (layer streamer, KV cache,
│   │                       checkpointing, sampling, energy metering,
│   │                       output text rules)
│   ├── core/               Core components (adapters, shard manager,
│   │   └── adapter/        database + meta, corpus index, security
│   │                       + write posture)
│   ├── data/               Data adapters and ingestion
│   ├── pipeline.py         Stage pipeline execution
│   ├── template.py         JSON template loading
│   ├── server.py           FastAPI wrapper
│   └── cli.py              CLI entry point
├── static/                 Dashboard UI
│   └── dashboard.html      Production (requires live API)
├── models/                 Pre-staged model shards
├── templates/              User templates
│   └── builtin/            Shipped templates
├── data/                   Ingestion directory
├── image-src/              Multimodal image source directory
├── export/                 Output directory
├── deploy/                 systemd unit + installer; Windows runbook
├── scripts/                Download and verify scripts
└── tests/                  Test suite (probe_* run cold — no torch)
```

## Data Sources (Tools)

A template's stages pull from one or more **data adapters** — the
mechanism by which the model consumes data. Each adapter implements a
two-method contract (`connect(source_config)` and
`fetch(token_budget, params) -> str`) and returns model-ready text that
fits within a token budget. Adapters are referenced by name in a
template's `data.sources` config (e.g. `"adapter": "json_file"`). All
shipped adapters are **ingress** — they read a source into the prompt.

| Adapter | Reads | Renders |
| --- | --- | --- |
| `json_file` | JSON objects, arrays, JSONL, directories, append-only logs; optional field extraction | Markdown table within budget |
| `csv_file` | CSV files; optional column filter | Markdown table within budget |
| `image_file` | Image files for multimodal inference (JPEG, PNG, BMP, TIFF, WebP) | Text placeholder in the prompt; raw image path passed to the engine |
| `verbatim` | Text from config or a file path | Pass-through, truncated to budget at a word boundary |
| `corpus_search` | The durable-knowledge index (`corpus.db`, built by gator's digestor) | BM25-retrieved passages relevant to `params.query` + terms derived from the cycle's records; each passage cited `[doc §section · chunk#n · sha1]` |

A template opts into grounding by declaring a `corpus_search` source, e.g.:

```jsonc
"sources": {
  "regulations": {
    "adapter": "corpus_search",
    "params": { "query": "vessel exclusion no-wake permit",
                "top_k": 6, "from_records": true, "max_terms": 24 }
  }
}
```

All knobs are params: `query` (fixed terms), `top_k` (passages considered,
default 8), `doc_ids` (restrict to named documents), `from_records`
(derive terms from the cycle's records, default true), `max_terms` (cap on
derived terms, default 24), `path` (corpus.db location).

Build the index with gator: `python ../gator/digestor.py docs/regs.pdf`
(section-aware chunks) or `--lines` for registries/watchlists; drop the
resulting envelope in `import/` (or let auto-ingest see it) and it indexes
into `corpus.db`. `from_records: true` (default) additionally derives query
terms from the cycle's fresh records, so the observations select their own
grounding.

Items marked `*` below are **not yet implemented** — they are examples
of how the same interface extends to the cyclical / self-tending
patterns Courier is aimed at. The egress entries imply a new sibling
type (a sink that *emits* a rendered artifact rather than reading one
in).

| Adapter | Role | Notes |
| --- | --- | --- |
| `current_state`* | Snapshot the newest ingested records into the prompt | Thin wrapper over existing `snapshot()` / `get_snapshot_records` |
| `prior_context`* | Inject recent cycles and verdicts (the recent window) | Backed by existing `db.py` reads (`get_cycles`, `get_stages`) |
| `semantic_retrieval`* | Retrieve relevant past episodes by similarity (the long tail) | Lexical half now shipped as `corpus_search` (FTS5); an embedding layer could hybridize it later |
| `sms_mms`* | Egress: send a cycle report (summary + one image) to a phone number | New sink type; pairs with the `cycle_*.md` report |
| `email_smtp`* | Egress: send a cycle report over SMTP | New sink type; more resilient over a satellite link |

## Status

Phase 1 — Core operational. The layer-streaming inference engine,
multi-stage template pipeline, browser dashboard, and data ingestion
system are working end-to-end.

**Supported model families:**
- **Qwen3** (0.6B–32B) — text-only, standard transformer with GQA
- **Qwen3.5** (0.8B–27B) — hybrid attention (Gated DeltaNet + full
  attention), native multimodal (vision encoder), non-standard
  `(1+weight)` RMSNorm
- **Llama 3.x** (1B–70B) — text-only, standard transformer with GQA,
  piecewise RoPE scaling (3.1/3.2)

### Speculative Decoding Compatibility

Models within the same family share a tokenizer and can be paired as
draft (small, fast) and verifier (large, accurate). Cross-family
pairing is **not supported** — different vocabularies mean every draft
token gets rejected, making inference slower than single-model.

| Family | Vocab | Models | SD Pairing |
|--------|-------|--------|------------|
| Qwen3 | 151,936 | 0.6B, 1.7B, 4B, 8B, 14B, 32B | Any smaller → any larger |
| Qwen3.5 | 248,320 | 0.8B, 2B, 4B, 9B, 27B | Any smaller → any larger |
| Llama 3.x | 128,256 | 1B, 3B, 8B, 70B | Any smaller → any larger |

> **Llama naming:** Meta changed their naming convention across releases
> (`Meta-Llama-3.1-*` vs `Llama-3.2-*`), but all Llama 3.x models use
> the same tiktoken BPE tokenizer and are fully cross-compatible.
> Llama 3.0 8B is excluded — 3.1 8B is the same architecture with 128K
> context and better benchmarks.

Model-family-specific defaults (sampling parameters, thinking mode)
are stored in each adapter class and applied automatically on model
load. See `core/adapter/` for per-family implementations.

The model catalog itself lives in **`models_catalog.json`** at the repo
root — edit it to add model profiles (the `family` must match an
existing adapter). It ships with the built-in list; delete it to
restore defaults. See the file's `_readme` key for the entry schema.

### GGUF Compatibility

Courier reads GGUF natively — parse, name-map to HF convention,
dequantize, stream — through the same adapters and engine as
safetensors (format detection is one branch in `create_engine`; nothing
downstream knows the difference). Single-file GGUFs only: split shards
raise with a `llama-gguf-split --merge` pointer.

**Quant types:** F32, F16, BF16, Q8_0, Q4_K, Q6_K — i.e. **Q4_K_M and
Q8_0 files work**; Q5_K, Q3_K, Q2, and IQ-anything fail loudly at the
dequantizer, never silently.

**Prefer GGUF Variants** (Settings → Model Format) makes the validated
families list and load as their published Q4_K_M quant instead of
safetensors+INT8 — same catalog rows, same engine, ~35% of the disk
footprint, no conversion pass. Off by default.

| Family | GGUF status | Evidence |
|--------|-------------|----------|
| Qwen3 | **Validated** | Full test ladder green on a real Q8_0 file: header vs gguf-py oracle, dequantization bit-for-bit vs oracle, shard manager end to end, cross-format vs safetensors (2026-07-03) |
| Qwen3.5 | Mapped, unverified | Name map covers the DeltaNet/SSM layer names (Tier-1 tested); no end-to-end GGUF run recorded. Run the ladder with `GGUF_MODEL_PATH` to promote |
| Llama 3.x | **Validated** | Q/K rotary permutation undone at load (adapter-declared `inverse_llama_permute`); confirmed on a real F16 GGUF via the diff harness — all roles agree elementwise, layers 0–1, Llama-3.2-1B (2026-07-03). Note: BF16-sourced checkpoints show ~1e-8 storage rounding vs F16 GGUFs; the harness treats that as MATCH |
| Gemma 3 | Deferred, not dead | Needs name-map entries for its extra pre/post-FFN norms plus a harness pass; no architectural blocker |

Family-specific GGUF layout knowledge lives in the adapters
(`ModelAdapter.gguf_load_transforms`, default none), applied blindly by
`GGUFShardManager` at every materialization point — the shard manager
never learns a family name, so GGUF support extends the same way the
framework already extends: per adapter. The transform math lives in the
torch-free `core/gguf_layout.py`, shared by the loader and the diff
harness so the harness can never "confirm" math the loader doesn't run.

**Deliberately not built: a GGUF writer.** Courier consumes the
ecosystem's GGUF files (`download_model.py --gguf`) and owns its own
INT8 format for safetensors (`quantize_model.py`). Producing GGUF means
reimplementing llama.cpp's converter and quant kernels — a large moving
target llama.cpp already maintains, for files the ecosystem already
publishes. If you ever need a GGUF that doesn't exist, use llama.cpp's
`convert_hf_to_gguf.py` + `llama-quantize`, then point Courier at the
file.

See ARCHITECTURE.md for the full design.

## Changelog

### Unreleased — 2026-07-03

**Added**

- **Llama GGUF Q/K permutation is now undone at load.** llama.cpp's
  `convert_hf_to_gguf.py` permutes Q/K projection weights on
  llama-architecture models; Courier's loader applied no inverse, so a
  Llama GGUF loaded without error and produced scrambled attention —
  the exact failure `tools/gguf_diff_harness.py` was built to diagnose
  (its docstring names `inverse_llama_permute()` as the fix, which was
  never wired in). Now: the transform math lives in torch-free
  `core/gguf_layout.py` (single source of truth — the harness imports
  from it instead of duplicating); family knowledge stays in the
  adapters via the new `ModelAdapter.gguf_load_transforms()` hook
  (default none; `Llama3Adapter` declares the inverse permute for
  `q_proj`/`k_proj` with the correct per-GQA head counts);
  `GGUFShardManager` applies whatever is declared blindly at a single
  materialization point (`_materialize`) covering fresh disk reads and
  tier-2 dequantize-from-RAM alike, so the tier-1 cache only ever holds
  transformed tensors. Qwen3/Qwen3.5 declare nothing — their converter
  path does not permute (oracle-validated). Pinned cold by the new
  `tests/probe_gguf_layout.py` (round-trip identity, GQA group counts,
  hand-built interleave recovery, blind suffix application) and by
  `TestTier1_LayoutTransforms` in the pytest ladder. A README **GGUF
  Compatibility** matrix records the per-family verdict, and the
  deliberate absence of a GGUF writer is now documented as a decision.

**Added**

- **The model catalog is now an editable JSON file.** `models_catalog.json`
  at the repo root ships pre-populated with the built-in list and IS the
  catalog when present: add a profile (`id`, `params`, `family` matching
  an adapter, `size_gb`, optional `gguf` block) and it appears in the
  dashboard on next boot — no code edit. Deleting the file falls back to
  the built-in catalog; a malformed file falls back LOUDLY at boot and
  invalid entries are skipped by name, so a bad edit can never leave a
  field box without models. Pinned by
  `test_server.py::test_models_catalog_file`.
- **Prefer GGUF Variants (Settings → Model Format).** The toggle the
  feature was always meant to be: catalog models with a published,
  validated quant (Qwen3 via Qwen's official `-GGUF` repos, Llama 3.x
  via community quants with an explicit `--base`) list and load AS that
  quant — same row, `Q4_K_M` in the label, GGUF directory's own status
  — instead of appearing as sibling entries. Smaller downloads (~35% of
  BF16), no INT8 conversion pass, same engine underneath. The
  safetensors row stays visible only while it is the loaded/loading
  model, so flipping the toggle never hides the running engine.
  Families without a validated GGUF path (Qwen3.5, Gemma) are
  deliberately not offered — the README compatibility matrix is the
  gate. Server: catalog `gguf` metadata, variant resolution in
  `/api/models/load` (downloads via `scripts/download_model.py --gguf`
  in a subprocess, reusing its quant scan and loud config-failure path)
  and in preflight (honest size/format in the confirm dialog).
  Config key `prefer_gguf`, default off — byte-for-byte the previous
  behavior. Pinned by `test_server.py::test_prefer_gguf_variant_listing`.
  Uncatalogued local model directories are unaffected either way.

**Fixed**

- **One ENOSPC during INT8 quantization no longer destroys the model's
  loadability.** Observed live: the quantizer's part files match the
  engine's weight glob, so a write that died mid-part (disk full during
  the server's auto-quantize) stranded a truncated
  `model.partNNN.safetensors` that poisoned every subsequent model
  load, and the next quantize attempt CRASHED in `_keys_overlap` trying
  to read the truncated part — blocking the very recovery that would
  have deleted it. Three fixes: (1) `quantize_shard` records every path
  before writing it and removes its own wreckage on any failure (the
  source shard is never written, so the pre-run state is fully
  restored); (2) `_keys_overlap` treats an unreadable part as the
  orphan verdict rather than an error — an unreadable SOURCE still
  raises; (3) a disk preflight refuses to start when the estimated
  output (~0.6× input + margin) doesn't fit in free space, with the
  BF16-still-loads escape hatch spelled out. Pinned cold by the new
  `tests/probe_quantize_recovery.py`. Recovery on an already-poisoned
  directory: delete `*.part*.safetensors` / `*.safetensors.tmp`; the
  original shard is intact.
- **Llama's tokenizer_config no longer triggers per-decode warnings (or
  worse).** Meta ships `clean_up_tokenization_spaces=true`; that
  cleanup is a WordPiece-ism which strips spaces before punctuation on
  the BPE/SentencePiece tokenizers every Courier family uses. Newer
  transformers refuses it and warns on every decode; older versions
  silently apply it, corrupting receipt text. The adapter base now pins
  `clean_up_tokenization_spaces = False` at the single tokenizer
  construction site.
- **The diff harness cried SCRAMBLED at float-storage rounding.** Its
  maiden voyage (Llama-3.2-1B, BF16 safetensors vs bartowski F16 GGUF)
  flagged 15 roles SCRAMBLED with max|diff|=2.98e-08 — nano-scale,
  i.e. the tensors AGREE, and the run actually CONFIRMS the Q/K permute
  fix (a real layout error gives diffs of weight magnitude). Cause: the
  harness's "F16 = no confound" premise fails when the HF checkpoint is
  BF16 — tiny weights below F16's normal range round in conversion —
  and the exact-hash row matching cannot survive a single rounded
  element, so epsilon noise fell through to the scariest verdict (norms
  stayed IDENTICAL because GGUF stores them F32, confirming the
  diagnosis). Now: a value-equality gate (atol 1e-6, far above ~3e-8
  rounding, far below any real weight) returns MATCH before layout
  forensics run; the llama-permute hypothesis uses allclose for the
  same reason (exact equality would blind it to the exact bug it exists
  for on BF16-sourced models); MATCH counts as a pass and the summary
  line says what is actually true.
- **rope_freqs.weight no longer triggers the unmapped-tensor warning.**
  Llama-family GGUFs carry a precomputed RoPE table; Courier's adapter
  is the authoritative inv_freq source (it owns the 3.x piecewise
  scaling), so the file's copy is deliberately unused. It joins a new
  `KNOWN_UNMAPPED` set in the name map, skipped with the rationale in a
  comment; genuinely unknown tensor names still warn.
- **The GGUF diff harness had never been runnable.** It imported
  `get_adapter`, a registry function that does not exist (the registry
  exports `detect_adapter`) — bit-rot from a rename, undetected because
  nothing had ever executed the harness. Fixed to `detect_adapter`,
  with `--adapter <name>` honored through the registry's `ADAPTERS`
  table. Found the honest way: the first real harness run failed on the
  import.
- **`download_model.py --gguf` now fails loud when no config.json can
  be fetched.** The auto-derived base repo (GGUF repo minus the "-GGUF"
  suffix) is wrong for community quants, which live in the quantizer's
  namespace (`bartowski/...`); `snapshot_download` does not raise on a
  missing repo, so the script warned and exited 0 with an unloadable
  model directory (no config.json → adapter detection, dashboard
  family, and the harness all fail later). Now the script exits 1
  naming the repo it tried and the two ways out: `--base
  <org>/<base-model>`, or copying config/tokenizer files from a
  safetensors twin.
- **GGUF models are now reachable from the dashboard.** The engine has
  auto-detected and loaded GGUF since the format-detection branch in
  `create_engine`, and `/api/models/load` loads any ready on-disk
  directory by name — but `_get_models()` listed only the
  `SUPPORTED_MODELS` catalog (20 safetensors repos, zero GGUF), so a
  quant fetched with `download_model.py --gguf` never appeared in
  `available_models` and the dropdown could not offer it. The listing
  now appends **local entries** for every ready on-disk directory the
  catalog doesn't claim: family read from `config.json` and normalized
  by the same rule SD pairing uses (`gemma3_text` → `gemma3`), honest
  size/format labels (`gguf · 0.6 GB`), and the same status machine as
  catalog entries. The dropdown label builder uses `.split("/").pop()`
  so slash-less local ids render (it previously indexed `[1]`, which is
  `undefined` for them). Pinned by
  `test_server.py::test_local_gguf_model_listed`. Payload law, model
  edition: what is on disk must have a road to the operator.
- **Tier-2 oracle test compared floats against raw quantized blocks.**
  `test_dequantization_matches_oracle` read `ReaderTensor.data` as if
  gguf-py returned dequantized values; it returns the raw block stream,
  so the first quantized tensor (the Q8_0 embedding, 34 bytes per 32
  weights = a 34/32 size explosion) failed the reshape. The oracle side
  now goes through `gguf.quants.dequantize`, which yields float32 values
  for every type; Courier's own dequantization was never at fault — the
  header oracle check and the Tier-4 cross-format tests pass unchanged.
- **Main dashboard state now obeys the payload law.** The full state
  object (history, records, queue, ingestion, system, templates, models,
  config) previously reached the client **only** via SSE: `poll()` was an
  empty stub and the Not-Connected screen offered no action, so a stream
  an intermediary proxy silently buffered — the exact hazard
  `X-Accel-Buffering: no` pleads against — meant a permanently blank
  dashboard over a perfectly healthy server. Same shape as the popout
  race, at whole-app scale. Now the state has all three legs the law
  requires: **on-demand fetch** — new `GET /api/state` returns the exact
  object an SSE frame carries, backed by the same builder
  (`_build_full_state`) so the two roads cannot drift (the
  `_cycle_result_payload` discipline), pinned by
  `test_server.py::test_state`; the dashboard's first paint fetches it
  instead of waiting on the stream, and one shared `ingestState()`
  processes both roads identically. **Retry** — a RETRY button on the
  Not-Connected screen, and a stream-silence watchdog in `tick()`: the
  server's keepalive is now a named `ping` event (SSE comments are
  invisible to `EventSource` by spec, so the old `: keepalive` could not
  prove liveness), and total stream silence past 3× the operator's
  refresh cadence falls back to polling `/api/state` at that cadence,
  attempt-gated. **Loud absence** — degraded mode is visible: the header
  reads `· SSE QUIET — POLLING` until real stream traffic resumes.
  `S.connected` now means "API reachable by *some* road," so a working
  REST path keeps the dashboard alive while `EventSource` reconnects.

### Unreleased — 2026-06-08

**Added**

- **Network tab — the single-node network view.** A network of one is
  still a network: the dashboard gains a NETWORK tab showing this
  instance's identity card — a stable **Courier ID** (minted once, stored
  in the ledger's new `meta` table, survives restarts and travels with a
  DB export; copy button included), hostname, version, LAN interface
  addresses, reach/scheme/auth mode, uptime, current and last-completed
  cycle, lifetime totals (cycles · tokens · metered joules), corpus
  holdings, and an honest **Peers: 0** section stating that envelope
  exchange between nodes is designed but not yet implemented. Backed by
  new `GET /api/node` and `GET /api/corpus` endpoints and
  `Database.get_meta/set_meta/cycle_totals`; the Courier ID is the first
  brick of the courier-network protocol. New cold suite
  `tests/probe_node.py` covers the layer beneath the endpoints.
- **Energy surfaced across the UI.** History rows now show each metered
  cycle's joules inline, the expanded cycle view carries an Energy line
  (matching the popout's `412 J (rapl) · 18.1 W avg` format), the panel
  header totals metered energy across listed cycles with the method mix,
  and the Settings drawer's System section reports the active metering
  instrument with a pointer to its `.env` knobs. History API rows and the
  SSE `system` state now carry the energy fields (`energy_j`,
  `energy_method`, `system.energy`) instead of dropping them; the worker's
  meter singleton is now public (`engine.worker.get_meter`).
- **Windows runbook in the README.** *Running Headless & Field Deployment*
  now documents the Windows path end to end instead of a one-line pointer:
  `python start.py` daemon commands in PowerShell, the `python` vs
  `python3`/Store-stub trap, NSSM vs Task Scheduler for the boot-to-running
  appliance path, and the energy-metering fallback to the labeled estimate
  (no sysfs on Windows — tune `COURIER_WATTS_PER_CORE` in `.env`). The
  Codespaces note now also warns that the systemd installer cannot work
  inside a container. `deploy/WINDOWS.md` remains the step-by-step; the
  README now routes to it properly.
- **Energy metering — joules per verdict.** Every completed cycle now
  records what it cost: `engine/energy.py` picks the best instrument the
  host has (Intel RAPL hardware counters → battery discharge telemetry →
  a labeled CPU-time estimate, `COURIER_WATTS_PER_CORE` tunable) and the
  worker banks `energy_j` + `energy_method` on the cycle row. Receipts and
  the dashboard popout show an Energy line ("412 J (rapl) · 18.1 W avg");
  the method always rides along so an estimate can never pass as a
  measurement, and a plugged-in battery refuses to report rather than
  reporting charge flow as load. This is the design's native metric — a
  field node lives on a fixed energy income, so the cost of a verdict
  belongs on the verdict.
- **Corpus retrieval (grounded reference, citable).** New durable-knowledge
  index `corpus.db` (SQLite FTS5/BM25 — zero new dependencies) beside the
  ledger, fed by corpus envelopes from gator's digestor and searched at
  render time by the new `corpus_search` data adapter. Where `verbatim`
  truncated reference documents relevance-blind, `corpus_search` fills its
  token budget with BM25-ranked passages, each cited
  `[doc §section · chunk#n · sha1]`; the query combines template-declared
  terms (`params.query`) with tokens derived deterministically from the
  cycle's own records (`params.from_records`, default on) — an observed
  hull ID retrieves its registry entry and the regulations that mention it.
  Corpus envelopes route to the index, never the ledger; re-ingesting a
  document replaces its chunks. Missing corpus / no matches render loud
  bracketed notices, never errors.
- **Field deployment: systemd service.** New `deploy/` directory:
  `courier.service` (commented unit: start on boot, restart-on-failure with
  a crash-loop guard sized for slow-disk model reloads, journald logging,
  `.env` loading), `install-service.sh` (one-command install/uninstall with
  user/port/permission checks), and `WINDOWS.md` (NSSM / Task Scheduler
  equivalents). This is the designed appliance path: power on → service
  starts → interrupted cycles resume from their last checkpoint.
- **Daemon mode — server survives closed tabs/terminals.** `start.sh --daemon`
  / `python start.py --daemon` launch uvicorn detached in its own session
  (`setsid` on POSIX, detached process group on Windows), with stdio in
  `logs/courier.log` and the PID in `courier.pid`; `stop` and `status`
  companions manage it. Fixes the "server dies when the browser is closed"
  report: nothing in Courier kills on client disconnect — the foreground
  server was being SIGTERM'd because remote terminals (Codespaces/VS Code
  Remote/SSH) dispose the pty, and everything under it, once their hosting
  client disconnects. Detaching removes the server from the pty's process
  tree entirely.

**Changed**

- **ARCHITECTURE.md brought current.** The reference doc described the
  system as of two sessions ago; a newcomer had to reconstruct the present
  by replaying the changelog as diffs. Added: *Corpus & Retrieval*, *Node
  Identity & Network*, *Energy Accounting*, the write-posture model under
  *Security*, the NETWORK tab + payload law under *Dashboard*, the
  textproc rules and `(text, count)` contract under *Inference Engine*,
  and both file trees (here and there) now list `energy.py`, `textproc.py`,
  `corpus.py`, `deploy/`, and the posture-bearing `security.py`.

- **Energy dials moved from env vars to Settings — one source of truth.**
  `watts_per_core` and `energy_sample_interval` are now ordinary persistent
  config keys, edited in Settings → System → Energy Metering beside every
  other dial, applied to the live meter at boot and on every save (next
  cycle uses the new value; no restart). Headless units edit the config
  file directly — still the same single source. The short-lived
  `COURIER_WATTS_PER_CORE` / `COURIER_ENERGY_SAMPLE_INTERVAL` env vars
  (introduced earlier this cycle) are now IGNORED, loudly: boot prints a
  warning naming the setting to use if either is set. One parameter must
  not live in two places.

**Fixes**

- **Boot log standardized — one grammar, two voices.** The console mixed
  the shell's `[courier]`-prefixed lines with the server's bare indented
  ones, tips floated unprefixed, and a foreground start printed the
  dashboard URL before attempting to bind — so a port collision read as
  "here's your dashboard" followed by a raw `address already in use`.
  Now every console line from both the launcher and the server follows
  `[courier] Key: value` (warnings keep `⚠`), the `dim` helper carries
  the prefix in both `start.sh` and `start.py`, and the foreground path
  reuses the daemon path's existing already-running check: if a daemon
  holds the port, it says so — with the pid and the working URL —
  instead of failing after promising a dashboard.

- **`pytest tests/` collection fixed — the fake-torch collision.** Two
  files died at collection on a machine that runs models fine:
  `test_globless_cycle.py` installed a bare EMPTY `sys.modules["torch"]`
  fake at import, and under pytest's single shared interpreter that empty
  module became every later file's torch — `test_resilience` (needs
  `get_rng_state`) and `test_sd_lossless` (needs `Tensor`) crashed, and
  the real library could never load in that process at all. Each file
  worked standalone; only the ensemble failed. Now one canonical
  `tests/_probe_util.ensure_torch()` — prefer real torch when importable,
  else ONE adequate shared stub marked `_courier_stub` — replaces the
  empty fake and test_resilience's private tempfile-written stub.
  Standalone probe scripts keep their process-local fakes (never
  pytest-collected); new cold tests must use the helper. Fixing this also
  surfaced a real regression from the token-count work: the pipeline's
  resume path read `row["output_tokens"]` from recovery-built row dicts
  that lack the key → `row.get(...)`; `test_resilience` (38 checks,
  cold-capable — it runs without torch) now passes shared-process and
  standalone, including full crash-recovery.
- **Popout race, second organ: stage outputs.** The config-fetch fix left a
  sibling untouched — the RESULTS payload (model, template, stage outputs,
  images) reached popouts only via the SSE state, and a popout opened
  before its cycle landed in that map showed "No stage outputs available"
  with Model "—" and never recovered on its own (a background-throttled
  opener processes no healing pushes; a manual refresh looked like a cache
  fix but was just a refetch). Results now follow the same discipline as
  configs: a shared server-side payload builder (`_cycle_result_payload`)
  guarantees `GET /api/cycles/{id}/result` and the SSE entry are identical
  — the REST shape had silently omitted `images` — and the client gains an
  on-demand `fetchCycleResult` cache that popouts populate before first
  paint and the refresh loop retries, with SSE data taking precedence when
  present. Missing results are loud ("stage outputs not loaded yet —
  fetching" in the popout banner and history notice, RETRY refetches
  both payloads), never a silent "No stage outputs available".
- **The 'think' block bug — three cooperating defects on the image-stage
  path.** A truncated non-thinking vision stage displayed an empty
  `<think></think>` block and reported "66 tokens" for a 32-token
  generation. Causes, all fixed: (1) `format_prompt` and
  `format_multimodal_prompt` accepted a `thinking` parameter documented as
  "Reserved for future use" and silently ignored it — so with thinking off,
  the model spent ~5 of its budgeted tokens emitting the empty think pair
  itself; both formatters now prime the assistant turn with the
  Qwen3-family closed-think convention (the text-only chat-template path
  already did this). (2) The think-strip was gated on *not truncated*,
  a guard meant to protect unclosed blocks that also caught closed ones —
  truncated receipts displayed the junk; the rules now live in torch-free
  `engine/textproc.py`: empty pairs stripped always, closed blocks stripped
  whenever thinking is off, unclosed blocks left intact, and a strip never
  blanks an output. (3) Stage and cycle token counts were `len(text)//4`
  estimates over final text that *included the scaffolding and the
  appended truncation banner*; the engine now returns
  `(text, generated_token_count)` (the pipeline still accepts bare strings
  from stubs), `cycle_stages.output_tokens` records the real count, and
  `pipeline.stage_token_count` prefers it everywhere with the estimate as
  fallback for legacy rows. Sixteen cold probes in
  `tests/probe_textproc.py`, including the screenshot case by name.
- **Popout "metadata dashes" — the deeper cause, fixed for good.** The
  cache fix removed one trigger (stale app code); a second one survived:
  `fetchCycleConfig` parsed the cycle's `config` JSON in the same breath as
  the row's ledger facts inside a silent `catch{}` — so any fetch failure
  or malformed config column voided the timestamps, energy, and params it
  had already fetched, permanently and without a word. Now the fragile
  parse is isolated (ledger facts are banked regardless), the endpoint
  guarantees its contract (`report.normalize_config_json`: valid JSON
  passes through, legacy Python-repr rows are repaired via
  `ast.literal_eval`, garbage degrades to `{}` plus an explicit
  `config_error` — five probes), and no failure is silent: the popout and
  the expanded history row show an amber notice with the actual reason and
  a RETRY button, and open popouts self-heal when a later fetch succeeds.
  Silent dashes were a diagnosis withheld; now the UI states what it
  couldn't load and why.

- **Cycles failed when model output contained non-Latin characters.** Report
  writing (`worker.py`) and most other file I/O used the platform default
  encoding, so on Windows (cp1252) a cycle whose output held any character
  outside that codepage — `⚠`, an em-dash, a degree sign, an emoji, accented or
  non-Latin text — died with `UnicodeEncodeError: 'charmap' codec can't
  encode...`. All text reads and writes across the codebase (reports, pipeline
  output, templates, ingest, adapters, CLI, model config) now specify
  `encoding="utf-8"`, so Unicode round-trips regardless of OS.

- **Dashboard returned HTTP 500 on load.** `serve_dashboard` read
  `dashboard.html` using the platform's default text encoding, which on Windows
  is `cp1252` and raised `UnicodeDecodeError` on the first non-ASCII byte. The
  dashboard read — and every config read/write — now specifies
  `encoding="utf-8"`.
- **Path traversal in model deletion.** `DELETE /api/models/{model_name}`
  joined the supplied name onto the models directory with no validation before
  calling `shutil.rmtree`, so a name containing `..` or path separators could
  remove files outside that directory. A shared `_reject_traversal` guard now
  protects the model-delete, model-detail, and image-serving routes (the image
  route's previous inline check was folded into the shared helper).
- **SSE stream leaked tasks and could spam errors.** `/api/events` never
  detected a disconnected client, so a background loop outlived every closed or
  refreshed dashboard tab; and a persistent state-build error emitted an error
  frame on every tick indefinitely. The stream now ends cleanly on client
  disconnect and stops after repeated consecutive errors.

**Security**

- **Write-auth posture: configurable, safest-by-default, loud when loose.**
  The tokenless local write path authenticates by transport facts a reverse
  proxy destroys (loopback peer, local `Host`), and inside a Codespace the
  gate trusted the proxy automatically — correct while the forwarded port
  is Private, silently wrong the moment it's made Public, and previously
  neither configurable nor announced. Now: `COURIER_REQUIRE_TOKEN=1`
  hard-locks every write behind the bearer token (beats every other
  setting, including `COURIER_INSECURE` — on conflict, safest wins);
  `COURIER_TRUST_PROXY=0` opts a Codespace out of automatic proxy trust
  (`=1` opts other authenticated proxies in, and is now documented — it
  existed as a hidden knob); and the effective posture is decided in one
  pure, probed function (`core/security.py::write_posture`), printed at
  startup with a `⚠ AUTH WARNING` when trust is broad, and shown on the
  NETWORK tab in amber/red with the hazard note. See **Security &
  Networking → Proxies & forwarded ports**. Nine new posture probes in
  `tests/probe_node.py`.

- **API token is no longer printed.** The auto-generated default token was
  written to stdout on first boot, leaking it into terminal scrollback and into
  any redirected/captured logs. It is now written to `data/default_token.txt`
  (`0600`); only the file location, not the secret, is printed. (It is stored
  in the database as a hash, as before, so it cannot be recovered after the
  fact — keep the file or rotate the token.)
- **Write authorization reworked — secure *and* turnkey.** Authorization was
  effectively disabled: the `insecure` flag defaulted on, and the launcher runs
  the app object directly so the secure path was never engaged. Writes are now
  protected by origin (cross-site browser requests and non-local `Host` headers
  are rejected) while the local same-origin dashboard continues to work with no
  token. A bearer token remains accepted for scripts and remote/automation use,
  and `COURIER_INSECURE=1` restores the old full-bypass behavior. See
  **Security & Networking** for the complete model and the `0.0.0.0` caveat.

**Configuration**

- **No hidden knobs — configurability pass over the session's additions.**
  Every should-be-configurable parameter now has an operator-facing surface,
  registered where its siblings live: `COURIER_WATTS_PER_CORE` and the new
  `COURIER_ENERGY_SAMPLE_INTERVAL` (battery sampling cadence) join the
  README's recognized-variables table and `.env.example`; the
  `corpus_search` adapter gains `max_terms` (cap on record-derived query
  terms, default 24) alongside its existing params; the digestor gains
  `--min-chunk-chars` (fragment-merge floor, default 200) to match
  `--chunk-chars`. Remaining literals in these modules are named module
  constants — visible and greppable, deliberately not knobs.

- **`HF_TOKEN` provisioning + `.env` support.** `HF_TOKEN` was only read for a
  startup status line and never passed to the download, and there was no way to
  supply it short of exporting it each session (it had relied on a Codespaces
  secret). Courier now loads a project-root `.env` at startup (dependency-free
  parser; real environment variables still take precedence) and passes
  `HF_TOKEN` explicitly to `snapshot_download`, so gated-model downloads work
  whenever the token is set. Added `.env.example` and a `.gitignore` that keeps
  `.env` and `data/default_token.txt` out of version control.

**Notes**

- `transformers` requires `torch >= 2.4`; an older install (e.g. `2.2.2`)
  causes transformers to disable the PyTorch backend. On Windows, a too-new CPU
  wheel (e.g. `2.12`) can fail to import with `OSError [WinError 1114]` — a DLL
  initialization failure, usually a missing/outdated Microsoft VC++ runtime.
  `torch==2.5.1+cpu` is a known-good middle ground; otherwise install the
  current VC++ redistributable or pin a wheel compatible with your environment.

## License

TBD
