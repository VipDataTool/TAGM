#!/usr/bin/env python3
"""Probe: two-engine resident-RAM partition + admission (multimodel spec §5).

partition_resident_budget is a pure function of injected inputs, so it verifies
cold — no torch, no weights, no psutil. Exercises the REAL engine.sizing code,
the single budget authority over a streaming primary + a fully-resident
secondary (the speculative draft, or a routing engine).

Mirrors the §9 admission bullet (non-overlapping caps for a fitting pair, None
for an oversized draft, None when the dial is off) plus boundaries.

    cd courier && python tests/probe_partition.py
"""
from _probe_util import Probe, add_src_to_path

add_src_to_path()
from engine.sizing import (                                          # noqa: E402
    partition_resident_budget,
    resident_budget_bytes,
    DEFAULT_PRIMARY_MIN_CAP,
)

GB = 1024 ** 3
MB = 1024 ** 2
p = Probe("partition")

# ── A fitting pair: 16 GB box, 90% dial, 0.8B draft (~1.6 GB bf16) ──────────
p.section("fitting pair")
DRAFT = int(1.6 * GB)
res = partition_resident_budget(16 * GB, 90, 1 * GB, DRAFT,
                                primary_kv_headroom_bytes=512 * MB,
                                secondary_kv_headroom_bytes=128 * MB)
budget = resident_budget_bytes(16 * GB, 90, 1 * GB)   # 14.4 GB
p.check("fitting pair admitted (dict)", isinstance(res, dict))
p.check("secondary cap == draft footprint (pinned full)", res["secondary_cap"] == DRAFT)
p.check("primary cap == budget remainder after secondary + headrooms",
        res["primary_cap"] == budget - DRAFT - 512 * MB - 128 * MB)
p.check("caps + headroom fit within the single budget",
        res["secondary_cap"] + res["primary_cap"] + 512 * MB + 128 * MB <= budget)
p.check("both caps strictly positive", res["primary_cap"] > 0 and res["secondary_cap"] > 0)

# ── Dial off -> refuse ─────────────────────────────────────────────────────
p.section("dial off")
p.check("dial 0 -> None", partition_resident_budget(16 * GB, 0, 1 * GB, DRAFT) is None)
p.check("negative dial -> None", partition_resident_budget(16 * GB, -5, 1 * GB, DRAFT) is None)
p.check("reserve eats percentage -> None",
        partition_resident_budget(8 * GB, 5, 8 * GB, 256 * MB) is None)

# ── Oversized / starved -> refuse ──────────────────────────────────────────
p.section("oversized / starved")
p.check("draft larger than budget -> None",
        partition_resident_budget(16 * GB, 90, 1 * GB, 20 * GB) is None)
p.check("secondary + its headroom >= budget -> None",
        partition_resident_budget(16 * GB, 90, 1 * GB,
                                  secondary_footprint_bytes=budget - 64 * MB,
                                  secondary_kv_headroom_bytes=128 * MB) is None)
p.check("primary below thrash floor -> None",
        partition_resident_budget(16 * GB, 90, 1 * GB,
                                  secondary_footprint_bytes=budget - DEFAULT_PRIMARY_MIN_CAP + 1) is None)

# ── primary_min_cap boundary ───────────────────────────────────────────────
p.section("floor boundary")
floor = 2 * GB
secondary = budget - floor
ok = partition_resident_budget(16 * GB, 90, 1 * GB, secondary, primary_min_cap=floor)
p.check("primary exactly at floor -> admitted", isinstance(ok, dict))
p.check("primary cap equals the floor", bool(ok) and ok["primary_cap"] == floor)
p.check("one byte under floor -> None",
        partition_resident_budget(16 * GB, 90, 1 * GB, secondary + 1, primary_min_cap=floor) is None)

# ── Channel-agnostic: a routing-only secondary partitions the same way ─────
p.section("channel-agnostic")
routing = partition_resident_budget(32 * GB, 80, 2 * GB, 4 * GB)
p.check("larger box, routing engine -> admitted", isinstance(routing, dict))
p.check("routing secondary pinned full", bool(routing) and routing["secondary_cap"] == 4 * GB)

# ── Input validation: negative bytes are a caller bug, not a refusal ───────
p.section("input validation")
for bad in (
    dict(total_ram_bytes=-1, max_ram_percent=90, reserve_bytes=GB, secondary_footprint_bytes=GB),
    dict(total_ram_bytes=16 * GB, max_ram_percent=90, reserve_bytes=GB, secondary_footprint_bytes=-1),
    dict(total_ram_bytes=16 * GB, max_ram_percent=90, reserve_bytes=-GB, secondary_footprint_bytes=GB),
):
    try:
        partition_resident_budget(**bad)
        p.check("negative input raises ValueError", False)
    except ValueError:
        p.check("negative input raises ValueError", True)

# ── Seam invariant (batch-10 audit): an admitted pair must never out-claim
#    the box. This is the connection-shaped assertion the component tests
#    lacked — the two-engines-two-full-budgets OOM lived exactly here. ──
p.section("seam: admitted caps stay within physical RAM")
for pct in (30, 60, 86, 100):
    r = partition_resident_budget(8 * GB, pct, 1 * GB, DRAFT)
    if r is not None:
        p.check(f"dial {pct}%: primary+secondary caps <= total - reserve",
                r["primary_cap"] + r["secondary_cap"] <= 8 * GB - 1 * GB)
    else:
        p.check(f"dial {pct}%: pair refused rather than over-committed", True)

p.done()
