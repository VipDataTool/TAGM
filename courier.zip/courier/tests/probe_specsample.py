#!/usr/bin/env python3
"""Probe: the speculative accept/reject rule is distribution-preserving.

This validates the MATH in engine/speculative.py without torch or models — the
single-position core of the algorithm: given target dist p and draft dist q,

    sample x ~ q
    accept x with prob min(1, p[x]/q[x])
    else return a draw from normalize((p - q)+)

produces a token distributed exactly as p. Run over many random (p, q) pairs and
assert the empirical output distribution matches p (small total-variation gap),
and that the temperature->0 (one-hot p) case returns p's argmax deterministically
— i.e. lossless greedy. Engine integration (snapshot/restore, the K-token sweep)
still needs the real models on-rig; this isolates the accept/reject correctness.
"""
import sys
import numpy as np

rng = np.random.default_rng(0)
PASS = FAIL = 0


def check(name, ok):
    global PASS, FAIL
    print(f"  {'PASS' if ok else 'FAIL'}  {name}")
    PASS += ok
    FAIL += (not ok)


def spec_step(p, q, r_accept, draw_q, draw_resid):
    """One speculative step. r_accept/draw_* are injected randomness so the test
    is deterministic. Mirrors speculative.py's rule exactly."""
    x = draw_q
    ratio = 1.0 if q[x] <= 0 else min(1.0, p[x] / q[x])
    if r_accept < ratio:
        return x
    resid = np.clip(p - q, 0, None)
    s = resid.sum()
    resid = resid / s if s > 0 else p
    return draw_resid(resid)


def empirical(p, q, n=200_000):
    out = np.zeros_like(p)
    qc = q / q.sum()
    pc = p / p.sum()
    xs = rng.choice(len(q), size=n, p=qc)          # x ~ q
    rs = rng.random(n)                              # accept coin
    # pre-draw residual samples lazily per trial (residual fixed given p,q)
    resid = np.clip(pc - qc, 0, None)
    rs_sum = resid.sum()
    resid_n = resid / rs_sum if rs_sum > 0 else pc
    resid_draws = rng.choice(len(q), size=n, p=resid_n)
    for i in range(n):
        x = xs[i]
        ratio = 1.0 if qc[x] <= 0 else min(1.0, pc[x] / qc[x])
        out[x if rs[i] < ratio else resid_draws[i]] += 1
    return out / n


# 1) Distribution preservation across random vocabularies and temperatures.
for trial in range(6):
    V = rng.integers(5, 12)
    p = rng.random(V) ** 2 + 1e-3
    q = rng.random(V) ** 2 + 1e-3
    p /= p.sum(); q /= q.sum()
    emp = empirical(p, q)
    tv = 0.5 * np.abs(emp - p).sum()
    check(f"output ~ target p (V={V}, TV={tv:.4f} < 0.02)", tv < 0.02)

# 2) Sanity: when q == p, everything is accepted, output == p.
p = rng.random(8); p /= p.sum()
emp = empirical(p, p.copy())
check("q==p reproduces p (TV<0.02)", 0.5 * np.abs(emp - p).sum() < 0.02)

# 3) Greedy reduction: p one-hot at its argmax. Whatever the draft proposes,
#    the committed token must be p's argmax — deterministically, lossless.
for trial in range(4):
    V = rng.integers(5, 12)
    target = int(rng.integers(V))
    p = np.zeros(V); p[target] = 1.0
    q = rng.random(V); q /= q.sum()
    # try every possible draft token + both accept-coin extremes
    ok = True
    for x in range(V):
        for r in (0.0, 0.999999):
            got = spec_step(p, q, r, x, lambda d: int(np.argmax(d)))
            if got != target:
                ok = False
    check(f"greedy one-hot p always commits argmax (V={V})", ok)

print(f"\n{PASS}/{PASS+FAIL} checks passed")
sys.exit(0 if FAIL == 0 else 1)
