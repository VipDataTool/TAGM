"""Ledger intake + windowing tests (stage one of the ingestion rework).

Verifies the DB-as-substrate behavior with no model and no torch — pure
SQLite plus a few tiny temp files, runs in milliseconds:

- tabular files (CSV/JSON) ingest as inline rows tagged source_type='inbox'
- image files ingest as a metadata row carrying an on-disk `path` (pixels stay
  on disk), not inline content
- snapshot() claims ONLY unconsumed inbox rows (the per-cycle window) and never
  touches reference rows
- reference rows are persistent: returned every cycle, never consumed
- a second cycle only claims data that arrived since the first (windowing)
"""

import json
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "src"))

from core.db import Database          # noqa: E402
from data import ingest               # noqa: E402


@pytest.fixture
def db(tmp_path):
    d = Database(tmp_path / "courier.db")
    yield d
    d.close()


def _write_csv(p):
    p.write_text("vessel,length_m\nSloop A,12\nBarge B,40\nFerry C,55\n")
    return p


def _write_json_array(p):
    p.write_text(json.dumps([{"reading": 1}, {"reading": 2}]))
    return p


def _write_fake_image(p):
    # Not a real decodable image — intake records path/checksum regardless;
    # dims are best-effort (PIL will fail to open and dims stay None).
    p.write_bytes(b"\xff\xd8\xff\xe0FAKEJPEGBYTES")
    return p


def test_tabular_intake_rows_are_inbox(db, tmp_path):
    n_csv = ingest.ingest_csv_file(db, _write_csv(tmp_path / "boats.csv"))
    n_json = ingest.ingest_json_file(db, _write_json_array(tmp_path / "sensors.json"))
    assert n_csv == 3 and n_json == 2
    assert db.unconsumed_count() == 5  # all inbox, all pending


def test_image_intake_is_pointer_not_inline(db, tmp_path):
    img = _write_fake_image(tmp_path / "boat_001.jpg")
    rid = ingest.ingest_image_file(db, img)
    assert rid > 0
    cid = "cyc-img"
    db.snapshot(cid)
    recs = db.get_snapshot_records(cid)
    assert len(recs) == 1
    r = recs[0]
    assert r["source_type"] == "inbox"
    assert r["mime_type"].startswith("image/")
    assert r["path"] == str(img)          # pointer to pixels on disk
    meta = json.loads(r["content"])       # content is metadata, not pixels
    assert meta["filename"] == "boat_001.jpg"


def test_snapshot_windows_inbox_only_and_leaves_reference(db, tmp_path):
    # Reference (persistent companion data) + inbox (windowed).
    ingest.ingest_json_file(db, _write_json_array(tmp_path / "star_catalog.json"),
                            source_id="stars", source_type="reference")
    ingest.ingest_csv_file(db, _write_csv(tmp_path / "boats.csv"))  # 3 inbox

    assert db.unconsumed_count() == 3            # reference excluded from "pending"

    claimed = db.snapshot("cyc-1")
    assert claimed == 3                          # only inbox claimed
    assert db.unconsumed_count() == 0

    refs = db.get_reference_records()
    assert len(refs) == 2
    assert all(r["source_type"] == "reference" for r in refs)
    # Reference must survive a snapshot — still returned, never stamped consumed.
    refs_after = db.get_reference_records()
    assert len(refs_after) == 2


def test_second_cycle_only_sees_new_arrivals(db, tmp_path):
    ingest.ingest_csv_file(db, _write_csv(tmp_path / "day1.csv"))   # 3 inbox
    assert db.snapshot("cyc-1") == 3

    # New data arrives before the next cycle.
    ingest.ingest_json_file(db, _write_json_array(tmp_path / "day2.json"))  # 2 inbox
    assert db.unconsumed_count() == 2
    assert db.snapshot("cyc-2") == 2             # only day2, not day1 again

    assert len(db.get_snapshot_records("cyc-1")) == 3
    assert len(db.get_snapshot_records("cyc-2")) == 2


def test_dispatch_by_extension(db, tmp_path):
    ingest.ingest_file(db, _write_csv(tmp_path / "a.csv"))
    ingest.ingest_file(db, _write_json_array(tmp_path / "b.json"))
    ingest.ingest_file(db, _write_fake_image(tmp_path / "c.png"))
    db.snapshot("cyc")
    recs = db.get_snapshot_records("cyc")
    mimes = sorted({r["mime_type"].split("/")[0] for r in recs})
    # Images are image/*; tabular rows use the default text/* mime.
    assert "image" in mimes and "text" in mimes
    img_rows = [r for r in recs if r["mime_type"].startswith("image/")]
    assert len(img_rows) == 1 and img_rows[0]["path"].endswith("c.png")
