#!/usr/bin/env python3
"""Probe: engine registry spine (multimodel spec §1-§3, §8 step 1).

The registry's role->engine bookkeeping is pure (torch-free), so it verifies
cold. The defining requirement (§3): with nothing enabled the registry holds
exactly one engine, ``primary``, and resolves identically to the single-model
build. Also checks routing fallback, independent secondary lifecycle, and the
footprint accounting that feeds the §5 partition.

    cd courier && python tests/probe_registry.py
"""
from _probe_util import Probe, add_src_to_path

add_src_to_path()
from engine.registry import EngineRegistry, make_entry, PRIMARY  # noqa: E402

p = Probe("registry")

# Stand-in handles — the registry stores opaque objects, never calls torch.
prim = make_entry(streamer="PRIM_STREAMER", infer_fn=lambda s, **k: "P:" + s,
                  model_path="models/Qwen3.5-4B", multimodal=True,
                  footprint_bytes=8 * 1024 ** 3)
draft = make_entry(streamer="DRAFT_STREAMER", infer_fn=lambda s, **k: "D:" + s,
                   model_path="models/Qwen3.5-0.8B", footprint_bytes=1_600_000_000)

# ── Default/dormant shape: only primary ────────────────────────────────────
p.section("default = single primary (dormant)")
r = EngineRegistry()
r.set_primary(prim)
p.check("exactly one engine", r.count() == 1)
p.check("is_single() true", r.is_single())
p.check("roles == [primary]", r.roles() == [PRIMARY])
p.check("resolve(None) -> primary", r.resolve(None)["streamer"] == "PRIM_STREAMER")
p.check("resolve('primary') -> primary", r.resolve("primary")["streamer"] == "PRIM_STREAMER")
p.check("unknown role falls back to primary (routing policy)",
        r.resolve("does-not-exist")["streamer"] == "PRIM_STREAMER")
p.check("infer_fns has only primary", list(r.infer_fns()) == [PRIMARY])
p.check("primary infer_fn works", r.resolve(None)["infer_fn"]("x") == "P:x")

# ── Entry normalization + required-field guard ─────────────────────────────
p.section("entry normalization")
p.check("optional fields defaulted", r.get(PRIMARY)["resident_cap"] == 0
        and r.get("primary")["multimodal"] is True)
try:
    r.set("bad", {"streamer": object()})  # missing infer_fn/model_path
    p.check("missing required field raises", False)
except ValueError:
    p.check("missing required field raises", True)

# ── Add a secondary (Channel A routing engine / Channel B draft) ───────────
p.section("secondary lifecycle (independent of primary)")
r.set("draft", draft)
p.check("two engines now", r.count() == 2)
p.check("not single anymore", not r.is_single())
p.check("roles primary-first", r.roles() == [PRIMARY, "draft"])
p.check("resolve('draft') -> draft", r.resolve("draft")["streamer"] == "DRAFT_STREAMER")
p.check("infer_fns has both", set(r.infer_fns()) == {PRIMARY, "draft"})

p.section("footprint accounting (feeds §5 partition)")
p.check("secondary footprint readable", r.secondary_footprint_bytes("draft") == 1_600_000_000)
p.check("total footprint sums both", r.total_footprint_bytes() == 8 * 1024 ** 3 + 1_600_000_000)

# ── Revert to dormant: removing secondary restores single-engine state ─────
p.section("revert to dormant")
r.clear_secondary()
p.check("back to single primary", r.is_single() and r.roles() == [PRIMARY])
try:
    r.remove(PRIMARY)
    p.check("refuses to remove primary", False)
except ValueError:
    p.check("refuses to remove primary", True)

p.done()
