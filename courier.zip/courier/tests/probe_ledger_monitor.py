#!/usr/bin/env python3
"""Ledger-vs-monitor diagnostic for Courier (handoff §5 bug 2).

This is the `test_vision_smoke` of the ingestion ledger: a standalone,
instrumented probe (run directly with `python`, NOT pytest — pytest hides the
output). It needs NO torch, NO weights, NO network — pure SQLite + the real
ingest/adapter/worker code. It runs in milliseconds.

THE BUG IT LOCALIZES
--------------------
A cycle that demonstrably SAW an image showed `DATA RECORDS: 0` / `unconsumed:
0` in the monitor. Two hypotheses (handoff §5):

  (A) the panel reflects POST-snapshot state — the cycle already claimed
      (consumed) the inbox image, so `unconsumed` is correctly 0 while the
      image is still in the ledger (total >= 1). A display-timing artifact,
      not data loss.
  (B) the image reached the engine by a path that left NO ledger record —
      a real bug (e.g. the old directory-glob fallback bypassing the ledger).

The decisive fact is `total_records`, NOT `unconsumed`:
  * total == 0  while the engine saw an image  -> (B), real leak.
  * total >= 1, unconsumed == 0 after snapshot  -> (A), expected timing.

WHAT THIS PROBE PROVES COLD
---------------------------
On the CURRENT (globless) build the worker feeds images to the engine ONLY
through `_records_by_source` -> the image adapter's `render_records()`, which
draws image paths from the snapshot's ledger rows. There is no worker path
that hands the engine an image without a ledger row. This probe demonstrates
that invariant and prints the exact monitor numbers before and after the
cycle's snapshot so the (A)-vs-(B) question is unambiguous.

The matching ON-BOX check (handoff §5): run a fresh image cycle on the real
model and look at the report's "Source Images" section. Present = the ledger
recorded it (and the monitor's 0 was post-snapshot timing -> A). Absent while
the description still saw the image = a leak -> B. This probe and that check
test the same invariant from the cold side.

    cd courier
    python tests/probe_ledger_monitor.py
"""

import json
import sys
import tempfile
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "src"))

# This probe targets the (torch-free) ingestion ledger logic. worker.py pulls
# in torch transitively at import time (engine.checkpoint), only ever using it
# inside functions we don't call here. If torch isn't installed (the cold
# sandbox), inject a bare stub so we still exercise the REAL _records_by_source
# rather than a re-implementation. If torch IS installed, this is a no-op.
import types  # noqa: E402
try:
    import torch  # noqa: F401
except ModuleNotFoundError:
    sys.modules["torch"] = types.ModuleType("torch")

from core.db import Database                       # noqa: E402
from data import ingest                            # noqa: E402
from data.adapters import image_file               # noqa: E402
from engine.worker import _records_by_source       # noqa: E402
from template import Template                       # noqa: E402

LINE = "=" * 70
_fails = []


def check(label, got, want):
    ok = got == want
    print(f"  [{'PASS' if ok else 'FAIL'}] {label}: got {got!r}, want {want!r}")
    if not ok:
        _fails.append(label)
    return ok


def monitor_view(db, when):
    """Print exactly what the dashboard/CLI monitor reads (ingestion_stats)."""
    s = db.ingestion_stats()
    print(f"  MONITOR ({when}):  Total: {s['total_records']}   "
          f"unconsumed: {s['unconsumed']}   consumed: {s['consumed']}")
    return s


def make_image(path: Path):
    # Minimal valid-enough file; pixels never enter the DB, only the path does.
    path.write_bytes(b"\xff\xd8\xff\xe0\x00\x10JFIF" + b"\x00" * 32)
    return path


def image_template():
    """A one-source template whose source is an image_file adapter."""
    return Template.from_dict({
        "template": {"id": "probe", "name": "probe"},
        "model": {"id": "Qwen/Qwen3.5-4B"},
        "data": {"sources": {"images": {"adapter": "image_file",
                                        "budget_tokens": 200}}},
        "stages": [{"label": "Look", "system_prompt": "Describe.",
                    "input": {"sources": ["images"]}}],
    })


def main():
    print(LINE)
    print("LEDGER-VS-MONITOR DIAGNOSTIC  (handoff §5 bug 2)")
    print(LINE)

    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        db = Database(td / "courier.db")
        tpl = image_template()

        # ── 1. Ingest one image as the upload/sweep path does ────────────
        print("\n[1] Ingest one inbox image (real ingest_image_file)")
        img = make_image(td / "boat_001.jpg")
        ingest.ingest_image_file(db, img, source_type="inbox")
        pre = monitor_view(db, "pre-cycle")
        check("image recorded in ledger (total_records)", pre["total_records"], 1)
        check("image pending before cycle (unconsumed)", pre["unconsumed"], 1)

        # ── 2. Cycle start: snapshot claims the windowed inbox row ───────
        print("\n[2] Cycle start: snapshot() claims the inbox window")
        cycle_id = db.create_cycle(cycle_number=1, template_id="probe", config={})
        claimed = db.snapshot(cycle_id)
        check("snapshot claimed the image row", claimed, 1)
        post = monitor_view(db, "post-snapshot")
        # THE crux: total stays, unconsumed drops to 0. This is exactly the
        # "0 unconsumed" the original monitor showed — and it is CORRECT.
        check("image STILL in ledger after snapshot (total_records)",
              post["total_records"], 1)
        check("unconsumed == 0 after snapshot (the reported number, expected)",
              post["unconsumed"], 0)

        # ── 3. The engine's images come from the ledger, via render_records
        print("\n[3] What the engine actually receives this cycle")
        rbs = _records_by_source(db, cycle_id, tpl)
        img_recs = rbs.get("images", [])
        check("image source bound to 1 ledger record", len(img_recs), 1)
        adapter = image_file.Adapter()
        adapter.connect({"path": ""})
        text = adapter.render_records(img_recs, token_budget=200)
        engine_paths = [str(p) for p in adapter.image_paths]
        print(f"  placeholder text -> {text!r}")
        print(f"  engine image_paths -> {engine_paths}")
        check("engine sees exactly the ledgered image", len(engine_paths), 1)
        check("engine path == on-disk pointer from the ledger row",
              engine_paths[0], str(img))
        # The report's "Source Images" section is fed from these same paths,
        # so present-in-report  <=>  present-in-ledger.

        # ── 4. Negative control: no ledger row => engine sees nothing ────
        print("\n[4] Negative control: empty ledger, fresh cycle")
        db2 = Database(td / "empty.db")
        cyc2 = db2.create_cycle(cycle_number=1, template_id="probe", config={})
        db2.snapshot(cyc2)
        rbs2 = _records_by_source(db2, cyc2, tpl)
        adapter2 = image_file.Adapter()
        adapter2.connect({"path": ""})
        adapter2.render_records(rbs2.get("images", []), token_budget=200)
        check("no ledger row -> engine gets zero images (no silent leak path)",
              len(adapter2.image_paths), 0)

        # ── 5. Reference image: fed to engine AND listed in the report ───
        # This is the exact shape of the observed mismatch: a cycle that
        # described an image while the report showed no Source Images. The
        # cause is a REFERENCE image (persistent companion data, fed every
        # cycle) — engine-visible, but absent from a report built only from
        # the inbox snapshot. The report must list it too.
        print("\n[5] Reference image: engine-visible AND report-listed")
        db3 = Database(td / "ref.db")
        ref_img = make_image(td / "neolithic.jpg")
        ingest.ingest_image_file(db3, ref_img, source_type="reference")
        cyc3 = db3.create_cycle(cycle_number=16, template_id="probe", config={})
        db3.snapshot(cyc3)                       # claims inbox only; ref untouched
        stats3 = monitor_view(db3, "reference-only cycle")
        rbs3 = _records_by_source(db3, cyc3, tpl)
        engine_ref = len(rbs3.get("images", []))
        report_ref = [im["name"] for im in db3.cycle_image_names(cyc3)]
        print(f"  engine sees (reference) -> {engine_ref} image(s)")
        print(f"  report Source Images    -> {report_ref}")
        check("reference image IS fed to the engine", engine_ref, 1)
        check("reference image IS listed in the report (the fix)",
              report_ref, ["neolithic.jpg"])
        check("reference image is not 'unconsumed inbox' (monitor stays 0)",
              stats3["unconsumed"], 0)

    # ── Verdict ──────────────────────────────────────────────────────────
    print("\n" + LINE)
    if _fails:
        print(f"RESULT: {len(_fails)} CHECK(S) FAILED -> {_fails}")
        print("A failure here means the ledger invariant is broken; investigate.")
        return 1
    print("RESULT: ALL CHECKS PASS")
    print(
        "Interpretation: on this build the engine can only see an image that\n"
        "has a ledger row, and after a cycle's snapshot the monitor correctly\n"
        "shows unconsumed=0 while total_records stays >=1. A monitor reading of\n"
        "'0 unconsumed' during/after a cycle is therefore the EXPECTED post-\n"
        "snapshot state, not a lost image. The original mismatch (a cycle that\n"
        "described an image while the report showed no Source Images) is a\n"
        "REFERENCE image: persistent companion data fed to the engine every\n"
        "cycle but, before the fix, omitted from a report built only from the\n"
        "inbox snapshot. db.cycle_image_names now returns inbox ∪ reference, so\n"
        "the report lists what the cycle actually saw. The only reading that\n"
        "would indicate a real leak is total_records == 0 while a cycle still\n"
        "described an image — which cannot happen on the worker path above.\n"
        "Confirm end-to-end on the real model: run a fresh cycle on a reference\n"
        "image and verify the report's 'Source Images' section now lists it.")
    print(LINE)

    # ── Feed semantics (the Datagator seam) ────────────────────────────────
    # A polling conduit re-delivers overlapping windows every run. Under the
    # windowed-inbox rule, a record a past cycle consumed re-enters as new
    # pending — right for hand re-uploads, wrong for feeds (cycles re-chew
    # old readings forever). source_type "feed", carried by the file's own
    # envelope, means: an identity seen EVER is not new work.
    print()
    print("FEED SEMANTICS (source_type='feed' — the conduit contract)")
    ftmp = Path(tempfile.mkdtemp())
    fdb = Database(ftmp / "feed.db")
    ffile = ftmp / "usgs_quakes.json"
    ffile.write_text(json.dumps({"source_type": "feed", "records": [
        {"id": "q1", "timestamp": 100.0, "mag": 4.2},
        {"id": "q2", "timestamp": 200.0, "mag": 1.1}]}))
    check("first delivery writes all records", ingest.ingest_file(fdb, ffile), 2)
    check("pending after first delivery", fdb.unconsumed_count(), 2)
    ingest.ingest_file(fdb, ffile)
    check("identical re-delivery while pending stays idempotent",
          fdb.unconsumed_count(), 2)
    fdb._conn.execute("UPDATE ingestion SET consumed=1")   # a cycle ran
    fdb._conn.commit()
    check("overlapping window re-delivery writes nothing",
          ingest.ingest_file(fdb, ffile), 0)
    check("consumed identities are NOT re-fed", fdb.unconsumed_count(), 0)
    plain = ftmp / "manual_set.json"
    plain.write_text(json.dumps([{"id": "m1", "timestamp": 300.0}]))
    ingest.ingest_file(fdb, plain)
    fdb._conn.execute(
        "UPDATE ingestion SET consumed=1 WHERE source_id='manual_set'")
    fdb._conn.commit()
    ingest.ingest_file(fdb, plain)
    check("inbox re-upload after consume STILL re-feeds (unchanged)",
          fdb.unconsumed_count(), 1)
    print(LINE)
    if _fails:
        print(f"RESULT: {len(_fails)} FAILED -> {_fails}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
