#!/usr/bin/env python3
"""Probe: quantizer recovery vs truncated part files (cold, no torch).

One ENOSPC mid-part used to become a permanent boot-loop: the truncated
model.partNNN.safetensors matched the engine's weight glob (poisoning
every model load) AND crashed _keys_overlap on the next quantize
attempt (blocking the recovery that would have deleted it). Observed
live on the field box, 2026-07-03. Pins, cold:

  1. _keys_overlap returns True (→ stale-part cleanup) for a part whose
     header cannot be parsed, instead of raising;
  2. it still raises when the SOURCE shard is the unreadable one —
     recovery must never bless a damaged source;
  3. readable disjoint/overlapping parts still get the right answer,
     so the tolerance did not blunt the actual test.

torch and safetensors are faked at import (the module imports both at
top level); _keys_overlap re-imports safe_open locally, which routes
through the same fake.
"""

import sys
import types
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "scripts"))

# ── Fakes: enough surface for `import quantize_model` + _keys_overlap ──
fake_torch = types.ModuleType("torch")
fake_torch.Tensor = object
sys.modules.setdefault("torch", fake_torch)


class _FakeHandle:
    """safe_open stand-in: keys come from a registry; CORRUPT raises."""
    REGISTRY: dict[str, list[str]] = {}

    def __init__(self, path, framework=None):
        keys = self.REGISTRY.get(str(path))
        if keys is None:
            raise RuntimeError(
                f"Error while deserializing header: incomplete metadata, "
                f"file not fully covered ({path})")
        self._keys = keys

    def keys(self):
        return list(self._keys)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


fake_st = types.ModuleType("safetensors")
fake_st.safe_open = _FakeHandle
fake_st_torch = types.ModuleType("safetensors.torch")
fake_st_torch.save_file = lambda *a, **k: None
fake_st.torch = fake_st_torch
sys.modules.setdefault("safetensors", fake_st)
sys.modules.setdefault("safetensors.torch", fake_st_torch)

from quantize_model import _keys_overlap  # noqa: E402

PASS, _failures = "  PASS ", []


def check(name, cond):
    if cond:
        print(f"{PASS} {name}")
    else:
        _failures.append(name)
        print(f"  FAIL  {name}")


REG = _FakeHandle.REGISTRY
REG["source.safetensors"] = ["w.a", "w.b", "w.c"]
REG["overlapping.part000.safetensors"] = ["w.b"]
REG["disjoint.part000.safetensors"] = ["w.z"]
# "truncated.part000.safetensors" deliberately NOT registered → open raises

print("1) The boot-loop case")
try:
    verdict = _keys_overlap(Path("source.safetensors"),
                            Path("truncated.part000.safetensors"))
    check("unreadable part returns True (orphan → deleted), no raise",
          verdict is True)
except Exception as e:
    check(f"unreadable part returns True (raised instead: {e})", False)

print("2) A damaged source is still a hard error")
try:
    _keys_overlap(Path("missing-source.safetensors"),
                  Path("overlapping.part000.safetensors"))
    check("unreadable source raises", False)
except Exception:
    check("unreadable source raises", True)

print("3) The real test is intact")
check("overlapping readable part → True",
      _keys_overlap(Path("source.safetensors"),
                    Path("overlapping.part000.safetensors")) is True)
check("disjoint readable part (a completed tail's parts) → False",
      _keys_overlap(Path("source.safetensors"),
                    Path("disjoint.part000.safetensors")) is False)

print()
if _failures:
    print(f"{len(_failures)} quantizer recovery probe(s) FAILED:")
    for f in _failures:
        print(f"  - {f}")
    sys.exit(1)
print("All quantizer recovery probes passed.")
