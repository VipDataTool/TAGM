"""Phase 4 tests — server API and CLI.

Tests the FastAPI endpoints via TestClient and CLI commands
via subprocess. Requires FastAPI + httpx.
"""

import json
import sys
import subprocess
import tempfile
import time
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

MODEL_PATH = Path(__file__).parent.parent / "models" / "Qwen3-0.6B"
DATA_DIR = Path(__file__).parent.parent / "data"
TEMPLATES_DIR = Path(__file__).parent.parent / "templates" / "builtin"
SRC_DIR = Path(__file__).parent.parent / "src"


def model_available():
    return MODEL_PATH.exists() and (MODEL_PATH / "config.json").exists()


# ── Security Tests ───────────────────────────────────────────

class TestSecurity:

    @pytest.fixture
    def token_mgr(self, tmp_path):
        from core.security import TokenManager
        tm = TokenManager(tmp_path / "test.db")
        yield tm
        tm.close()

    def test_create_token(self, token_mgr):
        token = token_mgr.create_token("test_user")
        assert len(token) > 20
        print(f"  token created ({len(token)} chars)", flush=True)

    def test_verify_valid(self, token_mgr):
        token = token_mgr.create_token("user1")
        info = token_mgr.verify(token)
        assert info is not None
        assert info["name"] == "user1"
        assert info["role"] == "readwrite"

    def test_verify_invalid(self, token_mgr):
        assert token_mgr.verify("bogus_token") is None

    def test_read_only(self, token_mgr):
        token = token_mgr.create_token("viewer", read_only=True)
        assert not token_mgr.can_write(token)

        rw_token = token_mgr.create_token("admin")
        assert token_mgr.can_write(rw_token)

    def test_revoke(self, token_mgr):
        token = token_mgr.create_token("temp")
        assert token_mgr.verify(token) is not None
        token_mgr.revoke("temp")
        assert token_mgr.verify(token) is None

    def test_list_tokens(self, token_mgr):
        token_mgr.create_token("a")
        token_mgr.create_token("b", read_only=True)
        tokens = token_mgr.list_tokens()
        assert len(tokens) == 2
        names = [t["name"] for t in tokens]
        assert "a" in names and "b" in names

    def test_default_token(self, token_mgr):
        token = token_mgr.ensure_default_token()
        assert token is not None
        # Second call returns None (already exists)
        assert token_mgr.ensure_default_token() is None


# ── Server API Tests ─────────────────────────────────────────

class TestServerAPI:

    @pytest.fixture(autouse=True)
    def require_model(self):
        if not model_available():
            pytest.skip("Model not downloaded")

    @pytest.fixture(scope="class")
    def client(self):
        try:
            from fastapi.testclient import TestClient
        except ImportError:
            pytest.skip("FastAPI testclient not available")

        # Use a temp database
        import tempfile
        tmp = tempfile.mkdtemp()
        tmp_db = Path(tmp) / "test.db"

        from server import app, STATE, DB_PATH
        import server
        server.DB_PATH = tmp_db
        STATE["insecure"] = True

        with TestClient(app) as c:
            yield c

    def test_dashboard(self, client):
        print("  dashboard...", end=" ", flush=True)
        r = client.get("/")
        assert r.status_code == 200
        assert "Courier" in r.text
        print("OK", flush=True)

    def test_status(self, client):
        print("  /api/status...", end=" ", flush=True)
        r = client.get("/api/status")
        assert r.status_code == 200
        data = r.json()
        assert "hostname" in data
        assert "uptime_hours" in data
        assert "model" in data
        assert "available_templates" in data
        print(f"host={data['hostname']}", flush=True)

    def test_state(self, client):
        # /api/state is the REST road to the exact object SSE frames carry
        # (payload law: SSE is never the only road). Pin the frame shape so
        # the two roads cannot drift: every key the dashboard reads from a
        # pushed frame must be present in a fetched one.
        print("  /api/state...", end=" ", flush=True)
        r = client.get("/api/state")
        assert r.status_code == 200
        data = r.json()
        for key in ("system", "cycle", "ingestion", "history", "records",
                    "results", "queue", "available_templates",
                    "available_models", "config", "template_detail"):
            assert key in data, f"SSE frame key missing from /api/state: {key}"
        print("shape OK", flush=True)

    def test_cycle_status(self, client):
        r = client.get("/api/cycle/status")
        assert r.status_code == 200
        data = r.json()
        assert "status" in data

    def test_ingest_status(self, client):
        r = client.get("/api/ingest/status")
        assert r.status_code == 200
        data = r.json()
        assert "total_records" in data

    def test_list_models(self, client):
        print("  /api/models...", end=" ", flush=True)
        r = client.get("/api/models")
        assert r.status_code == 200
        models = r.json()
        assert len(models) >= 1
        assert "id" in models[0]
        print(f"{len(models)} model(s)", flush=True)

    def test_models_catalog_file(self, tmp_path, monkeypatch):
        # models_catalog.json IS the catalog when present; bad entries
        # are skipped by name; a malformed file falls back to the
        # built-in list (a field box must always boot with models).
        print("  models_catalog.json loader...", end=" ", flush=True)
        import json as _json
        import server
        p = tmp_path / "models_catalog.json"
        monkeypatch.setattr(server, "MODELS_CATALOG_PATH", p)

        # No file → built-in
        assert server._load_supported_models() == server._BUILTIN_MODELS

        # Valid file with one good and one bad entry → good one only
        p.write_text(_json.dumps({"_readme": ["x"], "models": [
            {"id": "acme/Field-2B", "params": "2B",
             "family": "qwen3", "size_gb": 4.0},
            {"id": "acme/broken", "params": "1B"},  # missing keys
        ]}))
        loaded = server._load_supported_models()
        assert [m["id"] for m in loaded] == ["acme/Field-2B"]

        # Malformed JSON → built-in, not a crash
        p.write_text("{not json")
        assert server._load_supported_models() == server._BUILTIN_MODELS
        print("loader OK", flush=True)

    def test_prefer_gguf_variant_listing(self, client, monkeypatch):
        # Settings → Prefer GGUF Variants: a catalog entry with gguf
        # metadata must present AS its quant (dir <name>-GGUF, format
        # gguf, quant in the params label) and its safetensors row must
        # be hidden (nothing loaded in this test client). Entries
        # without gguf metadata (Qwen3.5) must be untouched.
        print("  prefer_gguf listing...", end=" ", flush=True)
        import server
        real = server.load_config
        monkeypatch.setattr(server, "load_config",
                            lambda: {**real(), "prefer_gguf": True})
        r = client.get("/api/models")
        assert r.status_code == 200
        models = r.json()
        by_dir = {m["dir_name"]: m for m in models}
        v = by_dir.get("Qwen3-0.6B-GGUF")
        assert v is not None, "GGUF variant row missing"
        assert v["format"] == "gguf" and v.get("gguf_variant") is True
        assert "Q4_K_M" in v["params"]
        assert v["family"] == "qwen3"          # SD pairing intact
        assert "Qwen3-0.6B" not in by_dir      # safetensors row hidden
        assert "Qwen3.5-4B" in by_dir          # unvalidated family untouched
        print("variant listing OK", flush=True)

    def test_local_gguf_model_listed(self, client, tmp_path, monkeypatch):
        # An on-disk GGUF directory outside SUPPORTED_MODELS must appear
        # in /api/models as a loadable local entry — the road from disk
        # to the dashboard dropdown. Before this, uncatalogued models
        # (every GGUF quant download_model.py --gguf produces) were
        # invisible to the UI even though the engine loads them fine.
        print("  local GGUF listing...", end=" ", flush=True)
        import server
        mdir = tmp_path / "Fake-0.6B-GGUF"
        mdir.mkdir()
        (mdir / "config.json").write_text('{"model_type": "qwen3"}')
        (mdir / "fake.gguf").write_bytes(b"GGUF")  # _model_ready needs a weight file
        monkeypatch.setattr(server, "MODELS_DIR", tmp_path)
        r = client.get("/api/models")
        assert r.status_code == 200
        entry = next((m for m in r.json()
                      if m["dir_name"] == "Fake-0.6B-GGUF"), None)
        assert entry is not None, "local GGUF dir missing from /api/models"
        assert entry["local"] is True
        assert entry["format"] == "gguf"
        assert entry["family"] == "qwen3"       # from config.json, SD-pairable
        assert entry["status"] == "downloaded"  # selectable, not "not_downloaded"
        assert "/" not in entry["id"]           # dropdown label must survive this
        print("listed OK", flush=True)

    def test_list_templates(self, client):
        print("  /api/templates...", end=" ", flush=True)
        r = client.get("/api/templates")
        assert r.status_code == 200
        templates = r.json()
        assert len(templates) >= 1
        print(f"{len(templates)} template(s)", flush=True)

    def test_get_template(self, client):
        r = client.get("/api/templates/field_report_summary")
        assert r.status_code == 200
        data = r.json()
        assert "stages" in data

    def test_cycles_empty(self, client):
        r = client.get("/api/cycles")
        assert r.status_code == 200

    def test_records_empty(self, client):
        r = client.get("/api/ingest/records")
        assert r.status_code == 200


# ── CLI Tests ────────────────────────────────────────────────

class TestCLI:

    def _run_cli(self, *args):
        cmd = [sys.executable, str(SRC_DIR / "cli.py")] + list(args)
        result = subprocess.run(cmd, capture_output=True, text=True,
                                cwd=str(Path(__file__).parent.parent))
        return result

    def test_help(self):
        r = self._run_cli("--help")
        assert r.returncode == 0
        assert "courier" in r.stdout.lower() or "usage" in r.stdout.lower()

    def test_template_list(self):
        print("  cli template list...", end=" ", flush=True)
        r = self._run_cli("template", "list")
        assert r.returncode == 0
        assert "field_report_summary" in r.stdout
        print("OK", flush=True)

    def test_template_show(self):
        r = self._run_cli("template", "show", "field_report_summary")
        assert r.returncode == 0
        assert "Summary" in r.stdout or "field_report" in r.stdout

    def test_data_status(self):
        r = self._run_cli("data", "status")
        assert r.returncode == 0

    def test_model_list(self):
        if not model_available():
            pytest.skip("Model not downloaded")
        print("  cli model list...", end=" ", flush=True)
        r = self._run_cli("model", "list")
        assert r.returncode == 0
        assert "qwen3" in r.stdout.lower() or "Qwen3" in r.stdout
        print("OK", flush=True)


# ── Write-gate browser defenses (cold: require_write called directly) ──

class TestWriteGate:
    """The tokenless local path's browser-origin rules, without a server.

    require_write is a plain function, so these probe its decision table
    directly with a stub Request — no engine, no filesystem writes.
    Argument order: (request, authorization, sec_fetch_site, origin, host).
    """

    def _req(self, peer="127.0.0.1"):
        import types
        return types.SimpleNamespace(client=types.SimpleNamespace(host=peer))

    @pytest.fixture(autouse=True)
    def _clean_slate(self, monkeypatch):
        import server
        for var in ("COURIER_REQUIRE_TOKEN", "COURIER_TRUST_PROXY",
                    "CODESPACES", "COURIER_INSECURE"):
            monkeypatch.delenv(var, raising=False)
        monkeypatch.setitem(server.STATE, "insecure", False)

    def _403(self, *args):
        from fastapi import HTTPException
        from server import require_write
        with pytest.raises(HTTPException) as exc:
            require_write(*args)
        assert exc.value.status_code == 403

    def test_local_dashboard_call_passes(self):
        # Same-origin fetch from the dashboard: loopback peer, local Host.
        from server import require_write
        assert require_write(self._req(), None, "same-origin", None,
                             "localhost:8000")

    def test_cross_site_blocked(self):
        self._403(self._req(), None, "cross-site", None, "localhost:8000")

    def test_same_site_blocked(self):
        # "Site" ignores ports: a page served by another local service
        # (localhost:9999) is same-site — it must not drive writes.
        self._403(self._req(), None, "same-site", None, "localhost:8000")

    def test_legacy_browser_foreign_origin_blocked(self):
        # No Sec-Fetch-Site (pre-metadata browser) but a foreign Origin.
        self._403(self._req(), None, None, "http://evil.example",
                  "localhost:8000")

    def test_legacy_browser_null_origin_blocked(self):
        # "Origin: null" is a sandboxed/opaque context, never the dashboard.
        self._403(self._req(), None, None, "null", "localhost:8000")

    def test_legacy_browser_local_origin_passes(self):
        from server import require_write
        assert require_write(self._req(), None, None,
                             "http://localhost:8000", "localhost:8000")

    def test_non_browser_local_client_passes(self):
        # curl from loopback: no fetch metadata, no Origin — trusted by design.
        from server import require_write
        assert require_write(self._req(), None, None, None, "localhost:8000")

    def test_remote_peer_still_needs_token(self):
        self._403(self._req(peer="192.168.1.50"), None, None, None,
                  "localhost:8000")


# ── Upload guards (endpoint-level: traversal + size cap) ──────────────

class TestUploadGuards:

    @pytest.fixture(scope="class")
    def client(self):
        try:
            from fastapi.testclient import TestClient
        except ImportError:
            pytest.skip("FastAPI testclient not available")

        import tempfile
        tmp = tempfile.mkdtemp()
        tmp_db = Path(tmp) / "test.db"

        from server import app, STATE
        import server
        server.DB_PATH = tmp_db
        STATE["insecure"] = True

        with TestClient(app) as c:
            yield c

    def test_ingest_filename_traversal_rejected(self, client):
        # "../models/pwn.json" passes the extension check but must never
        # reach the filesystem join. Shared guard answers 404 by design.
        r = client.post(
            "/api/ingest/file",
            files={"file": ("../models/pwn.json", b"{}", "application/json")})
        assert r.status_code == 404

    def test_ingest_backslash_traversal_rejected(self, client):
        r = client.post(
            "/api/ingest/file",
            files={"file": ("..\\models\\pwn.json", b"{}",
                            "application/json")})
        assert r.status_code == 404

    def test_ingest_oversize_rejected(self, client, monkeypatch):
        # Cap ≈ 1 KB, body 4 KB → 413 during the read, before any write.
        monkeypatch.setenv("COURIER_MAX_UPLOAD_MB", "0.001")
        r = client.post(
            "/api/ingest/file",
            files={"file": ("big.json", b"x" * 4096, "application/json")})
        assert r.status_code == 413

    def test_template_oversize_rejected(self, client, monkeypatch):
        monkeypatch.setenv("COURIER_MAX_UPLOAD_MB", "0.001")
        r = client.post(
            "/api/templates",
            files={"file": ("t.json", b"x" * 4096, "application/json")})
        assert r.status_code == 413
