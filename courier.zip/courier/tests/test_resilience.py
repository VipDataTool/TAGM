"""Standalone verification for checkpoint banking, resume, and crash recovery.

The engine (streamer/inference) needs torch and is not exercised here; this
suite covers the pure-Python orchestration — DB persistence, stage skipping,
the resume payload, and recovery re-entrancy — which is where the risk lives.
A minimal fake `torch` lets checkpoint.py (and thus worker.py) import.
"""
import os
import sys
import tempfile

# ── Torch: real if installed, one adequate shared stub if not ──
# (Replaces a private tempfile-written stub: under pytest's shared
# process, whichever fake lands in sys.modules first wins for everyone,
# so all pytest-collected files must share ONE correct implementation.)
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _probe_util import ensure_torch  # noqa: E402
ensure_torch()

import sqlite3

from core.db import Database
from template import Template
from engine.checkpoint import make_checkpoint_callback, load_checkpoint
from pipeline import run_pipeline
from engine.worker import recover_interrupted
from engine.signals import CancelledError

PASS = 0
FAIL = 0


def check(name, cond):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ok   - {name}")
    else:
        FAIL += 1
        print(f"  FAIL - {name}")


WORK = tempfile.mkdtemp()
TPL = Template.load(os.path.join(
    os.path.dirname(__file__), "..", "templates", "builtin", "eruption_risk_test.json"))


# ── Test 1: per-token banking ────────────────────────────────
print("\n[1] Per-token checkpoint banking")
db = Database(os.path.join(WORK, "t1.db"))
cid = db.create_cycle(1, "eruption_risk_test", {})
cb = make_checkpoint_callback(db, cid, stage_index=0, interval=5, prompt="PINNED-PROMPT")
for step in range(20):
    cb(1000 + step, step, 100 + step, list(range(step + 1)))
check("4 checkpoints banked at interval 5 over 20 tokens", db.count_checkpoints(cid) == 4)
cp = load_checkpoint(db, cid, stage_index=0)
check("latest checkpoint is the furthest token (step 19)", cp.generation_step == 19)
check("latest checkpoint carries all 20 tokens", len(cp.tokens) == 20)
check("stage prompt is pinned in the checkpoint", cp.prompt == "PINNED-PROMPT")
check("sampler RNG state is auto-captured", cp.rng_state is not None)
db.close()


# ── Test 2: idempotent schema migration ──────────────────────
print("\n[2] Schema migration on a legacy database")
p2 = os.path.join(WORK, "t2.db")
c = sqlite3.connect(p2)
c.execute("CREATE TABLE checkpoints (id INTEGER PRIMARY KEY AUTOINCREMENT, "
          "cycle_id TEXT NOT NULL, stage_index INTEGER NOT NULL, "
          "generation_step INTEGER NOT NULL, tokens_json TEXT NOT NULL, "
          "position INTEGER NOT NULL, rng_state BLOB, timestamp REAL NOT NULL, "
          "kv_cache_dir TEXT)")
c.commit()
c.close()
db2 = Database(p2)
cols = [r[1] for r in db2._conn.execute("PRAGMA table_info(checkpoints)").fetchall()]
check("prompt column added to a pre-existing checkpoints table", "prompt" in cols)
cid2 = db2.create_cycle(1, "x", {})
db2.save_checkpoint(cid2, 0, 0, [1, 2, 3], 3, prompt="MIGRATED")
check("prompt round-trips after migration",
      db2.get_latest_checkpoint(cid2, 0).get("prompt") == "MIGRATED")
db2.close()
db2b = Database(p2)  # reopen — migration must be a safe no-op
db2b.close()
check("migration is idempotent on reopen", True)


# ── Test 3: run_pipeline resume ──────────────────────────────
print("\n[3] run_pipeline — skip completed stages, resume the in-progress one")
completed_rows = [
    {"stage_index": 0, "label": "CO2 Analysis", "thinking": 0,
     "output_text": "OUT-0", "time_seconds": 1.0, "error": None, "status": "complete"},
    {"stage_index": 1, "label": "Seismic Analysis", "thinking": 0,
     "output_text": "OUT-1", "time_seconds": 1.0, "error": None, "status": "complete"},
]
resume = {"completed": completed_rows, "stage_index": 2,
          "resume_tokens": [7, 7, 7], "prompt": "PINNED-STAGE2",
          "rng_state": b"RNGBYTES"}
calls = []
saved = []
def stub_infer(prompt, **kw):
    calls.append({"prompt": prompt, "kw": dict(kw)})
    return f"INFER<{kw.get('resume_tokens')}>"
res = run_pipeline(TPL, {}, stub_infer, default_max_tokens=2048,
                   on_stage_complete=lambda sr: saved.append(sr.index),
                   resume=resume)
check("all 4 stages present in the result", len(res.stages) == 4)
check("stage 0 reused verbatim from its DB row", res.stages[0].output == "OUT-0")
check("stage 1 reused verbatim from its DB row", res.stages[1].output == "OUT-1")
check("inference ran only twice (stages 2 and 3)", len(calls) == 2)
check("in-progress stage used the pinned prompt", calls[0]["prompt"] == "PINNED-STAGE2")
check("in-progress stage received the banked tokens",
      calls[0]["kw"].get("resume_tokens") == [7, 7, 7])
check("in-progress stage received the banked RNG state",
      calls[0]["kw"].get("resume_rng") == b"RNGBYTES")
check("the stage after the resumed one ran fresh (no resume_tokens)",
      "resume_tokens" not in calls[1]["kw"])
check("on_stage_complete fired only for genuinely-run stages 2 and 3",
      saved == [2, 3])


# ── Test 4: full crash recovery ──────────────────────────────
print("\n[4] recover_interrupted — end-to-end resume of a crashed cycle")
db4 = Database(os.path.join(WORK, "t4.db"))
cid4 = db4.create_cycle(5, "eruption_risk_test", {})
db4.save_stage(cid4, 0, "CO2 Analysis", False, "DONE-0", 10, 10, 1.0, status="complete")
db4.save_stage(cid4, 1, "Seismic Analysis", False, "DONE-1", 10, 10, 1.0, status="complete")
db4.save_checkpoint(cid4, 2, 14, [5] * 15, 200, prompt="PINNED-S2-RECOVER")
db4.update_cycle(cid4, status="inferring")
check("cycle reads as interrupted before recovery",
      db4.get_interrupted_cycle() is not None)
rcalls = []
def infer4(prompt, **kw):
    rcalls.append({"prompt": prompt, "kw": dict(kw)})
    return "R-OUT"
exp = tempfile.mkdtemp()
wr = recover_interrupted(db4, TPL, infer4, {}, exp, default_max_tokens=2048)
cyc = db4.get_cycle(cid4)
check("recovered cycle is marked complete", cyc["status"] == "complete")
check("WorkerResult reports one completed cycle", wr.cycles_completed == 1)
check("checkpoints cleared once the cycle finished", db4.count_checkpoints(cid4) == 0)
check("inference ran only for stages 2 and 3 (0,1 not re-run)", len(rcalls) == 2)
check("in-progress stage resumed with its pinned prompt",
      rcalls[0]["prompt"] == "PINNED-S2-RECOVER")
check("in-progress stage resumed with its banked tokens",
      rcalls[0]["kw"].get("resume_tokens") == [5] * 15)
check("all 4 stages persisted after recovery", len(db4.get_stages(cid4)) == 4)
check("nothing left interrupted afterwards", db4.get_interrupted_cycle() is None)
db4.close()


# ── Test 5: recovery is a safe no-op when there is nothing to do ──
print("\n[5] recover_interrupted — no-op when no cycle is interrupted")
db5 = Database(os.path.join(WORK, "t5.db"))
wr5 = recover_interrupted(db5, TPL, infer4, {}, exp, default_max_tokens=2048)
check("no interrupted cycle -> 0 completed, no errors",
      wr5.cycles_completed == 0 and not wr5.errors)
db5.close()


# ── Test 6: operator interrupts propagate, never swallowed ───
# Resume straight to the template's final stage (input: prior-only, no data
# sources) so the inference call is reached with no data-fetch in the way —
# isolating exactly the property under test: run_pipeline's broad
# `except Exception` must NOT catch a BaseException-derived interrupt.
print("\n[6] CancelledError propagates through run_pipeline")
def infer_cancel(prompt, **kw):
    raise CancelledError("stop")
resume6 = {
    "completed": [
        {"stage_index": i, "label": l, "thinking": 0, "output_text": "x",
         "time_seconds": 0.0, "error": None, "status": "complete"}
        for i, l in enumerate(["CO2 Analysis", "Seismic Analysis", "Risk Integration"])
    ],
    "stage_index": 3, "resume_tokens": None, "prompt": None, "rng_state": None,
}
propagated = False
try:
    run_pipeline(TPL, {}, infer_cancel, default_max_tokens=2048, resume=resume6)
except CancelledError:
    propagated = True
except Exception:
    propagated = False
check("CancelledError is not caught by the stage error handler", propagated)


# ── Test 7: all stages already done -> finalize only ─────────
print("\n[7] recover_interrupted — finalize a cycle whose stages all finished")
db7 = Database(os.path.join(WORK, "t7.db"))
cid7 = db7.create_cycle(9, "eruption_risk_test", {})
for i, lbl in enumerate(["CO2 Analysis", "Seismic Analysis",
                         "Risk Integration", "Critical Review"]):
    db7.save_stage(cid7, i, lbl, False, f"DONE-{i}", 5, 5, 1.0, status="complete")
db7.save_checkpoint(cid7, 3, 5, [1, 2], 10, prompt="P")
db7.update_cycle(cid7, status="inferring")
fcalls = []
def infer7(p, **k):
    fcalls.append(1)
    return "X"
recover_interrupted(db7, TPL, infer7, {}, exp, default_max_tokens=2048)
check("cycle with all stages done is finalized to complete",
      db7.get_cycle(cid7)["status"] == "complete")
check("no inference is run when every stage was already complete",
      len(fcalls) == 0)
check("checkpoints cleared on finalize", db7.count_checkpoints(cid7) == 0)
db7.close()


# ── Test 8: active-time accounting across an interruption ────
# The elapsed clock is banked active compute time, not a wall-clock span.
# A checkpoint carries the active seconds spent up to it (via the clock), and
# a resumed stage continues from that banked seed — so neither the dead gap
# between crash and recovery nor a from-zero restart can corrupt the time.
print("\n[8] Active-time banking, resume fold, and migration")

# (a) the checkpoint callback banks whatever the clock reports, at write time
db8 = Database(os.path.join(WORK, "t8.db"))
cid8 = db8.create_cycle(11, "eruption_risk_test", {})
fake_active = {"s": 0.0}
cb8 = make_checkpoint_callback(db8, cid8, stage_index=0, interval=5,
                               prompt="P8", clock=lambda: fake_active["s"])
for step in range(10):
    fake_active["s"] = (step + 1) * 2.0   # 2s of "compute" per token
    cb8(1000 + step, step, 100 + step, list(range(step + 1)))
cp8 = load_checkpoint(db8, cid8, stage_index=0)
check("checkpoint banks the clock's active time (20.0s at step 9)",
      abs(cp8.active_seconds - 20.0) < 1e-6)

# (b) a fresh stage with no clock banks 0.0 — the safe default, never None
cid8b = db8.create_cycle(12, "eruption_risk_test", {})
cb8b = make_checkpoint_callback(db8, cid8b, 0, interval=2, prompt="P")
cb8b(1, 1, 2, [1, 2])
check("absent clock banks 0.0 active seconds (no crash, no None)",
      load_checkpoint(db8, cid8b, 0).active_seconds == 0.0)
db8.close()

# (c) resume folds the banked seed into the in-progress stage's recorded time,
#     and only into that stage — later stages start their clock fresh
resume8 = {
    "completed": [
        {"stage_index": 0, "label": "CO2 Analysis", "thinking": 0,
         "output_text": "O0", "time_seconds": 5.0, "error": None, "status": "complete"},
        {"stage_index": 1, "label": "Seismic Analysis", "thinking": 0,
         "output_text": "O1", "time_seconds": 7.0, "error": None, "status": "complete"},
    ],
    "stage_index": 2, "resume_tokens": [9, 9], "prompt": "P-S2",
    "rng_state": b"R", "active_seconds": 123.0,
}
res8 = run_pipeline(TPL, {}, lambda p, **k: "OUT", default_max_tokens=2048,
                    resume=resume8)
check("resumed stage's time includes the banked seed (>= 123s)",
      res8.stages[2].time_seconds >= 123.0)
check("the stage after the resumed one does NOT inherit the seed",
      res8.stages[3].time_seconds < 123.0)
# Cycle elapsed is the sum of per-stage active times: 5 + 7 + (123 + ε) + ε.
cycle_elapsed = sum(s.time_seconds for s in res8.stages)
check("cycle elapsed sums per-stage active time (>= 135s, no dead gap)",
      cycle_elapsed >= 135.0)

# (d) migration adds active_seconds to a legacy checkpoints table and it
#     round-trips
p8 = os.path.join(WORK, "t8_legacy.db")
lc = sqlite3.connect(p8)
lc.execute("CREATE TABLE checkpoints (id INTEGER PRIMARY KEY AUTOINCREMENT, "
           "cycle_id TEXT NOT NULL, stage_index INTEGER NOT NULL, "
           "generation_step INTEGER NOT NULL, tokens_json TEXT NOT NULL, "
           "position INTEGER NOT NULL, rng_state BLOB, timestamp REAL NOT NULL, "
           "kv_cache_dir TEXT, prompt TEXT)")
lc.commit()
lc.close()
db8c = Database(p8)
cols8 = [r[1] for r in db8c._conn.execute("PRAGMA table_info(checkpoints)").fetchall()]
check("active_seconds column added to a legacy checkpoints table",
      "active_seconds" in cols8)
cid8c = db8c.create_cycle(1, "x", {})
db8c.save_checkpoint(cid8c, 0, 0, [1, 2, 3], 3, prompt="M", active_seconds=42.5)
check("active_seconds round-trips after migration",
      abs((db8c.get_latest_checkpoint(cid8c, 0).get("active_seconds") or 0) - 42.5) < 1e-6)
db8c.close()


print(f"\n{'=' * 52}\n  {PASS} passed, {FAIL} failed\n{'=' * 52}")
sys.exit(1 if FAIL else 0)
