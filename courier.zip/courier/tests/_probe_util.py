"""Shared cold-probe harness.

The repo's probes are dependency-free assertion scripts (no pytest). This
factors the common check/approx/summary plumbing into one place so individual
probes don't each re-declare it. New probes import from here:

    from _probe_util import Probe
    p = Probe("my thing")
    p.check("name", cond)
    p.done()   # prints summary, exits non-zero on any failure

Importable because Python puts the running script's own directory (tests/) on
sys.path[0], so `python tests/probe_x.py` can `import _probe_util` directly.
"""
from __future__ import annotations

import sys
from pathlib import Path


def add_src_to_path() -> Path:
    """Put the repo's src/ on sys.path and return the repo root."""
    repo = Path(__file__).resolve().parent.parent
    sys.path.insert(0, str(repo / "src"))
    return repo


def approx(a: float, b: float, tol: float = 1e-6) -> bool:
    return abs(a - b) <= tol


class Probe:
    """A named group of cold checks with a pass/fail summary."""

    def __init__(self, title: str):
        self.title = title
        self._fails: list[str] = []
        print(title)

    def section(self, name: str) -> None:
        print(name)

    def check(self, name: str, cond: bool) -> bool:
        print(f"  {'PASS' if cond else 'FAIL'}  {name}")
        if not cond:
            self._fails.append(name)
        return bool(cond)

    def done(self) -> None:
        print()
        if self._fails:
            print(f"FAILED ({len(self._fails)}): " + ", ".join(self._fails))
            sys.exit(1)
        print(f"All {self.title} probes passed.")


def ensure_torch():
    """Real torch when importable, else ONE shared, adequate stub.

    Why this exists: per-file ``sys.modules["torch"] = <private fake>`` is
    safe when each test runs in its own process, but poisons a shared
    pytest interpreter — an empty fake installed by an alphabetically
    early module becomes every later module's torch AND blocks the real
    library from ever loading (``pytest tests/`` died collecting
    test_resilience and test_sd_lossless exactly this way).

    One rule instead: prefer the real library; only when it is genuinely
    absent, install a single stub carrying every attribute the
    cold-reachable modules touch (annotations in engine.sampler,
    checkpoint RNG banking), marked ``_courier_stub`` so callers may
    extend it — never extend the real library.

    Convention: pytest-collected test files MUST use this. Standalone
    probe_*.py scripts (never pytest-collected; one process each) may
    keep private fakes, but new probes should use this too.
    """
    import importlib.util
    import sys
    import types
    if "torch" in sys.modules:
        return sys.modules["torch"]
    if importlib.util.find_spec("torch") is not None:
        import torch
        return torch
    t = types.ModuleType("torch")
    t._courier_stub = True

    class _RNG:
        def numpy(self):
            return self

        def tobytes(self):
            return b"\x00" * 16

    t.Tensor = object            # signature annotations (engine.sampler)
    t.dtype = object
    t.bfloat16 = "bf16"
    t.get_rng_state = lambda: _RNG()   # checkpoint banking
    t.set_rng_state = lambda x: None
    t.from_numpy = lambda x: x
    nn = types.ModuleType("torch.nn")
    nn.functional = types.ModuleType("torch.nn.functional")
    t.nn = nn
    sys.modules["torch"] = t
    sys.modules["torch.nn"] = nn
    sys.modules["torch.nn.functional"] = nn.functional
    return t
