#!/usr/bin/env python3
"""Probe: resident-RAM mode is output-identical to streaming and removes the
per-forward re-reads (handoff §6 lever #3, built as an additive MODE).

The profile showed decode is dominated by re-streaming + re-dequantizing every
layer EVERY token (1056 raw reads = 33 loads x 32 forwards). Resident mode loads
+ dequantizes each layer ONCE and reuses it. This must not change a single
output token — so the cached tensors have to be the very ones the first
(streaming) load produced, and the byte cap must make a low-RAM box fall back to
streaming rather than OOM. This probe verifies all three, cold.

It exercises the REAL ShardManager.load_layer / load_lm_head / _room_for /
cache_stats. torch + safetensors aren't in the cold sandbox, so their I/O leaves
are stubbed (a fake adapter + a fake _load_raw); the cache logic under test is
the real code.

    cd courier
    python tests/probe_resident_cache.py
"""
import sys
import types
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "src"))

# ── Stub torch + safetensors (only their leaves are touched here) ───────────
if "torch" not in sys.modules:
    torch = types.ModuleType("torch")
    torch.bfloat16 = "bf16"
    torch.int8 = "int8"          # distinct sentinel; our fakes are never int8
    torch.Tensor = object        # only needed for type annotations
    torch.dtype = object
    sys.modules["torch"] = torch
if "safetensors" not in sys.modules:
    st = types.ModuleType("safetensors")
    st.safe_open = lambda *a, **k: None
    sys.modules["safetensors"] = st

from core.shard_manager import ShardManager      # noqa: E402

_fails = []


def check(label, cond):
    print(f"  [{'PASS' if cond else 'FAIL'}] {label}")
    if not cond:
        _fails.append(label)


class FakeTensor:
    """Minimal stand-in: carries a stable identity + the few attrs the cache
    code reads (dtype/numel/element_size)."""
    def __init__(self, key, n=1000):
        self.key = key
        self.dtype = "bf16"
        self._n = n

    def numel(self):
        return self._n

    def element_size(self):
        return 2           # bf16

    def to(self, dtype):
        return self        # already target dtype


class FakeAdapter:
    def layer_weight_keys(self, i):
        # a handful of roles per layer, mirroring the real shape
        return {r: f"model.layers.{i}.{r}" for r in
                ("q_proj", "k_proj", "v_proj", "o_proj")}

    def lm_head_key(self):
        return "lm_head.weight"

    def embedding_key(self):
        return "embed.weight"

    def final_norm_key(self):
        return "final_norm.weight"


class FakeShardManager(ShardManager):
    """Real resident logic; only the disk leaves are faked."""
    def _build_index(self):
        keys = []
        for i in range(4):
            keys += list(FakeAdapter().layer_weight_keys(i).values())
        keys += ["lm_head.weight"]
        self._key_to_shard = {k: Path("fake.safetensors") for k in keys}
        self._scale_keys = set()

    def _load_raw(self, key):
        self._raw_reads += 1
        return FakeTensor(key)


def main():
    print("=" * 64)
    print("RESIDENT-RAM MODE PROBE (== streaming, fewer reads)  §6 lever #3")
    print("=" * 64)
    A = FakeAdapter()

    # ── Streaming (default): every load re-reads ─────────────────────────
    print("\n[1] Streaming (resident=False): re-reads every call")
    s = FakeShardManager("x", A, resident=False)
    s.load_layer(0)
    r1 = s.cache_stats()["raw_reads"]
    s.load_layer(0)
    r2 = s.cache_stats()["raw_reads"]
    check("second load_layer re-reads from disk (raw_reads grows)", r2 > r1)
    check("nothing cached in streaming mode", s.cache_stats()["layers_cached"] == 0)

    # ── Resident: load once, reuse identical tensors ─────────────────────
    print("\n[2] Resident (resident=True): load once, reuse identical tensors")
    rm = FakeShardManager("x", A, resident=True)
    w_first = rm.load_layer(0)
    reads_after_first = rm.cache_stats()["raw_reads"]
    w_second = rm.load_layer(0)
    reads_after_second = rm.cache_stats()["raw_reads"]
    check("first load reads from disk", reads_after_first > 0)
    check("second load adds ZERO reads (served from cache)",
          reads_after_second == reads_after_first)
    # Output-preservation: the cached tensors ARE the ones the first load
    # produced -> identical values, token-for-token.
    same_objects = all(w_second[r] is w_first[r] for r in w_first)
    check("resident returns the SAME tensor objects (output-identical)",
          same_objects)
    check("returned dict is a copy (caller can't corrupt the cache)",
          w_second is not w_first)
    check("layer is cached", rm.cache_stats()["layers_cached"] == 1)

    # lm_head is re-read every forward in streaming; cached once in resident.
    rm.load_lm_head(); reads_a = rm.cache_stats()["raw_reads"]
    rm.load_lm_head(); reads_b = rm.cache_stats()["raw_reads"]
    check("lm_head cached too (second call adds no reads)", reads_b == reads_a)

    # ── Byte cap: degrade to streaming instead of OOM ────────────────────
    print("\n[3] Byte cap: once full, further layers fall back to streaming")
    one_layer_bytes = sum(t.numel() * t.element_size()
                          for t in FakeShardManager("x", A, resident=True)
                          .load_layer(0).values())
    capped = FakeShardManager("x", A, resident=True,
                              resident_max_bytes=one_layer_bytes)  # room for 1
    capped.load_layer(0)                  # fits -> cached
    capped.load_layer(1)                  # cap hit -> not cached
    check("cap admits exactly the layers that fit",
          capped.cache_stats()["layers_cached"] == 1)
    reads_before = capped.cache_stats()["raw_reads"]
    capped.load_layer(1)                  # uncached -> streams again
    capped.load_layer(0)                  # cached -> no read
    reads_after = capped.cache_stats()["raw_reads"]
    check("uncached layer still streams; cached layer still free",
          reads_after > reads_before)

    print("\n" + "=" * 64)
    if _fails:
        print(f"RESULT: {len(_fails)} FAILED -> {_fails}")
        return 1
    print("RESULT: ALL CHECKS PASS")
    print("Resident mode reuses the exact tensors streaming would produce (so\n"
          "output is identical), eliminates the per-forward re-reads that\n"
          "dominate decode, and falls back to streaming under a RAM cap. Confirm\n"
          "on the real model with a greedy A/B:\n"
          "  python tests/profile_cycle.py --greedy            # streaming\n"
          "  python tests/profile_cycle.py --greedy --resident # resident\n"
          "Identical Output preview + lower decode wall = win, output preserved.")
    print("=" * 64)
    return 0


if __name__ == "__main__":
    sys.exit(main())
