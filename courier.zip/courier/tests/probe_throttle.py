#!/usr/bin/env python3
"""Probe: pipeline-throttle logic — RAM budget sizing + dynamic CPU brake.

Both levers reduce to pure functions of injected inputs, so they verify cold:
no torch, no weights, no psutil. We exercise the REAL engine.sizing and
engine.brake code.

  - sizing: percentage-of-total resolves to a byte cap; the OS/collector
    reserve floors it; a floored-to-zero budget returns 0 (which the caller
    must read as "stream", never as the shard manager's 0 = unlimited);
    layers_that_fit reports emergent depth.
  - brake: disabled at target 0/100; first reading rests nothing; a process
    running hotter than target converges the working-rate down (more rest),
    cooler converges it up (less rest); the floor stops collapse.

    cd courier
    python tests/probe_throttle.py
"""
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "src"))

from engine.sizing import resident_budget_bytes, layers_that_fit   # noqa: E402
from engine.brake import CpuBrake                                  # noqa: E402

GB = 1024 ** 3
_fails = []


def check(name, cond):
    print(f"  {'PASS' if cond else 'FAIL'}  {name}")
    if not cond:
        _fails.append(name)


def approx(a, b, tol=1e-6):
    return abs(a - b) <= tol


# ── RAM sizing ──────────────────────────────────────────────────
print("sizing.resident_budget_bytes")

# Off: dial 0 -> 0 (caller keeps streaming; never enables a cap).
check("dial 0 returns 0 (off)", resident_budget_bytes(16 * GB, 0, GB) == 0)

# 90% of 16 GB, 1 GB reserve: 0.9*16 = 14.4 GB <= 16-1 = 15 GB, so 14.4 GB.
check("90% under reserve ceiling",
      resident_budget_bytes(16 * GB, 90, GB) == int(16 * GB * 0.9))

# 99% of 16 GB with 1 GB reserve: 0.99*16 = 15.84 > 15 ceiling -> clamps to 15.
check("reserve floor clamps high pct",
      resident_budget_bytes(16 * GB, 99, GB) == 16 * GB - GB)

# Reserve eats the whole percentage -> 0 (=> caller streams, not unlimited).
check("reserve eats percentage -> 0 (not unlimited)",
      resident_budget_bytes(8 * GB, 5, 8 * GB) == 0)

print("sizing.layers_that_fit")
# 14.4 GB budget, ~0.5 GB/layer, 24-layer model -> 28 fit but capped at 24.
check("depth capped at n_layers",
      layers_that_fit(int(14.4 * GB), GB // 2, 24) == 24)
# 2 GB budget, 0.5 GB/layer -> 4 layers.
check("depth from budget", layers_that_fit(2 * GB, GB // 2, 24) == 4)
check("zero budget -> 0 layers", layers_that_fit(0, GB // 2, 24) == 0)


# ── CPU brake ───────────────────────────────────────────────────
print("brake.CpuBrake — disabled cases")
for t in (0.0, 1.0, 1.5, -0.2):
    b = CpuBrake(t)
    check(f"target {t} disabled -> 0 rest", b.update(0.1, 0.9) == 0.0)

print("brake.CpuBrake — measurement gating")
b = CpuBrake(0.5)
check("no reading (None) -> 0 rest", b.update(0.1, None) == 0.0)

print("brake.CpuBrake — convergence")
# Target 50%; process pinned near 100% of capacity. Working-rate must fall
# (more rest) over successive layers as the loop reins it in.
b = CpuBrake(0.5, alpha=0.5, floor=0.05)
rests = [b.update(1.0, 0.99) for _ in range(8)]
check("hot process: working-rate drops below target",
      b.workingrate < 0.5)
check("hot process: rest grows then is positive", rests[-1] > 0.0)
check("hot process: rest non-decreasing as it reins in",
      rests[-1] >= rests[1])

# Target 50%; process already idling at 25%. Working-rate should climb toward 1
# (little/no rest needed) and rest should shrink.
b2 = CpuBrake(0.5, alpha=0.5, floor=0.05)
r2 = [b2.update(1.0, 0.25) for _ in range(8)]
check("cool process: working-rate rises above target", b2.workingrate > 0.5)
check("cool process: little rest", r2[-1] < r2[0] + 1e-9)

print("brake.CpuBrake — anti-windup floor")
# Even an impossibly hot reading can't push the working-rate below the floor.
b3 = CpuBrake(0.1, alpha=0.9, floor=0.05)
for _ in range(20):
    b3.update(1.0, 1.0)
check("working-rate never below floor", b3.workingrate >= 0.05 - 1e-9)

# Duty->rest arithmetic: at working-rate w, rest = compute*(1/w - 1).
b4 = CpuBrake(0.5, alpha=1.0, floor=0.01)
# alpha=1 => ema == measured. measured 0.5 == target => workingrate stays 1.0
# => zero rest (already at target).
check("at-target steady -> ~0 rest", approx(b4.update(2.0, 0.5), 0.0))


print()
if _fails:
    print(f"FAILED ({len(_fails)}): " + ", ".join(_fails))
    sys.exit(1)
print("All throttle probes passed.")
