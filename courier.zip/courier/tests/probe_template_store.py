#!/usr/bin/env python3
"""Probe: single-file TemplateStore — seed migration + CRUD.

Cold: no torch, no server. Exercises the real engine.template_store against a
temp file seeded from a couple of synthetic builtin templates.

    cd courier
    python tests/probe_template_store.py
"""
import json
import sys
import tempfile
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "src"))

from template_store import TemplateStore   # noqa: E402

_fails = []


def check(name, cond):
    print(f"  {'PASS' if cond else 'FAIL'}  {name}")
    if not cond:
        _fails.append(name)


def _tpl(tid, name, prompt="Summarize the data."):
    return {
        "template": {"id": tid, "name": name, "description": "d", "version": "1.0.0"},
        "model": {"id": "Qwen/Qwen3-4B"},
        "data": {"sources": {"default": {"adapter": "json", "budget_tokens": 500}}},
        "stages": [{"label": "Summary", "system_prompt": prompt,
                    "input": {"sources": ["default"]}}],
    }


def main():
    tmp = Path(tempfile.mkdtemp())
    seed_dir = tmp / "builtin"
    seed_dir.mkdir()
    (seed_dir / "a.json").write_text(json.dumps(_tpl("alpha", "Alpha")))
    (seed_dir / "b.json").write_text(json.dumps(_tpl("bravo", "Bravo")))
    store_file = tmp / "templates.json"
    store = TemplateStore(store_file, seed_dir)

    print("seed migration")
    check("file absent before first read", not store_file.exists())
    ids = set(store.ids())
    check("file created on first read", store_file.exists())
    check("seeded both builtin templates", ids == {"alpha", "bravo"})
    check("summaries sorted by name", [s["name"] for s in store.list_summaries()] == ["Alpha", "Bravo"])

    print("get")
    check("get_raw returns stored JSON", store.get_raw("alpha")["template"]["name"] == "Alpha")
    check("get_raw missing -> None", store.get_raw("nope") is None)
    check("get_template validates", store.get_template("bravo").metadata.id == "bravo")
    check("first_template stable (alpha)", store.first_template().metadata.id == "alpha")

    print("save (new + edit)")
    store.save("charlie", _tpl("charlie", "Charlie"))
    check("new template persisted", "charlie" in store.ids())
    # Edit existing content
    edited = _tpl("alpha", "Alpha Renamed", prompt="New prompt.")
    store.save("alpha", edited)
    check("edit updates content", store.get_raw("alpha")["template"]["name"] == "Alpha Renamed")
    check("edit didn't duplicate", store.ids().count("alpha") == 1)
    # Changing the id in the editor moves the entry
    moved = _tpl("alpha2", "Alpha Moved")
    store.save("alpha", moved)
    check("id change moves entry (old gone)", "alpha" not in store.ids())
    check("id change moves entry (new present)", "alpha2" in store.ids())

    print("save rejects invalid")
    try:
        store.save("bad", {"template": {"name": "no id"}})  # missing id -> ValueError
        check("invalid template rejected", False)
    except ValueError:
        check("invalid template rejected", True)
    check("invalid not written", "bad" not in store.ids())

    print("delete")
    check("delete existing -> True", store.delete("bravo") is True)
    check("deleted gone", "bravo" not in store.ids())
    check("delete missing -> False", store.delete("ghost") is False)

    print("persistence across instances")
    store2 = TemplateStore(store_file, seed_dir)
    check("reopened store sees saved state", set(store2.ids()) == set(store.ids()))

    print("output schema (the telegraph contract)")
    import copy
    from template import Template, schema_instruction, expand_dispatch
    import report as report_mod
    sch = {"delimiter": "|",
           "fields": [
               {"id": "status", "label": "Status",
                "values": {"ESCAL": "Escalating", "STABLE": "Stable"}},
               {"id": "clusters", "label": "Clusters"},
               {"id": "notes", "label": "Notes"}],
           "glossary": {"VT": "volcano-tectonic"}}
    raw_t = {"template": {"id": "tg", "name": "Telegraph"},
             "model": {"id": "m"},
             "stages": [{"label": "Classify", "system_prompt": "Assess.",
                         "output_schema": sch}]}
    t = Template.from_dict(raw_t)
    check("schema parsed and normalized",
          t.stages[0].output_schema["delimiter"] == "|"
          and t.stages[0].output_schema["fields"][0]["label"] == "Status")
    rt = t.to_dict()
    check("authored prompt serialized untouched",
          rt["stages"][0]["system_prompt"] == "Assess.")
    check("schema round-trips",
          Template.from_dict(rt).stages[0].output_schema
          == t.stages[0].output_schema)
    ins = schema_instruction(t.stages[0].output_schema)
    check("instruction lists field order", "status | clusters | notes" in ins)
    check("instruction expands the closed set", "ESCAL (Escalating)" in ins)
    check("instruction carries the glossary", "VT = volcano-tectonic" in ins)
    bad = copy.deepcopy(raw_t)
    bad["stages"][0]["output_schema"] = {"fields": [{"id": "a"}, {"id": "a"}]}
    try:
        Template.from_dict(bad); check("duplicate field id rejected", False)
    except ValueError:
        check("duplicate field id rejected", True)
    bad2 = copy.deepcopy(raw_t)
    bad2["stages"][0]["output_schema"] = {"fields": []}
    try:
        Template.from_dict(bad2); check("empty fields rejected", False)
    except ValueError:
        check("empty fields rejected", True)

    e = expand_dispatch(sch, "ESCAL | 4 | VT swarm rising\n")
    check("closed code expanded", dict(e["rows"])["Status"] == "Escalating")
    check("glossary expands on word boundary",
          dict(e["rows"])["Notes"] == "volcano-tectonic swarm rising")
    e2 = expand_dispatch(sch, "BOGUS | - | VTX intact")
    check("unknown code marked, never invented",
          dict(e2["rows"])["Status"] == "BOGUS (unrecognized code)")
    check("dash renders em-dash", dict(e2["rows"])["Clusters"] == "—")
    check("glossary respects word boundaries",
          dict(e2["rows"])["Notes"] == "VTX intact")
    e3 = expand_dispatch(sch, "ESCAL | 4")
    check("count mismatch refuses to guess",
          e3["ok"] is False and "expects 3" in e3["note"])
    e4 = expand_dispatch(sch, "ESCAL | 4 | ok\nextra prose")
    check("extra lines noted", e4["ok"] and "ignored" in e4["note"])

    fake_cycle = {"cycle_number": 99, "id": "c99", "status": "complete",
                  "created_at": 1750000000.0, "infer_started": 1750000000.0,
                  "tokens_generated": 9}
    vm = report_mod.build_view_model(
        fake_cycle, {}, [{"label": "Classify", "output": "ESCAL | 4 | VT swarm"}],
        template=t, completed_at=1750000100.0)
    md = report_mod.render_markdown(vm)
    check("receipt expands the dispatch", "| Status | Escalating |" in md)
    check("receipt preserves raw dispatch", "`ESCAL | 4 | VT swarm`" in md)
    vm2 = report_mod.build_view_model(
        fake_cycle, {}, [{"label": "Classify", "output": "only two | values"}],
        template=t, completed_at=1750000100.0)
    md2 = report_mod.render_markdown(vm2)
    check("mismatch shown verbatim with note",
          "only two | values" in md2 and "did not match the schema" in md2)

    print()
    if _fails:
        print(f"FAILED ({len(_fails)}): " + ", ".join(_fails))
        sys.exit(1)
    print("All template-store probes passed.")


if __name__ == "__main__":
    main()
