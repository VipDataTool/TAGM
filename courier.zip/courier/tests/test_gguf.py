"""GGUF integration test suite.

Tests are organized in tiers:

  Tier 1 (no model needed):    Synthetic data tests for reader and dequantization
  Tier 2 (GGUF file needed):   Parse a real GGUF file, validate against gguf-py oracle
  Tier 3 (model + torch):      End-to-end inference through GGUFShardManager
  Tier 4 (safetensors + GGUF): Cross-format logit comparison (Q8_0 vs safetensors)

Usage:
    # Run all available tests (skips tiers with missing dependencies)
    pytest tests/test_gguf.py -v

    # Run only synthetic tests (no downloads needed)
    pytest tests/test_gguf.py -v -k "Tier1"

    # Run with a specific GGUF model
    GGUF_MODEL_PATH=models/Qwen3-0.6B-GGUF pytest tests/test_gguf.py -v
"""

import struct
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

# ── Paths and fixtures ────────────────────────────────────────

# Default GGUF model path (override with GGUF_MODEL_PATH env var)
import os
GGUF_MODEL_DIR = Path(os.environ.get(
    "GGUF_MODEL_PATH",
    Path(__file__).parent.parent / "models" / "Qwen3-0.6B-GGUF"
))

SAFETENSORS_MODEL_DIR = Path(os.environ.get(
    "SAFETENSORS_MODEL_PATH",
    Path(__file__).parent.parent / "models" / "Qwen3-0.6B"
))


def gguf_file_available():
    return any(GGUF_MODEL_DIR.glob("*.gguf"))


def safetensors_available():
    return any(SAFETENSORS_MODEL_DIR.glob("*.safetensors"))


def torch_available():
    try:
        import torch
        return True
    except ImportError:
        return False


def gguf_py_available():
    """Check if the gguf-py oracle package is installed."""
    try:
        import gguf
        return True
    except ImportError:
        return False


# ══════════════════════════════════════════════════════════════
# Tier 1: Synthetic data tests (no model or torch required)
# ══════════════════════════════════════════════════════════════

class TestTier1_GGUFReader:
    """Test GGUF binary format parsing with synthetic data."""

    def test_block_size_computation(self):
        from core.gguf_reader import (
            _compute_tensor_nbytes,
            GGML_TYPE_F32, GGML_TYPE_F16, GGML_TYPE_Q8_0,
            GGML_TYPE_Q4_K, GGML_TYPE_Q6_K, GGML_TYPE_BF16,
        )

        # F32: 4 bytes per element
        assert _compute_tensor_nbytes(GGML_TYPE_F32, (4096, 4096)) == 4096 * 4096 * 4

        # F16: 2 bytes per element
        assert _compute_tensor_nbytes(GGML_TYPE_F16, (4096, 4096)) == 4096 * 4096 * 2

        # BF16: 2 bytes per element
        assert _compute_tensor_nbytes(GGML_TYPE_BF16, (1024,)) == 1024 * 2

        # Q8_0: 34 bytes per 32 elements
        n = 4096 * 4096
        assert _compute_tensor_nbytes(GGML_TYPE_Q8_0, (4096, 4096)) == (n // 32) * 34

        # Q4_K: 144 bytes per 256 elements
        assert _compute_tensor_nbytes(GGML_TYPE_Q4_K, (4096, 4096)) == (n // 256) * 144

        # Q6_K: 210 bytes per 256 elements
        assert _compute_tensor_nbytes(GGML_TYPE_Q6_K, (4096, 4096)) == (n // 256) * 210

    def test_unsupported_type_raises(self):
        from core.gguf_reader import _compute_tensor_nbytes
        with pytest.raises(ValueError, match="Unsupported"):
            _compute_tensor_nbytes(999, (32,))

    def test_alignment(self):
        from core.gguf_reader import _align_offset
        assert _align_offset(0, 32) == 0
        assert _align_offset(1, 32) == 32
        assert _align_offset(31, 32) == 32
        assert _align_offset(32, 32) == 32
        assert _align_offset(33, 32) == 64

    def test_ggml_type_names(self):
        from core.gguf_reader import GGML_TYPE_NAMES, GGML_TYPE_Q4_K
        assert "Q4_K" in GGML_TYPE_NAMES[GGML_TYPE_Q4_K]


class TestTier1_NameMapping:
    """Test GGUF ↔ HuggingFace tensor name translation."""

    def test_global_tensors(self):
        from core.gguf_name_map import gguf_to_hf_key, hf_to_gguf_key

        pairs = [
            ("token_embd.weight",   "model.embed_tokens.weight"),
            ("output_norm.weight",  "model.norm.weight"),
            ("output.weight",       "lm_head.weight"),
        ]
        for gguf, hf in pairs:
            assert gguf_to_hf_key(gguf) == hf
            assert hf_to_gguf_key(hf) == gguf

    def test_layer_tensors(self):
        from core.gguf_name_map import gguf_to_hf_key, hf_to_gguf_key

        pairs = [
            ("blk.0.attn_q.weight",     "model.layers.0.self_attn.q_proj.weight"),
            ("blk.0.attn_k.weight",     "model.layers.0.self_attn.k_proj.weight"),
            ("blk.0.attn_v.weight",     "model.layers.0.self_attn.v_proj.weight"),
            ("blk.0.attn_output.weight", "model.layers.0.self_attn.o_proj.weight"),
            ("blk.0.attn_norm.weight",  "model.layers.0.input_layernorm.weight"),
            ("blk.0.ffn_norm.weight",   "model.layers.0.post_attention_layernorm.weight"),
            ("blk.0.ffn_gate.weight",   "model.layers.0.mlp.gate_proj.weight"),
            ("blk.0.ffn_up.weight",     "model.layers.0.mlp.up_proj.weight"),
            ("blk.0.ffn_down.weight",   "model.layers.0.mlp.down_proj.weight"),
            ("blk.0.attn_q_norm.weight", "model.layers.0.self_attn.q_norm.weight"),
            ("blk.0.attn_k_norm.weight", "model.layers.0.self_attn.k_norm.weight"),
        ]
        for gguf, hf in pairs:
            assert gguf_to_hf_key(gguf) == hf, f"Forward: {gguf}"
            assert hf_to_gguf_key(hf) == gguf, f"Reverse: {hf}"

    def test_arbitrary_layer_index(self):
        from core.gguf_name_map import gguf_to_hf_key
        assert gguf_to_hf_key("blk.27.attn_q.weight") == "model.layers.27.self_attn.q_proj.weight"
        assert gguf_to_hf_key("blk.127.ffn_gate.weight") == "model.layers.127.mlp.gate_proj.weight"

    def test_qwen35_prefix(self):
        from core.gguf_name_map import gguf_to_hf_key
        result = gguf_to_hf_key("blk.0.attn_q.weight", "model.language_model.layers")
        assert result == "model.language_model.layers.0.self_attn.q_proj.weight"

    def test_unmapped_passthrough(self):
        from core.gguf_name_map import gguf_to_hf_key
        # Unknown names should pass through unchanged
        assert gguf_to_hf_key("some.unknown.tensor") == "some.unknown.tensor"

    def test_build_index(self):
        from core.gguf_name_map import build_gguf_to_hf_index
        names = ["token_embd.weight", "output_norm.weight", "blk.0.attn_q.weight"]
        index = build_gguf_to_hf_index(names)
        assert len(index) == 3
        assert "model.embed_tokens.weight" in index


class TestTier1_Dequantize:
    """Test dequantization kernels with synthetic data."""

    def test_f32_passthrough(self):
        from core.dequantize import _dequantize_f32
        data = np.array([1.0, -2.5, 3.14, 0.0], dtype=np.float32)
        result = _dequantize_f32(data.tobytes(), 4)
        np.testing.assert_array_equal(result, data)

    def test_f16_conversion(self):
        from core.dequantize import _dequantize_f16
        data = np.array([1.0, -2.0, 3.0, 0.0], dtype=np.float16)
        result = _dequantize_f16(data.tobytes(), 4)
        np.testing.assert_allclose(result, data.astype(np.float32), atol=1e-3)

    def test_bf16_conversion(self):
        from core.dequantize import _dequantize_bf16
        # BF16 of 1.0 = 0x3F80, BF16 of -1.0 = 0xBF80, BF16 of 0.0 = 0x0000
        raw = struct.pack("<HHH", 0x3F80, 0xBF80, 0x0000)
        result = _dequantize_bf16(raw, 3)
        np.testing.assert_allclose(result, [1.0, -1.0, 0.0], atol=1e-2)

    def test_q8_0_basic(self):
        from core.dequantize import _dequantize_q8_0
        # Scale = 2.0, values = 0..31
        scale = np.array([2.0], dtype=np.float16).tobytes()
        qs = np.arange(32, dtype=np.int8).tobytes()
        result = _dequantize_q8_0(scale + qs, 32)
        expected = 2.0 * np.arange(32, dtype=np.float32)
        np.testing.assert_allclose(result, expected, atol=0.01)

    def test_q8_0_negative_values(self):
        from core.dequantize import _dequantize_q8_0
        scale = np.array([0.5], dtype=np.float16).tobytes()
        qs = np.arange(-16, 16, dtype=np.int8).tobytes()
        result = _dequantize_q8_0(scale + qs, 32)
        expected = 0.5 * np.arange(-16, 16, dtype=np.float32)
        np.testing.assert_allclose(result, expected, atol=0.01)

    def test_q8_0_multi_block(self):
        from core.dequantize import _dequantize_q8_0
        scale = np.array([1.0], dtype=np.float16).tobytes()
        qs = np.ones(32, dtype=np.int8).tobytes()
        raw = (scale + qs) * 4  # 4 blocks = 128 elements
        result = _dequantize_q8_0(raw, 128)
        assert result.shape == (128,)
        np.testing.assert_allclose(result, np.ones(128), atol=0.01)

    def test_q4_k_zero_block(self):
        from core.dequantize import _dequantize_q4_k
        result = _dequantize_q4_k(bytes(144), 256)
        np.testing.assert_array_equal(result, np.zeros(256))

    def test_q4_k_known_values(self):
        from core.dequantize import _dequantize_q4_k
        block = bytearray(144)
        block[0:2] = np.array([1.0], dtype=np.float16).tobytes()   # d = 1.0
        block[2:4] = np.array([0.5], dtype=np.float16).tobytes()   # dmin = 0.5
        block[4] = 2     # sc[0] = 2
        block[8] = 1     # mn[0] = 1
        block[16] = 0x35  # qs[0]: low=5, high=3
        result = _dequantize_q4_k(bytes(block), 256)
        # Element 0: d * sc[0] * 5 - dmin * mn[0] = 1*2*5 - 0.5*1 = 9.5
        assert abs(result[0] - 9.5) < 0.01

    def test_q6_k_zero_block(self):
        from core.dequantize import _dequantize_q6_k
        result = _dequantize_q6_k(bytes(210), 256)
        np.testing.assert_array_equal(result, np.zeros(256))

    def test_q6_k_known_values(self):
        from core.dequantize import _dequantize_q6_k
        block = bytearray(210)
        block[208:210] = np.array([1.0], dtype=np.float16).tobytes()  # d = 1.0
        block[192] = 2     # scales[0] = 2
        block[0] = 0x03    # ql[0]: low nibble = 3
        # qh[0] = 0 → high bits are 0
        result = _dequantize_q6_k(bytes(block), 256)
        # Element 0: d * sc[0] * (3 - 32) = 1.0 * 2 * -29 = -58.0
        assert abs(result[0] - (-58.0)) < 0.01


class TestTier1_LayoutTransforms:
    """The llama Q/K permutation and its wiring (core/gguf_layout.py).

    convert_hf_to_gguf.py permutes llama-architecture Q/K weights; the
    Llama3 adapter declares the inverse via gguf_load_transforms and
    GGUFShardManager applies it at materialization. The math is
    torch-free (pure reshape/swapaxes) so numpy pins it exactly;
    tests/probe_gguf_layout.py runs the same checks cold.
    """

    def test_round_trip_identity(self):
        from core.gguf_layout import llama_permute, inverse_llama_permute
        rng = np.random.default_rng(7)
        n_head, head_dim, in_dim = 8, 16, 64
        w = rng.standard_normal((n_head * head_dim, in_dim)).astype(np.float32)
        assert np.array_equal(
            inverse_llama_permute(llama_permute(w, n_head), n_head), w)
        assert np.array_equal(
            llama_permute(inverse_llama_permute(w, n_head), n_head), w)

    def test_gqa_group_count(self):
        # K uses num_key_value_heads groups, not num_attention_heads —
        # the two permutes differ, and mixing them up would scramble.
        from core.gguf_layout import llama_permute, inverse_llama_permute
        rng = np.random.default_rng(11)
        n_kv, head_dim, in_dim = 2, 16, 64
        k = rng.standard_normal((n_kv * head_dim, in_dim)).astype(np.float32)
        assert np.array_equal(
            inverse_llama_permute(llama_permute(k, n_kv), n_kv), k)
        assert not np.array_equal(llama_permute(k, n_kv),
                                  llama_permute(k, 1))

    def test_inverse_recovers_hf_layout(self):
        # Hand-interleave one head's rows the way the converter does;
        # the inverse must give back HF split-half order.
        from core.gguf_layout import inverse_llama_permute
        head_dim, in_dim = 16, 8
        hf = np.arange(head_dim * in_dim,
                       dtype=np.float32).reshape(head_dim, in_dim)
        interleaved = np.empty_like(hf)
        interleaved[0::2] = hf[: head_dim // 2]
        interleaved[1::2] = hf[head_dim // 2:]
        assert np.array_equal(inverse_llama_permute(interleaved, 1), hf)

    def test_llama_adapter_declares_qk(self):
        # The declaration itself, without instantiating an adapter:
        # the harness and the loader must share one implementation.
        import core.adapter.llama3 as l3
        import inspect
        src = inspect.getsource(l3.Llama3Adapter.gguf_load_transforms)
        assert "inverse_llama_permute" in src
        assert "q_proj.weight" in src and "k_proj.weight" in src


# ══════════════════════════════════════════════════════════════
# Tier 2: Real GGUF file tests (requires downloaded model)
# ══════════════════════════════════════════════════════════════

class TestTier2_RealGGUF:
    """Parse a real GGUF file and verify the header."""

    @pytest.fixture(autouse=True)
    def require_gguf_file(self):
        if not gguf_file_available():
            pytest.skip(f"GGUF model not found at {GGUF_MODEL_DIR}")

    def _get_gguf_path(self):
        return sorted(GGUF_MODEL_DIR.glob("*.gguf"))[0]

    def test_parse_header(self):
        from core.gguf_reader import read_gguf
        header = read_gguf(self._get_gguf_path())
        assert header.version >= 2
        assert header.tensor_count > 0
        assert header.architecture != "unknown"
        print(f"\n  Architecture: {header.architecture}")
        print(f"  Tensors: {header.tensor_count}")

    def test_has_critical_tensors(self):
        from core.gguf_reader import read_gguf
        header = read_gguf(self._get_gguf_path())
        assert "token_embd.weight" in header.tensors
        assert "output_norm.weight" in header.tensors
        assert "blk.0.attn_q.weight" in header.tensors

    def test_name_mapping_covers_all_tensors(self):
        from core.gguf_reader import read_gguf
        from core.gguf_name_map import build_gguf_to_hf_index
        header = read_gguf(self._get_gguf_path())

        import warnings
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            index = build_gguf_to_hf_index(list(header.tensors.keys()))

        mapped_count = len(index)
        total_count = header.tensor_count
        unmapped = total_count - mapped_count
        print(f"\n  Mapped: {mapped_count}/{total_count}, unmapped: {unmapped}")

        # Allow some unmapped (e.g., rope_freqs), but most should map
        assert mapped_count >= total_count * 0.9, \
            f"Too many unmapped tensors: {unmapped}/{total_count}"


class TestTier2_OracleValidation:
    """Validate Courier's dequantization against gguf-py (the oracle)."""

    @pytest.fixture(autouse=True)
    def require_oracle(self):
        if not gguf_file_available():
            pytest.skip(f"GGUF model not found at {GGUF_MODEL_DIR}")
        if not gguf_py_available():
            pytest.skip("gguf-py not installed (pip install gguf)")

    def _get_gguf_path(self):
        return sorted(GGUF_MODEL_DIR.glob("*.gguf"))[0]

    def test_header_matches_oracle(self):
        """Compare Courier's parsed header against gguf-py's GGUFReader."""
        from core.gguf_reader import read_gguf
        import gguf

        path = self._get_gguf_path()
        courier_header = read_gguf(path)
        oracle_reader = gguf.GGUFReader(str(path))

        # Compare tensor count
        assert courier_header.tensor_count == len(oracle_reader.tensors), \
            f"Tensor count mismatch: Courier={courier_header.tensor_count}, oracle={len(oracle_reader.tensors)}"

        # Compare tensor names
        courier_names = set(courier_header.tensors.keys())
        oracle_names = set(t.name for t in oracle_reader.tensors)
        assert courier_names == oracle_names, \
            f"Name mismatch. Only in Courier: {courier_names - oracle_names}. " \
            f"Only in oracle: {oracle_names - courier_names}"

        # Compare shapes and types
        for oracle_tensor in oracle_reader.tensors:
            courier_tensor = courier_header.tensors[oracle_tensor.name]
            oracle_shape = tuple(int(d) for d in oracle_tensor.shape)
            # Note: gguf-py may not reverse dimensions; check both orders
            assert courier_tensor.shape == oracle_shape or \
                   courier_tensor.shape == tuple(reversed(oracle_shape)), \
                f"Shape mismatch for {oracle_tensor.name}: " \
                f"Courier={courier_tensor.shape}, oracle={oracle_shape}"

        print(f"\n  All {courier_header.tensor_count} tensors match oracle.")

    def test_dequantization_matches_oracle(self):
        """Compare Courier's dequantization output against gguf-py, bit-for-bit."""
        from core.gguf_reader import read_gguf
        from core.dequantize import dequantize as courier_dequant
        import gguf
        from gguf.quants import dequantize as oracle_dequant

        path = self._get_gguf_path()
        courier_header = read_gguf(path)
        oracle_reader = gguf.GGUFReader(str(path))

        # Test a few tensors of different types
        tested = 0
        with open(path, "rb") as f:
            for oracle_tensor in oracle_reader.tensors[:20]:
                name = oracle_tensor.name
                courier_info = courier_header.tensors[name]

                # Read raw bytes (Courier's way)
                offset = courier_header.tensor_data_offset + courier_info.offset
                f.seek(offset)
                raw = f.read(courier_info.nbytes)

                try:
                    # Courier dequantization (returns torch tensor → convert to numpy)
                    courier_result = courier_dequant(raw, courier_info.ggml_type, courier_info.shape)
                    courier_arr = courier_result.numpy()
                except ValueError:
                    continue  # skip unsupported types

                # Oracle dequantization. ReaderTensor.data is the RAW
                # quantized block stream, not values — for Q8_0 it is
                # 34/32 the element count (34-byte blocks of 32 weights),
                # which is exactly the reshape explosion this test used
                # to die on at the embedding. gguf.quants turns it into
                # float32 values for every type, F16/F32 included.
                oracle_arr = oracle_dequant(oracle_tensor.data,
                                            oracle_tensor.tensor_type)

                # Compare
                if courier_arr.shape != oracle_arr.shape:
                    # Try reshaping
                    oracle_arr = oracle_arr.reshape(courier_arr.shape)

                max_diff = np.max(np.abs(courier_arr - oracle_arr))
                assert max_diff == 0.0, \
                    f"Dequantization mismatch for {name} " \
                    f"(type={courier_info.type_name}): max_diff={max_diff}"
                tested += 1

        assert tested > 0, "No tensors were tested"
        print(f"\n  Bitwise match for {tested} tensors.")


# ══════════════════════════════════════════════════════════════
# Tier 3: Integration tests (requires model + torch)
# ══════════════════════════════════════════════════════════════

class TestTier3_ShardManager:
    """Test GGUFShardManager with a real model."""

    @pytest.fixture(autouse=True)
    def require_model(self):
        if not gguf_file_available():
            pytest.skip(f"GGUF model not found at {GGUF_MODEL_DIR}")
        if not (GGUF_MODEL_DIR / "config.json").exists():
            pytest.skip("config.json not found alongside GGUF")
        if not torch_available():
            pytest.skip("torch not installed")

    def test_shard_manager_creation(self):
        import torch
        from core.adapter.registry import detect_adapter
        from core.gguf_shard_manager import GGUFShardManager

        adapter = detect_adapter(GGUF_MODEL_DIR)
        gguf_path = sorted(GGUF_MODEL_DIR.glob("*.gguf"))[0]

        with GGUFShardManager(gguf_path, adapter) as mgr:
            assert len(mgr.all_keys()) > 0
            print(f"\n  {mgr}")

    def test_load_embedding(self):
        import torch
        from core.adapter.registry import detect_adapter
        from core.gguf_shard_manager import GGUFShardManager

        adapter = detect_adapter(GGUF_MODEL_DIR)
        gguf_path = sorted(GGUF_MODEL_DIR.glob("*.gguf"))[0]

        with GGUFShardManager(gguf_path, adapter) as mgr:
            embed = mgr.load_embedding(torch.bfloat16)
            assert embed.ndim == 2
            assert embed.dtype == torch.bfloat16
            assert embed.shape[1] == adapter.config.hidden_size
            print(f"\n  Embedding: {tuple(embed.shape)} {embed.dtype}")

    def test_load_layer(self):
        import torch
        from core.adapter.registry import detect_adapter
        from core.gguf_shard_manager import GGUFShardManager

        adapter = detect_adapter(GGUF_MODEL_DIR)
        gguf_path = sorted(GGUF_MODEL_DIR.glob("*.gguf"))[0]

        with GGUFShardManager(gguf_path, adapter) as mgr:
            w = mgr.load_layer(0, torch.bfloat16)
            assert "q_proj" in w
            assert "k_proj" in w
            assert "v_proj" in w
            assert w["q_proj"].dtype == torch.bfloat16
            print(f"\n  Layer 0 roles: {sorted(w.keys())}")

    def test_norm_precision_preserved(self):
        """Verify that get_tensor() without dtype returns FP32 (§8.2)."""
        import torch
        from core.adapter.registry import detect_adapter
        from core.gguf_shard_manager import GGUFShardManager

        adapter = detect_adapter(GGUF_MODEL_DIR)
        gguf_path = sorted(GGUF_MODEL_DIR.glob("*.gguf"))[0]

        with GGUFShardManager(gguf_path, adapter) as mgr:
            key = adapter.final_norm_key()
            tensor = mgr.get_tensor(key)  # No dtype → should be float32
            assert tensor.dtype == torch.float32, \
                f"Expected float32, got {tensor.dtype}"


# ══════════════════════════════════════════════════════════════
# Tier 4: Cross-format comparison (requires BOTH formats)
# ══════════════════════════════════════════════════════════════

class TestTier4_CrossFormat:
    """Compare GGUF output against safetensors for the same model."""

    @pytest.fixture(autouse=True)
    def require_both_formats(self):
        if not gguf_file_available():
            pytest.skip(f"GGUF model not found at {GGUF_MODEL_DIR}")
        if not safetensors_available():
            pytest.skip(f"Safetensors model not found at {SAFETENSORS_MODEL_DIR}")
        if not (GGUF_MODEL_DIR / "config.json").exists():
            pytest.skip("GGUF config.json missing")
        if not torch_available():
            pytest.skip("torch not installed")

    def test_embedding_shape_matches(self):
        import torch
        from core.adapter.registry import detect_adapter
        from core.shard_manager import ShardManager
        from core.gguf_shard_manager import GGUFShardManager

        adapter_st = detect_adapter(SAFETENSORS_MODEL_DIR)
        adapter_gguf = detect_adapter(GGUF_MODEL_DIR)

        st_mgr = ShardManager(SAFETENSORS_MODEL_DIR, adapter_st)
        gguf_path = sorted(GGUF_MODEL_DIR.glob("*.gguf"))[0]
        gguf_mgr = GGUFShardManager(gguf_path, adapter_gguf)

        embed_st = st_mgr.load_embedding(torch.float32)
        embed_gguf = gguf_mgr.load_embedding(torch.float32)

        assert embed_st.shape == embed_gguf.shape, \
            f"Shape mismatch: ST={embed_st.shape}, GGUF={embed_gguf.shape}"
        print(f"\n  Embedding shapes match: {embed_st.shape}")

        gguf_mgr.close()

    def test_layer_roles_match(self):
        """Verify both formats return the same set of weight role names."""
        import torch
        from core.adapter.registry import detect_adapter
        from core.shard_manager import ShardManager
        from core.gguf_shard_manager import GGUFShardManager

        adapter_st = detect_adapter(SAFETENSORS_MODEL_DIR)
        adapter_gguf = detect_adapter(GGUF_MODEL_DIR)

        st_mgr = ShardManager(SAFETENSORS_MODEL_DIR, adapter_st)
        gguf_path = sorted(GGUF_MODEL_DIR.glob("*.gguf"))[0]
        gguf_mgr = GGUFShardManager(gguf_path, adapter_gguf)

        w_st = st_mgr.load_layer(0, torch.float32)
        w_gguf = gguf_mgr.load_layer(0, torch.float32)

        assert set(w_st.keys()) == set(w_gguf.keys()), \
            f"Role mismatch: ST={set(w_st.keys())}, GGUF={set(w_gguf.keys())}"
        print(f"\n  Layer 0 roles match: {sorted(w_st.keys())}")

        gguf_mgr.close()
