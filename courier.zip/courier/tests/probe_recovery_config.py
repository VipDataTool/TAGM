#!/usr/bin/env python3
"""Probe: recovery honors the interrupted cycle's own config snapshot.

A job is a self-contained record — the RUN panel's widget values are
folded into the job at enqueue, and create_cycle pins them into the
cycle row's config snapshot. Crash recovery must rebuild its settings
from THAT snapshot, with the live system config only as fallback.
(The pre-fix recovery path rebuilt from `cfg`, so a mid-cycle crash
resumed under factory-ish settings: max-tokens/temperature silently
reverted — observed live as an OOM-killed 32-token job resuming at
2048.)

This probe exercises the REAL `_recovery_effective_config` from
src/server.py. Importing server.py wholesale needs fastapi (absent in
the cold sandbox), so the function is extracted by AST from the actual
source file and compiled standalone — the tested code is byte-for-byte
the shipped code, with only `json` supplied as its dependency.

    cd courier
    python tests/probe_recovery_config.py
"""
import ast
import json
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _probe_util import Probe  # noqa: E402

# ── Extract the real function from the shipped source ───────────────────────
SRC = (REPO / "src" / "server.py").read_text(encoding="utf-8")
tree = ast.parse(SRC)
node = next(n for n in tree.body
            if isinstance(n, ast.FunctionDef)
            and n.name == "_recovery_effective_config")
ns = {"json": json}
exec(compile(ast.Module(body=[node], type_ignores=[]), "server.py", "exec"), ns)
rec = ns["_recovery_effective_config"]

p = Probe("recovery config snapshot probe")

CFG = {"max_new_tokens": 2048, "temperature": 0.7, "top_p": 0.9,
       "export_dir": "./export/"}

p.section("1) The snapshot is authoritative")
row = {"config": json.dumps({"max_new_tokens": 32, "temperature": 0.3,
                             "model_id": "Qwen/Qwen3.5-4B"})}
eff = rec(row, CFG)
p.check("snapshot max_new_tokens (32) beats cfg (2048)",
        eff["max_new_tokens"] == 32)
p.check("snapshot temperature (0.3) beats cfg (0.7)",
        eff["temperature"] == 0.3)
p.check("keys the snapshot lacks fall back to cfg",
        eff["top_p"] == 0.9 and eff["export_dir"] == "./export/")
p.check("non-whitelisted snapshot keys are NOT copied in",
        "model_id" not in eff)
p.check("cfg itself is never mutated",
        CFG["max_new_tokens"] == 2048 and CFG["temperature"] == 0.7)

p.section("2) Snapshot may arrive as a dict (row_factory variance)")
eff = rec({"config": {"max_new_tokens": 64}}, CFG)
p.check("dict-form snapshot honored", eff["max_new_tokens"] == 64)

p.section("3) Recovery must never fail on an odd row")
p.check("missing config field -> plain cfg",
        rec({}, CFG)["max_new_tokens"] == 2048)
p.check("None config -> plain cfg",
        rec({"config": None}, CFG)["max_new_tokens"] == 2048)
p.check("malformed JSON -> plain cfg, no exception",
        rec({"config": "{not json"}, CFG)["temperature"] == 0.7)
p.check("non-dict JSON (a bare list) -> plain cfg",
        rec({"config": "[1,2]"}, CFG)["max_new_tokens"] == 2048)
p.check("snapshot null values do not shadow cfg",
        rec({"config": '{"max_new_tokens": null}'}, CFG)["max_new_tokens"] == 2048)

p.section("4) Floor when neither side carries a value")
eff = rec({"config": "{}"}, {"temperature": 1.0})
p.check("max_new_tokens defaults to 2048 as a last resort",
        eff["max_new_tokens"] == 2048)

p.done()
