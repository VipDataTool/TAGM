#!/usr/bin/env python3
"""Probe: dtype autotune resolver (performance spec §5, Phase 3, cold gate).

Exercises the REAL resolve_dtype with an injected bench so no torch GEMM
runs: explicit dtypes pass through byte-identically (the Class N opt-in
promise), 'auto' picks the measured winner in both directions, ties keep
bfloat16, bench failure falls back to bfloat16 without raising, and the
env-override plumbing in build_engine matches COURIER_THREADS' style.

    cd courier
    python tests/probe_dtype_autotune.py
"""
import sys
import types
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "src"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

# resolve_dtype imports torch only inside the 'auto' branch; give the stub
# the two dtype sentinels the bench receives. inference.py's module-level
# imports pull shard managers and adapters, so stub their leaves too
# (probe_resident_cache pattern).
if "torch" not in sys.modules:
    _t = types.ModuleType("torch")
    _t.bfloat16 = "BF16"
    _t.float16 = "FP16"
    _t.float32 = "FP32"
    _t.Tensor = object
    _t.dtype = object
    sys.modules["torch"] = _t
if "safetensors" not in sys.modules:
    _st = types.ModuleType("safetensors")
    _st.safe_open = lambda *a, **k: None
    sys.modules["safetensors"] = _st

from _probe_util import Probe  # noqa: E402
from engine.inference import resolve_dtype  # noqa: E402

p = Probe("dtype autotune probe")
DTYPE_MAP = {"bfloat16": "BF16", "float16": "FP16", "float32": "FP32"}


def bench_from(timings):
    return lambda torch_dtype: timings[torch_dtype]


p.section("1) Explicit dtypes pass through untouched (opt-in promise)")
for name in ("bfloat16", "float16", "float32"):
    p.check(f"'{name}' -> '{name}', no bench consulted",
            resolve_dtype(name, DTYPE_MAP,
                          bench=lambda d: (_ for _ in ()).throw(
                              AssertionError("bench must not run"))) == name)
p.check("case/whitespace normalized ('  BFloat16 ')",
        resolve_dtype("  BFloat16 ", DTYPE_MAP) == "bfloat16")

p.section("2) 'auto' picks the measured winner")
p.check("fp32 wins when bf16 is emulated-slow (Kaby Lake case)",
        resolve_dtype("auto", DTYPE_MAP,
                      bench=bench_from({"BF16": 0.080, "FP32": 0.030})) == "float32")
p.check("bf16 wins on native-bf16 silicon",
        resolve_dtype("auto", DTYPE_MAP,
                      bench=bench_from({"BF16": 0.020, "FP32": 0.035})) == "bfloat16")
p.check("exact tie keeps bfloat16 (today's default)",
        resolve_dtype("auto", DTYPE_MAP,
                      bench=bench_from({"BF16": 0.025, "FP32": 0.025})) == "bfloat16")

p.section("3) Failure never breaks an engine build")


def exploding_bench(_dtype):
    raise RuntimeError("no lapack on this box")


p.check("bench failure -> 'bfloat16', no exception",
        resolve_dtype("auto", DTYPE_MAP, bench=exploding_bench) == "bfloat16")

p.done()
