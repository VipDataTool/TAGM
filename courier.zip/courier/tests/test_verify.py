"""Regression tests for scripts/verify_model.py.

The boot bug these guard against: verify_safetensors used to open only the
first shard (safetensor_files[0]) and check every layer against that single
shard's keys. Single-file models (Qwen3-0.6B) passed; the first multi-shard
model (Qwen3.5-4B, 2 shards) failed verification even though it was intact,
which tripped start.sh into a spurious re-download.

These tests build tiny synthetic safetensors models — single-shard and
multi-shard, standard and Qwen3.5-style hybrid prefixes — entirely on disk,
so they need torch + safetensors but no model download.
"""

import json
import sys
from pathlib import Path

import pytest

# Make both src/ (for ShardManager parity, if needed) and scripts/ importable.
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
sys.path.insert(0, str(Path(__file__).parent.parent / "scripts"))


def _deps_available():
    try:
        import torch  # noqa: F401
        import safetensors  # noqa: F401
        return True
    except ImportError:
        return False


pytestmark = pytest.mark.skipif(
    not _deps_available(), reason="torch + safetensors required"
)


# ── Synthetic model builders ──────────────────────────────────

def _tiny_config(prefix_multimodal: bool):
    """Small, internally consistent config. Dims chosen so shapes are exact:
    q_proj = (n_heads*head_dim, hidden) = (2*4, 8) = (8, 8)."""
    text = {
        "num_hidden_layers": 4,
        "hidden_size": 8,
        "num_attention_heads": 2,
        "num_key_value_heads": 1,
        "head_dim": 4,
        "vocab_size": 16,
        "tie_word_embeddings": True,
    }
    if prefix_multimodal:
        # Qwen3.5-style: nested text_config + a vision_config marker.
        return {"model_type": "qwen3_5", "text_config": text,
                "vision_config": {"depth": 2}}
    return {"model_type": "qwen3", **text}


def _layer_tensors(torch, prefix: str, i: int, hidden: int, n_heads: int,
                   head_dim: int, kv_heads: int, linear: bool, gated_q: bool = False):
    """Tensors for one layer. `linear=True` mimics a Gated DeltaNet layer
    (no self_attn.q_proj). `gated_q=True` mimics Qwen3.5 full-attention, where
    q_proj output is q_dim*2 (Q interleaved with the attention gate)."""
    t = {f"{prefix}.{i}.input_layernorm.weight": torch.ones(hidden),
         f"{prefix}.{i}.post_attention_layernorm.weight": torch.ones(hidden)}
    if linear:
        t[f"{prefix}.{i}.linear_attn.in_proj_qkv.weight"] = torch.zeros(hidden, hidden)
    else:
        q_out = n_heads * head_dim * (2 if gated_q else 1)
        t[f"{prefix}.{i}.self_attn.q_proj.weight"] = torch.zeros(q_out, hidden)
        t[f"{prefix}.{i}.self_attn.k_proj.weight"] = torch.zeros(kv_heads * head_dim, hidden)
        t[f"{prefix}.{i}.self_attn.v_proj.weight"] = torch.zeros(kv_heads * head_dim, hidden)
    return t


def _build_model(dirpath: Path, *, shards: int, multimodal: bool,
                 layer0_linear: bool = False, gated_q: bool = False,
                 drop_layer: int | None = None):
    """Write a synthetic safetensors model to dirpath.

    shards=1 → single model.safetensors (no index).
    shards=2 → two files + model.safetensors.index.json (embed+norm and the
               first half of layers in shard 1, the rest in shard 2).
    gated_q → full-attention layers get a q_dim*2 q_proj (Qwen3.5 shape).
    drop_layer → omit that layer's input_layernorm to simulate real corruption.
    """
    import torch
    from safetensors.torch import save_file

    cfg = _tiny_config(multimodal)
    tc = cfg.get("text_config", cfg)
    prefix = "model.language_model.layers" if multimodal else "model.layers"
    embed_key = ("model.language_model.embed_tokens.weight" if multimodal
                 else "model.embed_tokens.weight")
    norm_key = ("model.language_model.norm.weight" if multimodal
                else "model.norm.weight")
    n = tc["num_hidden_layers"]

    all_t = {embed_key: torch.zeros(tc["vocab_size"], tc["hidden_size"]),
             norm_key: torch.ones(tc["hidden_size"])}
    for i in range(n):
        linear = layer0_linear and i == 0
        all_t.update(_layer_tensors(
            torch, prefix, i, tc["hidden_size"], tc["num_attention_heads"],
            tc["head_dim"], tc["num_key_value_heads"], linear, gated_q=gated_q))

    if drop_layer is not None:
        all_t.pop(f"{prefix}.{drop_layer}.input_layernorm.weight", None)

    dirpath.mkdir(parents=True, exist_ok=True)
    (dirpath / "config.json").write_text(json.dumps(cfg))

    if shards == 1:
        save_file(all_t, str(dirpath / "model.safetensors"))
    else:
        # Split: embed/norm + layers [0, n/2) → shard 1; rest → shard 2.
        half = n // 2
        def in_shard1(key):
            if key in (embed_key, norm_key):
                return True
            idx = int(key[len(prefix) + 1:].split(".")[0])
            return idx < half
        s1 = {k: v for k, v in all_t.items() if in_shard1(k)}
        s2 = {k: v for k, v in all_t.items() if not in_shard1(k)}
        f1, f2 = "model-00001-of-00002.safetensors", "model-00002-of-00002.safetensors"
        save_file(s1, str(dirpath / f1))
        save_file(s2, str(dirpath / f2))
        weight_map = {**{k: f1 for k in s1}, **{k: f2 for k in s2}}
        (dirpath / "model.safetensors.index.json").write_text(
            json.dumps({"metadata": {}, "weight_map": weight_map}))


# ── Tests ─────────────────────────────────────────────────────

def test_single_shard_passes(tmp_path):
    """Baseline: the case that always worked must keep working."""
    from verify_model import verify_safetensors
    _build_model(tmp_path, shards=1, multimodal=False)
    cfg = json.load(open(tmp_path / "config.json"))
    assert verify_safetensors(tmp_path, cfg) == []


def test_multi_shard_passes(tmp_path):
    """The regression: a healthy 2-shard model must verify clean. The old
    first-shard-only logic flagged every layer in shard 2 as missing."""
    from verify_model import verify_safetensors
    _build_model(tmp_path, shards=2, multimodal=False)
    cfg = json.load(open(tmp_path / "config.json"))
    errors = verify_safetensors(tmp_path, cfg)
    assert errors == [], f"healthy multi-shard model reported: {errors}"


def test_multi_shard_hybrid_prefix_passes(tmp_path):
    """Qwen3.5 shape: language_model.* prefix, 2 shards, layer 0 is a linear-
    attention layer with no self_attn.q_proj. Must still pass and must still
    validate q_proj (found on a later full-attention layer)."""
    from verify_model import verify_safetensors
    _build_model(tmp_path, shards=2, multimodal=True, layer0_linear=True)
    cfg = json.load(open(tmp_path / "config.json"))
    errors = verify_safetensors(tmp_path, cfg)
    assert errors == [], f"healthy hybrid multi-shard model reported: {errors}"


def test_gated_q_proj_passes(tmp_path):
    """Qwen3.5 full-attention q_proj is gated: output width is q_dim*2 (Q +
    attention gate). Verification must accept that, not just the plain width.
    This is the failure that surfaced on the real 4B once the layer scan
    started actually reaching a full-attention q_proj."""
    from verify_model import verify_safetensors
    _build_model(tmp_path, shards=2, multimodal=True,
                 layer0_linear=True, gated_q=True)
    cfg = json.load(open(tmp_path / "config.json"))
    errors = verify_safetensors(tmp_path, cfg)
    assert errors == [], f"gated-q_proj model should verify clean, got: {errors}"


def test_genuinely_missing_layer_still_fails(tmp_path):
    """The check must keep its teeth: a layer actually absent from shard 2
    (and from the index) must be reported, not silently passed."""
    from verify_model import verify_safetensors
    _build_model(tmp_path, shards=2, multimodal=False, drop_layer=3)
    cfg = json.load(open(tmp_path / "config.json"))
    errors = verify_safetensors(tmp_path, cfg)
    assert any("Missing layers" in e and "3" in e for e in errors), \
        f"expected a missing-layer error for layer 3, got: {errors}"


def test_index_keys_preferred_over_first_shard(tmp_path):
    """Directly assert the fix's mechanism: the key set spans BOTH shards,
    i.e. verification consults the index, not just safetensor_files[0]."""
    from verify_model import _safetensors_key_map
    _build_model(tmp_path, shards=2, multimodal=False)
    files = sorted(tmp_path.glob("*.safetensors"))
    keys, key_to_shard = _safetensors_key_map(tmp_path, files)
    shards_used = {p.name for p in key_to_shard.values()}
    assert len(shards_used) == 2, f"only consulted shards: {shards_used}"
    # The last layer lives in shard 2 — it must be visible.
    assert "model.layers.3.input_layernorm.weight" in keys
