#!/usr/bin/env python3
"""Test the SHIPPED speculative-decoding code — not a re-implementation.

Two parts:

PART 1 — sampler parity (needs torch; NO models; runs in seconds).
  Calls the real engine.sampler.sample() and engine.sampler.distribution() and
  checks they agree. Specifically pins the bug that broke temp-0 byte-identity:
  at temperature 0, distribution() must return a one-hot at the RAW argmax,
  exactly what sample() returns, EVEN when presence_penalty != 0 and tokens
  repeat. Also checks that at temperature > 0, drawing many tokens from sample()
  reproduces distribution()'s probabilities.

PART 2 — end-to-end greedy losslessness (needs torch AND the two models).
  Builds verifier + draft via the real build_engine(), then for the same
  prompt compares:
      verifier.generate(temperature=0, ...)            # plain greedy
      speculative_generate(verifier, draft, temp=0...) # SD
  The token-id lists MUST be identical. This exercises the real all-K verify
  sweep and the hybrid snapshot_state()/restore_state() rollback — the part that
  cannot be checked without the models. Run with presence_penalty=2.0 (the
  default) on purpose, so it also regression-tests the parity fix end to end.

USAGE
  Part 1 only (fast):
      python tests/test_sd_lossless.py
  Full (slow on edge hardware — generation runs at the model's real tok/s):
      python tests/test_sd_lossless.py \
          --verify-model Qwen3.5-4B --draft-model Qwen3.5-0.8B \
          --n-tokens 24 --block-k 4

Exit code 0 = all checks passed, 1 = a check failed. Model names are directory
names under <repo>/models, same as the dashboard.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "src"))

import torch  # noqa: E402
from engine.sampler import sample, distribution  # noqa: E402

MODELS_DIR = REPO / "models"
_PASS = _FAIL = 0


def check(name: str, ok: bool, detail: str = "") -> None:
    global _PASS, _FAIL
    print(f"  {'PASS' if ok else 'FAIL'}  {name}" + (f"  — {detail}" if detail else ""))
    _PASS += ok
    _FAIL += (not ok)


# ─────────────────────────── PART 1: sampler parity ───────────────────────────
def part1_sampler_parity(vocab: int = 2000, trials: int = 300,
                         draws: int = 60000) -> None:
    print("\n[1] Sampler parity — real sample() vs distribution() (no models)")
    torch.manual_seed(0)

    # Greedy: sample() and distribution() must both pick the RAW argmax, even
    # with a nonzero presence penalty over repeated tokens. (This is the exact
    # condition that previously diverged.)
    greedy_ok = True
    bad = None
    for _ in range(trials):
        logits = torch.randn(vocab)
        n_gen = int(torch.randint(1, 50, (1,)).item())
        gen = torch.randint(0, vocab, (n_gen,)).tolist()
        pp = float(torch.rand(()) * 3.0)  # often nonzero
        s = sample(logits.clone(), temperature=0.0,
                   presence_penalty=pp, generated_tokens=gen)
        d = distribution(logits.clone(), temperature=0.0,
                         presence_penalty=pp, generated_tokens=gen)
        raw = int(torch.argmax(logits))
        if not (s == int(torch.argmax(d)) == raw):
            greedy_ok = False
            bad = (s, int(torch.argmax(d)), raw, pp)
            break
    check("greedy: sample()==argmax(distribution())==raw argmax, incl. presence penalty",
          greedy_ok, "" if greedy_ok else f"sample={bad[0]} dist={bad[1]} raw={bad[2]} pp={bad[3]:.2f}")

    # distribution() one-hot at temp 0
    logits = torch.randn(vocab)
    d = distribution(logits, temperature=0.0, presence_penalty=2.0,
                     generated_tokens=[int(torch.argmax(logits))])
    check("greedy: distribution() is a clean one-hot (sums to 1, single nonzero)",
          abs(float(d.sum()) - 1.0) < 1e-5 and int((d > 0).sum()) == 1)

    # Sampled: histogram of many sample() draws ≈ distribution() probabilities.
    torch.manual_seed(1)
    logits = torch.randn(vocab)
    probs = distribution(logits, temperature=0.7, top_p=0.9, top_k=20,
                         presence_penalty=0.0)
    counts = torch.zeros(vocab)
    for _ in range(draws):
        counts[sample(logits, temperature=0.7, top_p=0.9, top_k=20)] += 1
    emp = counts / draws
    tv = 0.5 * float((emp - probs).abs().sum())
    check(f"sampled: sample() histogram matches distribution() (TV={tv:.4f} < 0.03)", tv < 0.03)


# ───────────────────── PART 2: end-to-end greedy losslessness ─────────────────
def _format(streamer, prompt: str) -> str:
    tok = streamer.adapter.tokenizer
    messages = [
        {"role": "system", "content": "You are Courier, a terse edge analyst."},
        {"role": "user", "content": prompt},
    ]
    try:
        return tok.apply_chat_template(messages, tokenize=False,
                                       add_generation_prompt=True,
                                       enable_thinking=False)
    except TypeError:
        return tok.apply_chat_template(messages, tokenize=False,
                                       add_generation_prompt=True)


def _first_divergence(a: list[int], b: list[int]) -> int:
    for i in range(min(len(a), len(b))):
        if a[i] != b[i]:
            return i
    return min(len(a), len(b)) if len(a) != len(b) else -1


def part2_lossless_e2e(args) -> None:
    print("\n[2] End-to-end greedy losslessness — real generate() vs speculative_generate()")
    try:
        from engine.inference import build_engine
        from engine.speculative import speculative_generate
        try:
            from server import load_config
            cfg = dict(load_config())
        except Exception:
            cfg = {"temperature": 0.0, "top_p": 1.0, "max_new_tokens": args.n_tokens,
                   "presence_penalty": 2.0, "max_ram_percent": 80.0}
    except Exception as e:
        check("imports", False, str(e))
        return

    vpath, dpath = MODELS_DIR / args.verify_model, MODELS_DIR / args.draft_model
    if not vpath.exists() or not dpath.exists():
        check("models present", False, f"missing {vpath if not vpath.exists() else dpath}")
        return

    print(f"  building verifier {args.verify_model} + draft {args.draft_model} "
          f"(this loads weights; slow on edge hardware)...")
    verifier, _ = build_engine(str(vpath), config=cfg)
    draft, _ = build_engine(str(dpath), config=cfg)

    prompts = args.prompt or [
        "Summarize the overnight seismic readings and flag anything unusual.",
    ]
    # presence_penalty=2.0 on purpose: at temp 0 BOTH paths must ignore it
    # identically. If the parity fix were wrong, this is where they'd diverge.
    PP = 2.0
    for prompt in prompts:
        formatted = _format(verifier, prompt)
        base = verifier.generate(prompt=formatted, max_new_tokens=args.n_tokens,
                                 temperature=0.0, top_p=1.0, top_k=0,
                                 presence_penalty=PP)
        for k in args.block_k:
            spec = speculative_generate(verifier, draft, formatted,
                                        max_new_tokens=args.n_tokens, block_k=k,
                                        temperature=0.0, top_p=1.0, top_k=0,
                                        presence_penalty=PP)
            ok = (base == spec)
            if ok:
                check(f"greedy off==on  (block_k={k}, {len(base)} tok)", True)
            else:
                i = _first_divergence(base, spec)
                check(f"greedy off==on  (block_k={k})", False,
                      f"diverge at token {i}: plain={base[i:i+3]} sd={spec[i:i+3]} "
                      f"(len {len(base)} vs {len(spec)})")


def main() -> int:
    ap = argparse.ArgumentParser(description="Test shipped speculative-decoding code.")
    ap.add_argument("--verify-model")
    ap.add_argument("--draft-model")
    ap.add_argument("--n-tokens", type=int, default=24)
    ap.add_argument("--block-k", type=int, nargs="+", default=[4])
    ap.add_argument("--prompt", nargs="+")
    ap.add_argument("--draws", type=int, default=60000, help="samples for the histogram check")
    args = ap.parse_args()

    part1_sampler_parity(draws=args.draws)
    if args.verify_model and args.draft_model:
        part2_lossless_e2e(args)
    else:
        print("\n[2] skipped — pass --verify-model and --draft-model to run the "
              "end-to-end greedy losslessness test on the real pair.")

    print(f"\n{_PASS}/{_PASS + _FAIL} checks passed")
    return 0 if _FAIL == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
