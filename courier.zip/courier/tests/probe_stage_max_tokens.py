#!/usr/bin/env python3
"""Probe: does the job/cycle-level max_new_tokens actually reach the engine?

Cold, no torch. Builds a 2-stage template (stage A: no per-stage cap; stage B:
cap=50), runs the REAL run_pipeline with default_max_tokens=576, and captures
the max_new_tokens that infer_fn actually receives for each stage.

Contract (run_pipeline docstring): default_max_tokens is "used when neither the
template nor the stage sets max_new_tokens". So stage A must be generated with
576 and stage B with 50.

BUG (pre-fix): stage A is called with NO max_new_tokens, so the engine falls
back to its own build-time default (e.g. 2048) — the job's 576 is silently
ignored. That is why a report can show "Max Tokens 576" while generation
truncates at 2048.

    cd courier
    python tests/probe_stage_max_tokens.py
"""
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "src"))

from pipeline import run_pipeline          # noqa: E402  (torch-free)
from template import Template              # noqa: E402

captured = []  # (effective max_new_tokens passed to infer_fn) per stage


def fake_infer_fn(prompt, **kwargs):
    captured.append(kwargs.get("max_new_tokens", "ABSENT"))
    return "ok."


def two_stage_template():
    return Template.from_dict({
        "template": {"id": "p", "name": "p"},
        "model": {"id": "Qwen/Qwen3.5-4B", "max_new_tokens": 2048},
        "data": {"sources": {}},
        "stages": [
            {"label": "A no-cap", "system_prompt": "Say ok.", "input": {}},
            {"label": "B cap50", "system_prompt": "Say ok.",
             "max_new_tokens": 50, "input": {}},
        ],
    })


def main():
    JOB_DEFAULT = 576  # the value a report would show as "Max Tokens"
    run_pipeline(two_stage_template(), data={}, infer_fn=fake_infer_fn,
                 default_max_tokens=JOB_DEFAULT, records_by_source={})

    print("=" * 60)
    print("max_new_tokens infer_fn received, per stage:")
    print(f"  stage A (no per-stage cap): {captured[0]!r}")
    print(f"  stage B (per-stage cap=50): {captured[1]!r}")
    print("=" * 60)

    ok = True
    if captured[0] != JOB_DEFAULT:
        ok = False
        print(f"  [FAIL] stage A: job default {JOB_DEFAULT} NOT applied "
              f"(got {captured[0]!r}). The configured cap is being ignored; "
              f"the engine will use its own build-time default instead.")
    else:
        print(f"  [PASS] stage A honors the job default ({JOB_DEFAULT}).")
    if captured[1] != 50:
        ok = False
        print(f"  [FAIL] stage B: per-stage cap 50 NOT applied (got {captured[1]!r}).")
    else:
        print("  [PASS] stage B honors its per-stage cap (50).")

    print("=" * 60)
    print("RESULT:", "ALL PASS" if ok else "BUG REPRODUCED")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
