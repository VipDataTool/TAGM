"""Phase 1A tests — inference engine.

Tests the model adapter, shard manager, KV cache, and layer-streaming
inference engine. Model tests require Qwen3-0.6B to be downloaded.
"""

import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

MODEL_PATH = Path(__file__).parent.parent / "models" / "Qwen3-0.6B"


def model_available():
    return MODEL_PATH.exists() and (MODEL_PATH / "config.json").exists()


# ── 1A.1: Adapter Tests ─────────────────────────────────────

class TestQwen3Adapter:

    @pytest.fixture(autouse=True)
    def require_model(self):
        if not model_available():
            pytest.skip("Model not downloaded")

    def test_auto_detect(self):
        from core.adapter.registry import detect_adapter
        adapter = detect_adapter(MODEL_PATH)
        assert adapter.config.model_type == "qwen3"

    def test_config_values(self):
        from core.adapter.registry import detect_adapter
        adapter = detect_adapter(MODEL_PATH)
        c = adapter.config
        assert c.num_hidden_layers == 28
        assert c.hidden_size == 1024
        assert c.head_dim == 128
        assert c.num_key_value_heads == 8
        assert c.vocab_size == 151936
        assert c.tie_word_embeddings is True

    def test_head_dim_decoupled(self):
        from core.adapter.registry import detect_adapter
        c = detect_adapter(MODEL_PATH).config
        assert c.head_dim != c.hidden_size // c.num_attention_heads

    def test_layer_keys(self):
        from core.adapter.registry import detect_adapter
        keys = detect_adapter(MODEL_PATH).layer_weight_keys(0)
        assert "q_norm" in keys and "k_norm" in keys
        assert len(keys) == 11

    def test_gqa_and_kv(self):
        from core.adapter.registry import detect_adapter
        a = detect_adapter(MODEL_PATH)
        assert a.gqa_group_size() == 2
        assert a.kv_cache_bytes_per_token_per_layer() == 4096


# ── 1A.2: Shard Manager Tests ───────────────────────────────

class TestShardManager:

    @pytest.fixture(autouse=True)
    def require_model(self):
        if not model_available():
            pytest.skip("Model not downloaded")

    @pytest.fixture(scope="class")
    def shard_mgr(self):
        from core.adapter.registry import detect_adapter
        from core.shard_manager import ShardManager
        return ShardManager(MODEL_PATH, detect_adapter(MODEL_PATH))

    def test_load_embedding(self, shard_mgr):
        e = shard_mgr.load_embedding()
        assert e.shape == (151936, 1024)

    def test_load_layer_0(self, shard_mgr):
        w = shard_mgr.load_layer(0)
        assert w["q_proj"].shape == (2048, 1024)
        assert w["q_norm"].shape == (128,)

    def test_load_layer_27(self, shard_mgr):
        assert "q_proj" in shard_mgr.load_layer(27)

    def test_final_norm(self, shard_mgr):
        assert shard_mgr.load_final_norm().shape == (1024,)

    def test_tied_lm_head(self):
        from core.adapter.registry import detect_adapter
        assert detect_adapter(MODEL_PATH).lm_head_key() is None


# ── 1A.4: KV Cache Tests ────────────────────────────────────

class TestKVCache:

    def test_ram_write_read(self):
        import torch
        from engine.kv_cache import KVCacheManager
        kv = KVCacheManager(n_layers=4, num_kv_heads=8, head_dim=128, max_ram_layers=4)
        k = torch.randn(1, 8, 5, 128, dtype=torch.bfloat16)
        v = torch.randn(1, 8, 5, 128, dtype=torch.bfloat16)
        kv.write(0, k, v)
        r = kv.read(0)
        assert r is not None and torch.equal(r[0], k)

    def test_lru_spillover(self):
        import torch
        from engine.kv_cache import KVCacheManager
        with tempfile.TemporaryDirectory() as d:
            kv = KVCacheManager(n_layers=10, num_kv_heads=8, head_dim=128,
                                max_ram_layers=3, cache_dir=d)
            for i in range(10):
                kv.write(i, torch.randn(1,8,2,128), torch.randn(1,8,2,128))
            s = kv.stats()
            assert s["ram_layers"] == 3 and s["disk_layers"] >= 1
            assert kv.read(0) is not None

    def test_clear(self):
        import torch
        from engine.kv_cache import KVCacheManager
        kv = KVCacheManager(n_layers=4, num_kv_heads=8, head_dim=128)
        kv.write(0, torch.randn(1,8,2,128), torch.randn(1,8,2,128))
        kv.clear()
        assert kv.read(0) is None


# ── 1A.3 + 1A.5: Inference Tests ────────────────────────────

class TestInference:

    @pytest.fixture(autouse=True)
    def require_model(self):
        if not model_available():
            pytest.skip("Model not downloaded")

    @pytest.fixture(scope="class")
    def streamer(self):
        """Build once, reuse across all inference tests."""
        from core.adapter.registry import detect_adapter
        from core.shard_manager import ShardManager
        from engine.streamer import LayerStreamer
        print("\n  Loading model...", end=" ", flush=True)
        adapter = detect_adapter(MODEL_PATH)
        shard_mgr = ShardManager(MODEL_PATH, adapter)
        s = LayerStreamer(shard_mgr, adapter)
        print("done.", flush=True)
        return s

    def test_forward_logits_shape(self, streamer):
        import torch
        logits = streamer.forward(torch.tensor([[1, 2, 3]]))
        assert logits.shape == (1, 151936)
        print("  logits OK", flush=True)

    def test_forward_deterministic(self, streamer):
        import torch
        ids = torch.tensor([[1, 2, 3]])
        streamer.kv_cache.clear()
        l1 = streamer.forward(ids)
        streamer.kv_cache.clear()
        l2 = streamer.forward(ids)
        assert torch.equal(l1, l2)
        print("  deterministic OK", flush=True)

    def test_generate(self, streamer):
        import time
        start = time.time()
        tokens = streamer.generate(
            prompt="The capital of France is",
            max_new_tokens=10,
            temperature=0.3,
        )
        elapsed = time.time() - start
        text = streamer.adapter.tokenizer.decode(tokens)
        tok_s = len(tokens) / elapsed if elapsed > 0 else 0
        print(f"  generated {len(tokens)} tok in {elapsed:.1f}s ({tok_s:.0f} tok/s): {text}", flush=True)
        assert len(tokens) > 0
