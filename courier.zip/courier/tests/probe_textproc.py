#!/usr/bin/env python3
"""Cold probes for engine.textproc — the think-block and truncation rules.

The regression that motivated this module: a truncated non-thinking stage
displayed an empty <think></think> block (the strip was wrongly gated on
not-truncated) and reported 66 tokens for a 32-token generation (the count
was estimated over text that included the scaffolding and the truncation
banner). These probes pin every rule; the token-count fix itself lives in
the (text, count) contract between inference and pipeline, exercised by
the stub-contract section below.

Run:  python tests/probe_textproc.py
"""
from __future__ import annotations

from _probe_util import Probe, add_src_to_path

add_src_to_path()

from engine.textproc import (nothink_primer, strip_chat_markers,   # noqa: E402
                             clean_think_blocks, truncation_notice,
                             NOTHINK_PRIMER)

p = Probe("Inference text mechanics")

# ── No-think priming ─────────────────────────────────────────
p.section("no-think priming")
p.check("thinking off → assistant turn primed with closed think pair",
        nothink_primer(False) == NOTHINK_PRIMER and
        NOTHINK_PRIMER.startswith("<think>") and
        "</think>" in NOTHINK_PRIMER)
p.check("thinking on → no primer", nothink_primer(True) == "")

# ── Chat-marker cleanup ──────────────────────────────────────
p.section("chat markers")
p.check("markers stripped, content kept",
        strip_chat_markers("<|im_start|>assistant\nHello.<|im_end|>")
        == "Hello.")

# ── Think-block display rules ────────────────────────────────
p.section("think blocks")
shot = ("<think>\n\n</think>\n\nThe image shows a stratovolcano with a "
        "prominent summit crater emitting a large ash plume")
p.check("THE SCREENSHOT CASE: empty pair stripped from truncated "
        "non-thinking output",
        clean_think_blocks(shot, thinking=False).startswith("The image"))
p.check("empty pair stripped even in thinking mode (zero information)",
        clean_think_blocks(shot, thinking=True).startswith("The image"))
full = "<think>Let me reason about craters.</think>\n\nIt is erupting."
p.check("closed block stripped when thinking off — truncated or not",
        clean_think_blocks(full, thinking=False) == "It is erupting.")
p.check("closed block KEPT when thinking on (the feature)",
        clean_think_blocks(full, thinking=True) == full)
dangling = "<think>Reasoning that ran out of tok"
p.check("unclosed block left intact (cannot strip safely)",
        clean_think_blocks(dangling, thinking=False) == dangling)
only_think = "<think>All reasoning, no answer.</think>"
p.check("full strip never blanks the output",
        clean_think_blocks(only_think, thinking=False) == only_think)
p.check("scaffolding-only output honestly reduces to nothing",
        clean_think_blocks("<think>\n\n</think>\n", thinking=False) == "")

# ── Truncation banner ────────────────────────────────────────
p.section("truncation banner")
note = truncation_notice(32)
p.check("banner names the actual limit", "32-token" in note)
p.check("banner is marked as UI, not model output",
        note.startswith("\n\n[⚠"))

# ── The (text, count) contract the pipeline accepts ──────────
p.section("pipeline token contract")
from pipeline import StageResult                              # noqa: E402
sr = StageResult(index=0, label="t", thinking=False,
                 system_prompt_preview="", input_text="", input_chars=0,
                 output="x" * 264, output_chars=264, output_tokens=32,
                 time_seconds=1.0)
p.check("StageResult carries the engine's real count", sr.output_tokens == 32)
sr2 = StageResult(index=0, label="t", thinking=False,
                  system_prompt_preview="", input_text="", input_chars=0,
                  output="x" * 264, output_chars=264, time_seconds=1.0)
p.check("count is optional — stub engines fall back to the estimate",
        sr2.output_tokens is None)
from pipeline import stage_token_count                       # noqa: E402
p.check("receipts prefer the real count over the estimate",
        stage_token_count(sr) == 32 and stage_token_count(sr2) == 264 // 4)
p.check("THE SCREENSHOT NUMBERS: 264 chars of banner-padded text no "
        "longer reports 66 for a 32-token stage",
        stage_token_count(sr) == 32 != 264 // 4)

p.done()
