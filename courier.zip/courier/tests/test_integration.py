"""Phase 2 integration tests — real engine in the pipeline.

Short prompts, 10-20 tokens max, visible progress.
"""

import sys
import time
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

MODEL_PATH = Path(__file__).parent.parent / "models" / "Qwen3-0.6B"
DATA_DIR = Path(__file__).parent.parent / "data"
TEMPLATES_DIR = Path(__file__).parent.parent / "templates" / "builtin"
EXPORT_DIR = Path(__file__).parent.parent / "export"


def model_available():
    return MODEL_PATH.exists() and (MODEL_PATH / "config.json").exists()


@pytest.fixture(scope="module")
def infer_fn():
    if not model_available():
        pytest.skip("Model not downloaded")
    from engine.inference import build_engine
    print("\n  Building engine...", end=" ", flush=True)
    _, fn = build_engine(str(MODEL_PATH))
    print("done.", flush=True)
    return fn


def short_infer(fn):
    """Wrap infer_fn to cap at 15 tokens."""
    def wrapped(prompt, **kw):
        kw["max_new_tokens"] = 15
        return fn(prompt, **kw)
    return wrapped


class TestIntegration:

    def test_infer_fn_basic(self, infer_fn):
        print("  infer_fn...", end=" ", flush=True)
        t = time.time()
        r = infer_fn("You are helpful.\n\n---\n\nWhat is 2+2?", max_new_tokens=10)
        print(f"{time.time()-t:.1f}s: {r[:80]}", flush=True)
        assert len(r) > 0

    def test_thinking_mode(self, infer_fn):
        print("  thinking...", end=" ", flush=True)
        t = time.time()
        r = infer_fn("You are a math tutor.\n\n---\n\n7 times 8?", thinking=True, max_new_tokens=15)
        print(f"{time.time()-t:.1f}s: {r[:80]}", flush=True)
        assert len(r) > 0

    def test_single_stage(self, infer_fn):
        from template import Template
        from pipeline import run_pipeline
        print("  1-stage pipeline...", end=" ", flush=True)
        t = time.time()
        tmpl = Template.load(TEMPLATES_DIR / "field_report_summary.json")
        r = run_pipeline(tmpl, {"default": str(DATA_DIR / "test_seismic.json")}, short_infer(infer_fn))
        print(f"{time.time()-t:.1f}s: {r.stages[0].output[:80]}", flush=True)
        assert len(r.stages) == 1
        assert r.stages[0].error is None

    def test_two_stage(self, infer_fn):
        from template import Template
        from pipeline import run_pipeline
        print("  2-stage pipeline...", end=" ", flush=True)
        t = time.time()
        tmpl = Template.load(TEMPLATES_DIR / "sensor_anomaly.json")
        r = run_pipeline(tmpl, {"default": str(DATA_DIR / "test_seismic.json")}, short_infer(infer_fn))
        print(f"{time.time()-t:.1f}s", flush=True)
        assert len(r.stages) == 2
        for s in r.stages:
            assert s.error is None
            assert len(s.output) > 0

    def test_export_file(self, infer_fn):
        from template import Template
        from pipeline import run_pipeline
        print("  export...", end=" ", flush=True)
        tmpl = Template.load(TEMPLATES_DIR / "field_report_summary.json")
        r = run_pipeline(tmpl, {"default": str(DATA_DIR / "test_weather.json")}, short_infer(infer_fn))
        out = EXPORT_DIR / "test_output.md"
        r.write(str(out))
        assert out.exists() and len(out.read_text()) > 10
        print(f"wrote {out}", flush=True)
