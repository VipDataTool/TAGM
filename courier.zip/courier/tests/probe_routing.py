#!/usr/bin/env python3
"""Probe: Channel A stage routing (multimodel spec §2, §8 step 5, §9).

pipeline + template import cold (no torch), so the routing SELECTION logic and
the StageConfig.model parse/round-trip verify here. The §9 "independent
switches" bullet for routing reduces to: with no routing map, every stage uses
the one infer_fn (today's behavior); with a map, a stage runs on its named
engine and falls back to primary otherwise.

    cd courier && python tests/probe_routing.py
"""
from _probe_util import Probe, add_src_to_path

add_src_to_path()
from pipeline import select_stage_infer_fn   # noqa: E402
from template import StageConfig             # noqa: E402

p = Probe("routing")

PRIM = lambda s, **k: "P"      # noqa: E731
DRAFT = lambda s, **k: "D"     # noqa: E731
VISION = lambda s, **k: "V"    # noqa: E731

s_plain = StageConfig(label="a", system_prompt="x")                 # no model
s_draft = StageConfig(label="b", system_prompt="x", model="draft")  # routed
s_vision = StageConfig(label="c", system_prompt="x", model="vision")

# ── Off path: no routing map -> always the single infer_fn (today) ─────────
p.section("no routing map (dormant default)")
p.check("plain stage -> primary", select_stage_infer_fn(s_plain, PRIM, None) is PRIM)
p.check("even a model-tagged stage -> primary when map absent",
        select_stage_infer_fn(s_draft, PRIM, None) is PRIM)

# ── On path: routing map present ───────────────────────────────────────────
fns = {"primary": PRIM, "draft": DRAFT, "vision": VISION}
p.section("routing map present")
p.check("untagged stage still -> primary", select_stage_infer_fn(s_plain, PRIM, fns) is PRIM)
p.check("draft-tagged stage -> draft engine", select_stage_infer_fn(s_draft, PRIM, fns) is DRAFT)
p.check("vision-tagged stage -> vision engine", select_stage_infer_fn(s_vision, PRIM, fns) is VISION)
p.check("unknown role falls back to primary",
        select_stage_infer_fn(StageConfig(label="d", system_prompt="x", model="nope"), PRIM, fns) is PRIM)

# ── StageConfig.model default + parse/round-trip ───────────────────────────
p.section("StageConfig.model field")
p.check("defaults to None (off)", StageConfig(label="e", system_prompt="x").model is None)
parsed = StageConfig(label="f", system_prompt="x", model="draft")
p.check("carries the role when set", parsed.model == "draft")

p.section("template JSON round-trip")
from template import Template, ModelSpec, TemplateMetadata   # noqa: E402
tpl = Template(
    metadata=TemplateMetadata(id="t1", name="T"),
    model=ModelSpec(id="Qwen3.5-4B"),
    sources={},
    stages=[s_plain, s_draft],
)
d = tpl.to_dict()
stage_dicts = d["stages"]
p.check("untagged stage omits 'model' key (unchanged serialization)",
        "model" not in stage_dicts[0])
p.check("tagged stage serializes its role", stage_dicts[1].get("model") == "draft")

p.done()
