"""Globless cycle tests: the DB ledger is the load-bearing data source.

Proves the worker's ledger->pipeline path end to end without the model:
- a cycle's scope is built from the ledger (windowed inbox UNION reference),
  grouped by template source (images -> image rows, tabular -> matching rows)
- fetch_source_data renders that scope via render_records (same formatter the
  file path uses), producing the table + ordered image_paths the engine consumes
- windowing: a second cycle claims only data that arrived since the first
- reference (persistent companion) data is returned every cycle, never consumed
- consume-on-success moves only the inbox files, never reference files

engine.worker imports torch transitively (via engine.checkpoint); the helpers
under test are pure-Python, so we stub torch to import them. No model runs.
"""

import sys
import tempfile
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "src"))

# Torch (real if installed, one adequate shared stub if not) BEFORE
# importing the worker. NEVER install a bare empty fake here: under
# pytest's shared process it becomes every later module's torch and
# blocks the real library — this exact line once broke collection of
# test_resilience and test_sd_lossless.
sys.path.insert(0, str(REPO / "tests"))
from _probe_util import ensure_torch                          # noqa: E402
ensure_torch()

from core.db import Database                                  # noqa: E402
from data import ingest                                        # noqa: E402
from template import Template                                  # noqa: E402
from pipeline import fetch_source_data                         # noqa: E402
from engine.worker import _records_by_source, _move_consumed_to_processed  # noqa: E402


def _template():
    return Template.from_dict({
        "template": {"id": "boats", "name": "Boat Watch"},
        "model": {"id": "Qwen/Qwen3.5-4B"},
        "data": {"sources": {
            "sensors": {"adapter": "csv_file", "budget_tokens": 400},
            "images": {"adapter": "image_file", "budget_tokens": 100},
        }},
        "stages": [{"label": "S", "system_prompt": "analyze",
                    "input": {"sources": ["sensors", "images"]}}],
    })


@pytest.fixture
def setup(tmp_path):
    db = Database(tmp_path / "courier.db")
    tpl = _template()
    # inbox: a sensors CSV (source_id 'sensors') + two boat images
    csv = tmp_path / "sensors.csv"
    csv.write_text("station,co2_ppm\nA,415\nB,418\n")
    ingest.ingest_csv_file(db, csv)
    for n in ("boat_01.jpg", "boat_02.jpg"):
        (tmp_path / n).write_bytes(b"\xff\xd8\xff\xe0FAKE")
        ingest.ingest_image_file(db, tmp_path / n)
    # persistent reference companion dataset
    ref = tmp_path / "registry.csv"
    ref.write_text("hull,owner\nH1,Acme\n")
    ingest.ingest_csv_file(db, ref, source_id="registry", source_type="reference")
    yield db, tpl, tmp_path, csv, ref
    db.close()


def test_ledger_feeds_grouped_by_source(setup):
    db, tpl, _, _, _ = setup
    db.snapshot("c1")
    rbs = _records_by_source(db, "c1", tpl)
    # tabular 'sensors' bound to the sensor rows (named binding), as dicts
    assert {d["station"] for d in rbs["sensors"]} == {"A", "B"}
    assert all(isinstance(d, dict) for d in rbs["sensors"])
    # images bound to the image source as raw rows with path pointers
    assert [Path(r["path"]).name for r in rbs["images"]] == ["boat_01.jpg", "boat_02.jpg"]


def test_rendered_scope_has_table_and_ordered_images(setup):
    db, tpl, _, _, _ = setup
    db.snapshot("c1")
    rbs = _records_by_source(db, "c1", tpl)
    text, imgs = fetch_source_data(["sensors", "images"], tpl, {}, 1000,
                                   records_by_source=rbs)
    assert "| station | co2_ppm |" in text       # tabular rendered from DB
    assert "2 image(s)" in text
    assert [Path(p).name for p in imgs] == ["boat_01.jpg", "boat_02.jpg"]


def test_consume_on_success_moves_inbox_only(setup):
    db, tpl, tmp, csv, ref = setup
    db.snapshot("c1")
    moved = _move_consumed_to_processed(db, "c1")
    assert moved == 3                              # csv + 2 images
    assert (tmp / "processed" / "boat_01.jpg").exists()
    assert (tmp / "processed" / "sensors.csv").exists()
    assert not csv.exists()                        # inbox file retired
    assert ref.exists()                            # reference NEVER moved


def test_second_cycle_windows_new_arrivals(setup):
    db, tpl, tmp, _, _ = setup
    db.snapshot("c1")                              # claims day-1 inbox
    _move_consumed_to_processed(db, "c1")

    (tmp / "boat_03.jpg").write_bytes(b"\xff\xd8\xff\xe0FAKE")
    ingest.ingest_image_file(db, tmp / "boat_03.jpg")

    claimed = db.snapshot("c2")
    assert claimed == 1                            # only the new arrival
    rbs2 = _records_by_source(db, "c2", tpl)
    assert [Path(r["path"]).name for r in rbs2["images"]] == ["boat_03.jpg"]
    # reference still in scope on the second cycle
    assert len(db.get_reference_records()) == 1
