#!/usr/bin/env python3
"""Vision-path diagnostic for Courier's multimodal (Qwen3.5-4B) inference.

This is NOT a pass/fail unit test — it's an instrumented end-to-end probe.
It runs each stage of the image path separately against the REAL model on
this machine and prints the actual shapes and counts, so we can see what the
vision path truly does rather than infer it from reading code.

The single most important line it prints is the COUNT CHECK:

    image_pad tokens in prompt   vs   vision tokens from encoder

The embedding merge (embed_with_vision) replaces image-placeholder positions
with vision-encoder output and only fills min(n_placeholders, n_vision_tokens)
of them. If the prompt has 1 placeholder but the encoder emits ~hundreds, the
model effectively sees a single patch, not the image. That comparison tells us
whether that's happening.

Run it directly (NOT via pytest — pytest hides the output):

    cd courier
    python tests/test_vision_smoke.py
    # or point it explicitly:
    python tests/test_vision_smoke.py models/Qwen3.5-4B image-src/Neolithic_era.jpeg

It will take a few minutes on CPU (a full prefill + a short generation).
Every stage is isolated in try/except, so an error in one stage still lets the
later stages (and the summary) run. Paste the whole output back.
"""

import sys
import json
import traceback
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "src"))

LINE = "=" * 70


def _hr(title):
    print(f"\n{LINE}\n{title}\n{LINE}", flush=True)


def _find_model(argv) -> Path | None:
    pos = [a for a in argv[1:] if not a.startswith("--")]
    if len(pos) > 0:
        p = Path(pos[0])
        return p if p.exists() else None
    for cand in ("models/Qwen3.5-4B-int8", "models/Qwen3.5-4B"):
        p = REPO / cand
        if p.exists():
            return p
    return None


def _find_image(argv) -> Path | None:
    pos = [a for a in argv[1:] if not a.startswith("--")]
    if len(pos) > 1:
        p = Path(pos[1])
        return p if p.exists() else None
    exts = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}
    for d in ("image-src", "data"):
        dd = REPO / d
        if dd.exists():
            for f in sorted(dd.iterdir()):
                if f.suffix.lower() in exts:
                    return f
    return None


def _load_config() -> dict:
    """build_engine requires temperature/top_p/max_new_tokens. Use the real
    config if present, else minimal defaults — values don't affect the shape
    diagnostics, only the end-to-end generation."""
    for cand in ("courier_config.json", "config/courier_config.json"):
        p = REPO / cand
        if p.exists():
            try:
                cfg = json.loads(p.read_text())
                cfg.setdefault("temperature", 0.3)
                cfg.setdefault("top_p", 0.9)
                cfg.setdefault("max_new_tokens", 64)
                print(f"  Loaded config: {p}")
                return cfg
            except Exception:
                pass
    print("  No courier_config.json found — using diagnostic defaults.")
    return {"temperature": 0.3, "top_p": 0.9, "max_new_tokens": 64,
            "presence_penalty": 2.0, "enable_thinking": False}


def main():
    print(LINE)
    print("COURIER VISION-PATH DIAGNOSTIC")
    print(LINE)

    findings = {}

    model_dir = _find_model(sys.argv)
    image_path = _find_image(sys.argv)
    print(f"Model:  {model_dir}")
    print(f"Image:  {image_path}")
    if model_dir is None:
        print("\nFATAL: no model directory found. Pass one: "
              "python tests/test_vision_smoke.py <model_dir> <image>")
        return
    if image_path is None:
        print("\nFATAL: no image found in image-src/ or data/. Pass one explicitly.")
        return

    qcfg = model_dir / "quantization_config.json"
    if qcfg.exists():
        print(f"Quantized: {qcfg.read_text().strip()}")
    else:
        print("Quantized: no marker (bf16 / full precision)")

    # ── Stage 1: preprocess_image ───────────────────────────────────
    _hr("STAGE 1 — preprocess_image()")
    pixel_values = grid_thw = None
    merge = None
    expected_vtok = None
    try:
        from engine.vision import preprocess_image
        pixel_values, grid_thw = preprocess_image(str(image_path))
        print(f"  pixel_values shape: {tuple(pixel_values.shape)}  dtype={pixel_values.dtype}")
        print(f"  grid_thw:           {grid_thw.tolist()}")
        t, h, w = (int(x) for x in grid_thw[0])
        findings["grid_thw"] = (t, h, w)
        print(f"  patch grid (t,h,w): {t} x {h} x {w}  =>  {t*h*w} raw patches")
    except Exception:
        print("  ERROR in preprocess_image:")
        traceback.print_exc()

    # ── Stage 2: build engine / vision encoder present? ─────────────
    _hr("STAGE 2 — build_engine() + vision encoder")
    streamer = infer_fn = None
    try:
        cfg = _load_config()
        from engine.inference import build_engine
        streamer, infer_fn = build_engine(str(model_dir), cfg, dtype="bfloat16")
        is_mm = hasattr(streamer, "vision_encoder") and streamer.adapter.is_multimodal
        print(f"  streamer type:      {type(streamer).__name__}")
        print(f"  is_multimodal:      {is_mm}")
        ve = streamer.vision_encoder
        print(f"  vision_encoder:     {type(ve).__name__ if ve else None}")
        if ve is not None:
            merge = ve.vision_cfg.spatial_merge_size
            print(f"  spatial_merge_size: {merge}")
            nh = ve.vision_cfg.num_heads
            print(f"  ViT num_heads:      {nh}  head_dim: {ve.vision_cfg.hidden_size // nh}"
                  f"  rope_dim: {(ve.vision_cfg.hidden_size // nh) // 2}")
            print(f"  ViT depth:          {ve.vision_cfg.depth}")
            print(f"  image_token_id:     {streamer.config.image_token_id}")
            if findings.get("grid_thw"):
                t, h, w = findings["grid_thw"]
                expected_vtok = t * (h // merge) * (w // merge)
                print(f"  EXPECTED vision tokens (t*(h//m)*(w//m)): {expected_vtok}")
    except Exception:
        print("  ERROR building engine:")
        traceback.print_exc()

    # ── Stage 2.5: actual vision tensor inventory ───────────────────
    _hr("STAGE 2.5 — vision tensor inventory (ground truth from checkpoint)")
    try:
        from safetensors import safe_open
        idx = model_dir / "model.safetensors.index.json"
        key_to_shard = {}
        if idx.exists():
            wm = json.loads(idx.read_text()).get("weight_map", {})
            for k, sh in wm.items():
                key_to_shard[k] = model_dir / sh
        else:
            for sp in sorted(model_dir.glob("*.safetensors")):
                with safe_open(str(sp), framework="pt") as f:
                    for k in f.keys():
                        key_to_shard[k] = sp

        def shape_of(k):
            try:
                with safe_open(str(key_to_shard[k]), framework="pt") as f:
                    return tuple(f.get_slice(k).get_shape())
            except Exception:
                return "?"

        vis = [k for k in key_to_shard if ".visual." in k]
        block0 = sorted(k for k in vis if ".visual.blocks.0." in k)
        nonblock = sorted(k for k in vis if ".visual.blocks." not in k)
        print(f"  total visual tensors in checkpoint: {len(vis)}")
        print("  --- block 0 tensors (the ViT layer) ---")
        for k in block0:
            print(f"    {shape_of(k)}  {k}")
        print("  --- non-block visual tensors (patch_embed / merger / pos) ---")
        for k in nonblock:
            print(f"    {shape_of(k)}  {k}")

        if streamer is not None:
            print("  --- adapter expectations vs reality ---")
            adapter = streamer.adapter
            for role, key in adapter.vision_layer_keys(0).items():
                mark = "OK  " if key in key_to_shard else "MISS"
                print(f"    [{mark}] layer  {role:10} -> {key}")
            for role, key in adapter.vision_embedding_keys().items():
                mark = "OK  " if key in key_to_shard else "MISS"
                print(f"    [{mark}] embed  {role:16} -> {key}")
    except Exception:
        print("  ERROR building vision inventory:")
        traceback.print_exc()

    # ── Stage 3: run the vision encoder ─────────────────────────────
    _hr("STAGE 3 — vision_encoder.encode()")
    n_vision_tokens = None
    if streamer is not None and pixel_values is not None:
        try:
            vtokens = streamer.vision_encoder.encode(pixel_values, grid_thw)
            n_vision_tokens = vtokens.shape[1]
            print(f"  vision_tokens shape: {tuple(vtokens.shape)}")
            print(f"  => {n_vision_tokens} vision tokens, dim {vtokens.shape[-1]}")
            if expected_vtok is not None:
                ok = (n_vision_tokens == expected_vtok)
                print(f"  matches expected ({expected_vtok})? {ok}")
                findings["encode_matches_expected"] = ok
        except Exception:
            print("  ERROR in encode():")
            traceback.print_exc()
    else:
        print("  skipped (engine or pixels unavailable)")

    # ── Stage 4: prompt placeholder count ───────────────────────────
    _hr("STAGE 4 — multimodal prompt placeholder count")
    n_pad_tokens = None
    if streamer is not None:
        try:
            from engine.inference import format_multimodal_prompt
            # Mirror infer_fn: emit one image_pad per vision token.
            n_pad = expected_vtok if expected_vtok else 1
            formatted = format_multimodal_prompt(
                "You are a field analyst.", "Describe this image.",
                num_images=1, image_token_counts=[n_pad])
            tok = streamer.adapter.tokenizer
            ids = tok.encode(formatted, add_special_tokens=False)
            img_id = streamer.config.image_token_id
            n_pad_tokens = sum(1 for i in ids if i == img_id)
            print(f"  formatted prompt (repr): {formatted[:120]!r}")
            print(f"  total prompt tokens:     {len(ids)}")
            print(f"  image_pad tokens (id={img_id}) in prompt: {n_pad_tokens}")
        except Exception:
            print("  ERROR formatting/tokenizing prompt:")
            traceback.print_exc()
    else:
        print("  skipped (engine unavailable)")

    # ── THE COUNT CHECK ─────────────────────────────────────────────
    _hr("COUNT CHECK  (the key diagnostic)")
    print(f"  image_pad tokens in prompt:   {n_pad_tokens}")
    print(f"  vision tokens from encoder:   {n_vision_tokens}")
    if n_pad_tokens is not None and n_vision_tokens is not None:
        if n_pad_tokens == n_vision_tokens:
            print("  => MATCH. The merge can place every vision token. Good.")
        else:
            filled = min(n_pad_tokens, n_vision_tokens)
            print(f"  => MISMATCH. embed_with_vision fills min({n_pad_tokens},"
                  f" {n_vision_tokens}) = {filled} position(s).")
            if n_pad_tokens < n_vision_tokens:
                print(f"     Only {filled} of {n_vision_tokens} vision tokens reach the model"
                      f" — the image is under-represented (prompt needs"
                      f" {n_vision_tokens} placeholders, has {n_pad_tokens}).")
            else:
                print(f"     {n_pad_tokens - n_vision_tokens} placeholder(s) get no vision"
                      f" data and stay as raw image_pad tokens.")
        findings["count_match"] = (n_pad_tokens == n_vision_tokens)

    # ── Stage 4.5: multi-image plumbing (cheap — no encode, no generate) ────
    _hr("STAGE 4.5 — multi-image placeholder accounting")
    if streamer is not None and pixel_values is not None:
        try:
            from engine.inference import format_multimodal_prompt
            from engine.vision import preprocess_image
            # Collect up to 2 distinct images to exercise the multi-image path.
            exts = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}
            imgs = []
            for d in ("image-src", "data"):
                dd = REPO / d
                if dd.exists():
                    for f in sorted(dd.iterdir()):
                        if f.suffix.lower() in exts:
                            imgs.append(f)
            imgs = imgs[:2]
            merge = streamer.vision_encoder.vision_cfg.spatial_merge_size
            counts = []
            for ip in imgs:
                _pv, gt = preprocess_image(str(ip))
                t, h, w = int(gt[0][0]), int(gt[0][1]), int(gt[0][2])
                counts.append(t * (h // merge) * (w // merge))
            formatted = format_multimodal_prompt(
                "You are a field analyst.", "Compare these images.",
                num_images=len(imgs), image_token_counts=counts)
            ids = streamer.adapter.tokenizer.encode(formatted, add_special_tokens=False)
            img_id = streamer.config.image_token_id
            pad = sum(1 for i in ids if i == img_id)
            print(f"  images used: {len(imgs)}  per-image vision tokens: {counts}")
            print(f"  sum of per-image counts:     {sum(counts)}")
            print(f"  image_pad tokens in prompt:  {pad}")
            ok = (pad == sum(counts))
            print(f"  => {'MATCH' if ok else 'MISMATCH'} — prompt placeholders == total vision tokens")
            findings["multi_image_match"] = ok
        except Exception:
            print("  ERROR in multi-image accounting:")
            traceback.print_exc()
    else:
        print("  skipped (engine or pixels unavailable)")

    # ── Stage 5: end-to-end single-image generation ─────────────────
    _hr("STAGE 5 — end-to-end infer_fn() on the image (short)")
    if "--quick" in sys.argv:
        print("  skipped (--quick: plumbing-only run, no generation)")
    elif infer_fn is not None:
        try:
            prompt = ("You are examining a photograph. Describe what you see in "
                      "one or two sentences.")
            print("  running (this may take a few minutes on CPU)...", flush=True)
            out = infer_fn(prompt, image_paths=[str(image_path)], max_new_tokens=48)
            print("  --- model output ---")
            print(out)
            print("  --- end output ---")
        except Exception:
            print("  ERROR in end-to-end inference:")
            traceback.print_exc()
    else:
        print("  skipped (infer_fn unavailable)")

    # ── Summary ─────────────────────────────────────────────────────
    _hr("SUMMARY")
    print(f"  preprocess grid_thw:        {findings.get('grid_thw')}")
    print(f"  encoder token count OK:     {findings.get('encode_matches_expected')}")
    print(f"  prompt pads == vision toks: {findings.get('count_match')}")
    print("\n  Paste this entire output back for analysis.")


if __name__ == "__main__":
    main()
