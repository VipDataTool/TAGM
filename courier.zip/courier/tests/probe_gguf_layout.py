#!/usr/bin/env python3
"""Probe: GGUF layout transforms (the llama Q/K permute fix).

llama.cpp's converter permutes Q/K projection weights on
llama-architecture GGUFs; a loader that skips the inverse produces
scrambled attention with no error. The fix is family knowledge, so it
lives in the adapter (gguf_load_transforms) and GGUFShardManager
applies it blindly. This probe pins, cold (numpy, no torch, no model):

  1. inverse_llama_permute is the true inverse of llama_permute —
     round-trip identity, both directions, Q-shaped and GQA-K-shaped;
  2. the permutation actually interleaves (not a no-op): the forward
     permute moves rows, and the inverse recovers HF split-half layout
     from a hand-built interleaved example;
  3. the transforms are per-head-group correct: a Q permute with n_head
     does NOT equal a K permute with n_kv (different group counts);
  4. GGUFShardManager's suffix matching applies a declared transform to
     matching HF keys at materialization, leaves others untouched, and
     an adapter with no declarations (Qwen's default) changes nothing.

The math is validated on numpy because core/gguf_layout.py is
deliberately torch-free (pure reshape/swapaxes) — the same code path
the loader runs on torch tensors.
"""

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from core.gguf_layout import llama_permute, inverse_llama_permute  # noqa: E402

PASS = "  PASS "
_failures = []


def check(name: str, cond: bool):
    if cond:
        print(f"{PASS} {name}")
    else:
        _failures.append(name)
        print(f"  FAIL  {name}")


# ── 1+2+3: the math ───────────────────────────────────────────

print("1) Round-trip identity")
rng = np.random.default_rng(7)
n_head, n_kv, head_dim, in_dim = 8, 2, 16, 64
q = rng.standard_normal((n_head * head_dim, in_dim)).astype(np.float32)
k = rng.standard_normal((n_kv * head_dim, in_dim)).astype(np.float32)

check("inverse(permute(Q)) == Q",
      np.array_equal(inverse_llama_permute(llama_permute(q, n_head), n_head), q))
check("permute(inverse(Q)) == Q",
      np.array_equal(llama_permute(inverse_llama_permute(q, n_head), n_head), q))
check("round-trip holds for GQA K (n_kv groups)",
      np.array_equal(inverse_llama_permute(llama_permute(k, n_kv), n_kv), k))

print("2) The permute genuinely moves rows")
check("forward permute is not the identity",
      not np.array_equal(llama_permute(q, n_head), q))
# Hand-built check: within one head, HF layout is [first-halves…,
# second-halves…]; gguf interleaves them. Build the interleaved form by
# hand and confirm the inverse recovers the HF original.
one_head = np.arange(head_dim * in_dim, dtype=np.float32).reshape(head_dim, in_dim)
interleaved = np.empty_like(one_head)
interleaved[0::2] = one_head[: head_dim // 2]      # first halves → even rows
interleaved[1::2] = one_head[head_dim // 2:]       # second halves → odd rows
check("inverse recovers HF split-half from hand-interleaved rows",
      np.array_equal(inverse_llama_permute(interleaved, 1), one_head))

print("3) Head-group count matters")
check("Q permute (n_head) != K-style permute (n_kv) on same matrix",
      not np.array_equal(llama_permute(q, n_head), llama_permute(q, n_kv)))

# ── 4: blind application in the shard manager ────────────────
# Reuse the residency probe's environment fakery: fake torch + fake
# dequantize let GGUFShardManager import and run its real logic cold.

print("4) Shard manager applies declared transforms blindly")
import types  # noqa: E402

fake_torch = types.ModuleType("torch")
fake_torch.Tensor = object
fake_torch.dtype = object
fake_torch.bfloat16 = object()
fake_torch.float32 = object()
sys.modules.setdefault("torch", fake_torch)

import core.gguf_shard_manager as gsm  # noqa: E402

TRANSFORMED = []


class _FakeInfo:
    def __init__(self, name):
        self.name = name
        self.ggml_type = 0
        self.shape = (4, 4)
        self.nbytes = 64
        self.offset = 0


class _Mgr(gsm.GGUFShardManager):
    """Bypass file parsing: exercise only _materialize + transform table."""
    def __init__(self, adapter):
        self.adapter = adapter
        self._load_transforms = dict(
            getattr(adapter, "gguf_load_transforms", dict)() or {})


def _fake_dequant(raw, ggml_type, shape, dtype=None):
    return {"raw": raw}


gsm.dequantize = _fake_dequant


class _LlamaLikeAdapter:
    def gguf_load_transforms(self):
        def mark(t):
            TRANSFORMED.append(True)
            t["permuted"] = True
            return t
        return {"self_attn.q_proj.weight": mark}


class _PlainAdapter:
    pass  # no hook at all — predates it, like the fakes in other probes


m = _Mgr(_LlamaLikeAdapter())
hit = m._materialize("model.layers.3.self_attn.q_proj.weight",
                     b"x", _FakeInfo("blk.3.attn_q.weight"), None)
miss = m._materialize("model.layers.3.self_attn.v_proj.weight",
                      b"x", _FakeInfo("blk.3.attn_v.weight"), None)
check("suffix match applies the transform (any layer index)",
      hit.get("permuted") is True and len(TRANSFORMED) == 1)
check("non-matching key is untouched", "permuted" not in miss)

p = _Mgr(_PlainAdapter())
plain = p._materialize("model.layers.0.self_attn.q_proj.weight",
                       b"x", _FakeInfo("blk.0.attn_q.weight"), None)
check("adapter without the hook declares nothing and nothing changes",
      "permuted" not in plain and p._load_transforms == {})

# ── Verdict ──────────────────────────────────────────────────
print()
if _failures:
    print(f"{len(_failures)} GGUF layout probe(s) FAILED:")
    for f in _failures:
        print(f"  - {f}")
    sys.exit(1)
print("All GGUF layout probes passed.")
