#!/usr/bin/env python3
"""Channel-B speculative-decoding *acceptance-rate* bench (no engine changes).

WHAT THIS MEASURES
------------------
The single number that decides whether external-draft speculative decoding is
worth building: the **acceptance rate alpha** for a (draft, verify) pair — the
probability that the small draft model's greedy next token equals the big
verifier's greedy next token, conditioned on the verifier's own trajectory.

It also reports baseline tokens/sec for each model (so you see the compute cost
ratio) and projects the *idealized* speedup ceiling from alpha.

WHY TEACHER-FORCING (and not a real SD loop)
--------------------------------------------
A production speculative-decode loop needs two things the current streamer does
NOT expose:
  1. all-K-position logits from ONE forward (streamer.forward returns logits for
     the LAST position only — see engine/streamer.py),
  2. KV-cache rollback to discard rejected draft tokens (the cache is append-only).
Rather than build those just to measure payoff, we sidestep both:
  - greedy-decode the verifier to get its token path G (ground truth + baseline speed),
  - run the draft model ALONG G one token at a time (teacher forcing), counting
    how often the draft's greedy prediction matches the verifier's actual next token.
That agreement fraction is exactly the per-token acceptance probability of GREEDY
speculative decoding, and greedy SD reproduces G exactly — so it is lossless by
construction. No rollback, no all-K logits, no engine changes required.

WHAT IT DOES *NOT* MEASURE
--------------------------
Wall-clock SD speedup. The real speedup comes from verifying K tokens in one
sweep, which needs change (1) above. On a RESIDENT, compute-bound verifier the
realized speedup is below the idealized ceiling printed here, because the verify
forward's cost grows with K. Treat the projection as an upper bound that tells
you whether to invest in the engine work — not as a measured result.

USAGE
-----
    python tests/spec_decode_bench.py \
        --verify-model Qwen3.5-4B \
        --draft-model  Qwen3.5-0.8B \
        --n-tokens 128

Model names are directory names under <repo>/models (same as the dashboard).
Run from the repo root (the script adds ./src to sys.path).
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "src"))

import torch  # noqa: E402
from engine.inference import build_engine  # noqa: E402
try:
    from server import load_config as _server_load_config  # the real loader
except Exception:
    _server_load_config = None

MODELS_DIR = REPO / "models"

DEFAULT_PROMPTS = [
    "Summarize the overnight sensor readings and flag anything unusual.",
    "A buoy reports a sudden 3°C sea-surface temperature drop. What might explain it?",
    "List three checks before declaring a station offline.",
]
DEFAULT_SYSTEM = "You are Courier, a terse edge analyst. Answer briefly and precisely."


def _load_cfg(args) -> dict:
    """The live config (server.load_config), with optional CLI overrides overlaid.

    Falls back to factory-like defaults only if server can't be imported, so the
    bench loads models the same way the running system does.
    """
    if _server_load_config is not None:
        cfg = dict(_server_load_config())
        cfg["_source"] = "server.load_config()"
    else:
        cfg = {"max_ram_percent": 80.0, "ram_reserve_gb": 1.0,
               "resident_weights": False, "resident_max_gb": 0.0,
               "_source": "built-in fallback (server import failed)"}
    if args.max_ram_percent is not None:
        cfg["max_ram_percent"] = args.max_ram_percent
    if args.ram_reserve_gb is not None:
        cfg["ram_reserve_gb"] = args.ram_reserve_gb
    if args.resident_max_gb is not None:
        cfg["resident_max_gb"] = args.resident_max_gb
        cfg["resident_weights"] = args.resident_max_gb > 0
    return cfg


def _reset_kv(streamer) -> None:
    """Reset all per-sequence state between prompts. Type-aware and fail-loud.

    HybridStreamer carries recurrent + conv state beyond the KV cache, so its own
    clear_state() is required (kv_cache.clear() alone would leave that state and
    silently corrupt later prompts). Base Streamer exposes kv_cache.clear().
    """
    if hasattr(streamer, "clear_state"):
        streamer.clear_state()
    elif getattr(streamer, "kv_cache", None) is not None:
        streamer.kv_cache.clear()
    else:
        raise RuntimeError(
            "streamer exposes no known state reset (clear_state / kv_cache.clear); "
            "refusing to run, because per-prompt numbers would silently drift.")


def _eos_set(streamer) -> set[int]:
    eos = getattr(streamer.config, "eos_token_id", None)
    if eos is None:
        return set()
    return set(eos) if isinstance(eos, (list, tuple, set)) else {int(eos)}


def _tokenize(streamer, system: str, user: str) -> torch.Tensor:
    tok = streamer.adapter.tokenizer
    messages = [{"role": "system", "content": system},
                {"role": "user", "content": user}]
    try:
        ids = tok.apply_chat_template(
            messages, tokenize=True, add_generation_prompt=True,
            enable_thinking=False, return_tensors="pt",
        )
    except TypeError:
        ids = tok.apply_chat_template(
            messages, tokenize=True, add_generation_prompt=True,
            return_tensors="pt",
        )
    dev = getattr(streamer, "device", "cpu")
    return _as_id_tensor(ids, dev)


def _as_id_tensor(ids, dev) -> torch.Tensor:
    """Coerce apply_chat_template output to a (1, seq) LongTensor.

    Depending on the transformers version it may return a Tensor, a dict-like
    BatchEncoding (use its 'input_ids'), or a plain list of ints.
    """
    if isinstance(ids, torch.Tensor):
        t = ids
    elif hasattr(ids, "input_ids"):          # BatchEncoding / dict-like
        t = ids["input_ids"]
        if not isinstance(t, torch.Tensor):
            t = torch.tensor(t)
    else:                                     # plain list/sequence
        t = torch.tensor(ids)
    if t.dim() == 1:
        t = t.unsqueeze(0)                    # (seq,) -> (1, seq)
    return t.to(dev)


def _last_logits(out: torch.Tensor) -> torch.Tensor:
    """Normalize forward output to (vocab,) for the last position."""
    if out.dim() == 3:      # (batch, seq, vocab)
        out = out[:, -1, :]
    return out[0]           # (vocab,)


def _step(streamer, token_id: int, pos: int) -> torch.Tensor:
    dev = getattr(streamer, "device", "cpu")
    ids = torch.tensor([[token_id]], device=dev)
    return streamer.forward(ids, position_offset=pos)


def verifier_path(streamer, system: str, user: str, n_tokens: int):
    """Greedy-decode the verifier. Returns (G, seconds)."""
    _reset_kv(streamer)
    eos = _eos_set(streamer)
    ids = _tokenize(streamer, system, user)
    pos = ids.shape[1]
    t0 = time.perf_counter()
    logits = _last_logits(streamer.forward(ids, position_offset=0))
    G: list[int] = []
    for _ in range(n_tokens):
        nxt = int(logits.argmax())
        if nxt in eos:
            break
        G.append(nxt)
        logits = _last_logits(_step(streamer, nxt, pos))
        pos += 1
    return G, time.perf_counter() - t0


def draft_agreement(streamer, system: str, user: str, G: list[int]):
    """Teacher-force the draft along G. Returns (agreements, count, seconds)."""
    _reset_kv(streamer)
    ids = _tokenize(streamer, system, user)
    pos = ids.shape[1]
    t0 = time.perf_counter()
    logits = _last_logits(streamer.forward(ids, position_offset=0))
    agree = 0
    for g in G:
        if int(logits.argmax()) == g:
            agree += 1
        logits = _last_logits(_step(streamer, g, pos))  # advance along the TRUE path
        pos += 1
    return agree, len(G), time.perf_counter() - t0


def projected_ceiling(alpha: float, k: int) -> float:
    """Idealized expected tokens per verify block for greedy SD, block size k.

    E[accepted + 1 bonus] = (1 - alpha^(k+1)) / (1 - alpha). This is the
    throughput multiplier in the IO-bound limit where one sweep verifies k
    tokens; it is an UPPER BOUND for a resident/compute-bound verifier.
    """
    if alpha >= 1.0:
        return float(k + 1)
    return (1.0 - alpha ** (k + 1)) / (1.0 - alpha)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--verify-model", required=True, help="dir under models/ (big)")
    ap.add_argument("--draft-model", required=True, help="dir under models/ (small)")
    ap.add_argument("--n-tokens", type=int, default=128)
    ap.add_argument("--max-ram-percent", type=float, default=None,
                    help="override server.load_config()")
    ap.add_argument("--ram-reserve-gb", type=float, default=None,
                    help="override server.load_config()")
    ap.add_argument("--resident-max-gb", type=float, default=None,
                    help="explicit resident cap override; >0 pins, 0 derives from %%RAM")
    ap.add_argument("--prompt", action="append", help="repeatable; overrides defaults")
    args = ap.parse_args()

    prompts = args.prompt or DEFAULT_PROMPTS
    cfg = _load_cfg(args)
    print(f"Config source: {cfg.get('_source')}  "
          f"(max_ram%={cfg.get('max_ram_percent')}, resident_max_gb={cfg.get('resident_max_gb')})")

    vpath = MODELS_DIR / args.verify_model
    dpath = MODELS_DIR / args.draft_model
    for p in (vpath, dpath):
        if not p.exists():
            print(f"ERROR: model dir not found: {p}", file=sys.stderr)
            return 2

    print(f"Loading verifier: {vpath.name}")
    verify_streamer, _ = build_engine(str(vpath), config=cfg)
    print(f"Loading draft:    {dpath.name}")
    draft_streamer, _ = build_engine(str(dpath), config=cfg)

    # Fail loud NOW if either streamer can't be reset, before any long decode.
    for _s in (verify_streamer, draft_streamer):
        _reset_kv(_s)

    # Same-family guard: tokenizers must match for draft tokens to map onto the verifier.
    if verify_streamer.adapter.tokenizer.vocab_size != draft_streamer.adapter.tokenizer.vocab_size:
        print("WARNING: vocab sizes differ — draft and verify are likely not same-family; "
              "acceptance numbers below are meaningless.", file=sys.stderr)

    tot_agree = tot = 0
    v_tok = v_sec = d_sec = 0.0
    print()
    print(f"{'prompt':<40} {'tokens':>7} {'alpha':>7}")
    print("-" * 58)
    for user in prompts:
        G, vs = verifier_path(verify_streamer, DEFAULT_SYSTEM, user, args.n_tokens)
        if not G:
            print(f"{user[:38]:<40} {0:>7} {'--':>7}  (no tokens)")
            continue
        agree, n, ds = draft_agreement(draft_streamer, DEFAULT_SYSTEM, user, G)
        tot_agree += agree
        tot += n
        v_tok += len(G)
        v_sec += vs
        d_sec += ds
        print(f"{user[:38]:<40} {n:>7} {agree / n:>7.3f}")

    if tot == 0:
        print("\nNo tokens generated; cannot compute alpha.")
        return 1

    alpha = tot_agree / tot
    print("-" * 58)
    print(f"\nOverall acceptance alpha = {alpha:.3f}  (over {tot} tokens)")
    print(f"Verifier baseline : {v_tok / v_sec:6.2f} tok/s   ({args.verify_model})")
    print(f"Draft forward     : {tot / d_sec:6.2f} tok/s   ({args.draft_model})")
    print(f"Draft/verify speed ratio ~ {(v_tok / v_sec) / (tot / d_sec):.2f}x slower verifier")
    print("\nIdealized speedup ceiling (upper bound; real value lower when resident):")
    print(f"  {'block K':>8} {'E[tokens/sweep]':>18}")
    for k in (1, 2, 3, 4, 6):
        print(f"  {k:>8} {projected_ceiling(alpha, k):>18.3f}")
    print("\nNotes:")
    print("  * Greedy SD reproduces the verifier's path exactly — lossless by construction.")
    print("  * Realizing any speedup needs (1) all-K logits in one forward and")
    print("    (2) KV rollback. This bench gauges payoff (alpha) before that work.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
