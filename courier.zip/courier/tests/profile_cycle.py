#!/usr/bin/env python3
"""Performance profiler — the instrumented cycle (handoff §6 Step 0).

MEASURE FIRST. The project has asserted "prefill is compute-bound, streaming is
I/O-bound" but never measured it. This script runs ONE real multimodal cycle on
THIS machine with the engine's phase profiler enabled and prints where the
wall-clock time actually goes:

    disk_read     — streaming LLM layer weights off disk (+ dequant + move)
    vision_encode — ViT COMPUTE (matmul/attention; scales with image resolution)
    vision_disk   — ViT weight loading (fixed per image, independent of res)
    sampling      — token sampling in the decode loop
    (unattributed)— pure LLM matmul/attention/norm compute + overhead
                    i.e. the LLM "compute" bucket, by subtraction

    plus a prefill-vs-decode wall split.

That profile dictates the optimization order. Likely contenders (handoff §6):
threading / BLAS backend (free, possibly huge), resident-RAM (kills disk_read),
INT4 (bandwidth), prefill caching. Optimize the phase that dominates HERE, not
the one we guessed.

This needs the real model (torch + weights), so run it in the Codespace, NOT in
the cold sandbox. It is NOT a unit test — run directly:

    cd courier
    python tests/profile_cycle.py                       # auto-find model + image
    python tests/profile_cycle.py models/Qwen3.5-4B-int8 image-src/Neolithic_era.jpeg
    python tests/profile_cycle.py --max-new-tokens 24   # shorter decode sample

Flags:
    --max-new-tokens N   tokens to decode for the sample (default 32). Decode is
                         per-token, so the decode wall scales with this; a small
                         N still reveals the per-token cost and the split.
    --text-only          skip the image (profile a pure-text cycle for contrast)

Paste the whole PHASE PROFILE block back.
"""

import sys
import time
import traceback
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "src"))

LINE = "=" * 68


def _flag(argv, name, default=None, cast=str):
    for i, a in enumerate(argv):
        if a == name and i + 1 < len(argv):
            return cast(argv[i + 1])
        if a.startswith(name + "="):
            return cast(a.split("=", 1)[1])
    return default


# Flags that consume the following token as their value. Their values must NOT
# be treated as positional (model/image) args — otherwise
# `--max-new-tokens 64` makes `64` look like a model path.
_VALUE_FLAGS = {"--max-new-tokens", "--threads", "--resident-max-gb",
                "--max-pixels"}


def _positionals(argv):
    """argv positionals, skipping flags and any value-taking flag's value."""
    pos = []
    skip_next = False
    for a in argv[1:]:
        if skip_next:
            skip_next = False
            continue
        if a.startswith("--"):
            if a in _VALUE_FLAGS and "=" not in a:
                skip_next = True   # the next token is this flag's value
            continue
        pos.append(a)
    return pos


def _find_model(argv):
    pos = _positionals(argv)
    if pos:
        p = Path(pos[0])
        return p if p.exists() else None
    for cand in ("models/Qwen3.5-4B-int8", "models/Qwen3.5-4B"):
        p = REPO / cand
        if p.exists():
            return p
    return None


def _find_image(argv):
    pos = _positionals(argv)
    if len(pos) > 1:
        p = Path(pos[1])
        return p if p.exists() else None
    exts = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}
    for d in ("image-src", "data"):
        dd = REPO / d
        if dd.exists():
            for f in sorted(dd.iterdir()):
                if f.suffix.lower() in exts:
                    return f
    return None


def _load_config():
    import json
    for cand in ("courier_config.json", "config/courier_config.json"):
        p = REPO / cand
        if p.exists():
            try:
                cfg = json.loads(p.read_text())
                cfg.setdefault("temperature", 0.3)
                cfg.setdefault("top_p", 0.9)
                cfg.setdefault("max_new_tokens", 64)
                return cfg
            except Exception:
                pass
    return {"temperature": 0.3, "top_p": 0.9, "max_new_tokens": 64,
            "presence_penalty": 2.0, "enable_thinking": False}


def main():
    argv = sys.argv
    max_new = _flag(argv, "--max-new-tokens", 32, int)
    text_only = "--text-only" in argv
    threads = _flag(argv, "--threads", None, int)
    greedy = "--greedy" in argv
    resident = "--resident" in argv
    resident_max_gb = _flag(argv, "--resident-max-gb", 0, float)
    max_pixels = _flag(argv, "--max-pixels", None, int)

    # Thread overrides must be set BEFORE torch is imported anywhere for OMP to
    # take full effect. profile_cycle imports torch lazily (in the diagnostic
    # and build_engine), so setting these here is early enough.
    if threads is not None:
        import os as _os0
        _os0.environ["OMP_NUM_THREADS"] = str(threads)
        _os0.environ["MKL_NUM_THREADS"] = str(threads)

    print(LINE)
    print("COURIER PERFORMANCE PROFILE — instrumented cycle (§6 Step 0)")
    print(LINE)

    model_dir = _find_model(argv)
    image_path = None if text_only else _find_image(argv)
    print(f"Model:          {model_dir}")
    print(f"Image:          {image_path if not text_only else '(text-only run)'}")
    print(f"Decode tokens:  {max_new}")
    print(f"Threads:        {threads if threads is not None else '(default)'}")
    print(f"Decode mode:    {'greedy (deterministic)' if greedy else 'sampling'}")
    print(f"Weights:        {'RESIDENT' + (f' (cap {resident_max_gb}GB)' if resident_max_gb else '') if resident else 'streaming (default)'}")
    if max_pixels is not None:
        print(f"Max pixels:     {max_pixels:,} (vision resolution budget; "
              f"default ~{1280*28*28:,})")
    if model_dir is None:
        print("\nFATAL: no model directory found. Pass one explicitly:")
        print("  python tests/profile_cycle.py <model_dir> [<image>]")
        return 1
    if not text_only and image_path is None:
        print("\nNote: no image found; profiling a TEXT-ONLY cycle "
              "(vision_encode will be ~0).")

    # Enable profiling for this process BEFORE building the engine.
    from engine.profiler import PROFILER
    PROFILER.enable()

    # Apply the intra-op thread override now that torch is about to be used.
    if threads is not None:
        import torch as _torch0
        _torch0.set_num_threads(threads)

    # ── Machine / threading / BLAS diagnostic (levers #1 and #2, §6) ─────
    # This is measurement, not a change: it shows whether matmuls can use all
    # cores and whether torch routes through an optimized BLAS. If threads are
    # idle or BLAS is a reference path, those are the cheapest wins — but only
    # if the profile below shows compute (not disk) dominates.
    try:
        import os as _os
        import torch as _torch
        print("\nMACHINE / THREADING / BLAS")
        print("-" * 68)
        print(f"  logical CPUs (os.cpu_count): {_os.cpu_count()}")
        print(f"  torch.get_num_threads():     {_torch.get_num_threads()}  "
              f"(intra-op / matmul parallelism)")
        try:
            print(f"  torch.get_num_interop_threads(): "
                  f"{_torch.get_num_interop_threads()}")
        except Exception:
            pass
        for var in ("OMP_NUM_THREADS", "MKL_NUM_THREADS",
                    "OPENBLAS_NUM_THREADS"):
            print(f"  ${var} = {_os.environ.get(var, '(unset)')}")
        # BLAS / build info — look for MKL vs OpenBLAS and AVX flags.
        cfg_str = ""
        try:
            cfg_str = _torch.__config__.show()
        except Exception:
            pass
        flags = [tok for tok in ("MKL", "OpenBLAS", "blas", "AVX2", "AVX512")
                 if tok.lower() in cfg_str.lower()]
        print(f"  torch BLAS/build hints: {', '.join(flags) or '(none found)'}")
        if _torch.get_num_threads() < (_os.cpu_count() or 1):
            print("  >> threads < CPUs: matmuls may be leaving cores idle. If the\n"
                  "     profile shows compute-bound, try torch.set_num_threads("
                  f"{_os.cpu_count()}) /\n"
                  "     OMP_NUM_THREADS before launch (verify it changes the split).")
        print("-" * 68)
    except Exception:
        print("  (threading/BLAS diagnostic unavailable)")

    try:
        from engine.inference import build_engine
        cfg = _load_config()
        cfg["max_new_tokens"] = max_new        # bound the decode sample
        cfg["resident_weights"] = resident     # opt-in resident-RAM mode
        cfg["resident_max_gb"] = resident_max_gb
        print("\nBuilding engine (this loads embeddings / vision weights)...")
        t_build = time.perf_counter()
        streamer, infer_fn = build_engine(str(model_dir), cfg, dtype="bfloat16")
        print(f"  build_engine: {time.perf_counter() - t_build:.1f}s")
    except Exception:
        print("\nFATAL: build_engine failed:")
        traceback.print_exc()
        return 1

    prompt = ("You are a field analyst. Describe what you observe in the "
              "image: terrain, vegetation, structures, and any notable "
              "features. Be precise and factual. Keep it under 125 words.")
    if text_only:
        prompt = ("You are a field analyst. In under 125 words, summarize the "
                  "standard procedure for documenting a remote monitoring site.")

    kwargs = {}
    if image_path is not None:
        kwargs["image_paths"] = [str(image_path)]
    if greedy:
        # top_k=1 -> argmax every step: deterministic regardless of temperature,
        # so two runs (e.g. --threads 2 vs --threads 4) can be diffed to verify
        # a threading change preserves output, not just speed (§6 non-negotiable).
        kwargs["top_k"] = 1
    if max_pixels is not None:
        kwargs["max_pixels"] = max_pixels

    # Reset the profiler so the report covers ONLY the cycle (not the build),
    # then run a single real inference through the same infer_fn the worker uses.
    print("\nRunning one cycle (prefill + decode). This is the slow part —\n"
          "expect minutes on CPU. The profiler is recording...\n")
    PROFILER.reset()
    t_cycle = time.perf_counter()
    try:
        output = infer_fn(prompt, max_new_tokens=max_new, **kwargs)
    except Exception:
        print("FATAL: inference failed:")
        traceback.print_exc()
        return 1
    cycle_wall = time.perf_counter() - t_cycle

    snap = PROFILER.snapshot()
    print("\n" + PROFILER.report())

    # Resident-cache telemetry: how much RAM it pinned and whether re-reads
    # were actually eliminated (raw_reads should be ~one set of weights, not
    # one-set-per-forward, when resident is on and fits).
    try:
        cs = streamer.shards.cache_stats()
        if cs.get("resident"):
            gb = cs["resident_bytes"] / (1024 ** 3)
            print(f"\nRESIDENT CACHE: {cs['layers_cached']} layers + "
                  f"{cs['misc_cached']} misc pinned, {gb:.2f} GB RAM, "
                  f"{cs['raw_reads']:,} underlying reads this run")
        else:
            print(f"\n(streaming mode: {cs.get('raw_reads', 0):,} underlying "
                  f"reads this run — re-read every forward)")
    except Exception:
        pass

    # ── Derived guidance ─────────────────────────────────────────────────
    excl = snap["exclusive"]
    marks = snap["marks"]
    wall = snap["wall_total"] or cycle_wall
    disk = excl.get("disk_read", 0.0)
    vision_c = excl.get("vision_encode", 0.0)   # ViT compute (loads excluded)
    vision_d = excl.get("vision_disk", 0.0)     # ViT weight loading
    sampling = excl.get("sampling", 0.0)
    compute = max(0.0, wall - disk - vision_c - vision_d - sampling)
    pre = marks.get("wall_prefill", 0.0)
    dec = marks.get("wall_decode", 0.0)

    def pct(x):
        return f"{(100.0 * x / wall):.0f}%" if wall else "n/a"

    print("\nINTERPRETATION")
    print("-" * 68)
    print(f"  llm disk_read   {disk:8.1f}s  ({pct(disk)})  LLM layer streaming I/O + dequant")
    print(f"  llm compute     {compute:8.1f}s  ({pct(compute)})  matmul/attention/norms")
    print(f"  vision compute  {vision_c:8.1f}s  ({pct(vision_c)})  ViT matmul (SCALES WITH RESOLUTION)")
    print(f"  vision disk     {vision_d:8.1f}s  ({pct(vision_d)})  ViT weight loading (fixed per image)")
    print(f"  sampling        {sampling:8.1f}s  ({pct(sampling)})")
    print(f"  prefill wall    {pre:8.1f}s   |  decode wall {dec:8.1f}s")
    if max_new > 1 and dec > 0:
        print(f"  ~per-decode-token: {dec / max(1, max_new):.2f}s "
              f"(over {max_new} tokens)")
    print("-" * 68)

    # Order-of-attack hint, strictly from the measured split.
    ranked = sorted(
        [("llm disk_read   (-> resident-RAM MODE w/ streaming fallback; INT4)", disk),
         ("llm compute     (-> threading; INT4)  [BLAS already MKL/AVX2]", compute),
         ("vision compute  (-> lower capture resolution; ViT threading)", vision_c),
         ("vision disk     (-> resident ViT weights; one-shot per image)", vision_d),
         ("sampling        (-> minor)", sampling)],
        key=lambda kv: kv[1], reverse=True)
    print("ATTACK ORDER (by measured payoff on THIS run):")
    for i, (label, sec) in enumerate(ranked, 1):
        print(f"  {i}. {label:<58} {sec:6.1f}s  {pct(sec)}")
    print("-" * 68)
    print("Reading the split:\n"
          "  * 'vision compute' high  -> capture-resolution triage is a FREE win\n"
          "    (fewer patches = proportionally less ViT). 'vision disk' high\n"
          "    instead -> resolution won't help; resident ViT weights would.\n"
          "  * disk_read is layer streaming (a feature for low-RAM boxes). The\n"
          "    lever is resident-RAM MODE: load+dequant once, pin when RAM\n"
          "    allows, fall back to streaming when it doesn't. Streaming stays.\n"
          "  * Compare --threads 2 vs --threads 4 (add --greedy) to measure the\n"
          "    free threading win AND confirm identical output.")
    print(f"\nOutput preview: {output[:160]!r}")
    print(LINE)
    return 0


if __name__ == "__main__":
    sys.exit(main())
