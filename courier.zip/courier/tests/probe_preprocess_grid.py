#!/usr/bin/env python3
"""Probe: image preprocessing always yields a patch grid spatial_merge can fold.

spatial_merge folds the ViT patch grid in merge_size x merge_size blocks via a
.view() that REQUIRES the patch count per side to be divisible by merge_size.
At --max-pixels 400000 the old rounding produced a 39x39 grid (odd) and crashed:
  RuntimeError: shape '[1,1,19,2,19,2,1024]' invalid for input of size 1557504
This probe exercises the real _fit_image_grid across a sweep of budgets and
aspect ratios and asserts the grid is always merge-divisible and within budget —
so the capture-resolution lever is safe at ANY budget.

Pure-math helper; torch/safetensors are stubbed only so vision.py imports cold.

    cd courier
    python tests/probe_preprocess_grid.py
"""
import sys
import types
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "src"))

# Stub torch (+ nn.functional) and safetensors so vision.py imports without the
# real deps. _fit_image_grid itself uses only `math`.
if "torch" not in sys.modules:
    torch = types.ModuleType("torch")
    torch.Tensor = object
    torch.dtype = object
    torch.bfloat16 = "bf16"
    torch.int8 = "int8"
    nn = types.ModuleType("torch.nn")
    functional = types.ModuleType("torch.nn.functional")
    for _act in ("gelu", "relu", "silu", "softmax"):
        setattr(functional, _act, lambda *a, **k: None)
    nn.functional = functional
    torch.nn = nn
    sys.modules["torch"] = torch
    sys.modules["torch.nn"] = nn
    sys.modules["torch.nn.functional"] = functional
if "safetensors" not in sys.modules:
    st = types.ModuleType("safetensors")
    st.safe_open = lambda *a, **k: None
    sys.modules["safetensors"] = st

from engine.vision import _fit_image_grid     # noqa: E402  (real function)

_fails = []


def check(label, cond):
    print(f"  [{'PASS' if cond else 'FAIL'}] {label}")
    if not cond:
        _fails.append(label)


def main():
    print("=" * 64)
    print("PREPROCESS GRID PROBE — merge-divisible, within budget")
    print("=" * 64)

    PATCH, MERGE = 16, 2
    MINP = 4 * 28 * 28
    block = PATCH * MERGE

    # The exact case that crashed before the fix.
    print("\n[1] Regression: --max-pixels 400000 on a ~square image")
    w, h, hp, wp = _fit_image_grid(1024, 1024, PATCH, MERGE, 400000, MINP)
    print(f"  -> {w}x{h} px, grid {hp}x{wp} patches")
    check("h_patches divisible by merge_size", hp % MERGE == 0)
    check("w_patches divisible by merge_size", wp % MERGE == 0)
    check("within max_pixels budget", w * h <= 400000)

    # Sweep budgets x aspect ratios; every result must be foldable + in budget.
    print("\n[2] Sweep of budgets x aspect ratios")
    budgets = [50_000, 100_000, 150_000, 250_000, 400_000, 600_000,
               1280 * 28 * 28]
    shapes = [(1024, 1024), (1920, 1080), (640, 480), (1000, 1500),
              (4032, 3024), (320, 240), (37, 41)]
    bad = []
    for mp in budgets:
        for (W, H) in shapes:
            w, h, hp, wp = _fit_image_grid(W, H, PATCH, MERGE, mp, MINP)
            if hp % MERGE or wp % MERGE:
                bad.append((mp, W, H, hp, wp, "odd grid"))
            if w * h > mp and (W * H) > mp:
                bad.append((mp, W, H, hp, wp, "over budget"))
            if hp < 1 or wp < 1:
                bad.append((mp, W, H, hp, wp, "empty grid"))
    check(f"all {len(budgets)*len(shapes)} (budget x shape) cases foldable, "
          f"in-budget, non-empty", not bad)
    if bad:
        for b in bad[:8]:
            print(f"    BAD: {b}")

    # Default budget must be unchanged by the fix (was already even at 62x62-ish).
    print("\n[3] Default budget still lands on the same even grid")
    w, h, hp, wp = _fit_image_grid(1024, 1024, PATCH, MERGE, 1280 * 28 * 28, MINP)
    print(f"  -> {w}x{h} px, grid {hp}x{wp} patches (multiple of {block})")
    check("default dims are a multiple of patch_size*merge_size",
          w % block == 0 and h % block == 0)

    print("\n" + "=" * 64)
    if _fails:
        print(f"RESULT: {len(_fails)} FAILED -> {_fails}")
        return 1
    print("RESULT: ALL CHECKS PASS")
    print("Any --max-pixels budget now yields a foldable grid, so capture-\n"
          "resolution triage (the biggest free lever for image cycles) is safe\n"
          "to dial down. Re-run: python tests/profile_cycle.py --max-pixels 400000")
    print("=" * 64)
    return 0


if __name__ == "__main__":
    sys.exit(main())
