"""Phase 0 acceptance test — scaffold verification.

Tests:
  1. The courier package is importable and has a version string
  2. All subpackages are importable
  3. If the model is downloaded, verify shard is openable and
     embedding tensor shape matches config.json
"""

import json
import sys
from pathlib import Path

import pytest

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

MODEL_PATH = Path(__file__).parent.parent / "models" / "Qwen3-0.6B"


class TestPackageStructure:
    """Verify the courier package is importable."""

    def test_import_courier(self):
        import src
        assert hasattr(src, "__version__")
        assert src.__version__ == "0.2.7"

    def test_import_engine(self):
        import src.engine
        assert src.engine is not None

    def test_import_core(self):
        import src.core
        assert src.core is not None

    def test_import_adapter(self):
        import src.core.adapter
        assert src.core.adapter is not None

    def test_import_data(self):
        import src.data
        assert src.data is not None


class TestDirectoryStructure:
    """Verify all required directories exist."""

    BASE = Path(__file__).parent.parent

    def test_src_exists(self):
        assert (self.BASE / "src").is_dir()

    def test_static_exists(self):
        assert (self.BASE / "static").is_dir()

    def test_models_exists(self):
        assert (self.BASE / "models").is_dir()

    def test_templates_exists(self):
        assert (self.BASE / "templates").is_dir()

    def test_data_exists(self):
        assert (self.BASE / "data").is_dir()

    def test_export_exists(self):
        assert (self.BASE / "export").is_dir()

    def test_scripts_exists(self):
        assert (self.BASE / "scripts").is_dir()

    def test_dashboard_exists(self):
        dashboard = self.BASE / "static" / "dashboard.html"
        assert dashboard.exists(), "Production dashboard not found"

    def test_dashboard_dev_exists(self):
        dashboard = self.BASE / "static" / "dashboard-dev.html"
        assert dashboard.exists(), "Development dashboard not found"

    def test_requirements_exists(self):
        assert (self.BASE / "requirements.txt").exists()


class TestModelVerification:
    """Verify the model is downloaded and loadable.

    These tests are skipped if the model is not present.
    Run scripts/download_model.py first.
    """

    @pytest.fixture(autouse=True)
    def check_model_present(self):
        if not MODEL_PATH.exists():
            pytest.skip(
                f"Model not found at {MODEL_PATH}. "
                f"Run: python scripts/download_model.py"
            )

    def test_config_exists(self):
        config_path = MODEL_PATH / "config.json"
        assert config_path.exists()

    def test_config_valid(self):
        config = json.load(open(MODEL_PATH / "config.json"))
        assert config["model_type"] == "qwen3"
        assert config["num_hidden_layers"] == 28
        assert config["hidden_size"] == 1024
        assert config["vocab_size"] == 151936
        assert config["num_attention_heads"] == 16
        assert config["num_key_value_heads"] == 8
        assert config["head_dim"] == 128
        assert config["tie_word_embeddings"] is True

    def test_safetensor_exists(self):
        shards = list(MODEL_PATH.glob("*.safetensors"))
        assert len(shards) >= 1, "No safetensor shards found"

    def test_embedding_shape(self):
        from safetensors import safe_open

        config = json.load(open(MODEL_PATH / "config.json"))
        shard = list(MODEL_PATH.glob("*.safetensors"))[0]

        with safe_open(str(shard), framework="pt") as f:
            embed = f.get_tensor("model.embed_tokens.weight")
            assert tuple(embed.shape) == (
                config["vocab_size"],
                config["hidden_size"],
            ), f"Embedding shape mismatch: {embed.shape}"

    def test_qk_norm_present(self):
        """Verify Qwen3-specific QK-LayerNorm exists."""
        from safetensors import safe_open

        config = json.load(open(MODEL_PATH / "config.json"))
        shard = list(MODEL_PATH.glob("*.safetensors"))[0]

        with safe_open(str(shard), framework="pt") as f:
            q_norm = f.get_tensor("model.layers.0.self_attn.q_norm.weight")
            assert tuple(q_norm.shape) == (config["head_dim"],)

    def test_all_layers_present(self):
        from safetensors import safe_open

        config = json.load(open(MODEL_PATH / "config.json"))
        shard = list(MODEL_PATH.glob("*.safetensors"))[0]
        n_layers = config["num_hidden_layers"]

        with safe_open(str(shard), framework="pt") as f:
            keys = f.keys()
            for i in range(n_layers):
                key = f"model.layers.{i}.input_layernorm.weight"
                assert key in keys, f"Layer {i} missing from shard"

    def test_tied_embeddings(self):
        """Verify embed_tokens.weight exists (used as lm_head when tied)."""
        from safetensors import safe_open

        shard = list(MODEL_PATH.glob("*.safetensors"))[0]

        with safe_open(str(shard), framework="pt") as f:
            assert "model.embed_tokens.weight" in f.keys(), \
                "embed_tokens.weight must exist for tied embedding inference"
