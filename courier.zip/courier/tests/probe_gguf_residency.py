#!/usr/bin/env python3
"""Probe: GGUF two-tier PIN residency (performance spec §3–§4, Phases 1–2).

The decode loop reads layers 0..N-1 cyclically every token. The old LRU cache
scored exactly 0% hits whenever budget < model (the wrap-around access always
landed on the just-evicted layer). This probe proves, cold, that the revised
GGUFShardManager:

  1. pins first-touch and NEVER evicts (tier 1 and tier 2);
  2. achieves the C/N hit profile: every resident layer is read from disk
     EXACTLY once for the whole run, non-resident layers stream every token;
  3. keeps the one-tier-ownership invariant (tensors in tier 1 XOR bytes in
     tier 2, never both, never double-counted);
  4. serves tier-2 hits by dequantizing from RAM (no disk read), and the
     result is byte-identical to a fresh disk load;
  5. applies the second-access rule for hot non-layer tensors: first direct
     get_tensor() read is free, the second pins the bytes (the streamed LM
     head), so load-once tensors never spend budget;
  6. respects both byte budgets exactly and reports honest cache_stats,
     including the ShardManager-compatible aliases the dashboard reads.

It exercises the REAL GGUFShardManager code. torch isn't in the cold sandbox
and no .gguf file exists here, so the I/O leaves are stubbed (fake header,
fake file, fake dequantize that tags its inputs); the cache logic under test
is the real code, in the style of probe_resident_cache.py.

    cd courier
    python tests/probe_gguf_residency.py
"""
import io
import sys
import types
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "src"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

# ── Stub torch (only annotations + dtype sentinels are touched here) ────────
if "torch" not in sys.modules:
    torch = types.ModuleType("torch")
    torch.bfloat16 = "bf16"
    torch.float32 = "fp32"
    torch.Tensor = object
    torch.dtype = object
    sys.modules["torch"] = torch

from _probe_util import Probe  # noqa: E402

# ── Stub the dequantize kernel BEFORE importing the shard manager ───────────
# The real dequantize needs numpy+torch. The fake returns an object that
# records (raw, ggml_type, shape, dtype) so identity and byte-equality checks
# are possible, and reports nbytes like a tensor for tier-1 accounting.
import core.dequantize as _dq  # noqa: E402

DEQUANT_CALLS = {"n": 0}


class FakeTensor:
    def __init__(self, raw, ggml_type, shape, dtype):
        self.raw = bytes(raw)
        self.ggml_type = ggml_type
        self.shape = shape
        self.dtype = dtype

    # tier-1 accounting reads these; pretend dequant is 4x the raw bytes
    def nelement(self):
        return len(self.raw)

    def element_size(self):
        return 4

    def __eq__(self, other):
        return isinstance(other, FakeTensor) and self.raw == other.raw

    def __hash__(self):
        return hash(self.raw)


def fake_dequantize(raw, ggml_type, shape, dtype=None):
    DEQUANT_CALLS["n"] += 1
    return FakeTensor(raw, ggml_type, shape, dtype)


_dq.dequantize = fake_dequantize

import core.gguf_shard_manager as gsm  # noqa: E402

gsm.dequantize = fake_dequantize  # the module imported the name directly

# ── Fake GGUF plumbing ───────────────────────────────────────────────────────
N_LAYERS = 6
ROLES = ("q_proj", "k_proj")
LAYER_TENSOR_BYTES = 100          # raw bytes per tensor
LAYER_RAW_BYTES = LAYER_TENSOR_BYTES * len(ROLES)   # 200 raw bytes per layer
LAYER_T1_BYTES = LAYER_RAW_BYTES * 4                # fake dequant = 4x raw

DISK_READS = {"n": 0, "keys": []}


class FakeInfo:
    def __init__(self, key, nbytes, offset):
        self.name = key
        self.ggml_type = 12          # Q4_K, arbitrary
        self.shape = (10, 10)
        self.nbytes = nbytes
        self.offset = offset


class FakeAdapter:
    def layer_weight_keys(self, i):
        return {r: f"model.layers.{i}.{r}.weight" for r in ROLES}

    def embedding_key(self):
        return "model.embed_tokens.weight"

    def final_norm_key(self):
        return "model.norm.weight"

    def lm_head_key(self):
        return "lm_head.weight"


def build_manager(cache_mb_bytes, qcache_mb_bytes):
    """Construct a real GGUFShardManager with all I/O leaves faked out."""
    m = object.__new__(gsm.GGUFShardManager)
    m.gguf_path = Path("/fake/model.gguf")
    m.adapter = FakeAdapter()
    m._file = io.BytesIO(b"")

    # Tensor index: layer tensors + embedding + lm_head, each with unique raw
    # bytes so identity is checkable.
    m._hf_to_info = {}
    m._raw_store = {}
    off = 0
    keys = []
    for i in range(N_LAYERS):
        for r in ROLES:
            keys.append((f"model.layers.{i}.{r}.weight", LAYER_TENSOR_BYTES))
    keys.append(("model.embed_tokens.weight", 300))
    keys.append(("lm_head.weight", 250))
    for key, nb in keys:
        m._hf_to_info[key] = FakeInfo(key, nb, off)
        m._raw_store[key] = bytes([hash(key) % 251] ) * nb
        off += nb
    m._gguf_to_hf = {}

    # Intercept disk reads
    def _read_raw(info):
        DISK_READS["n"] += 1
        DISK_READS["keys"].append(info.name)
        return m._raw_store[info.name]

    m._read_raw = _read_raw

    # Real cache state, exactly as __init__ builds it
    from collections import OrderedDict
    # Layout transforms: __init__ reads adapter.gguf_load_transforms
    # (default none). The fake adapter declares none — this probe pins
    # residency, not layout; probe_gguf_layout.py pins the transforms.
    m._load_transforms = dict(
        getattr(m.adapter, "gguf_load_transforms", dict)() or {})
    m._cache_budget_bytes = cache_mb_bytes
    m._layer_cache = OrderedDict()
    m._cache_bytes = 0
    m._cache_hits = 0
    m._cache_misses = 0
    m._qcache_budget_bytes = qcache_mb_bytes
    m._qcache = {}
    m._qcache_bytes = 0
    m._qcache_hits = 0
    m._misc_qcache = {}
    m._misc_seen = set()
    m._misc_qhits = 0
    return m


p = Probe("GGUF two-tier PIN residency")

# ─────────────────────────────────────────────────────────────────────────────
p.section("1) PIN policy: budget for 2 tier-1 layers + 2 tier-2 layers, 6-layer model")
# tier 1 holds exactly 2 layers of fake-dequant bytes; tier 2 exactly 2 of raw
m = build_manager(cache_mb_bytes=2 * LAYER_T1_BYTES,
                  qcache_mb_bytes=2 * LAYER_RAW_BYTES)
TOKENS = 10
for _tok in range(TOKENS):
    for layer in range(N_LAYERS):
        m.load_layer(layer, dtype="bf16")

s = m.cache_stats()
p.check("tier 1 pinned exactly 2 layers", s["cached_layers"] == 2)
p.check("tier 1 pinned layers are 0 and 1 (first-touch order)",
        sorted(m._layer_cache.keys()) == [0, 1])
p.check("tier 2 pinned exactly 2 layers", s["qcached_layers"] == 2)
p.check("tier 2 pinned layers are 2 and 3", sorted(m._qcache.keys()) == [2, 3])
p.check("no layer lives in both tiers",
        not (set(m._layer_cache) & set(m._qcache)))

# C/N read profile: resident layers read from disk once ever; streamed layers
# read every token. Reads counted per-tensor: 2 tensors per layer.
expected_reads = (4 * len(ROLES)                       # layers 0-3: once each
                  + 2 * len(ROLES) * TOKENS)           # layers 4-5: every token
p.check(f"disk reads match C/N profile ({expected_reads})",
        DISK_READS["n"] == expected_reads)
p.check("tier-1 hit rate = (2/6 of post-warmup reads)",
        s["hits"] == 2 * (TOKENS - 1))
p.check("tier-2 hits = 2 layers x (tokens-1)", s["qhits"] == 2 * (TOKENS - 1))

# ─────────────────────────────────────────────────────────────────────────────
p.section("2) No eviction, budgets exact")
p.check("tier 1 bytes == exactly 2 layers, never exceeded",
        m._cache_bytes == 2 * LAYER_T1_BYTES)
p.check("tier 2 bytes == exactly 2 layers, never exceeded",
        m._qcache_bytes == 2 * LAYER_RAW_BYTES)
before = dict(m._layer_cache)
for _ in range(3):
    for layer in range(N_LAYERS):
        m.load_layer(layer, dtype="bf16")
p.check("resident set unchanged after 3 more full sweeps (no churn)",
        dict(m._layer_cache) == before and sorted(m._qcache) == [2, 3])

# ─────────────────────────────────────────────────────────────────────────────
p.section("3) Correctness: tier-2 hit is byte-identical to a disk load")
fresh = build_manager(cache_mb_bytes=0, qcache_mb_bytes=0)
fresh_l2 = fresh.load_layer(2, dtype="bf16")     # pure streaming load
cached_l2 = m.load_layer(2, dtype="bf16")        # tier-2 hit in warmed manager
p.check("tier-2-served tensors byte-equal streamed tensors",
        all(cached_l2[r] == fresh_l2[r] for r in ROLES))
p.check("tier-1 hit returns a fresh dict (caller can't mutate the cache)",
        m.load_layer(0, dtype="bf16") is not m._layer_cache[0])
p.check("tier-1 hit shares the cached tensors (no copy of data)",
        m.load_layer(0, dtype="bf16")["q_proj"] is m._layer_cache[0]["q_proj"])

# ─────────────────────────────────────────────────────────────────────────────
p.section("4) Second-access rule for hot non-layer tensors")
m2 = build_manager(cache_mb_bytes=0, qcache_mb_bytes=10_000)
r0 = DISK_READS["n"]
m2.get_tensor("model.embed_tokens.weight", dtype="bf16")   # load-once: 1st read
p.check("first access does NOT pin (embedding stays unpinned)",
        "model.embed_tokens.weight" not in m2._misc_qcache)
m2.get_tensor("lm_head.weight", dtype="bf16")   # 1st read — free
m2.get_tensor("lm_head.weight", dtype="bf16")   # 2nd read — pins bytes
p.check("second access pins the LM head bytes",
        "lm_head.weight" in m2._misc_qcache)
r1 = DISK_READS["n"]
m2.get_tensor("lm_head.weight", dtype="bf16")   # 3rd read — served from RAM
m2.get_tensor("lm_head.weight", dtype="bf16")
p.check("subsequent accesses are RAM hits (no further disk reads)",
        DISK_READS["n"] == r1 and m2._misc_qhits == 2)
p.check("pinned misc bytes count against the tier-2 budget",
        m2._qcache_bytes == 250)
p.check("reads so far: embed once + lm_head twice",
        r1 - r0 == 3)

# ─────────────────────────────────────────────────────────────────────────────
p.section("5) Zero-budget managers stream forever (default unchanged)")
z = build_manager(cache_mb_bytes=0, qcache_mb_bytes=0)
r0 = DISK_READS["n"]
for _tok in range(3):
    for layer in range(N_LAYERS):
        z.load_layer(layer, dtype="bf16")
p.check("every layer read from disk every token",
        DISK_READS["n"] - r0 == 3 * N_LAYERS * len(ROLES))
zs = z.cache_stats()
p.check("stats report nothing resident",
        zs["cached_layers"] == 0 and zs["qcached_layers"] == 0
        and zs["resident"] is False and zs["resident_bytes"] == 0)

# ─────────────────────────────────────────────────────────────────────────────
p.section("6) Dashboard aliases")
p.check("warmed manager reports resident=True with summed bytes",
        s["resident"] is True
        and s["resident_bytes"] == 2 * LAYER_T1_BYTES + 2 * LAYER_RAW_BYTES
        and s["resident_max_bytes"] == m._cache_budget_bytes + m._qcache_budget_bytes
        and s["layers_cached"] == 4)

p.done()
