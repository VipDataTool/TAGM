#!/usr/bin/env python3
"""Cold probes for the node layer: meta storage, lifetime totals, corpus
stats shape — the DB-side substance behind GET /api/node and /api/corpus.

The FastAPI handlers themselves are thin wrappers and need fastapi to
import, so they are exercised by test_server.py on a full install; these
probes cover everything beneath them with zero dependencies.

Run:  python tests/probe_node.py
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

from _probe_util import Probe, add_src_to_path

add_src_to_path()

from core.db import Database                                  # noqa: E402
from core.corpus import CorpusStore                           # noqa: E402
from core.security import write_posture                       # noqa: E402

p = Probe("Node layer")

# ── Write-authorization posture ──────────────────────────────
p.section("write posture")
p.check("bare environment → local-origin, quiet",
        write_posture({}) ==
        {"mode": "local-origin", "loud": False,
         "summary": write_posture({})["summary"], "note": ""})
p.check("CODESPACES → proxy-trusted and LOUD",
        write_posture({"CODESPACES": "true"})["mode"] == "proxy-trusted"
        and write_posture({"CODESPACES": "true"})["loud"] is True)
p.check("codespace can opt out: TRUST_PROXY=0 → local-origin",
        write_posture({"CODESPACES": "true",
                       "COURIER_TRUST_PROXY": "0"})["mode"] == "local-origin")
p.check("explicit TRUST_PROXY=1 → proxy-trusted and LOUD",
        write_posture({"COURIER_TRUST_PROXY": "1"}) ["mode"] == "proxy-trusted"
        and write_posture({"COURIER_TRUST_PROXY": "1"})["loud"] is True)
p.check("INSECURE=1 → insecure-bypass and LOUD",
        write_posture({"COURIER_INSECURE": "1"})["mode"] == "insecure-bypass"
        and write_posture({"COURIER_INSECURE": "1"})["loud"] is True)
p.check("REQUIRE_TOKEN=1 → token-required, quiet",
        write_posture({"COURIER_REQUIRE_TOKEN": "1"})["mode"]
        == "token-required")
p.check("conflict: REQUIRE_TOKEN beats INSECURE (safest wins)",
        write_posture({"COURIER_REQUIRE_TOKEN": "1",
                       "COURIER_INSECURE": "1"})["mode"] == "token-required")
p.check("conflict: REQUIRE_TOKEN beats proxy trust",
        write_posture({"COURIER_REQUIRE_TOKEN": "1",
                       "CODESPACES": "true"})["mode"] == "token-required")
p.check("loud postures carry an actionable note",
        all(write_posture(e)["note"]
            for e in ({"CODESPACES": "true"}, {"COURIER_INSECURE": "1"})))

# ── Meta key/value (identity storage) ────────────────────────
p.section("meta table")
w = Path(tempfile.mkdtemp())
db = Database(w / "courier.db")
p.check("absent key → None", db.get_meta("courier_id") is None)
p.check("absent key honors default",
        db.get_meta("courier_id", "fallback") == "fallback")
db.set_meta("courier_id", "courier-abc123def456")
p.check("set then get round-trips",
        db.get_meta("courier_id") == "courier-abc123def456")
db.set_meta("courier_id", "courier-overwritten")
p.check("set overwrites (upsert)",
        db.get_meta("courier_id") == "courier-overwritten")
db2 = Database(w / "courier.db")
p.check("value survives a reopen — identity is durable",
        db2.get_meta("courier_id") == "courier-overwritten")

# ── Lifetime totals ──────────────────────────────────────────
p.section("cycle totals")
t = db.cycle_totals()
p.check("empty ledger → 0 cycles, 0 tokens",
        t["cycles"] == 0 and t["tokens"] == 0)
p.check("empty ledger → energy is None, not zero (absent ≠ free)",
        t["energy_j"] is None)
c1 = db.create_cycle(cycle_number=1, template_id="t", config={})
db.update_cycle(c1, status="complete", tokens_generated=100,
                energy_j=412.3, energy_method="rapl")
c2 = db.create_cycle(cycle_number=2, template_id="t", config={})
db.update_cycle(c2, status="complete", tokens_generated=50)   # unmetered
c3 = db.create_cycle(cycle_number=3, template_id="t", config={})
db.update_cycle(c3, status="failed", tokens_generated=999)    # excluded
t = db.cycle_totals()
p.check("counts completed cycles only", t["cycles"] == 2)
p.check("sums completed tokens only", t["tokens"] == 150)
p.check("sums metered energy, skips unmetered",
        t["energy_j"] is not None and abs(t["energy_j"] - 412.3) < 1e-9)

# ── History rows carry energy ────────────────────────────────
p.section("history energy fields")
rows = db.get_cycles(10)
by_id = {r["id"]: r for r in rows}
p.check("metered cycle row carries energy_j + method",
        by_id[c1]["energy_j"] == 412.3 and
        by_id[c1]["energy_method"] == "rapl")
p.check("unmetered cycle row carries None, not 0",
        by_id[c2]["energy_j"] is None)

# ── Corpus stats shape (what /api/corpus wraps) ──────────────
p.section("corpus stats")
cs = CorpusStore(w / "corpus.db")
cs.add_document("regs", [{"body": "No wake within 100m of a marked buoy."}],
                title="Regulations")
st = cs.stats()
cs.close()
p.check("stats reports documents/chunks/listing",
        st["documents"] == 1 and st["chunks"] == 1 and
        st["listing"][0]["doc_id"] == "regs")

# ── Config normalization (what /api/cycles/{id} guarantees) ──
p.section("config normalization")
from report import normalize_config_json                      # noqa: E402
p.check("valid JSON passes through untouched",
        normalize_config_json('{"temperature": 0.7}') ==
        ('{"temperature": 0.7}', False, None))
p.check("None/empty pass through (nothing to normalize)",
        normalize_config_json(None) == (None, False, None) and
        normalize_config_json("") == ("", False, None))
fixed, repaired, err = normalize_config_json("{'temperature': 0.7, 'x': None}")
import json as _json
p.check("legacy Python-repr row is repaired to real JSON",
        repaired and err is None and
        _json.loads(fixed) == {"temperature": 0.7, "x": None})
fixed, repaired, err = normalize_config_json('{"truncated": ')
p.check("garbage degrades to {} with a stated reason, never a throw",
        fixed == "{}" and not repaired and err and "unparseable" in err)
p.check("repair never executes code (literal_eval, not eval)",
        normalize_config_json("__import__('os').system('id')")[2] is not None)

p.done()
