"""Format-parity tests: the DB-fed path must hand the model the SAME tokens
as the old file-fed (glob) path.

The model ingests a formatted prompt string (+ image paths). It is blind to
whether the bytes came from a file or the ledger. These tests prove that
adapter.render_records(records_from_db) produces byte-identical output to
adapter.fetch(file) for tabular data, and the same ordered image_paths for
images — so swapping the glob for the DB cannot change what the model sees.

Pure stdlib + SQLite; no torch, runs in milliseconds.
"""

import json
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "src"))

from core.db import Database                 # noqa: E402
from data import ingest                       # noqa: E402
from data.adapters import csv_file, json_file, image_file  # noqa: E402

BUDGET = 500


@pytest.fixture
def db(tmp_path):
    d = Database(tmp_path / "courier.db")
    yield d
    d.close()


def _records_for(db, cycle="cyc"):
    db.snapshot(cycle)
    out = []
    for r in db.get_snapshot_records(cycle):
        out.append(r)
    return out


def test_csv_file_vs_db_identical(db, tmp_path):
    p = tmp_path / "sensors.csv"
    p.write_text("station,temp_c,co2_ppm\nA,12.4,415\nB,13.1,418\nC,11.9,420\n")

    # File-fed
    a_file = csv_file.Adapter()
    a_file.connect({"path": str(p)})
    out_file = a_file.fetch(BUDGET, {})

    # DB-fed
    ingest.ingest_csv_file(db, p)
    recs = [json.loads(r["content"]) for r in _records_for(db)]
    a_db = csv_file.Adapter()
    a_db.connect({})
    out_db = a_db.render_records(recs, BUDGET, {})

    assert out_file == out_db, f"\nFILE:\n{out_file}\nDB:\n{out_db}"
    assert "| station | temp_c | co2_ppm |" in out_db  # sanity: real table


def test_json_file_vs_db_identical(db, tmp_path):
    p = tmp_path / "readings.json"
    p.write_text(json.dumps([
        {"sensor": "s1", "value": 1.0},
        {"sensor": "s2", "value": 2.0},
        {"sensor": "s3", "value": 3.0},
    ]))

    a_file = json_file.Adapter()
    a_file.connect({"path": str(p)})
    out_file = a_file.fetch(BUDGET, {})

    ingest.ingest_json_file(db, p)
    recs = [json.loads(r["content"]) for r in _records_for(db)]
    a_db = json_file.Adapter()
    a_db.connect({})
    out_db = a_db.render_records(recs, BUDGET, {})

    assert out_file == out_db, f"\nFILE:\n{out_file}\nDB:\n{out_db}"


def test_budget_truncation_parity(db, tmp_path):
    # Many rows + a tiny budget → both paths must truncate identically.
    rows = "\n".join(f"r{i},{i*10}" for i in range(200))
    p = tmp_path / "big.csv"
    p.write_text("id,val\n" + rows + "\n")

    a_file = csv_file.Adapter(); a_file.connect({"path": str(p)})
    out_file = a_file.fetch(40, {})

    ingest.ingest_csv_file(db, p)
    recs = [json.loads(r["content"]) for r in _records_for(db)]
    a_db = csv_file.Adapter(); a_db.connect({})
    out_db = a_db.render_records(recs, 40, {})

    assert out_file == out_db
    assert "more records" in out_db  # truncation actually triggered


def test_image_paths_order_preserved(db, tmp_path):
    # Image order determines which vision-token span each image fills, so the
    # DB-fed image_paths must come back in deterministic ingest order.
    names = ["boat_01.jpg", "boat_02.jpg", "boat_03.jpg"]
    for n in names:
        (tmp_path / n).write_bytes(b"\xff\xd8\xff\xe0FAKE")
        ingest.ingest_image_file(db, tmp_path / n)

    recs = _records_for(db)
    a = image_file.Adapter(); a.connect({})
    text = a.render_records(recs, 200, {})

    got = [p.name for p in a.image_paths]
    assert got == names, got
    assert "3 image(s)" in text
    for n in names:
        assert n in text
