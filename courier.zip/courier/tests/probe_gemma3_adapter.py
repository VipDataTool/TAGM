#!/usr/bin/env python3
"""Probe: Gemma 3 adapter — config parsing, prefix detection, layer types,
key maps, and the BOS encode hook (GEMMA3_ADAPTER_BUILD_PLAN.md §4, cold gate).

Exercises the REAL Gemma3Adapter against synthetic checkpoints written to a
temp dir: a composite (4B-style, nested text_config) with the new-style
prefix index, an early-2025 composite with the old-style prefix, and a flat
gemma3_text (1B-style) with a bare safetensors header. torch and
transformers aren't in the cold sandbox; the adapter's parsing path is pure
stdlib, and the tokenizer is stubbed only for the encode-hook checks.

    cd courier
    python tests/probe_gemma3_adapter.py
"""
import json
import struct
import sys
import tempfile
import types
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "src"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

if "torch" not in sys.modules:  # only build_rope_inv_freq touches torch; unused here
    _torch = types.ModuleType("torch")
    _torch.Tensor = object      # module-level annotations in llama3.py touch these
    _torch.dtype = object
    _torch.bfloat16 = "bf16"
    sys.modules["torch"] = _torch

from _probe_util import Probe  # noqa: E402
from core.adapter.gemma3 import Gemma3Adapter  # noqa: E402
from core.adapter.registry import ADAPTERS  # noqa: E402

p = Probe("Gemma 3 adapter probe")

COMPOSITE_CFG = {
    "model_type": "gemma3",
    "image_token_index": 262144,
    "tie_word_embeddings": True,
    "eos_token_id": [1, 106],
    "text_config": {
        "num_hidden_layers": 26, "hidden_size": 2560, "intermediate_size": 10240,
        "num_attention_heads": 8, "num_key_value_heads": 4, "head_dim": 256,
        "vocab_size": 262208, "rope_theta": 1_000_000.0, "rms_norm_eps": 1e-6,
        "max_position_embeddings": 131072, "bos_token_id": 2,
        "sliding_window": 1024, "sliding_window_pattern": 6,
        "rope_local_base_freq": 10_000.0, "query_pre_attn_scalar": 256,
        "rope_scaling": {"rope_type": "linear", "factor": 8.0},
    },
}


def make_checkpoint(tmp, cfg, prefix, use_index=True):
    d = Path(tmp)
    (d / "config.json").write_text(json.dumps(cfg), encoding="utf-8")
    keys = [prefix + "embed_tokens.weight", prefix + "norm.weight",
            prefix + "layers.0.self_attn.q_proj.weight"]
    if use_index:
        (d / "model.safetensors.index.json").write_text(
            json.dumps({"weight_map": {k: "model-00001.safetensors" for k in keys}}),
            encoding="utf-8")
    else:
        header = json.dumps({k: {"dtype": "F32", "shape": [1],
                                 "data_offsets": [0, 4]} for k in keys}).encode()
        with open(d / "model.safetensors", "wb") as f:
            f.write(struct.pack("<Q", len(header)) + header)
    return d


# ── 1) Composite, new-style prefix, index json ──────────────────────────────
p.section("1) Composite config (4B-style), new-style prefix")
with tempfile.TemporaryDirectory() as tmp:
    a = Gemma3Adapter(make_checkpoint(tmp, COMPOSITE_CFG, "model.language_model."))
    c = a.config
    p.check("nested text_config parsed (hidden=2560, layers=26)",
            c.hidden_size == 2560 and c.num_hidden_layers == 26)
    p.check("prefix detected: model.language_model.",
            a.embedding_key() == "model.language_model.embed_tokens.weight")
    p.check("(1+weight) norm flag set", a.rmsnorm_uses_residual_weight is True)
    p.check("QK-norm flag set", a.has_qk_norm is True)
    p.check("eos = [1, 106]", c.eos_token_id == [1, 106])
    p.check("tied embeddings -> lm_head_key None", a.lm_head_key() is None)
    p.check("sliding fields parsed (window=1024, qpas=256, local theta=10k)",
            c.sliding_window == 1024 and c.query_pre_attn_scalar == 256.0
            and c.rope_local_base_freq == 10_000.0)
    p.check("rope_scaling carried (linear, factor 8)",
            c.rope_scaling == {"rope_type": "linear", "factor": 8.0})

    # Layer types: pattern 6 over 26 layers -> global at (i+1)%6==0
    globals_ = [i for i, t in enumerate(c.layer_types) if t == "full_attention"]
    p.check("layer types derived: globals at {5,11,17,23}",
            globals_ == [5, 11, 17, 23])
    p.check("5:1 ratio holds (22 sliding, 4 full)",
            c.layer_types.count("sliding_attention") == 22)
    p.check("layer_type() reads the derived list",
            a.layer_type(5) == "full_attention"
            and a.layer_type(6) == "sliding_attention")

    roles = a.layer_weight_keys(3)
    p.check("all 13 layer roles mapped (sandwich norms + qk-norm present)",
            len(roles) == 13 and
            roles["pre_feedforward_layernorm"]
            == "model.language_model.layers.3.pre_feedforward_layernorm.weight" and
            roles["q_norm"] == "model.language_model.layers.3.self_attn.q_norm.weight")

# ── 2) Early-2025 composite prefix ──────────────────────────────────────────
p.section("2) Composite, early-2025 prefix (language_model.model.)")
with tempfile.TemporaryDirectory() as tmp:
    a = Gemma3Adapter(make_checkpoint(tmp, COMPOSITE_CFG, "language_model.model."))
    p.check("old-vintage prefix detected",
            a.final_norm_key() == "language_model.model.norm.weight")

# ── 3) Flat 1B config, prefix from a raw safetensors header ─────────────────
p.section("3) Flat gemma3_text (1B-style), header-based detection")
flat = dict(COMPOSITE_CFG["text_config"])
flat["model_type"] = "gemma3_text"
with tempfile.TemporaryDirectory() as tmp:
    a = Gemma3Adapter(make_checkpoint(tmp, flat, "model.", use_index=False))
    p.check("flat config parsed", a.config.vocab_size == 262208)
    p.check("prefix from safetensors header: model.",
            a.embedding_key() == "model.embed_tokens.weight")

# ── 4) Registry + guards + hook ─────────────────────────────────────────────
p.section("4) Registry, Gemma 2 guard, BOS hook")
p.check("registry maps gemma3 and gemma3_text",
        ADAPTERS.get("gemma3") is Gemma3Adapter
        and ADAPTERS.get("gemma3_text") is Gemma3Adapter)

bad = json.loads(json.dumps(COMPOSITE_CFG))
bad["text_config"]["final_logit_softcapping"] = 30.0
with tempfile.TemporaryDirectory() as tmp:
    d = make_checkpoint(tmp, bad, "model.language_model.")
    try:
        Gemma3Adapter(d)
        p.check("Gemma 2 softcapping config fails loud", False)
    except ValueError as e:
        p.check("Gemma 2 softcapping config fails loud", "softcapping" in str(e))

with tempfile.TemporaryDirectory() as tmp:
    a = Gemma3Adapter(make_checkpoint(tmp, COMPOSITE_CFG, "model.language_model."))

    class StubTok:  # encodes to marker ids; never emits bos itself
        def encode(self, text, add_special_tokens=False):
            return [42, 43]
    a._tokenizer = StubTok()
    p.check("encode_prompt prepends <bos> (id 2)", a.encode_prompt("hi") == [2, 42, 43])

    class StubTokBos(StubTok):  # some tokenizer configs add bos themselves
        def encode(self, text, add_special_tokens=False):
            return [2, 42, 43]
    a._tokenizer = StubTokBos()
    p.check("encode_prompt never double-prepends", a.encode_prompt("hi") == [2, 42, 43])

    from core.adapter.base import ModelAdapter
    base_default = ModelAdapter.encode_prompt(a, "hi")
    p.check("base-class hook default == historical encode (no specials)",
            base_default == [2, 42, 43])  # StubTokBos returns this regardless of flag

p.done()
