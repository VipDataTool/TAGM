"""Phase 3 tests — persistence and durability.

Tests database operations, data ingestion, checkpointing, and the
cycle worker loop. Model-dependent tests require Qwen3-0.6B.
"""

import json
import sys
import tempfile
import time
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

MODEL_PATH = Path(__file__).parent.parent / "models" / "Qwen3-0.6B"
DATA_DIR = Path(__file__).parent.parent / "data"
TEMPLATES_DIR = Path(__file__).parent.parent / "templates" / "builtin"


def model_available():
    return MODEL_PATH.exists() and (MODEL_PATH / "config.json").exists()


# ── 3.1: Database Tests ──────────────────────────────────────

class TestDatabase:

    @pytest.fixture
    def db(self, tmp_path):
        from core.db import Database
        d = Database(tmp_path / "test.db")
        yield d
        d.close()

    def test_create_tables(self, db):
        """Tables exist after init."""
        stats = db.ingestion_stats()
        assert stats["total_records"] == 0

    def test_ingest_and_query(self, db):
        rid = db.ingest("sensor_1", "temp=23.5", timestamp=1000.0)
        assert rid > 0
        assert db.unconsumed_count() == 1

    def test_ingest_batch(self, db):
        records = [
            {"source_id": f"s{i}", "content": f"val={i}"}
            for i in range(50)
        ]
        count = db.ingest_batch(records)
        assert count == 50
        assert db.unconsumed_count() == 50

    def test_snapshot(self, db):
        for i in range(30):
            db.ingest(f"sensor", f"reading {i}")

        count = db.snapshot("cycle_001")
        assert count == 30
        assert db.unconsumed_count() == 0

        records = db.get_snapshot_records("cycle_001")
        assert len(records) == 30

    def test_snapshot_excludes_later(self, db):
        """Records ingested after snapshot are not included."""
        for i in range(20):
            db.ingest("sensor", f"before {i}")

        db.snapshot("cycle_001")

        # Ingest more after snapshot
        for i in range(10):
            db.ingest("sensor", f"after {i}")

        assert db.unconsumed_count() == 10
        snap = db.get_snapshot_records("cycle_001")
        assert len(snap) == 20

    def test_cycle_crud(self, db):
        cid = db.create_cycle(1, "test_template", {"model": "test"})
        assert len(cid) > 0

        cycle = db.get_cycle(cid)
        assert cycle["status"] == "created"
        assert cycle["cycle_number"] == 1

        db.update_cycle(cid, status="complete", completed_at=time.time())
        cycle = db.get_cycle(cid)
        assert cycle["status"] == "complete"

    def test_interrupted_cycle(self, db):
        cid = db.create_cycle(1, "t", {})
        db.update_cycle(cid, status="inferring")

        found = db.get_interrupted_cycle()
        assert found is not None
        assert found["id"] == cid

    def test_no_interrupted_cycle(self, db):
        cid = db.create_cycle(1, "t", {})
        db.update_cycle(cid, status="complete")
        assert db.get_interrupted_cycle() is None

    def test_save_and_get_stages(self, db):
        cid = db.create_cycle(1, "t", {})
        db.save_stage(cid, 0, "Stage 1", False, "output text",
                      100, 50, 1.5)
        db.save_stage(cid, 1, "Stage 2", True, "more output",
                      80, 40, 2.0)

        stages = db.get_stages(cid)
        assert len(stages) == 2
        assert stages[0]["label"] == "Stage 1"
        assert stages[1]["thinking"] == 1

    def test_checkpoint_save_load(self, db):
        cid = db.create_cycle(1, "t", {})
        db.save_checkpoint(cid, stage_index=0, generation_step=10,
                           tokens=[1, 2, 3], position=15)
        db.save_checkpoint(cid, stage_index=0, generation_step=20,
                           tokens=[1, 2, 3, 4, 5], position=25)

        cp = db.get_latest_checkpoint(cid, stage_index=0)
        assert cp is not None
        assert cp["generation_step"] == 20
        assert cp["tokens"] == [1, 2, 3, 4, 5]

    def test_clear_checkpoints(self, db):
        cid = db.create_cycle(1, "t", {})
        db.save_checkpoint(cid, 0, 10, [1], 15)
        db.clear_checkpoints(cid)
        assert db.get_latest_checkpoint(cid) is None


# ── 3.2: Ingestion Tests ─────────────────────────────────────

class TestIngestion:

    @pytest.fixture
    def db(self, tmp_path):
        from core.db import Database
        d = Database(tmp_path / "test.db")
        yield d
        d.close()

    def test_ingest_json_file(self, db):
        from data.ingest import ingest_json_file
        count = ingest_json_file(db, DATA_DIR / "test_seismic.json", "seismic")
        assert count == 10
        assert db.unconsumed_count() == 10

    def test_ingest_csv_file(self, db):
        from data.ingest import ingest_csv_file
        count = ingest_csv_file(db, DATA_DIR / "test_readings.csv", "readings")
        assert count == 30
        assert db.unconsumed_count() == 30

    def test_snapshot_and_format(self, db):
        from data.ingest import ingest_json_file, snapshot_data
        ingest_json_file(db, DATA_DIR / "test_seismic.json", "seismic")

        count, text = snapshot_data(db, "cycle_test")
        assert count == 10
        assert len(text) > 0
        assert db.unconsumed_count() == 0

    def test_ingest_during_snapshot(self, db):
        """Data ingested after snapshot belongs to next cycle."""
        from data.ingest import ingest_record, snapshot_data

        for i in range(20):
            ingest_record(db, "sensor", f"before {i}")

        snapshot_data(db, "cycle_1")

        for i in range(10):
            ingest_record(db, "sensor", f"after {i}")

        assert db.unconsumed_count() == 10
        snap = db.get_snapshot_records("cycle_1")
        assert len(snap) == 20


# ── 3.4: Worker Tests (stub inference) ───────────────────────

def stub_infer(prompt, **kwargs):
    return f"[Stub: {len(prompt)} chars, thinking={kwargs.get('thinking', False)}]"


class TestWorker:

    @pytest.fixture
    def setup(self, tmp_path):
        from core.db import Database
        db = Database(tmp_path / "test.db")
        export_dir = tmp_path / "export"
        return db, export_dir, tmp_path

    def test_single_cycle(self, setup):
        from data.ingest import ingest_json_file
        from engine.worker import run_worker, CycleConfig
        from template import Template

        db, export_dir, _ = setup

        ingest_json_file(db, DATA_DIR / "test_seismic.json", "seismic")
        tmpl = Template.load(TEMPLATES_DIR / "field_report_summary.json")

        print("  single cycle...", end=" ", flush=True)
        result = run_worker(
            db, tmpl, stub_infer,
            data_paths={"default": str(DATA_DIR / "test_seismic.json")},
            export_dir=export_dir,
            cycle_config=CycleConfig(max_cycles=1),
        )
        print(f"{result.cycles_completed} cycle, {result.total_tokens} tokens", flush=True)

        assert result.cycles_completed == 1
        assert result.cycles_failed == 0
        assert len(list(export_dir.glob("*.md"))) == 1

        cycle = db.get_latest_cycle()
        assert cycle["status"] == "complete"

    def test_two_cycles(self, setup):
        from data.ingest import ingest_json_file
        from engine.worker import run_worker, CycleConfig
        from template import Template

        db, export_dir, _ = setup
        tmpl = Template.load(TEMPLATES_DIR / "field_report_summary.json")

        print("  two cycles...", end=" ", flush=True)

        # First batch → first cycle
        ingest_json_file(db, DATA_DIR / "test_seismic.json", "seismic")
        r1 = run_worker(
            db, tmpl, stub_infer,
            data_paths={"default": str(DATA_DIR / "test_seismic.json")},
            export_dir=export_dir,
            cycle_config=CycleConfig(max_cycles=1),
        )
        assert r1.cycles_completed == 1

        # Second batch → second cycle
        ingest_json_file(db, DATA_DIR / "test_co2.json", "co2")
        r2 = run_worker(
            db, tmpl, stub_infer,
            data_paths={"default": str(DATA_DIR / "test_co2.json")},
            export_dir=export_dir,
            cycle_config=CycleConfig(max_cycles=1),
        )
        assert r2.cycles_completed == 1

        total = r1.cycles_completed + r2.cycles_completed
        print(f"{total} cycles", flush=True)
        assert len(list(export_dir.glob("*.md"))) == 2

    def test_stops_when_no_data(self, setup):
        from engine.worker import run_worker, CycleConfig
        from template import Template

        db, export_dir, _ = setup
        tmpl = Template.load(TEMPLATES_DIR / "field_report_summary.json")

        print("  no data...", end=" ", flush=True)
        result = run_worker(
            db, tmpl, stub_infer,
            data_paths={"default": str(DATA_DIR / "test_seismic.json")},
            export_dir=export_dir,
            cycle_config=CycleConfig(max_cycles=0),  # unlimited
        )
        print(f"{result.cycles_completed} cycles (expected 0)", flush=True)
        assert result.cycles_completed == 0

    def test_auto_resume(self, setup):
        """Simulate interrupted cycle, verify auto-resume."""
        from data.ingest import ingest_json_file
        from engine.worker import run_worker, CycleConfig
        from template import Template

        db, export_dir, _ = setup

        ingest_json_file(db, DATA_DIR / "test_seismic.json", "seismic")

        # Simulate an interrupted cycle
        cid = db.create_cycle(1, "field_report_summary", {"model": "test"})
        db.snapshot(cid)
        db.update_cycle(cid, status="inferring", infer_started=time.time())

        tmpl = Template.load(TEMPLATES_DIR / "field_report_summary.json")

        print("  auto-resume...", end=" ", flush=True)
        result = run_worker(
            db, tmpl, stub_infer,
            data_paths={"default": str(DATA_DIR / "test_seismic.json")},
            export_dir=export_dir,
            cycle_config=CycleConfig(auto_resume=True, max_cycles=1),
        )
        print(f"resumed + {result.cycles_completed} cycle(s)", flush=True)

        # The interrupted cycle should have been resumed
        cycle = db.get_cycle(cid)
        assert cycle["status"] == "complete"

    def test_auto_resume_disabled(self, setup):
        """With auto_resume=false, interrupted cycle stays paused."""
        from engine.worker import run_worker, CycleConfig
        from template import Template

        db, export_dir, _ = setup

        cid = db.create_cycle(1, "test", {"model": "test"})
        db.update_cycle(cid, status="inferring")

        tmpl = Template.load(TEMPLATES_DIR / "field_report_summary.json")

        print("  no auto-resume...", end=" ", flush=True)
        result = run_worker(
            db, tmpl, stub_infer,
            data_paths={"default": str(DATA_DIR / "test_seismic.json")},
            export_dir=export_dir,
            cycle_config=CycleConfig(auto_resume=False, max_cycles=1),
        )
        print("done", flush=True)

        # Interrupted cycle should still be inferring (not resumed)
        cycle = db.get_cycle(cid)
        assert cycle["status"] == "inferring"

    def test_cycle_stores_stages(self, setup):
        from data.ingest import ingest_json_file
        from engine.worker import run_worker, CycleConfig
        from template import Template

        db, export_dir, _ = setup

        ingest_json_file(db, DATA_DIR / "test_seismic.json", "seismic")
        tmpl = Template.load(TEMPLATES_DIR / "sensor_anomaly.json")

        print("  stage storage...", end=" ", flush=True)
        run_worker(
            db, tmpl, stub_infer,
            data_paths={"default": str(DATA_DIR / "test_seismic.json")},
            export_dir=export_dir,
            cycle_config=CycleConfig(max_cycles=1),
        )

        cycle = db.get_latest_cycle()
        stages = db.get_stages(cycle["id"])
        assert len(stages) == 2
        assert stages[0]["label"] == "Anomaly Detection"
        assert stages[1]["label"] == "Anomaly Review"
        print(f"{len(stages)} stages saved", flush=True)
