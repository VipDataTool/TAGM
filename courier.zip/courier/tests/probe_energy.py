#!/usr/bin/env python3
"""Cold probes for energy metering (joules-per-verdict).

Synthetic sysfs trees stand in for real hardware, so every source path is
exercised anywhere: RAPL delta + counter wraparound + subdomain exclusion,
battery discharge integration + the refuse-to-fake-it-on-AC rule, the
labeled estimate fallback, DB persistence via migration, and the Energy
row in the receipt view-model.

Run:  python tests/probe_energy.py
"""
from __future__ import annotations

import sys
import tempfile
import time
from pathlib import Path

from _probe_util import Probe, add_src_to_path

add_src_to_path()

from engine.energy import EnergyMeter, _RaplSource, _BatterySource  # noqa: E402

p = Probe("Energy metering")


def make_rapl(root: Path, uj: int, rng: int = 262143328850):
    d = root / "intel-rapl:0"
    d.mkdir(parents=True)
    (d / "energy_uj").write_text(str(uj))
    (d / "max_energy_range_uj").write_text(str(rng))
    sub = root / "intel-rapl:0:0"          # subdomain must be EXCLUDED
    sub.mkdir()
    (sub / "energy_uj").write_text("999999999")
    return d


def make_battery(root: Path, status="Discharging", power_uw=18_000_000):
    b = root / "BAT0"
    b.mkdir(parents=True)
    (b / "type").write_text("Battery")
    (b / "status").write_text(status)
    if power_uw is not None:
        (b / "power_now").write_text(str(power_uw))
    return b


# ── RAPL ─────────────────────────────────────────────────────
p.section("RAPL source")
w = Path(tempfile.mkdtemp())
rd = make_rapl(w / "rapl", uj=1_000_000)
src = _RaplSource(w / "rapl")
p.check("package domain found, subdomain excluded", len(src.domains) == 1)
b0 = src.read_uj()
(rd / "energy_uj").write_text(str(1_000_000 + 412_300_000))   # +412.3 J
p.check("delta in joules", abs(src.delta_j(b0, src.read_uj()) - 412.3) < 0.01)
(rd / "energy_uj").write_text("500000")                       # wrapped
d = src.delta_j([262143000000], src.read_uj())
p.check("counter wraparound handled (delta stays positive)", 0 < d < 1000)

m = EnergyMeter(rapl_root=w / "rapl", battery_root=w / "nobat")
p.check("meter prefers rapl", m.method == "rapl")
(rd / "energy_uj").write_text("2000000")
r = m.start()
(rd / "energy_uj").write_text(str(2_000_000 + 55_000_000))    # +55 J
out = r.stop()
p.check("reading reports joules + method",
        out["method"] == "rapl" and abs(out["joules"] - 55.0) < 0.01)
p.check("avg watts computed", out["avg_watts"] is not None)

# ── Battery ──────────────────────────────────────────────────
p.section("Battery source")
w2 = Path(tempfile.mkdtemp())
make_battery(w2 / "ps", status="Discharging", power_uw=18_000_000)
bs = _BatterySource(w2 / "ps")
p.check("discharging battery reports watts", abs(bs.watts() - 18.0) < 0.01)
m2 = EnergyMeter(rapl_root=w2 / "norapl", battery_root=w2 / "ps",
                 sample_interval=0.05)
p.check("meter falls back to battery", m2.method == "battery")
r2 = m2.start()
time.sleep(0.25)
out2 = r2.stop()
p.check("battery integrates watts over time",
        out2["method"] == "battery" and out2["joules"] is not None
        and abs(out2["avg_watts"] - 18.0) < 1.0)

w3 = Path(tempfile.mkdtemp())
make_battery(w3 / "ps", status="Charging", power_uw=30_000_000)
p.check("on AC, battery refuses to fake a reading",
        not _BatterySource(w3 / "ps").available)

# ── Estimate ─────────────────────────────────────────────────
p.section("Estimate fallback")
w4 = Path(tempfile.mkdtemp())
m3 = EnergyMeter(rapl_root=w4 / "norapl", battery_root=w4 / "nobat",
                 watts_per_core=6.0)
p.check("falls back to labeled estimate", m3.method == "estimate")
r3 = m3.start()
_ = sum(i * i for i in range(400_000))       # burn a little CPU
out3 = r3.stop()
p.check("estimate produces joules and says it's an estimate",
        out3["method"] == "estimate" and out3["joules"] is not None)
m4 = EnergyMeter(rapl_root=w4 / "x", battery_root=w4 / "y",
                 allow_estimate=False)
p.check("with estimate disallowed, method is honest 'none'",
        m4.method == "none")

# ── Persistence + receipt ────────────────────────────────────
p.section("DB migration + receipt row")
from core.db import Database                                  # noqa: E402
from report import build_view_model                           # noqa: E402
w5 = Path(tempfile.mkdtemp())
db = Database(w5 / "courier.db")
cid = db.create_cycle(cycle_number=1, template_id="t", config={})
db.update_cycle(cid, status="complete", infer_started=100.0,
                completed_at=122.8, tokens_generated=55,
                energy_j=412.3, energy_method="rapl")
row = db.get_cycle(cid)
p.check("energy columns persisted",
        row["energy_j"] == 412.3 and row["energy_method"] == "rapl")
vm = build_view_model(row, {}, [])
rows = dict(vm["param_rows"])
p.check("receipt carries the Energy row",
        "Energy" in rows and "412 J (rapl)" in rows["Energy"])
p.check("receipt shows average watts", "W avg" in rows["Energy"])
cid2 = db.create_cycle(cycle_number=2, template_id="t", config={})
db.update_cycle(cid2, status="complete", tokens_generated=3)
vm2 = build_view_model(db.get_cycle(cid2), {}, [])
p.check("no energy → no invented row",
        "Energy" not in dict(vm2["param_rows"]))

p.done()
