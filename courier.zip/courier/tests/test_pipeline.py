"""Phase 1B tests — template, data adapters, and pipeline.

These tests run without a model — they use stub inference.
"""

import json
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

TEMPLATES_DIR = Path(__file__).parent.parent / "templates" / "builtin"
DATA_DIR = Path(__file__).parent.parent / "data"


# ── 1B.1: Template Loader Tests ─────────────────────────────

class TestTemplateLoader:
    """Test JSON template loading, validation, and defaults."""

    def test_load_minimal(self):
        from template import Template
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump({
                "template": {"id": "test", "name": "Test"},
                "model": {"id": "test-model"},
                "stages": [{"label": "S1", "system_prompt": "Do something."}]
            }, f)
            f.flush()
            t = Template.load(f.name)

        assert t.metadata.id == "test"
        assert t.metadata.name == "Test"
        assert t.metadata.version == "0.1.0"  # default
        assert t.model.id == "test-model"
        assert t.model.temperature == 0.3  # default
        assert len(t.stages) == 1
        assert t.stages[0].label == "S1"

    def test_load_full_template(self):
        from template import Template
        t = Template.load(TEMPLATES_DIR / "eruption_risk_test.json")
        assert t.metadata.id == "eruption_risk_test"
        assert len(t.stages) == 4
        assert t.stages[2].thinking is True
        assert t.stages[0].thinking is False
        assert "co2" in t.sources
        assert "seismic" in t.sources

    def test_load_field_report(self):
        from template import Template
        t = Template.load(TEMPLATES_DIR / "field_report_summary.json")
        assert len(t.stages) == 1
        assert t.stages[0].label == "Summary"

    def test_validation_error_no_id(self):
        from template import Template
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump({
                "template": {"name": "No ID"},
                "model": {"id": "m"},
                "stages": [{"label": "S", "system_prompt": "X"}]
            }, f)
            f.flush()
            with pytest.raises(ValueError, match="template.id"):
                Template.load(f.name)

    def test_validation_error_no_stages(self):
        from template import Template
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump({
                "template": {"id": "t", "name": "T"},
                "model": {"id": "m"},
                "stages": []
            }, f)
            f.flush()
            with pytest.raises(ValueError, match="At least one stage"):
                Template.load(f.name)

    def test_roundtrip(self):
        from template import Template
        t = Template.load(TEMPLATES_DIR / "eruption_risk_test.json")
        d = t.to_dict()
        t2 = Template.from_dict(d)
        assert t2.metadata.id == t.metadata.id
        assert len(t2.stages) == len(t.stages)


# ── 1B.2: Data Adapter Tests ────────────────────────────────

class TestVerbatimAdapter:
    def test_passthrough(self):
        from data.adapters.verbatim import Adapter
        a = Adapter()
        a.connect({"text": "Hello world, this is a test."})
        result = a.fetch(1000, {})
        assert result == "Hello world, this is a test."

    def test_truncation(self):
        from data.adapters.verbatim import Adapter
        a = Adapter()
        a.connect({"text": "word " * 1000})
        result = a.fetch(100, {})  # ~400 chars budget
        assert len(result) < 600
        assert "truncated" in result


class TestJsonFileAdapter:
    def test_read_array(self):
        from data.adapters.json_file import Adapter
        a = Adapter()
        a.connect({"path": str(DATA_DIR / "test_co2.json")})
        result = a.fetch(500, {})
        assert "ppm" in result
        assert "|" in result  # markdown table

    def test_read_with_fields(self):
        from data.adapters.json_file import Adapter
        a = Adapter()
        a.connect({
            "path": str(DATA_DIR / "test_co2.json"),
            "params": {"fields": ["timestamp", "ppm"]}
        })
        result = a.fetch(500, {"fields": ["timestamp", "ppm"]})
        assert "ppm" in result
        assert "temperature" not in result.split("\n")[0]  # not in header

    def test_budget_truncation(self):
        from data.adapters.json_file import Adapter
        a = Adapter()
        a.connect({"path": str(DATA_DIR / "test_co2.json")})
        result = a.fetch(50, {})  # very small budget
        assert "more records" in result

    def test_missing_file(self):
        from data.adapters.json_file import Adapter
        a = Adapter()
        a.connect({"path": "/nonexistent/file.json"})
        result = a.fetch(500, {})
        assert "not found" in result


class TestCsvAdapter:
    def test_read_csv(self):
        from data.adapters.csv_file import Adapter
        a = Adapter()
        a.connect({"path": str(DATA_DIR / "test_readings.csv")})
        result = a.fetch(500, {})
        assert "sensor" in result
        assert "|" in result


# ── 1B.4: Pipeline Tests ────────────────────────────────────

def stub_infer(prompt: str, **kwargs) -> str:
    """Stub inference: echoes a summary of the prompt."""
    lines = prompt.strip().split("\n")
    return f"[Stub output: received {len(lines)} lines, {len(prompt)} chars]"


class TestPipeline:
    """Test the stage pipeline with stub inference."""

    def test_single_stage(self):
        from template import Template
        from pipeline import run_pipeline

        t = Template.load(TEMPLATES_DIR / "field_report_summary.json")
        data = {"default": str(DATA_DIR / "test_co2.json")}

        result = run_pipeline(t, data, stub_infer)

        assert len(result.stages) == 1
        assert result.stages[0].label == "Summary"
        assert "Stub output" in result.stages[0].output
        assert result.stages[0].input_chars > 0

    def test_two_stage_with_prior(self):
        from template import Template
        from pipeline import run_pipeline

        t = Template.load(TEMPLATES_DIR / "sensor_anomaly.json")
        data = {"default": str(DATA_DIR / "test_co2.json")}

        result = run_pipeline(t, data, stub_infer)

        assert len(result.stages) == 2
        # Stage 2 should receive stage 1's output
        assert result.stages[1].input_chars > 0

    def test_four_stage_eruption(self):
        from template import Template
        from pipeline import run_pipeline

        t = Template.load(TEMPLATES_DIR / "eruption_risk_test.json")
        data = {
            "co2": str(DATA_DIR / "test_co2.json"),
            "seismic": str(DATA_DIR / "test_seismic.json"),
            "weather": str(DATA_DIR / "test_weather.json"),
        }

        result = run_pipeline(t, data, stub_infer)

        assert len(result.stages) == 4
        assert result.stages[0].label == "CO2 Analysis"
        assert result.stages[3].label == "Critical Review"

        # All stages produced output
        for s in result.stages:
            assert len(s.output) > 0
            assert s.error is None

        # Collated output includes all stages
        assert "CO2 Analysis" in result.collated_output
        assert "Critical Review" in result.collated_output

    def test_stage_receives_prior_outputs(self):
        """Stage 3 (prior=all) should get outputs from stages 1 and 2."""
        from template import Template
        from pipeline import run_pipeline

        # Custom infer that includes stage label in output
        stage_counter = [0]
        def labeled_infer(prompt, **kwargs):
            stage_counter[0] += 1
            return f"[Output from stage {stage_counter[0]}]"

        t = Template.load(TEMPLATES_DIR / "eruption_risk_test.json")
        data = {
            "co2": str(DATA_DIR / "test_co2.json"),
            "seismic": str(DATA_DIR / "test_seismic.json"),
            "weather": str(DATA_DIR / "test_weather.json"),
        }

        result = run_pipeline(t, data, labeled_infer)

        # Stage 3 input should contain outputs from stages 1 and 2
        stage3_input = result.stages[2].input_text
        assert "Output from stage 1" in stage3_input
        assert "Output from stage 2" in stage3_input

        # Stage 4 input should contain stage 3 output only (prior=last)
        stage4_input = result.stages[3].input_text
        assert "Output from stage 3" in stage4_input

    def test_collated_output_write(self):
        from template import Template
        from pipeline import run_pipeline

        t = Template.load(TEMPLATES_DIR / "field_report_summary.json")
        data = {"default": str(DATA_DIR / "test_co2.json")}
        result = run_pipeline(t, data, stub_infer)

        with tempfile.NamedTemporaryFile(suffix=".md", delete=False) as f:
            result.write(f.name)
            content = Path(f.name).read_text()
            assert "Summary" in content


# ── 1B.5: Token Budget Allocation ────────────────────────────

class TestTokenBudget:
    def test_fits_within_budget(self):
        from pipeline import allocate_budgets
        budgets = {"a": 500, "b": 300, "c": 200}
        result = allocate_budgets(budgets, 2000)
        assert result == {"a": 500, "b": 300, "c": 200}

    def test_proportional_scaling(self):
        from pipeline import allocate_budgets
        budgets = {"a": 1000, "b": 1000, "c": 1000}
        result = allocate_budgets(budgets, 2000)
        total = sum(result.values())
        assert total <= 2000
        # Each should get roughly 667
        for v in result.values():
            assert 600 <= v <= 700

    def test_empty(self):
        from pipeline import allocate_budgets
        assert allocate_budgets({}, 1000) == {}
