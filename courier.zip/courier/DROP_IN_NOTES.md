# Courier Drop-In Changeset — Manifest & Run Order

Unzip over the repo root (paths mirror the tree). Every change is additive or
default-preserving except ONE deliberate default flip, flagged below. Four
cold probes ship with it and all pass torch-free.

## What's in it

**Speed (live path — this is the sprint):**
- `src/engine/inference.py` — `dtype: auto` (or `COURIER_DTYPE=auto`): one
  timed GEMM per candidate at engine build picks bf16 vs fp32 for THIS box,
  logged with the ratio. Explicit dtypes pass through untouched; any bench
  failure falls back to bfloat16 with a warning, never an exception. Also
  plumbs tier-2 (below) from config `qresident_max_gb` / `COURIER_QRESIDENT_GB`.
- `src/core/shard_manager.py` — tier-2 raw-at-rest residency for the INT8
  safetensors path: pins int8+scale pairs beyond what tier 1 holds
  dequantized (2× more layers per GB at bf16, 4× at fp32); a hit pays one
  chunked dequant instead of a disk read. One tier owns a layer; both off =
  today's behavior byte-for-byte. `cache_stats()` reports both tiers.
- `src/server.py` — **THE DEFAULT FLIP**: factory `max_ram_percent` 0 → 50,
  so a fresh install doesn't pay streaming tax on a model that fits in RAM.
  Your SAVED config overrides this — nothing changes on an existing install
  until you touch the dial or factory-reset. Revert = one line (search
  `"max_ram_percent": 50`).

**Gemma 3 family (Phase A/B text path):**
- `src/core/adapter/gemma3.py`, `src/engine/gemma3_streamer.py` — new.
- `src/core/adapter/base.py` — 3 optional ModelConfig fields + the
  `encode_prompt` hook (default = historical behavior exactly).
- `src/core/adapter/registry.py` — gemma3 / gemma3_text.
- `src/engine/streamer.py`, `speculative.py`, `hybrid_streamer.py` — encode
  through the hook (identical for Qwen/Llama; Gemma gets its required <bos>).
- `GEMMA3_ADAPTER_BUILD_PLAN.md` — architecture facts + parity gates.
- `src/server.py` also gains the Gemma 3 catalog entries (1B/4B/12B/27B -it)
  so they appear in the dashboard downloader; one family string across all
  sizes gives SD draft-pairing in the UI, and the runtime family-mismatch
  warning normalizes gemma3_text→gemma3 so the 1B→4B+ pair doesn't
  false-alarm. Gemma downloads need HF terms acceptance + HF_TOKEN (same
  flow as meta-llama).

**Dormant (GGUF path — ships for consistency, nothing routes through it):**
- `src/core/gguf_shard_manager.py` — PIN eviction + two-tier cache.

**Probes (tests/):** `probe_qresident.py`, `probe_dtype_autotune.py`,
`probe_gemma3_adapter.py`, `probe_gguf_residency.py`.

## Run order (Codespace, ~20 min)

1. `for p in qresident dtype_autotune gemma3_adapter gguf_residency; do
      python tests/probe_$p.py; done`      # expect 4× all-pass
2. Baseline: your usual 4B cycle, greedy, note tok/s and the Settings value
   of Max RAM (%).
3. Set Max RAM ≈ 60% (dashboard). Re-run the SAME cycle. This is the
   headline A/B.
4. Set `dtype: auto` in config (or `COURIER_DTYPE=auto`). Re-run. The build
   log prints the pick and the ratio — send me that line.
5. Byte-identity spot check (Class I gate): greedy 32 tokens with residency
   off vs on must match token-for-token.
6. Optional, if RAM is tight for a bigger model: `qresident_max_gb: 8` and
   watch `cache_stats` report tier-2 layers.

Gemma Phase A (when you feel like it): download `google/gemma-3-1b-it`,
greedy-parity vs transformers per the build plan — including the >1024-token
prompt; that's the one that can catch a wrong band mask.

## Numbers I want back

tok/s at steps 2/3/4, the autotune log line, and pass/fail on step 5.
Those go straight into the performance spec's §10 and settle whether the
Codespace was streaming-taxed, compute-bound, or both.
