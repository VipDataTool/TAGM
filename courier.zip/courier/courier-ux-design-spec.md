# Courier — Data Queue & Template Editor UX Design Spec

**Status:** Implemented. Popouts are **real browser windows** (`window.open` → standalone
pages served from `/static/`), not in-page modals. Both design calls resolved to their
defaults — builtin templates are editable/deletable once seeded into the single file, and the
record filters live in the dataset window.
**Scope:** Two list→detail interactions and a storage consolidation. (1) The Data viewer
lists **datasets**, not records; a dataset opens in a popout that lazily populates its records.
(2) Templates move to a **single JSON file** as the source of truth, with a **View** button on
the Run-tab picker that opens each template in an editable popout (Save / Delete / Cancel).
Additive server endpoints + one new `src/template_store.py`; two standalone popout pages in the
dashboard. No engine or inference path touched.
**Audience:** Maintainer/engineer extending Courier.

---

## 1. Purpose

The Data tab currently dumps individual ingestion **records** into a flat list — unusable once
more than a handful exist, and the wrong unit: an operator thinks in *datasets* (the `co2`
feed, the `seismic` feed), not in rows. And templates are six separate files on disk with no
in-app way to read or edit them; the Run picker can only *select* one. Two paralel fixes:

- **Data → dataset queue.** The viewer lists one row per dataset (per `source_id`): record
  count, unconsumed count, last-seen, type. Clicking a dataset opens a **popout** that fetches
  and paginates *that* dataset's records on demand — the records live one level down, not
  flattened into the top view.
- **Templates → single source + editor.** All templates live in **one JSON file**. The Run
  picker gains a **View** button that opens the selected template in a popout: its full JSON in
  an editable textarea with **Save / Delete / Cancel**. Edit, validate, persist — without
  leaving the app or hand-editing files on disk.

Both reuse one shared popout stylesheet. Both are read/curate surfaces — no engine, pipeline, or
inference code is touched.

---

## 2. Design principles

1. **The list shows the unit the operator thinks in.** Data lists datasets, not records.
   Records are detail, reached by opening a dataset — never the top-level view.
2. **Populate detail on demand.** A popout fetches its contents when opened and paginates as
   needed; the top list stays a cheap summary (aggregate counts, not row payloads).
3. **One file is the source of truth for templates.** All templates live in a single
   `templates/templates.json`, keyed by id. The list, the picker, the editor, and the cycle
   runner all read the same file — they cannot drift. (Mirrors the tooling spec's "one
   manifest, three consumers.")
4. **Seed once, then own it.** On first run the single file is seeded from the existing
   `builtin/*.json`, so no shipped template is lost. After that, the single file is
   authoritative and every template in it is viewable, editable, and deletable.
5. **Loud validation on save.** Saving an edited template validates through the existing
   `Template.from_dict` before it touches disk. Invalid JSON or a failed schema check returns a
   specific error to the editor and writes nothing — never a half-saved or corrupt template.
6. **Shared popout windows.** Both detail views are real browser windows (`window.open` →
   standalone same-origin pages) sharing one stylesheet (`popout.css`); consistent look, no
   per-feature window code.
7. **Read/curate only — engine untouched.** No change to streaming, throttle, checkpointing,
   or the decode loop. This is dashboard + storage + read endpoints.

---

## 3. Module layout

```
src/
  template_store.py   # NEW — single-file template store: load + seed-migration + CRUD (pure-ish)
```

Integration touch points (existing files, additive changes only):

- `src/server.py` —
  - Template endpoints rewired to `TemplateStore`: `GET /api/templates` (summaries),
    `GET /api/templates/{id}` (raw dict), `PUT /api/templates/{id}` (validate + save),
    `DELETE /api/templates/{id}`, and existing `POST /api/templates` (upload → store).
  - `_get_templates` / `_get_active_template` / recovery / cycle-trigger read the store instead
    of globbing `TEMPLATES_DIR`.
  - New `GET /api/ingest/sources` — dataset summaries (GROUP BY `source_id`).
- `src/template.py` — unchanged; `Template.from_dict` (validation) and `to_dict`
  (serialization) are reused by the store. No schema change.
- `static/dashboard.html` —
  - Data tab (`vData`): record list → **dataset list** (dense `.dtable`); row click →
    `window.open` a real browser window for that dataset.
  - Run tab (`vRun`): **View** button beside the picker → `window.open` the template editor
    window.
- `static/dataset.html`, `static/template.html`, `static/popout.css` — NEW standalone popout
  pages (record viewer, template editor) and their shared stylesheet. Same-origin, so they
  reuse the dashboard's `localStorage` token against the existing `/api/...` endpoints.
- `src/server.py` — `/static/{filename}` given proper MIME handling so the popout pages render
  rather than download.
- `templates/templates.json` — NEW single source of truth (git-seeded or migrated at startup
  from `builtin/`). `templates/builtin/*.json` retained as the immutable seed only.

---

## 4. Data: dataset queue + record popout

**Summary endpoint.** `GET /api/ingest/sources` aggregates the `ingestion` table:

```sql
SELECT source_id,
       COUNT(*)                              AS records,
       SUM(CASE WHEN consumed=0 THEN 1 END)  AS unconsumed,
       MAX(timestamp)                        AS last_ts,
       MAX(mime_type)                        AS mime
FROM ingestion GROUP BY source_id ORDER BY last_ts DESC;
```

Returns one summary per dataset. Cheap; no record payloads.

**Data tab.** The flat record list becomes a **dataset list** — one row per source:
`source_id · N records · M unconsumed · last seen · type`. The existing source/consumed/search
controls move *into* the popout (they filter records, which now live there). The top view's job
is to show what datasets exist and how full they are.

**Record popout.** Clicking a dataset opens a browser window, titled with the `source_id`, and
**dynamically populates** it: fetch `GET /api/ingest/records?source=<id>&limit=50&offset=0`,
render rows (timestamp · type · consumed · content preview), and page in more on scroll / "Load
more" (offset += 50). A row expands to full content via the existing
`GET /api/ingest/records/{id}`. Read-only. The fetch-on-open keeps the top list light no matter
how many records a dataset holds.

---

## 5. Templates: single file + editor popout

**Storage.** `src/template_store.py` owns one file, `templates/templates.json`:

```jsonc
{ "field_report_summary": { /* full template JSON */ },
  "eruption_risk_test":   { /* … */ } }
```

API (all validate/serialize through the existing `Template`):

```python
class TemplateStore:
    def __init__(self, path, seed_dir): ...      # path=templates.json, seed_dir=builtin/
    def _ensure(self):   # if file missing, seed from seed_dir/*.json (no template lost)
    def list(self) -> list[dict]   # [{id,name,description,version,stages}] summaries
    def get(self, tid) -> dict     # raw template dict (for the editor)
    def save(self, tid, raw):      # Template.from_dict(raw) → validate; then write file
    def delete(self, tid):         # remove key; write file
```

- **Seed-migration** (principle 4): first `_ensure()` with no `templates.json` reads every
  `builtin/*.json` into the single file. Idempotent; runs once.
- **Last-write-wins** on the file (single-operator tool; no locking beyond the existing DB lock
  pattern). Writes are whole-file rewrites — small, atomic via temp-file + rename.

**Run-tab View button.** Beside the template `<select>` (next to *Upload .JSON*), a **View**
button opens the editor popout for the currently-selected template.

**Editor popout.** The window body is a `<textarea>` pre-filled with the template's
pretty-printed JSON (`GET /api/templates/{id}`), plus three buttons:

- **Save** → parse the textarea as JSON (loud error on parse failure), `PUT /api/templates/{id}`
  → server validates via `Template.from_dict` (loud, specific error on schema failure) → writes
  the single file. On success, refresh the picker and close.
- **Delete** → confirm, `DELETE /api/templates/{id}`, refresh picker, close.
- **Cancel** → close, no write.

Validation is server-side and authoritative (principle 5); the client only pre-checks JSON
parseability so the operator gets an instant, specific message before the round-trip.

---

## 6. Shared popout windows

The popouts are **real browser windows**, opened with `window.open(...)` against standalone
same-origin pages, not in-page overlays:

- `static/dataset.html?source=<id>` — the dataset record viewer.
- `static/template.html?id=<id>` — the template editor.
- `static/popout.css` — one stylesheet shared by both (DRY; dark theme matching the app).

Same-origin means they share the dashboard's `localStorage` token, so they authenticate to the
existing `/api/...` endpoints directly. The server's `/static/{filename}` route was given
proper MIME handling (`text/html`, `text/css`) so the pages render rather than download. The
template window notifies the opener on save/delete (`courier-template-changed`) and the picker
also refreshes on the next SSE tick.

---

## 7. Out of scope (named on purpose)

- **Structured stage-by-stage template form.** This is raw-JSON editing first — the whole
  template in a textarea. A field-level visual editor (add/reorder stages, pick sources) is a
  later layer on top of the same store and popout window.
- **Editing or deleting individual records.** The dataset popout is read-only; mutation stays
  in the ingestion path.
- **Concurrency control on the template file.** Single-operator tool; last-write-wins, like the
  rest of Courier's single-instance model.
- **Tool-calling subsystem.** Separate spec (`courier-tooling-design-spec.md`), unaffected.

---

## 8. Suggested build order

1. `template_store.py` — single-file load, seed-migration, list/get/save/delete.
2. `tests/probe_template_store.py` — cold: seed from builtin, round-trip save/get, delete,
   reject-invalid-on-save. No torch.
3. `server.py` — rewire template endpoints + readers to the store; add `PUT`/`DELETE`.
4. `server.py` — `GET /api/ingest/sources` aggregation.
5. `static/dataset.html` + `static/template.html` + `static/popout.css` — standalone popout
   pages; `/static` MIME fix in `server.py`.
6. `dashboard.html` — Data tab dataset list + record popout (paged fetch).
7. `dashboard.html` — Run-tab View button + template editor popout (save/delete/cancel, loud
   errors).

Each backend step is independently cold-probe testable in the existing `tests/probe_*.py`
style; the UI steps verify against the live endpoints.

---

## Two design calls I'm making (say so if you'd rather not)

- **Builtin templates become editable/deletable** once seeded into the single file — that's
  what "single source of truth" implies. If you'd rather `builtin/` stay read-only and only
  *user* templates be editable, that's a two-tier store instead; tell me and I'll split it.
- **Record filters (source/consumed/search) move into the dataset popout**, since that's where
  records now live. If you want a global record search to survive at the top level too, I'll
  keep a search affordance on the dataset list.
