# Phase 1+2 Hardware Run Sheet — GGUF Two-Tier PIN Residency

What changed: `src/core/gguf_shard_manager.py` only. Tier-1 layer cache now
PINs instead of LRU-evicting; new tier-2 raw-bytes cache (`COURIER_QCACHE_MB`,
default 0); hot non-layer tensors (streamed LM head) byte-cached on second
access; `cache_stats()` gained tier-2 keys + dashboard aliases. Defaults
unchanged: with both env vars unset/0, behavior is byte-for-byte today's
streaming. Cold probe (22 checks) passes: `python tests/probe_gguf_residency.py`.

## Gate 1 — byte-identity (Codespace, ~10 min)

Proves Class I: caching changes plumbing, never output.

    cd courier && source .venv/bin/activate   # torch env
    python tests/probe_gguf_residency.py       # 22/22 expected

    # Greedy decode, streaming (both knobs off):
    COURIER_CACHE_MB=0 COURIER_QCACHE_MB=0 \
      python -m src.cli run --template templates/builtin/quick_test.json \
      --model <your 0.6B GGUF dir> > /tmp/run_stream.txt

    # Same, fully tier-1 resident:
    COURIER_CACHE_MB=4000 COURIER_QCACHE_MB=0 \
      python -m src.cli run ... > /tmp/run_t1.txt

    # Same, forced through tier 2 (tier 1 too small for even one layer):
    COURIER_CACHE_MB=1 COURIER_QCACHE_MB=4000 \
      python -m src.cli run ... > /tmp/run_t2.txt

    diff /tmp/run_stream.txt /tmp/run_t1.txt && \
    diff /tmp/run_stream.txt /tmp/run_t2.txt && echo IDENTICAL

Use temperature 0 in the template for this gate. Any diff = stop, report.
(Adjust the run command to however you normally drive a one-shot cycle —
what matters is same prompt, same settings, three cache configs.)

## Gate 2 — throughput + the two open questions (CF-31)

Model: your real target (e.g. 32B or 70B Q4_K_M). Fixed prompt, ≥32 tokens,
greedy. Between runs: reboot or otherwise drop the OS file cache so run A
doesn't warm run B (on Windows, RAMMap's "Empty Standby List", or just
reboot — crude but honest).

Record tokens/sec (steady-state, ignore prefill) + `cache_stats()` from the
dashboard/status endpoint + psutil disk read bytes if convenient:

  A. Baseline:        COURIER_CACHE_MB=0     COURIER_QCACHE_MB=0
  B. Tier 1 only:     COURIER_CACHE_MB=20000 COURIER_QCACHE_MB=0
  C. Split tiers:     COURIER_CACHE_MB=2000  COURIER_QCACHE_MB=20000
  D. Page-cache bet:  same as A, but run the prompt TWICE back-to-back and
                      record the second run (OS cache warmed, our caches off)

C vs D answers "pinned bytes vs page cache" (spec §11 risk 1).
C's per-token time vs B's answers "dequant cost vs SATA read" (risk 2) —
if C beats B at equal total budget, tier 2 earns its keep on this CPU.

Expected shape (estimates, to be retired by your numbers): B and C both far
above A; C ≥ B for models ≫ tier-1 budget; D somewhere between A and C
depending on how hard Windows fights for the standby list.

## Gate 3 — the dashboard freebie

With any budget set, the Monitor residency panel should now show on/MB/layers
for GGUF models (it previously only lit for safetensors). Zero server changes
were needed — confirm it renders sanely.

## Report back

tok/s for A–D + model size + which config you'd bless as the box default.
That writes §10's real numbers and settles §11's first two risks.
