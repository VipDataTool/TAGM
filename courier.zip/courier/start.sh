#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════
# Courier — start.sh
# Checks environment, downloads model if needed, starts server.
# Safe to run repeatedly.
# ═══════════════════════════════════════════════════════════════

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Clear bytecode cache to ensure fresh code loads after updates
find . -name __pycache__ -exec rm -rf {} + 2>/dev/null || true

PORT="${COURIER_PORT:-8000}"
PID_FILE="$SCRIPT_DIR/courier.pid"
LOG_FILE="$SCRIPT_DIR/logs/courier.log"

# ── Colors ───────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
AMBER='\033[0;33m'
DIM='\033[0;90m'
BOLD='\033[1m'
NC='\033[0m'

log()  { echo -e "${GREEN}[courier]${NC} $1"; }
warn() { echo -e "${AMBER}[courier]${NC} $1"; }
err()  { echo -e "${RED}[courier]${NC} $1"; }
dim()  { echo -e "${DIM}[courier] $1${NC}"; }

# ── Args / subcommands ───────────────────────────────────────
# start.sh                 foreground server (dies with this terminal)
# start.sh --daemon | -d   detached server: survives closed tabs/terminals
# start.sh --test  | -t    run test suite before starting
# start.sh stop            stop a daemonized server
# start.sh status          report whether a daemonized server is running
DAEMON=0
RUN_TESTS=0

_daemon_pid() {
    # Prints the PID from the pidfile if that process is still alive.
    [ -f "$PID_FILE" ] || return 1
    local pid
    pid=$(cat "$PID_FILE" 2>/dev/null) || return 1
    [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null || return 1
    echo "$pid"
}

case "${1:-}" in
    stop)
        if pid=$(_daemon_pid); then
            log "Stopping Courier (pid $pid)..."
            kill "$pid"
            for _ in $(seq 1 20); do
                kill -0 "$pid" 2>/dev/null || break
                sleep 0.5
            done
            if kill -0 "$pid" 2>/dev/null; then
                warn "  Still running after 10s; sending SIGKILL."
                kill -9 "$pid" 2>/dev/null || true
            fi
            rm -f "$PID_FILE"
            log "  Stopped."
        else
            rm -f "$PID_FILE"
            warn "No running Courier daemon found."
        fi
        exit 0
        ;;
    status)
        if pid=$(_daemon_pid); then
            log "Courier daemon running (pid $pid, port likely ${PORT})."
            dim "  Log: $LOG_FILE"
        else
            warn "Courier daemon not running."
        fi
        exit 0
        ;;
esac

for arg in "$@"; do
    case "$arg" in
        --daemon|-d) DAEMON=1 ;;
        --test|-t)   RUN_TESTS=1 ;;
    esac
done

echo ""
echo -e "${AMBER}${BOLD}  ╔═══════════════════════════════════════╗${NC}"
echo -e "${AMBER}${BOLD}  ║         COURIER v0.2.7                ║${NC}"
echo -e "${AMBER}${BOLD}  ║   Edge Inference Framework            ║${NC}"
echo -e "${AMBER}${BOLD}  ╚═══════════════════════════════════════╝${NC}"
echo ""

# ── 1. Check Python ──────────────────────────────────────────
log "Checking Python..."
if ! command -v python3 &> /dev/null; then
    err "Python 3 not found. Install Python 3.10+ and try again."
    exit 1
fi
PYVER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
log "  Python ${PYVER}"

# ── 2. Check dependencies ───────────────────────────────────
log "Checking dependencies..."
DEP_STATUS=$(python3 - <<'PYCHECK'
import importlib, traceback
missing, broken = [], []
for pkg in ("torch", "safetensors", "transformers", "fastapi", "uvicorn", "psutil", "PIL"):
    try:
        importlib.import_module(pkg)
    except ImportError:
        missing.append(pkg)
    except Exception:
        broken.append(pkg)
        traceback.print_exc()
if broken:
    print("BROKEN:" + ",".join(broken))
elif missing:
    print("MISSING:" + ",".join(missing))
else:
    print("OK")
PYCHECK
)

case "$DEP_STATUS" in
    BROKEN:*)
        pkgs="${DEP_STATUS#BROKEN:}"
        err "  Installed but failing: ${pkgs//,/, }"
        err "  See tracebacks above. A reinstall may not fix this."
        exit 1
        ;;
    MISSING:*)
        pkgs="${DEP_STATUS#MISSING:}"
        warn "  Missing: ${pkgs//,/, }"
        log "Installing dependencies..."
        pip install -r requirements.txt --quiet
        log "  Dependencies installed."
        ;;
    OK)
        log "  All dependencies present."
        ;;
esac

# ── 3. Check model ──────────────────────────────────────────
# Read default_model from config, fall back to any ready model on disk,
# and only download a bootstrap model if nothing is available.
MODEL_DIR=$(python3 -c "
import json, sys
from pathlib import Path
cfg_path = Path('courier_config.json')
models_dir = Path('models')

# Try config's default_model first
default = ''
if cfg_path.exists():
    try:
        default = json.load(open(cfg_path)).get('default_model', '')
    except: pass

if default and (models_dir / default / 'config.json').exists():
    print(f'models/{default}')
    sys.exit(0)

# Fall back to any ready model on disk
for d in sorted(models_dir.glob('*')):
    cfg = d / 'config.json'
    has_weights = list(d.glob('*.safetensors')) or list(d.glob('*.gguf'))
    if cfg.exists() and has_weights:
        print(str(d))
        sys.exit(0)

# Nothing found
print('')
" 2>/dev/null)

if [ -z "$MODEL_DIR" ] || [ ! -f "$MODEL_DIR/config.json" ]; then
    MODEL_DIR="models/Qwen3-0.6B"
    warn "No model found on disk"
    log "Downloading Qwen3-0.6B (~1.5 GB)..."
    python3 scripts/download_model.py
    echo ""
else
    log "Model: $(basename $MODEL_DIR)"
fi

# ── 4. Verify model ─────────────────────────────────────────
log "Verifying model..."
VERIFY_OUTPUT=$(python3 scripts/verify_model.py "$MODEL_DIR" 2>&1) || true
if echo "$VERIFY_OUTPUT" | grep -q "VERIFICATION PASSED"; then
    log "  Model verified."
else
    warn "  Model verification failed:"
    echo "$VERIFY_OUTPUT" | grep -E "✗|VERIFICATION FAILED" | sed 's/^/    /'
    warn "  Re-downloading..."
    # Re-download the model that failed, not a hardcoded default
    MODEL_NAME=$(basename "$MODEL_DIR")
    # Find the HuggingFace repo ID from SUPPORTED_MODELS
    HF_ID=$(python3 -c "
import json
models = [
    {'dir': 'Qwen3-0.6B', 'id': 'Qwen/Qwen3-0.6B'},
    {'dir': 'Qwen3.5-0.8B', 'id': 'Qwen/Qwen3.5-0.8B'},
    {'dir': 'Qwen3.5-2B', 'id': 'Qwen/Qwen3.5-2B'},
    {'dir': 'Qwen3.5-4B', 'id': 'Qwen/Qwen3.5-4B'},
    {'dir': 'Llama-3.2-1B-Instruct', 'id': 'meta-llama/Llama-3.2-1B-Instruct'},
    {'dir': 'Llama-3.2-3B-Instruct', 'id': 'meta-llama/Llama-3.2-3B-Instruct'},
]
for m in models:
    if m['dir'] == '$MODEL_NAME':
        print(m['id']); break
else:
    print('')
" 2>/dev/null)
    if [ -n "$HF_ID" ]; then
        python3 scripts/download_model.py --model "$HF_ID" --dest "$MODEL_DIR"
    else
        warn "  Unknown model '$MODEL_NAME' — cannot re-download"
    fi
    echo ""
    # Verify again
    VERIFY_OUTPUT=$(python3 scripts/verify_model.py "$MODEL_DIR" 2>&1) || true
    if echo "$VERIFY_OUTPUT" | grep -q "VERIFICATION PASSED"; then
        log "  Model verified."
    else
        warn "  Verification still failing:"
        echo "$VERIFY_OUTPUT" | grep -E "✗|VERIFICATION FAILED" | sed 's/^/    /'
        warn "  Server will attempt to load anyway."
    fi
fi

# ── 5. Run tests (opt-in) ──────────────────────────────────
if [[ "$RUN_TESTS" == "1" ]]; then
    log "Running tests..."
    if command -v pytest &> /dev/null; then
        if pytest tests/ -s -q --tb=short; then
            log "  Tests passed."
        else
            warn "  Some tests failed. Check output above."
        fi
    else
        python3 -c "
import sys; sys.path.insert(0,'src')
import src; assert src.__version__=='0.2.7'
print('  Basic import test passed.')
" && log "  Basic tests passed." || { err "  Import test failed."; exit 1; }
    fi
else
    dim "  Skipping tests. Use 'bash start.sh --test' to run."
fi

# ── 6. Start server ─────────────────────────────────────────
echo ""
if [[ "$DAEMON" == "1" ]]; then
    if pid=$(_daemon_pid); then
        warn "Courier daemon already running (pid $pid). Use 'bash start.sh stop' first."
        exit 1
    fi
    log "Starting Courier daemon on port ${PORT}..."
    mkdir -p "$(dirname "$LOG_FILE")"
    # setsid: new session, so the pty host of THIS terminal can never signal
    # it when the tab/terminal closes. nohup + /dev/null stdin + log redirect:
    # no lingering ties to the pty at all. This is what makes headless real.
    setsid nohup python3 -m uvicorn src.server:app \
        --host 0.0.0.0 \
        --port "$PORT" \
        --log-level error \
        --app-dir "." >> "$LOG_FILE" 2>&1 < /dev/null &
    SERVER_PID=$!
    echo "$SERVER_PID" > "$PID_FILE"
    sleep 2
    if kill -0 "$SERVER_PID" 2>/dev/null; then
        log "  Daemon running (pid $SERVER_PID)."
        dim "  Dashboard:  http://localhost:${PORT}/"
        dim "  Log:        $LOG_FILE"
        dim "  Stop with:  bash start.sh stop"
    else
        err "  Daemon exited immediately. Last log lines:"
        tail -n 20 "$LOG_FILE" | sed 's/^/    /'
        rm -f "$PID_FILE"
        exit 1
    fi
else
    # Same guard the daemon path already has: a raw "address already in
    # use" AFTER printing the dashboard URL misleads; say what's true.
    if pid=$(_daemon_pid); then
        warn "Courier is already running (pid $pid) and holding port ${PORT}."
        warn "It's serving now at http://localhost:${PORT}/ — or 'bash start.sh stop' first."
        exit 1
    fi
    log "Starting Courier server on port ${PORT}..."
    dim "  Dashboard:  http://localhost:${PORT}/"
    dim "  API:        http://localhost:${PORT}/api/status"
    dim "  Press Ctrl+C to stop.  (Tip: 'bash start.sh --daemon' survives closed terminals.)"
    echo ""

    python3 -m uvicorn src.server:app \
        --host 0.0.0.0 \
        --port "$PORT" \
        --log-level error \
        --app-dir "."
fi
