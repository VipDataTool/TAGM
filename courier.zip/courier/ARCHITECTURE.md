# Courier

## What It Is

Courier runs large language models on hardware that has no business running
them. A 70B-parameter model needs 140GB of RAM loaded conventionally. Courier
runs it on a laptop with 16GB by streaming weight shards through memory one
layer at a time, treating the SSD as the primary weight store and RAM as a
working buffer. The tradeoff is time: a response might take hours or days.
In the environments Courier targets — field camps, research vessels, remote
monitoring stations, disaster response nodes — that tradeoff is worth making.
A slow answer beats no answer.

Courier is a Python library first and a server second. The core engine is a
set of functions with no framework dependencies. A FastAPI wrapper exposes it
over HTTPS for networked sensor deployments. A Jupyter notebook imports it
directly for single-laptop fieldwork. A CLI script runs it headless. A
browser-based dashboard provides remote observation and workflow control.
Same engine, different entry points, same results.

The system collects data from local sources — sensors on a WLAN, API
endpoints, files dropped on disk — and periodically runs inference over
the accumulated data using a templated multi-stage pipeline. Each stage is
a single clean model instance: system prompt plus data, in, response out.
No conversation history, no accumulated context, no drift. The model is
maximally grounded in its training priors plus exactly the data provided.

The layer-streaming technique and disk-backed weight management are adapted
from TAGM's High-Efficiency Pipeline (HEP).


## Principles

**Durability over speed.** Every design decision prioritizes completion
guarantees over throughput. Progress survives power loss.

**Protect the hardware.** The system may run for months on a single SSD.
Write amplification is a first-class constraint. RAM is the working medium;
the SSD is for persistence, not scratch.

**One path, not many.** Running once is running N times where N=1. A manual
trigger is a threshold of zero. Every operation follows the same code path
with different parameters.

**Library, not framework.** The engine is importable, callable, and testable
without a server, a browser, or a network. The server is one possible entry
point among several.

**Single instances.** Each inference pass starts with a clean context. No
conversational history between stages. The model reasons from its training
priors plus the data it was given, nothing else.

**Secure by default.** TLS and token authentication out of the box for
networked deployments. Data integrity guaranteed by checksums at every
boundary.

**Model-agnostic.** Model-family-specific knowledge lives in adapter classes.
The engine never inspects model internals directly.


## Hardware Assumptions

| Resource        | Minimum     | Reference (Codespace) |
|-----------------|-------------|-----------------------|
| RAM             | 8 GB        | 16 GB                 |
| Disk            | 64 GB       | 32 GB (expandable)    |
| Disk type       | SSD         | SSD                   |
| CPU             | 4 cores     | 4 cores               |
| GPU             | None        | None                  |
| Network         | None        | LAN only              |
| Power           | Intermittent| Stable                |

Fewer resources means slower inference, never failed inference.


## Model Strategy

### Prototype Target: Qwen3-0.6B

A single safetensor shard at 1.5 GB (BF16), ~400 MB quantized. On a 4-core
CPU with 16 GB RAM, this model generates 50-100+ tokens/second. A full
4-stage chain-of-thought cycle completes in seconds.

The 0.6B output will not produce meaningful analysis. That is the point.
The prototype validates the apparatus — template loading, adapter fetch,
stage pipeline chaining, checkpointing, cycle loop, data snapshotting,
collation, dashboard rendering — without waiting hours for inference to
tell you whether the plumbing works. When the pipeline is solid, changing
the model path to an 8B is a one-line change. Same code, same templates,
same results structure.

### Production Targets: Qwen3 and Qwen3.5

The Qwen 3 family (April 2025) provides dense models from 0.6B through
14B with dual thinking/non-thinking modes. All use the same fundamental
architecture (GQA, SwiGLU, RoPE, standard RMSNorm) with qk-layernorm,
trained on 36 trillion tokens across 119 languages. Apache 2.0 licensed.

The Qwen 3.5 small model series (March 2026) is explicitly designed for
on-device and edge deployment: 0.8B, 2B, 4B, and 9B parameters, with
262K context windows and improved architectural efficiency. Key
architectural differences from Qwen3:

- **Hybrid attention**: 3:1 ratio of Gated DeltaNet (linear-time
  recurrent) to full attention layers. DeltaNet maintains a fixed-size
  memory matrix instead of a growing KV cache, giving O(1) state per
  layer regardless of sequence length. Full attention layers provide
  periodic "refresh" points for direct context access.
- **Non-standard RMSNorm**: Uses `output * (1 + weight)` with weight
  initialized to zeros, not the standard `output * weight` with weight
  initialized to ones. This is a critical implementation detail —
  using standard RMSNorm produces ~20× magnitude errors.
- **Interleaved Q/gate split**: The `q_proj` output is 2× q_dim,
  organized as interleaved per-head `[Q_h0, gate_h0, Q_h1, gate_h1, ...]`,
  not contiguous `[Q_all, gate_all]`. Must reshape to heads before splitting.
- **Native multimodal**: Early-fusion ViT processes images in the same
  latent space as text — no bolted-on vision encoder.

Each adapter stores model-family-specific defaults (sampling parameters,
thinking mode, presence penalty) via `recommended_defaults()`. These
are merged into the system config when a model is first loaded.

| Model             | Params | Q4 Size | CPU tok/s (16GB) | Use case          |
|-------------------|--------|---------|------------------|-------------------|
| Qwen3-0.6B       | 0.6B   | ~400 MB | 50-100+          | Prototype/testing |
| Qwen3.5-2B       | 2B     | ~1.2 GB | 20-40            | Lightweight tasks |
| Qwen3.5-4B (MM)  | 4B     | ~2.5 GB | 12-25            | Multimodal field  |
| Qwen3-8B         | 8B     | ~4.5 GB | 5-12             | Full analytical   |
| Qwen3.5-9B       | 9B     | ~5 GB   | 5-10             | Best small-scale  |

### Thinking Modes

Qwen 3 and 3.5 models support thinking (explicit reasoning chain) and
non-thinking (direct response) modes, controlled via the
`enable_thinking` parameter in `tokenizer.apply_chat_template()`.

Non-thinking is the default — structured output, no wasted tokens.
Thinking mode can be enabled per-stage in the template for analytical
stages where step-by-step reasoning improves quality. The system-wide
default is set in the Config tab and stored in `courier_config.json`;
per-stage template overrides take precedence.

```json
{
  "label": "Risk Integration",
  "thinking": true,
  "system_prompt": "..."
}
```

### Scaling Beyond 9B

On 16 GB RAM, 13B Q4_K_M fits with a short context window at 3-6 tok/s.
Above 13B requires disk offload and drops below 1 tok/s — viable only
for overnight batch jobs. On 32 GB RAM or with a consumer GPU, 30B-class
models become practical. Same code path, more layers, slower clock.

Quantization (GGUF Q4_K_M) is the recommended format for CPU inference.
Q5_K_M for arithmetic-heavy workloads. Below Q4, arithmetic reasoning
degrades sharply.


## Template

The template is the experimental apparatus. It carries full provenance
metadata and defines a multi-stage inference pipeline. It is the complete,
reproducible specification of what Courier does in a cycle.

### Structure

```json
{
  "template": {
    "id": "eruption_risk_v2",
    "name": "Volcanic Eruption Risk Assessment",
    "description": "Multi-stage CoT pipeline for eruption risk",
    "version": "2.0.0",
    "created": "2026-05-24T08:00:00Z",
    "updated": "2026-05-24T08:00:00Z",
    "author": {
      "name": "J. Ostrander",
      "organization": "Field Research Group",
      "contact": ""
    },
    "project": {
      "id": "volcan-norte-2026",
      "name": "Volcán Norte Monitoring Campaign",
      "description": "Continuous eruption risk assessment for the 2026 field season"
    },
    "software": {
      "courier_version": "0.1.0",
      "min_courier_version": "0.1.0"
    },
    "notes": {
      "docnotes": "Stages 1-2 process sensor domains independently. Stage 3 integrates model summaries only. Stage 4 provides adversarial review."
    }
  },

  "model": {
    "id": "Qwen/Qwen3-8B",
    "dtype": "bfloat16",
    "max_new_tokens": 2048,
    "temperature": 0.3,
    "top_p": 0.9
  },

  "data": {
    "sources": {
      "co2_north": {
        "adapter": "json_api",
        "endpoint": "http://192.168.1.10/api/readings",
        "params": { "window": "48h", "fields": ["timestamp", "ppm", "temperature"] },
        "budget_tokens": 800,
        "aggregation": "downsample_30min"
      },
      "seismic": {
        "adapter": "custom",
        "module": "adapters.seismometer",
        "params": { "event_threshold": 1.0, "summary": "frequency_and_magnitude" },
        "budget_tokens": 400
      },
      "weather": {
        "adapter": "json_api",
        "endpoint": "http://192.168.1.20/api/current",
        "budget_tokens": 200
      }
    }
  },

  "stages": [
    {
      "label": "CO₂ Analysis",
      "input": { "sources": ["co2_north", "co2_south"] },
      "system_prompt": "You are a geochemist..."
    },
    {
      "label": "Seismic Analysis",
      "input": { "sources": ["seismic"] },
      "system_prompt": "You are a seismologist..."
    },
    {
      "label": "Risk Integration",
      "thinking": true,
      "input": { "prior": "all", "sources": ["weather"] },
      "system_prompt": "You are a volcanologist..."
    },
    {
      "label": "Critical Review",
      "input": { "prior": "last" },
      "system_prompt": "You are a methodological skeptic..."
    }
  ]
}
```

### Template Fields

**Metadata** — `id`, `name`, `description`, `version`, timestamps.

**Author** — `name`, `organization`, `contact`. Provenance.

**Project** — `id`, `name`, `description`. Links to a research campaign.

**Software** — `courier_version`, `min_courier_version`. Compatibility.

**Notes** — `docnotes`. Design rationale. Included in exports.

**Model** — model ID, precision, generation parameters. Shared across
stages unless overridden.

**Data sources** — each source has an adapter type, connection parameters,
a token budget, and optional aggregation directives.

**Stages** — ordered chain-of-thought blocks. Each defines a system prompt,
input source, optional thinking mode, and optional parameter overrides.

### Stage Input

```json
{ "sources": ["co2_north", "co2_south"] }
{ "prior": "last" }
{ "prior": "all" }
{ "prior": "all", "sources": ["weather"] }
```

### Defaults

A minimal template:

```json
{
  "template": { "id": "minimal", "name": "Minimal Template" },
  "model": { "id": "Qwen/Qwen3-0.6B" },
  "stages": [
    {
      "label": "Analysis",
      "system_prompt": "Summarize the following data.",
      "input": { "sources": ["default"] }
    }
  ]
}
```

Missing fields populate with system defaults.


## Data Adapters

An adapter sits between a data source and the context window. It connects,
queries, aggregates, and returns model-ready text within a token budget.

### Interface

```python
class DataAdapter:
    def connect(self, source_config: dict) -> None:
        """Bind to the data source."""

    def fetch(self, token_budget: int, params: dict) -> str:
        """Query, aggregate, render. Returns text ≤ token_budget tokens."""
```

### Built-in Adapters

**json_api** — fetch JSON endpoint, extract fields, aggregate by time
window, render as markdown table. Handles pagination.

**json_file** — read local JSON files, arrays, or newline-delimited JSONL.
Flatten nested structures, aggregate, render as markdown tables or
key-value blocks. Handles append-only log files.

**csv_file** — read CSV files. Column selection, time filtering,
aggregation. Renders as markdown table.

**sqlite_query** — execute SQL against a local database. Render as table.

**directory** — read text files from a path. Concatenate. Truncate.

**verbatim** — pass through text as-is.

### Custom Adapters

Python module implementing `DataAdapter`. Drop in `adapters/`, reference
by module path in the template.

### Token Budget

Each source declares `budget_tokens`. The pipe step allocates:

```
Total context window
  - system prompt tokens
  - response budget (max_new_tokens)
  = available for data → divided proportionally
```


## Operational Model

Courier runs a loop with three phases and a counter.

```
        ┌──────────────────────────────────────────┐
        │                                          │
        ▼                                          │
   ┌─────────┐     ┌─────────┐     ┌─────────┐    │
   │ COLLECT  │────▶│  INFER  │────▶│ REPORT  │────┘
   │          │     │         │     │         │  cycles_remaining -= 1
   │ Always   │     │ Snapshot│     │ Write   │
   │ running  │     │ at T₀   │     │ output  │
   └─────────┘     └─────────┘     └─────────┘
        │
        │  (no data OR cycles_remaining == 0)
        ▼
   ┌─────────┐
   │ STANDBY │
   └─────────┘
```

**Collect** — data arrives continuously. Stored in SQLite with source ID,
timestamp, checksum (SHA-256), and `consumed = 0`.

**Infer** — triggered by threshold, schedule, or manual request (including
from the dashboard's Run tab). Snapshots unconsumed data. Executes the
template's stage pipeline.

**Report** — writes output to the `export/` directory and the database.
Marks data consumed. Decrements cycle counter.

**New data** is `consumed = 0`. A corrected reading is a new record.

```python
@dataclass
class CycleConfig:
    max_cycles: int = 0         # 0 = unlimited; N = run N then stop
    trigger_threshold: int = 0  # 0 = trigger when any data exists
    schedule_cron: str = ""     # overrides threshold if set
    auto_resume: bool = True    # resume interrupted cycles on startup
```

A cycle has two dimensions: **depth** (number of stages) and **length**
(tokens generated per stage).

### Session Recovery

On startup, Courier checks for an interrupted cycle (status = inferring
or paused with a valid checkpoint).

When `auto_resume = true` (the default): Courier logs the recovery event,
resumes from the last valid checkpoint, and continues the cycle. No human
action required. The ops dashboard shows the recovery in the cycle log:
"resumed from checkpoint at generation step 847 after interruption."
This is the correct default for unattended remote installations where
there is no operator present to restart manually.

When `auto_resume = false` (set explicitly for attended operation): the
interrupted cycle remains in a paused state. The dashboard shows the
interrupted state and the operator decides to resume or reset via the
config mode. Use this when sitting at the machine and reconfiguring
between campaigns.

Data collection resumes immediately on startup regardless of
`auto_resume` — the fast loop is always running.

### Output and Export

Cycle results are stored in SQLite and written as files to the `export/`
directory under the application root. The export path is configurable
per-cycle via the CLI or the dashboard's Run tab, defaulting to
`./export/`. Results are exportable as markdown or JSON from the
dashboard's Results tab via browser download.


## Inference Engine

A standard transformer decoder forward pass, reorganized so that only one
layer's weights occupy RAM at a time.

### Layer-Streaming Forward Pass

For each new token:

```
1.  Load embedding weights, compute input embeddings
2.  For each layer 0..N:
    a.  Load layer weights from shard
    b.  Read KV cache (RAM if resident, disk if spilled)
    c.  Run attention + MLP
    d.  Store updated KV cache (RAM-first, spill if needed)
    e.  Release layer weights
3.  Load LM head, compute logits, sample next token
4.  Every checkpoint_interval steps: flush dirty KV pages, write journal
5.  Repeat until stop token or max_new_tokens
```

### Shard Manager

Pre-staged safetensors shards. One persistent `safe_open` context for the
entire inference session. Per-layer tensors loaded on demand via
`f.get_tensor(key)` — mmap-backed, only the requested pages are read.

```python
class ShardManager:
    def __init__(self, model_path: Path, adapter: ModelAdapter): ...
    def load_layer(self, layer_idx: int, dtype: torch.dtype) -> dict[str, Tensor]: ...
    def load_embedding(self, dtype: torch.dtype) -> Tensor: ...
    def load_lm_head(self, dtype: torch.dtype) -> Tensor: ...
```

### KV Cache

RAM-first. LRU spill to disk. Append-only on disk. Dirty pages flush only
at checkpoint boundaries.

```python
class KVCacheManager:
    def __init__(self, max_ram_layers: int, cache_dir: Path,
                 n_layers: int, dtype: torch.dtype): ...
    def write(self, layer_idx: int, k: Tensor, v: Tensor) -> None: ...
    def read(self, layer_idx: int) -> tuple[Tensor, Tensor]: ...
    def flush(self) -> None: ...
    def clear(self) -> None: ...
```

### Checkpointing and Resume

The unit of durable progress is a single generated token. Inference on edge
hardware is slow — a stage can be hours of work — so progress is *banked* in
slices: every `checkpoint_interval` tokens the engine writes one atomic
SQLite row recording the work done so far.

```python
@dataclass
class CheckpointState:
    cycle_id: str
    stage_index: int
    generation_step: int      # 0-indexed token step within the stage
    tokens: list[int]         # every token generated so far
    position: int             # RoPE position offset
    rng_state: bytes | None   # sampler RNG — captured for an exact resume
    kv_cache_dir: str | None  # reserved; unused in v1 (see below)
    prompt: str | None        # the stage prompt, pinned to this checkpoint
```

A checkpoint is *self-contained*: it pins the exact prompt the banked tokens
were generated against. Resume therefore depends on nothing in memory and
nothing outside this single row.

**Re-prefill resume.** A checkpoint deliberately does not store the KV cache.
On resume the in-progress stage re-prefills `[pinned prompt + banked tokens]`
in one forward pass — rebuilding the KV cache exactly — then restores the
sampler RNG and continues. The banked tokens are re-fed, never lost, and the
continuation is token-for-token identical to what the interrupted run would
have produced. Re-prefill is a single parallel forward pass: fast relative to
generation but not free — its cost scales with how far the stage had
progressed (seconds to minutes, to recover hours of work).

**Stage-level durability.** Each completed stage is persisted to
`cycle_stages` the moment it finishes, not batched at end of cycle. A crash
mid-cycle leaves every finished stage intact; recovery reuses them from the
database and re-runs only the stage that was in flight.

**Recovery.** Recovery is driven entirely by durable DB state. On startup
Courier looks for a cycle still marked `inferring` or `paused`; if found, it
re-prefills from that cycle's latest checkpoint. This is re-entrant — a crash
*during* recovery simply leaves the cycle interrupted for the next startup to
pick up. Whether recovery runs automatically or waits for the operator is
governed by `auto_resume` (see Session Recovery). A cycle's checkpoints are
discarded once it completes cleanly.

**Future upgrade — instant revival.** v1 rebuilds the KV cache by re-prefill.
A future option is to persist the KV cache to disk alongside each checkpoint,
making resume zero-recompute — "instant revival." It is deliberately out of
v1: the KV cache is large and grows with sequence length, so on storage-
constrained edge hardware it spends a scarce resource to optimize a rare
event, and writing it atomically alongside the token row introduces a
two-write consistency hole. The `kv_cache_dir` field is reserved for this
path. Whichever way it evolves, the token-list checkpoint remains the single
source of truth.

### SSD Wear Monitoring

Write volume tracked per cycle and cumulatively. Exposed via `/api/status`
and the dashboard's System panel.


### Output text mechanics (engine/textproc.py)

Torch-free by design so cold probes can pin every rule. Think-block
handling: with thinking off, the assistant turn is primed with the
Qwen3-family closed-think pair so the model spends zero generated tokens
on scaffolding; empty `<think></think>` pairs are stripped always, closed
blocks are stripped whenever thinking is off (truncated or not), unclosed
blocks are left intact, and a strip never blanks an output. The
truncation banner is appended after token accounting — it is the UI
talking, never model output. The infer function returns
`(text, generated_token_count)`; the pipeline accepts bare strings from
stubs, and receipts prefer the real count (`pipeline.stage_token_count`)
over the legacy chars//4 estimate.

## Model Adapters

One adapter per model family. Auto-detection via `model_type` in
`config.json`.

| Adapter  | model_type | Coverage                          | Origin    |
|----------|-----------|-----------------------------------|-----------|
| Qwen2    | `qwen2`   | Qwen 2.5 0.5B–72B                | From TAGM |
| Qwen3    | `qwen3`   | Qwen 3 0.6B–14B                  | New       |
| Qwen3.5  | `qwen3_5` | Qwen 3.5 0.8B–9B (edge-optimized)| New       |
| Llama3   | `llama`   | Llama 3 / 3.1 / 3.2 / 3.3 8B–70B| From TAGM |

New families: implement `ModelAdapter`. No engine changes.


## Multimodal Readiness

Qwen3.5-4B with native multimodal is the forward target. The architecture
accommodates it without structural changes: adapters declare vision
encoders, shard manager loads encoder weights, pipeline assembles mixed
inputs, KV cache doesn't care.


## Dashboard

The dashboard is a single self-contained HTML file (`static/dashboard.html`)
with vanilla JavaScript and CSS. No build step, no dependencies. FastAPI
serves it as a static file at `/`.

### Architecture

A small `h()` helper builds DOM elements. View renderers produce DOM trees
from a data object. The API layer fetches from the server on every poll.
If the connection fails, the dashboard shows an explicit, unmistakable
error state — a full-screen "NOT CONNECTED" indicator with the last
successful contact time and the endpoint it was trying to reach. No mock
data, no silent fallback, no stale renders. The operator always knows
whether they are looking at real data or nothing.

Tabs: DATA, RUN, MONITOR, HISTORY, NETWORK (the single-node identity
view; see *Node Identity & Network*). Cycle receipts pop out into their
own windows and self-heal: fetch/parse failures render an amber banner
with the reason and a RETRY, and a later successful fetch repairs an
open popout.

**Payload law** (binding): every payload the UI renders must have an
on-demand fetch, a retry path, and a loud absent state. SSE is an
optimization, never the only road to the data. (Established after two
popout-race bugs; cycle configs and stage results both obey it.)

A poll loop calls `getData() → render()` every 2 seconds. Connection
failures trigger the error state immediately. Recovery is automatic —
when the API responds again, the dashboard resumes normal rendering.

The dashboard authenticates with the same bearer token mechanism as the
API. Token is stored in `localStorage` (browser-side). If the token is
missing or rejected, the dashboard shows an authentication prompt, not
an empty page.

### Modes

The dashboard has two functional modes within a single page, visually
separated in the tab bar by a divider. Operations tabs use standard
styling; configuration tabs highlight in amber when active. Each panel
header carries a mode badge (green "OPS" or amber "CONFIG").

**Operations mode** — what you look at while Courier is working. Read-only,
status-driven, always accessible. Any team member can observe from any
device on the network. Shows recovery events when auto-resume activates
after an interruption.

**Configuration mode** — what you use to set up and launch. Write access,
form-driven, authenticated. Used at deployment time and between campaigns.
When an interrupted cycle exists and `auto_resume = false`, this mode
presents the choice to resume or reset.

### Tooltips

Every technical metric and form label carries a CSS tooltip (hover to
reveal) with a plain-language explanation written for non-specialist
operators. A biologist who has never tuned an LLM can hover "Checkpoint
Interval" and read: "How often to save progress. Lower = more disk
writes but less lost work on power loss. Higher = less SSD wear."

Tooltips are CSS-only (`[data-tip]::after` pseudo-element), require no
JavaScript event handling, and auto-position left/right to avoid
viewport overflow. They cover:

- All gauge labels (RAM, Disk, CPU, Generation, Layer)
- All stat counters (Tokens/hr, Generated, Checkpoints, Records)
- System panel sections (SSD Wear, KV Cache, Auto-Resume)
- Thinking mode indicator (◆)
- All Run tab form labels (Cycles, Temperature, Top-p, Max Tokens,
  Checkpoint Interval, Throttle, Output Destination)
- Key status concepts (unconsumed record count)

### Tabs

**Operations mode:**

**Monitor** — real-time operational view. Active cycle progress with
stage timeline, generation and layer gauges, tokens/hour, estimated
completion time. System health: RAM, disk, CPU gauges, SSD lifetime
writes, KV cache RAM/disk split. Data ingestion: per-source cards
showing record counts, rates, and last-seen times. Model and template
info. Displays recovery events when auto-resume activates after
power loss.

**Data** — browse ingested records. Filter by source, consumed/unconsumed
status, and text search. Click to expand and inspect raw content
(JSON pretty-printed). Shows record ID, source, timestamp, mime type,
and which cycle consumed it.

**Results** — view prior cycle outputs. Cycle selector in sidebar.
Stage-by-stage output display with metadata (tokens, generation time,
thinking mode). Each stage is collapsible. Export buttons download the
full result as markdown or JSON via browser blob download.

**History** — cycle log. Status, record counts, token counts, timing,
error messages. Rows are clickable — completed cycles navigate to
the Results tab.

**Configuration mode:**

**Run** — workflow runner. Select template and model from dropdowns.
Set cycles, temperature, top-p, max tokens, checkpoint interval, and
throttle. Specify output destination (defaults to `./export/`, reset
button). Summary box previews the full configuration. Run button
submits to `/api/cycle/trigger`. Right panel shows unconsumed data by
source so the operator knows what the cycle will process.

**Config** — system configuration and template metadata. Stage pipeline
visualization with thinking mode indicators. Auto-resume toggle.
Model management.


## Logging and Diagnostics

### Cycle Log

```python
@dataclass
class CycleLog:
    cycle_id: str
    cycle_number: int
    template_id: str
    template_version: str
    model_id: str
    started_at: float
    completed_at: float
    status: str
    stages: list[StageLog]
    data_snapshot: dict
    tokens_generated: int
    disk_writes_mb: float
    peak_ram_mb: float
    checkpoint_count: int
    errors: list[str]
    tracebacks: list[str]
```

### Stage Log

```python
@dataclass
class StageLog:
    stage_index: int
    label: str
    system_prompt_hash: str
    input_sources: list[str]
    input_token_count: int
    output_token_count: int
    thinking_enabled: bool
    generation_time_seconds: float
    tokens_per_hour: float
    checkpoint_count: int
    error: str
    traceback: str
```

### Traceback Capture

All exceptions captured with full tracebacks. Stored in cycle log and
log file. Stage failures are recorded; the cycle continues or halts per
template configuration.

### Output

SQLite (structured, queryable) and plain text log file (`tail -f`
friendly). Log level configurable.

```
~/.courier/logs/courier.log
~/.courier/courier.db
```


## Security

For networked deployments (FastAPI mode).

**Transport** — TLS by default. Auto-generated self-signed cert.
Custom cert/key supported. `--insecure` for development only.

**Authentication** — token-based. Generated on first start, stored
hashed. Multiple tokens with role scoping (read-write, read-only).
Sensors authenticate with the same mechanism. Dashboard stores token
in browser localStorage.

**Data integrity** — SHA-256 checksums on ingested records and outputs.

**Encryption at rest** — delegated to LUKS, FileVault, BitLocker,
or SQLCipher.

**Write-authorization posture** — one pure decision point,
`core/security.py::write_posture()`, with four modes; on conflicting
settings the safest wins:

```
token-required   COURIER_REQUIRE_TOKEN=1 — bearer token for every write;
                 beats everything, including the insecure bypass.
insecure-bypass  COURIER_INSECURE=1 — all write auth waived (dev only). LOUD.
proxy-trusted    CODESPACES env (opt out: COURIER_TRUST_PROXY=0) or
                 COURIER_TRUST_PROXY=1 — the loopback-peer check is skipped
                 because an authenticating proxy fronts the node. LOUD:
                 correct only while that proxy actually authenticates
                 (e.g. a Codespaces port kept Private).
local-origin     the turnkey default — tokenless writes only from a
                 loopback TCP peer with a local Host and no cross-site
                 fetch marker; remote writes need the bearer token.
```

The effective posture is printed at boot (with a `⚠ AUTH WARNING` when
trust is broad), reported by `GET /api/node`, and rendered on the
dashboard's NETWORK tab. The underlying truth: a reverse proxy destroys
both transport facts the tokenless path authenticates by (peer address,
Host), so behind one the gate can only be as trustworthy as the proxy's
own door.


## Data Ingestion

### Endpoints

```
POST /api/ingest              Single record (JSON body)
POST /api/ingest/file         File upload
POST /api/ingest/batch        Multiple records
GET  /api/ingest/status       Buffer stats
GET  /api/ingest/records      Paginated record list (filterable)
GET  /api/ingest/records/{id} Single record with content
```

File watcher monitors a directory for automatic ingestion.

### Schema

```sql
CREATE TABLE ingestion (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    source_id   TEXT NOT NULL,
    timestamp   REAL NOT NULL,
    content     TEXT NOT NULL,
    mime_type   TEXT DEFAULT 'text/plain',
    byte_size   INTEGER,
    checksum    TEXT,
    ingested_at REAL NOT NULL,
    consumed    INTEGER DEFAULT 0,
    cycle_id    TEXT
);

CREATE INDEX idx_ingestion_unconsumed ON ingestion(consumed) WHERE consumed = 0;
CREATE INDEX idx_ingestion_source ON ingestion(source_id, timestamp);
```


## Corpus & Retrieval

Reference knowledge (regulations, registries, watchlists) lives in a
separate FTS5 index, `corpus.db`, beside the ledger — never in it.

**In:** gator's `digestor.py` chunks documents deterministically
(section-aware for prose, one-record-per-line for registries; spans and
hashes map every chunk back into its source) and writes corpus-typed
envelopes into the import folder. Courier's ingest routes them into the
index; re-ingesting a document replaces its chunks rather than
duplicating them. Chunking dials: `--chunk-chars`, `--min-chunk-chars`.

**Out:** the `corpus_search` data adapter retrieves passages at template
render time via BM25, using a fixed `query`, terms derived from the
cycle's own records (`from_records`, capped by `max_terms`), or both — so
a hull ID seen by a camera trap pulls its registry entry and the
regulations that bear on it. Missing corpus or empty terms fail loud in
the rendered block, never silently.

## Node Identity & Network

A network of one is still a network. Each node has a stable **Courier
ID** (`courier-<12 hex>`), minted on first request and persisted in the
ledger's `meta` key/value table — it survives restarts and travels with a
DB export. `GET /api/node` is the node's self-description: identity,
interface addresses, reach/scheme, auth posture, uptime, current and
last-completed cycle, lifetime totals (cycles · tokens · metered joules),
corpus holdings, and an honest `peers: 0` block. The dashboard's NETWORK
tab renders it. The envelope-exchange protocol between nodes (hash-chained
signed receipts, witness countersignatures) is designed but unbuilt; the
Courier ID is its first brick — future receipts sign as this name.

## Energy Accounting

Every completed cycle records what it cost. `engine/energy.py` picks the
best instrument the host offers, in order:

```
rapl      /sys/class/powercap counters (CPU+DRAM domains; wraparound
          handled; subdomains excluded to avoid double-counting)
battery   discharge telemetry, integrated by a sampling thread — only
          meaningful ON battery; on AC the meter refuses to fake it
estimate  CPU-time × the 'watts_per_core' setting. A model, not a
          measurement — and every receipt says so
```

One meter per process (`engine.worker.get_meter`), so the method is
stable across a run and receipts are comparable. The worker banks
`energy_j` + `energy_method` on the cycle row; receipts, the history
tab, and the NETWORK tab's lifetime totals surface them. Doctrines:
an unmetered cycle is `None`, never 0 (absent ≠ free), and the method
label always travels with the number. Dials (`watts_per_core`,
`energy_sample_interval`) are ordinary settings — Settings → System —
live-applied on save; there is deliberately no env-var path.

## Cycle Management

### Schema

```sql
CREATE TABLE cycles (
    id              TEXT PRIMARY KEY,
    cycle_number    INTEGER NOT NULL,
    status          TEXT NOT NULL,
    config          TEXT NOT NULL,
    template_id     TEXT NOT NULL,
    created_at      REAL NOT NULL,
    infer_started   REAL,
    completed_at    REAL,
    progress        TEXT,
    result_path     TEXT,
    error           TEXT,
    tokens_generated INTEGER DEFAULT 0,
    disk_writes_mb  REAL DEFAULT 0
);

CREATE TABLE cycle_stages (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    cycle_id    TEXT NOT NULL,
    stage_index INTEGER NOT NULL,
    label       TEXT NOT NULL,
    thinking    INTEGER DEFAULT 0,
    input_tokens INTEGER,
    output_tokens INTEGER,
    output_text TEXT,
    time_seconds REAL,
    status      TEXT NOT NULL,
    error       TEXT,
    FOREIGN KEY (cycle_id) REFERENCES cycles(id)
);
```

### API

```
GET    /api/cycle/status            Current state + progress
POST   /api/cycle/trigger           Trigger a cycle (accepts config overrides)
POST   /api/cycle/pause             Checkpoint and stop
POST   /api/cycle/resume            Resume from checkpoint
POST   /api/cycle/cancel            Cancel
GET    /api/cycles                  History (paginated)
GET    /api/cycles/{id}             Cycle detail
GET    /api/cycles/{id}/result      Stage-by-stage output
GET    /api/cycles/{id}/export/md   Download as markdown
GET    /api/cycles/{id}/export/json Download as JSON

GET    /api/models                  List available
GET    /api/models/{id}             Detail
GET    /api/models/{id}/verify      Shard integrity check
POST   /api/models                  Register
DELETE /api/models/{id}             Unregister

GET    /api/templates               List available
GET    /api/templates/{id}          Detail

GET    /api/status                  System health + SSD wear
```


## Entry Points

### FastAPI Server (networked deployments)

```bash
courier start                           # HTTPS, foreground
courier start --daemon                  # background
courier start --insecure                # development
```

Serves the dashboard at `/` and the API at `/api/*`.

### CLI (headless operation)

```bash
courier run eruption_risk \
    --model /mnt/models/Qwen3-8B \
    --data ./field_data/ \
    --cycles 1 \
    --output ./export/
```

### Library (Jupyter, scripts, notebooks)

```python
from courier import Engine, Template

template = Template.load("eruption_risk.json")
engine = Engine(model_path="/mnt/models/Qwen3-8B")

result = engine.run_cycle(
    template=template,
    data={"co2_north": "data/co2_north.csv"},
    output_dir="./export/",
)
print(result.stages[-1].output)
```


## CLI Reference

```bash
# Server
courier status
courier start [--daemon] [--insecure] [--cert PATH --key PATH]

# Auth
courier token create --name <name> [--read-only]
courier token list
courier token revoke <name>

# Models
courier model add <path>
courier model list
courier model verify <id>

# Templates
courier template list
courier template show <id>
courier template add <file.json>

# Data
courier ingest <file_or_dir> [--source-id <id>]
courier data status
courier data list [--source <id>] [--unconsumed]
courier data show <record_id>

# Run
courier run <template_id> --model <model_id> [--cycles N] [--output PATH]
courier cycle status
courier cycle pause
courier cycle resume
courier cycle cancel

# Results
courier result latest
courier result list
courier result <cycle_id>
courier export <cycle_id> -o report.md
courier export <cycle_id> --json -o report.json
```


## File Structure

```
courier/
├── src/
│   ├── __init__.py
│   ├── engine/
│   │   ├── __init__.py
│   │   ├── streamer.py             # Layer-streaming forward pass
│   │   ├── kv_cache.py             # RAM-first KV cache
│   │   ├── checkpoint.py           # Journal
│   │   ├── sampler.py              # Token sampling
│   │   ├── energy.py               # Joules-per-verdict instrument ladder
│   │   ├── textproc.py             # Think/truncation text rules (torch-free)
│   │   └── config.py               # Configuration registry
│   ├── core/
│   │   ├── __init__.py
│   │   ├── adapter/
│   │   │   ├── __init__.py
│   │   │   ├── base.py             # ModelAdapter ABC
│   │   │   ├── registry.py         # Auto-detection via config.json
│   │   │   ├── qwen2.py
│   │   │   ├── qwen3.py
│   │   │   ├── qwen35.py
│   │   │   └── llama3.py
│   │   ├── shard_manager.py
│   │   ├── db.py                   # SQLite persistence (ledger + meta)
│   │   ├── corpus.py               # FTS5 reference-knowledge index
│   │   ├── cache.py                # Resource monitoring
│   │   └── security.py             # TLS, tokens, write posture
│   ├── data/
│   │   ├── __init__.py
│   │   ├── adapter_base.py         # DataAdapter ABC
│   │   ├── adapters/
│   │   │   ├── json_api.py
│   │   │   ├── json_file.py
│   │   │   ├── csv_file.py
│   │   │   ├── sqlite_query.py
│   │   │   ├── directory.py
│   │   │   └── verbatim.py
│   │   ├── ingest.py               # Ingestion logic + file watcher
│   │   └── parsers.py
│   ├── pipeline.py                 # Stage pipeline execution
│   ├── template.py                 # JSON loading, validation, defaults
│   ├── logging.py                  # Structured logging + tracebacks
│   ├── server.py                   # FastAPI wrapper + API endpoints
│   └── cli.py                      # CLI entry point
├── static/
│   └── dashboard.html              # Production UI (served by FastAPI)
├── adapters/                       # User custom data adapters
├── templates/
│   └── builtin/
│       ├── field_report_summary.json
│       ├── sensor_anomaly.json
│       └── observation_extract.json
├── models/                         # Pre-staged model shards
├── data/                           # Default data/ingestion directory
├── export/                         # Default output directory
├── results/
├── requirements.txt
├── start.sh
└── README.md
```


## Dependencies

Core (library mode, all offline-capable):

- **torch** (CPU) — inference
- **safetensors** — partial tensor extraction
- **transformers** — tokenizer, model config
- **psutil** — resource monitoring

Server mode adds:

- **fastapi** + **uvicorn** — HTTPS server
- **cryptography** — TLS, token hashing
- **aiofiles** — async I/O
- **watchdog** — directory watcher

Dashboard has zero dependencies (vanilla HTML/JS/CSS).


## Lineage from TAGM

| Component           | TAGM Source                | Courier Usage                         |
|---------------------|----------------------------|---------------------------------------|
| Adapter ABC         | `core/adapter/base.py`     | Extended for layer-boundary resolution|
| Adapter registry    | `core/adapter/registry.py` | Extended for Qwen3/3.5 auto-detect    |
| Qwen2 adapter       | `core/adapter/qwen2.py`    | Base for Qwen3 adapter                |
| Llama3 adapter      | `core/adapter/llama3.py`   | Extended with layer loading           |
| Mmap storage        | `core/deltas/store.py`     | Pattern reused for KV cache           |
| Shard streaming     | `core/deltas/compute.py`   | Core of the layer streamer            |
| SQLite patterns     | `core/db.py`               | Schema adapted for cycles/ingest      |
| Config registry     | `engine/config.py`         | Same pattern                          |
| Resource monitoring | `core/cache.py`            | Direct reuse                          |
| Static HTML UI      | `static/index.html`        | Pattern reused for dashboard          |


## Open Questions

**KV cache on-disk format.** RAM-first with disk spillover is settled.
The on-disk representation needs prototyping and benchmarking.

**Layer-streaming feasibility.** The concept needs a working prototype
to validate end-to-end on reference hardware.
