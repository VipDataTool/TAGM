#!/usr/bin/env python3
"""Probe: Datagator adapters + cap + config resolution + the run() conduit.

Cold — no network. Feeds canned responses shaped like the real public APIs
through each adapter's parse(), checks the cap and the config contract, and
drives Datagator.run() end-to-end with the network stubbed. (Live fetch runs in
a networked environment.)

    cd gator && python probe_datagator.py
"""
import json
import sys
import tempfile
import datetime as _dt
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import datagator as dg  # noqa: E402
from datagator import (Adapter, UsgsGeojson, SwpcProducts, SwpcJson, IssPoint,  # noqa: E402
                       SHAPES, resolve_sources, cap_recent, Datagator)

_fails = []


def check(name, cond):
    print(f"  {'PASS' if cond else 'FAIL'}  {name}")
    if not cond:
        _fails.append(name)


USGS = {"type": "FeatureCollection", "features": [
    {"id": "us100abcd", "properties": {"mag": 4.2, "place": "100km S of Nowhere",
        "time": 1716800000000, "type": "earthquake", "url": "http://x"},
     "geometry": {"coordinates": [-120.5, 38.1, 10.2]}},
    {"id": "us100efgh", "properties": {"mag": 1.1, "place": "near Here",
        "time": 1716800600000, "type": "quarry blast"},
     "geometry": {"coordinates": [-118.0, 34.0, 3.0]}},
]}

KP = [["time_tag", "Kp", "a_running", "station_count"],
      ["2024-05-27 00:00:00", "2", "5", "8"],
      ["2024-05-27 03:00:00", "3", "7", "8"]]

XRAY = [{"time_tag": "2024-05-27T00:00:00Z", "satellite": 16, "flux": 1.2e-7,
         "energy": "0.1-0.8nm"},
        {"time_tag": "2024-05-27T00:00:00Z", "satellite": 16, "flux": 3.4e-9,
         "energy": "0.05-0.4nm"}]

ISS = {"name": "iss", "latitude": 12.3, "longitude": 45.6, "altitude": 420.1,
       "velocity": 27600.0, "visibility": "daylight", "timestamp": 1716800000}


def main():
    print("usgs adapter (parse)")
    q = UsgsGeojson({"url": "x"}).parse(USGS)
    check("two quakes", len(q) == 2)
    check("epoch from ms", q[0]["timestamp"] == 1716800000.0)
    check("depth from geometry", q[0]["depth_km"] == 10.2)
    check("lon/lat split", q[0]["lon"] == -120.5 and q[0]["lat"] == 38.1)
    check("mag carried", q[0]["mag"] == 4.2)

    print("swpc products adapter (Kp)")
    k = SwpcProducts({"url": "x"}).parse(KP)
    check("header dropped, 2 rows", len(k) == 2)
    check("zipped to dict", k[0]["Kp"] == "2" and k[0]["station_count"] == "8")
    check("time parsed to epoch", isinstance(k[0]["timestamp"], float))
    check("short input safe", SwpcProducts({"url": "x"}).parse([["h"]]) == [])
    ko = SwpcProducts({"url": "x"}).parse([
        {"time_tag": "2024-05-27 00:00:00", "Kp": "2", "a_running": "5", "station_count": "8"},
        {"time_tag": "2024-05-27 03:00:00", "Kp": "3", "a_running": "7", "station_count": "8"}])
    check("object form: value intact", ko[0]["Kp"] == "2")
    check("object form: not key==key", ko[0]["time_tag"] != "time_tag")
    check("object form: time parsed", isinstance(ko[0]["timestamp"], float))

    print("swpc json adapter (xray)")
    x = SwpcJson({"url": "x"}).parse(XRAY)
    check("two bands", len(x) == 2)
    check("iso-T-Z parsed", isinstance(x[0]["timestamp"], float))
    check("non-list safe", SwpcJson({"url": "x"}).parse({"x": 1}) == [])

    print("iss adapter")
    i = IssPoint({"url": "x"}).parse(ISS)
    check("one sample", len(i) == 1)
    check("epoch passthrough", i[0]["timestamp"] == 1716800000)
    check("lat/lon mapped", i[0]["lat"] == 12.3 and i[0]["lon"] == 45.6)
    check("missing fields safe", IssPoint({"url": "x"}).parse({}) == [])

    print("base adapter contract")
    check("base parse() is NotImplemented",
          _raises_type(lambda: Adapter({"url": "x"}).parse({}), NotImplementedError))

    print("cap_recent (the scoping primitive)")
    recs = [{"id": n, "timestamp": float(n)} for n in range(250)]
    capped = cap_recent(recs, 100)
    check("capped to 100", len(capped) == 100)
    check("keeps most-recent", capped[-1]["id"] == 249 and capped[0]["id"] == 150)
    check("chronological order out", [r["id"] for r in capped] == list(range(150, 250)))
    check("under-limit passes through", len(cap_recent(recs[:30], 100)) == 30)
    check("default limit is 100", len(cap_recent(recs)) == 100)
    mixed = [{"id": "no-ts"}] + [{"id": n, "timestamp": float(n)} for n in range(100)]
    check("timeless record dropped first", "no-ts" not in [r["id"] for r in cap_recent(mixed, 100)])

    print("shape registry")
    check("four shapes", set(SHAPES) == {"usgs_geojson", "swpc_products",
                                         "swpc_json", "iss_point"})
    check("shapes map to Adapter subclasses",
          all(isinstance(c, type) and issubclass(c, Adapter) for c in SHAPES.values()))
    check("shape binds the right adapter", SHAPES["usgs_geojson"] is UsgsGeojson)

    print("resolve_sources (config -> runnable specs)")
    cfg = {"sources": [
        {"source_id": "a", "shape": "usgs_geojson", "url": "http://a", "enabled": True, "limit": 50},
        {"source_id": "b", "shape": "swpc_json", "url": "http://b"},
        {"source_id": "c", "shape": "iss_point", "url": "http://c", "enabled": False},
    ]}
    specs = resolve_sources(cfg)
    check("disabled source excluded", [s["source_id"] for s in specs] == ["a", "b"])
    check("adapter class bound by shape", specs[0]["adapter_cls"] is UsgsGeojson)
    check("per-source limit carried", specs[0]["limit"] == 50 and specs[1]["limit"] is None)

    print("resolve_sources guardrails (loud failures)")
    check("unknown shape raises",
          _raises(lambda: resolve_sources({"sources": [{"source_id": "x", "shape": "made_up", "url": "u"}]})))
    check("missing shape raises",
          _raises(lambda: resolve_sources({"sources": [{"source_id": "x", "url": "u"}]})))
    check("empty config is empty, not an error", resolve_sources({}) == [])

    print("Datagator.run (the conduit, network stubbed)")
    tmp = Path(tempfile.mkdtemp())
    dg.http_json = lambda url, timeout=30: USGS if "quake" in url else ISS
    run_cfg = {"out_dir": str(tmp), "limit": 100, "sources": [
        {"source_id": "usgs_quakes", "shape": "usgs_geojson", "url": "http://quake", "enabled": True},
        {"source_id": "iss_position", "shape": "iss_point", "url": "http://iss", "enabled": True},
        {"source_id": "noaa_xray", "shape": "swpc_json", "url": "http://x", "enabled": False},
    ]}
    st = Datagator.run(run_cfg)
    files = sorted(f.name for f in tmp.glob("*.json"))
    check("writes enabled sources only", files == ["iss_position.json", "usgs_quakes.json"])
    check("status counts ok", st["ok"] == 2 and st["records"] == 3)
    check("status reports paths", all("path" in w for w in st["written"]))
    env = json.loads((tmp / "usgs_quakes.json").read_text())
    check("written file is a feed envelope",
          env.get("source_type") == "feed" and isinstance(env.get("records"), list))
    check("envelope carries the records", len(env["records"]) == 2)

    print("Datagator.run resilience + knobs")
    class Boom(Adapter):
        def produce(self): raise RuntimeError("device offline")
    SHAPES["boom"] = Boom
    tmp2 = Path(tempfile.mkdtemp())
    cfg2 = {"out_dir": str(tmp2), "limit": 100, "sources": [
        {"source_id": "good", "shape": "usgs_geojson", "url": "http://quake", "enabled": True},
        {"source_id": "bad", "shape": "boom", "url": "http://b", "enabled": True},
    ]}
    st2 = Datagator.run(cfg2, force_limit=1)
    check("one bad source reported not fatal",
          st2["ok"] == 1 and st2["errors"][0]["source_id"] == "bad")
    check("force_limit caps output", st2["written"][0]["records"] == 1)
    check("only filter selects subset",
          Datagator.run(cfg2, only=["good"])["sources"] == 1)
    del SHAPES["boom"]

    print()
    if _fails:
        print(f"FAILED ({len(_fails)}): " + ", ".join(_fails)); sys.exit(1)
    print("All Datagator probes passed.")


def _raises(fn):
    try:
        fn(); return False
    except ValueError:
        return True


def _raises_type(fn, exc):
    try:
        fn(); return False
    except exc:
        return True


if __name__ == "__main__":
    main()
