#!/usr/bin/env python3
"""Datagator — the configurable conduit between instruments and Courier.

One script. Instruments speak their own native tongue; Courier only ever sees
clean records bound for its SQL ledger. Every awkward translation in between is
quarantined here. Datagator reads datagator.json, runs each enabled source's
adapter, caps the result, and writes a JSON array of flat records into Courier's
import folder — the spot Courier's auto-ingest watches. That's the whole job.

An ADAPTER owns whatever it takes to get from one instrument's reality to clean
records: fetch, handshake, demodulation, parsing — all of it. A trivial source
is a few lines around a JSON GET; a radio telescope can be a hundred lines of
signal wrangling. Both are just adapters. The mess lives in the adapter, never
in the instrument and never in Courier.

  produce() -> [records]   is the whole contract. The default produce() fetches
  the source's `url` as JSON and hands it to parse(); an adapter that needs to
  do something else (talk to a device, decode a non-JSON wire format) overrides
  produce() and does its own thing. Each record carries a `timestamp` (epoch
  seconds) so Courier time-orders it.

Datagator shares a root with Courier and nothing more: it never imports Courier
and never reaches across the root. It only writes JSON into the import folder.

  python datagator.py                      # all enabled sources -> courier/import
  python datagator.py --feeds usgs_quakes  # subset by source_id
  python datagator.py --limit 50           # force a cap across all sources
  python datagator.py --config other.json  # use a different config
  python datagator.py --out /some/dir      # override destination
  python datagator.py --list               # show resolved sources and exit

At runtime (e.g. Courier's fetch/refresh button) call Datagator.run(config) ->
status dict. Stdlib only (urllib/json).
"""

from __future__ import annotations

import argparse
import datetime as _dt
import json
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

UA = "datagator/1.0 (+https://github.com/courier; edge inference feeder)"
HERE = Path(__file__).resolve().parent
DEFAULT_CONFIG_PATH = HERE / "datagator.json"
DEFAULT_OUT = HERE.parent / "courier" / "import"
LIMIT_CEILING = 100  # bounded by construction: no set exceeds this


# ── shared helpers ───────────────────────────────────────────────

def http_json(url: str, timeout: int = 30):
    """GET a URL and decode JSON. The default fetch path for simple sources."""
    req = urllib.request.Request(url, headers={"User-Agent": UA,
                                               "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def parse_iso(s):
    """Best-effort ISO-8601 / SWPC 'YYYY-MM-DD HH:MM:SS[.sss]' -> epoch seconds."""
    if not s or not isinstance(s, str):
        return None
    txt = s.strip().replace("T", " ").replace("Z", "")
    for fmt in ("%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
        try:
            d = _dt.datetime.strptime(txt, fmt).replace(tzinfo=_dt.timezone.utc)
            return d.timestamp()
        except ValueError:
            continue
    return None


def cap_recent(records, limit=100):
    """Keep the most-recent `limit` records, in chronological order. Records
    lacking a timestamp sort oldest, so they're dropped first over the cap."""
    def k(r):
        t = r.get("timestamp")
        return t if isinstance(t, (int, float)) else float("-inf")
    return sorted(records, key=k)[-limit:]


# ── adapters ─────────────────────────────────────────────────────
# One class per shape. The base owns the contract and the common JSON-GET path;
# each adapter overrides only what its instrument needs. Register each under a
# shape name in SHAPES at the bottom — that name is what datagator.json refers to.

class Adapter:
    """Base adapter: produce() -> [records].

    Default behavior covers the common case — fetch `url` as JSON, hand it to
    parse(). Simple sources implement only parse(). Sources that aren't a plain
    JSON GET (a device read, a non-JSON wire format, a multi-step handshake)
    override produce() and do whatever they need; the only promise is that
    produce() returns a list of flat record dicts, each ideally carrying a
    `timestamp` in epoch seconds.

    `kind` declares the source's cardinality, authoritatively, in code:
      - "series": one fetch returns a window of timestamped samples (already a
        time-series — USGS quakes, SWPC products/json).
      - "point":  one fetch returns a single current value (a referent — the ISS
        position right now). Point sources are what the fixed-duration poller
        assembles a time-series from.
    """

    kind = "series"

    def __init__(self, source: dict):
        self.source = source
        self.url = source.get("url")

    def produce(self) -> list[dict]:
        return self.parse(http_json(self.url))

    def parse(self, raw) -> list[dict]:        # override for a JSON-GET source
        raise NotImplementedError(
            f"{type(self).__name__} must implement parse() or override produce()")


class UsgsGeojson(Adapter):
    """USGS earthquake GeoJSON → one record per quake."""
    def parse(self, raw) -> list[dict]:
        out = []
        for f in (raw or {}).get("features", []):
            p = f.get("properties", {}) or {}
            g = (f.get("geometry") or {}).get("coordinates") or [None, None, None]
            t = p.get("time")  # milliseconds epoch
            out.append({
                "id": f.get("id"),
                "timestamp": (t / 1000.0) if isinstance(t, (int, float)) else None,
                "mag": p.get("mag"),
                "place": p.get("place"),
                "depth_km": g[2] if len(g) > 2 else None,
                "lon": g[0] if len(g) > 0 else None,
                "lat": g[1] if len(g) > 1 else None,
                "type": p.get("type", "earthquake"),
                "url": p.get("url"),
            })
        return out


class SwpcProducts(Adapter):
    """SWPC space-weather data → one record per row.

    Tolerates BOTH shapes SWPC ships for the same product:
      - header-row form:  [["time_tag","Kp",...], ["2024-...","2",...], ...]
      - object form:      [{"time_tag":"2024-...","Kp":"2",...}, ...]

    The object form used to fall through dict(zip(header, row)) and, because
    iterating a dict yields its keys, produced {key: key} rows with a null
    timestamp. We branch on the row shape.
    """
    def parse(self, raw) -> list[dict]:
        if not isinstance(raw, list) or not raw:
            return []

        # Object form: rows are already keyed; just stamp the time.
        if isinstance(raw[0], dict):
            out = []
            for rec in raw:
                if not isinstance(rec, dict):
                    continue
                r = dict(rec)
                r["timestamp"] = parse_iso(r.get("time_tag"))
                out.append(r)
            return out

        # Header-row form: first row names the columns, the rest are values.
        if len(raw) < 2:
            return []
        header = [str(h) for h in raw[0]]
        out = []
        for row in raw[1:]:
            if not isinstance(row, (list, tuple)):
                continue  # guard: never zip a dict/str against the header again
            rec = dict(zip(header, row))
            rec["timestamp"] = parse_iso(rec.get("time_tag"))
            out.append(rec)
        return out


class SwpcJson(Adapter):
    """SWPC plain-JSON arrays (e.g. GOES X-ray flux) → records as-is, timed."""
    def parse(self, raw) -> list[dict]:
        if not isinstance(raw, list):
            return []
        out = []
        for rec in raw:
            if not isinstance(rec, dict):
                continue
            r = dict(rec)
            r["timestamp"] = parse_iso(r.get("time_tag"))
            out.append(r)
        return out


class IssPoint(Adapter):
    """wheretheiss.at satellite position → a single position sample."""
    kind = "point"

    def parse(self, raw) -> list[dict]:
        if not isinstance(raw, dict) or "latitude" not in raw:
            return []
        return [{
            "timestamp": raw.get("timestamp"),  # already epoch seconds
            "lat": raw.get("latitude"),
            "lon": raw.get("longitude"),
            "altitude_km": raw.get("altitude"),
            "velocity_kmh": raw.get("velocity"),
            "visibility": raw.get("visibility"),
        }]


# Example of an adapter that owns its own fetch — the pattern your radio
# telescope (or any non-JSON instrument) follows. Override produce(), do
# whatever the instrument needs, return flat records. Uncomment + register.
#
# class RadioTelescope(Adapter):
#     def produce(self) -> list[dict]:
#         raw = self._read_device(self.source.get("device", self.url))
#         samples = self._demodulate(raw)
#         now = _dt.datetime.now(_dt.timezone.utc).timestamp()
#         return [{"timestamp": now, "freq_mhz": s.freq, "power_db": s.power}
#                 for s in samples]


SHAPES: dict[str, type] = {
    "usgs_geojson":  UsgsGeojson,
    "swpc_products": SwpcProducts,
    "swpc_json":     SwpcJson,
    "iss_point":     IssPoint,
    # "radio_telescope": RadioTelescope,
}


# ── config resolution (pure, cold-testable) ──────────────────────

def resolve_sources(config: dict) -> list[dict]:
    """Turn a config dict into runnable source specs (pure, no I/O).

    For each *enabled* source, bind its declared `shape` to an Adapter class and
    return {source_id, url, label, adapter_cls, limit, source}. Raises ValueError
    on a missing required field or an unknown shape — a source naming a shape we
    don't implement is a loud failure, never a silent skip. A new shape arrives
    as an Adapter in this file, not as a line in the config.
    """
    out = []
    for i, s in enumerate(config.get("sources", [])):
        if not s.get("enabled", True):
            continue
        sid, shape = s.get("source_id"), s.get("shape")
        if not (sid and shape):
            raise ValueError(
                f"source #{i}: 'source_id' and 'shape' are required")
        if shape not in SHAPES:
            raise ValueError(
                f"source '{sid}': unknown shape '{shape}' "
                f"(known: {', '.join(sorted(SHAPES))}). A new shape needs an "
                f"Adapter in datagator.py — it cannot be declared in config.")
        out.append({
            "source_id": sid,
            "url": s.get("url"),
            "label": s.get("label", ""),
            "adapter_cls": SHAPES[shape],
            "kind": SHAPES[shape].kind,
            "limit": s.get("limit"),
            "source": s,
        })
    return out


# ── the conduit ──────────────────────────────────────────────────

DEFAULT_CONFIG = {
    "out_dir": str(DEFAULT_OUT),
    "limit": 100,
    "sources": [
        {"source_id": "usgs_quakes", "shape": "usgs_geojson", "enabled": True,
         "url": "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_hour.geojson",
         "label": "USGS earthquakes (past hour)"},
        {"source_id": "noaa_kindex", "shape": "swpc_products", "enabled": True,
         "url": "https://services.swpc.noaa.gov/products/noaa-planetary-k-index.json",
         "label": "NOAA/SWPC planetary K-index (geomagnetic)"},
        {"source_id": "noaa_xray", "shape": "swpc_json", "enabled": True,
         "url": "https://services.swpc.noaa.gov/json/goes/primary/xrays-6-hour.json",
         "label": "NOAA/SWPC GOES X-ray flux (solar flares)"},
        {"source_id": "iss_position", "shape": "iss_point", "enabled": True,
         "url": "https://api.wheretheiss.at/v1/satellites/25544",
         "label": "ISS position (live point)"},
    ],
}


class Datagator:
    """The conduit. Datagator.run(config) is what the fetch/refresh button calls."""

    LIMIT_CEILING = LIMIT_CEILING

    @staticmethod
    def load_config(path) -> dict:
        """Read the config; fall back to DEFAULT_CONFIG only when it is ABSENT.
        A present-but-malformed file raises (loud failure, no silent default)."""
        try:
            return json.loads(Path(path).read_text())
        except FileNotFoundError:
            return DEFAULT_CONFIG

    @staticmethod
    def _clamp(n) -> int:
        return max(1, min(int(n), LIMIT_CEILING))

    @staticmethod
    def _write(out_dir: Path, source_id: str, records: list) -> Path:
        """Write <source_id>.json atomically (.tmp then rename) so Courier never
        sweeps a half-written file."""
        out_dir.mkdir(parents=True, exist_ok=True)
        dest = out_dir / f"{source_id}.json"
        tmp = dest.with_name(dest.name + ".tmp")
        # Self-describing envelope: source_type "feed" tells Courier's
        # ledger that an identity it has EVER seen (even consumed) is not
        # new work — so overlapping fetch windows don't re-feed old readings
        # to new cycles. Hand-uploaded plain arrays keep re-feed semantics.
        tmp.write_text(json.dumps(
            {"source_type": "feed", "records": records}, indent=2))
        tmp.replace(dest)
        return dest

    @staticmethod
    def run(config: dict, out=None, only=None, force_limit=None) -> dict:
        """Run each enabled source through its adapter, cap, dump into import/.

        Returns a status dict — counts and written paths — for the caller (the
        button) to render. Writes only into the import folder; never reaches
        back into Courier. One bad source is reported, not fatal.
        """
        sources = resolve_sources(config)            # loud on unknown shape
        if only:
            want = set(only)
            sources = [s for s in sources if s["source_id"] in want]
        global_limit = config.get("limit", LIMIT_CEILING)
        out_dir = Path(out or config.get("out_dir") or DEFAULT_OUT)

        results, errors, total = [], [], 0
        for s in sources:
            lim = Datagator._clamp(
                force_limit if force_limit is not None
                else (s["limit"] or global_limit))
            try:
                records = cap_recent(s["adapter_cls"](s["source"]).produce(), lim)
            except Exception as e:                   # noqa: BLE001
                errors.append({"source_id": s["source_id"], "error": str(e)})
                continue
            dest = Datagator._write(out_dir, s["source_id"], records)
            results.append({"source_id": s["source_id"],
                            "records": len(records), "path": str(dest)})
            total += len(records)
        return {"out_dir": str(out_dir), "sources": len(sources),
                "ok": len(results), "records": total,
                "written": results, "errors": errors}

    @staticmethod
    def poll(spec: dict, interval: int, duration: int, out=None,
             force_limit=None, global_limit=100, on_tick=None,
             _sleep=time.sleep) -> dict:
        """Assemble a time-series from a single point source.

        Calls the source's adapter every `interval` seconds for `duration`
        seconds, accumulating each fetch's records into one set, then writes a
        single <source_id>.json. Polling every 5s for 60s yields 12 samples
        (60 // 5). Meant for `kind == "point"` sources — the ISS position is a
        referent that changes moment to moment, so polling turns it into a
        series. Pointing it at a `series` source still works, but re-fetches
        overlapping windows, which is rarely what you want.

        Bounded by construction: at most `duration // interval` fetches, then
        capped like any other set. Writes only into the import folder.
        """
        interval = max(1, int(interval))
        ticks = max(1, int(duration) // interval)
        out_dir = Path(out or DEFAULT_OUT)
        adapter = spec["adapter_cls"](spec["source"])

        samples, errors = [], []
        for i in range(ticks):
            try:
                samples.extend(adapter.produce())
            except Exception as e:                   # noqa: BLE001
                errors.append({"tick": i + 1, "error": str(e)})
            if on_tick:
                on_tick(i + 1, ticks, len(samples))
            if i < ticks - 1:
                _sleep(interval)

        lim = Datagator._clamp(force_limit if force_limit is not None
                               else (spec.get("limit") or global_limit))
        records = cap_recent(samples, lim)
        dest = Datagator._write(out_dir, spec["source_id"], records)
        return {"out_dir": str(out_dir), "source_id": spec["source_id"],
                "kind": spec.get("kind"), "interval": interval,
                "ticks": ticks, "records": len(records),
                "path": str(dest), "errors": errors}


# ── CLI ──────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(
        description="Datagator — public/instrument data into Courier (config-driven)")
    ap.add_argument("--config", default=str(DEFAULT_CONFIG_PATH),
                    help="config file (default: datagator.json beside this script)")
    ap.add_argument("--out", help="override out_dir from the config")
    ap.add_argument("--feeds", help="comma-separated source_id subset")
    ap.add_argument("--limit", type=int, help="force this cap across all sources")
    ap.add_argument("--list", action="store_true", help="show resolved sources and exit")
    ap.add_argument("--poll", metavar="SOURCE_ID",
                    help="poll one (point) source repeatedly and assemble a series")
    ap.add_argument("--interval", type=int, default=5,
                    help="seconds between polls in --poll mode (default: 5)")
    ap.add_argument("--duration", type=int, default=60,
                    help="total seconds to poll in --poll mode (default: 60)")
    args = ap.parse_args()

    try:
        config = Datagator.load_config(args.config)
        sources = resolve_sources(config)            # loud on bad config
    except ValueError as e:                          # includes JSONDecodeError
        print(f"config error: {e}", file=sys.stderr)
        sys.exit(2)

    only = [s.strip() for s in args.feeds.split(",")] if args.feeds else None
    if only:
        for u in set(only) - {s["source_id"] for s in sources}:
            print(f"  ? not an enabled source: '{u}'")

    if args.list:
        gl = config.get("limit", LIMIT_CEILING)
        print(f"config:  {args.config}")
        print(f"out_dir: {args.out or config.get('out_dir') or DEFAULT_OUT}")
        for s in sources:
            if only and s["source_id"] not in only:
                continue
            lim = Datagator._clamp(args.limit if args.limit is not None
                                   else (s["limit"] or gl))
            print(f"  {s['source_id']:<14} [{s['kind']:<6}] <= {lim:>3}  {s['label']}")
        return

    if args.poll:
        spec = next((s for s in sources if s["source_id"] == args.poll), None)
        if spec is None:
            print(f"poll: '{args.poll}' is not an enabled source", file=sys.stderr)
            sys.exit(1)
        if spec["kind"] != "point":
            print(f"  note: '{spec['source_id']}' is a {spec['kind']} source — the "
                  f"poller is meant for point sources; it will re-fetch overlapping "
                  f"windows.")
        gl = config.get("limit", LIMIT_CEILING)
        ticks = max(1, int(args.duration) // max(1, int(args.interval)))
        print(f"poll {spec['source_id']}: every {max(1, args.interval)}s "
              f"for {args.duration}s -> {ticks} sample(s)")
        st = Datagator.poll(
            spec, args.interval, args.duration,
            out=args.out or config.get("out_dir") or DEFAULT_OUT,
            force_limit=args.limit, global_limit=gl,
            on_tick=lambda i, n, c: print(f"  · {i}/{n}  ({c} so far)"))
        for e in st["errors"]:
            print(f"  ! tick {e['tick']}: {e['error']}")
        print(f"done: {st['records']} record(s) -> {Path(st['path']).name} "
              f"in {st['out_dir']}/")
        print('next: in Courier, Settings -> Auto-Ingest -> "Sweep Now"')
        return

    status = Datagator.run(config, out=args.out, only=only, force_limit=args.limit)
    for w in status["written"]:
        print(f"  + {w['source_id']}: {w['records']} record(s) -> {Path(w['path']).name}")
    for e in status["errors"]:
        print(f"  ! {e['source_id']}: {e['error']}")
    print(f"done: {status['ok']}/{status['sources']} source(s), "
          f"{status['records']} record(s) -> {status['out_dir']}/")
    print('next: in Courier, Settings -> Auto-Ingest -> "Sweep Now"')


if __name__ == "__main__":
    main()
