#!/usr/bin/env python3
"""Digestor — Gator's document side.

Datagator moves *perishable* observations; the digestor prepares *durable*
knowledge: regulations, permits, registries, species lists. It chunks
textual documents (PDF / .txt / .md) into citable passages and writes a
corpus envelope — {"source_type": "corpus", "doc_id": ..., "records":
[chunks]} — into Courier's import folder, where Courier indexes it into
corpus.db (FTS5) for render-time retrieval by the `corpus_search` adapter.

Same containment rules as Datagator: shares a root with Courier and nothing
more; never imports Courier; only writes JSON into the import folder.

Every chunk is a citation, not a paraphrase: it carries the document id,
the section heading in force at that point, its character span in the
extracted text, and a content hash. A report referencing
[marine_traffic_regs §4.2.1 · chunk#12 · 3fa9c2d1] can be checked by hand.

Usage:
    python digestor.py docs/regs.pdf                     # one document
    python digestor.py docs/ --out ../courier/import     # a folder
    python digestor.py registry.txt --doc-id poacher_registry --lines
    python digestor.py docs/regs.pdf --chunk-chars 1000 --dry-run

Flags:
    --out              destination folder (default: ../courier/import)
    --doc-id           override the document id (default: filename stem,
                       sanitized); only valid with a single input file
    --chunk-chars      target chunk size in characters (default 1400 ≈ 350 tok)
    --min-chunk-chars  fragments below this merge into a neighbor (default 200)
    --lines            list mode: one record per non-empty line (registries,
                       watchlists — keeps each entry an atomic, retrievable unit)
    --dry-run          print chunking stats, write nothing

PDF text extraction needs pypdf (pip install pypdf). Scanned/image PDFs
have no text layer and fail loudly — OCR is out of scope here on purpose.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import time
from pathlib import Path

DEFAULT_OUT = Path(__file__).resolve().parent.parent / "courier" / "import"
DEFAULT_CHUNK_CHARS = 1400
DEFAULT_MIN_CHUNK_CHARS = 200  # merge fragments smaller than this forward

# ── heading detection (regulation-flavored) ──────────────────
# A line "opens a section" if it looks like any of the common regulatory /
# markdown heading shapes. The current heading is carried onto every chunk
# so retrieval hits stay locatable in the source document.
_HEADING_RES = [
    re.compile(r"^#{1,6}\s+(?P<t>.+)$"),                     # markdown
    re.compile(r"^(?P<t>§+\s*[\w\.\-]+.*)$"),                # § 4.2.1 ...
    re.compile(r"^(?P<t>(?:Section|SECTION|Article|ARTICLE|Part|PART|"
               r"Appendix|APPENDIX|Schedule|SCHEDULE)\s+[\w\.\-]+.*)$"),
    re.compile(r"^(?P<t>\d+(?:\.\d+){0,4})[\.\)]?\s+\S.*$"), # 4. / 4.2.1 Title
    re.compile(r"^(?P<t>[A-Z][A-Z0-9 \-,&/\.]{3,79})$"),     # ALL-CAPS line
]


def _heading(line: str):
    s = line.strip()
    if not s or len(s) > 120:
        return None
    for rx in _HEADING_RES:
        m = rx.match(s)
        if m:
            # numbered headings: keep the whole line as the label
            return s if rx is _HEADING_RES[3] else m.group("t").strip()
    return None


def _sha1(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8")).hexdigest()


def _slug(name: str) -> str:
    s = re.sub(r"[^A-Za-z0-9_\-]+", "_", name).strip("_").lower()
    return s or "doc"


# ── extraction ───────────────────────────────────────────────
def extract_text(path: Path) -> str:
    """Plain text from a document. PDFs via pypdf; .txt/.md read directly.
    A PDF with no extractable text (scanned) fails loudly."""
    suf = path.suffix.lower()
    if suf in (".txt", ".md", ".text", ".markdown"):
        return path.read_text(encoding="utf-8", errors="replace")
    if suf == ".pdf":
        try:
            from pypdf import PdfReader
        except ImportError as e:
            raise RuntimeError(
                "PDF input needs pypdf: pip install pypdf") from e
        reader = PdfReader(str(path))
        pages = [(p.extract_text() or "") for p in reader.pages]
        text = "\n".join(pages)
        if len(text.strip()) < 40:
            raise RuntimeError(
                f"{path.name}: no text layer found ({len(reader.pages)} "
                f"page(s)) — likely a scanned/image PDF; OCR it first.")
        return text
    raise RuntimeError(f"{path.name}: unsupported type '{suf}' "
                       f"(supported: .pdf .txt .md)")


# ── chunking ─────────────────────────────────────────────────
def chunk_text(text: str, chunk_chars: int = DEFAULT_CHUNK_CHARS,
               lines_mode: bool = False,
               min_chunk_chars: int = DEFAULT_MIN_CHUNK_CHARS) -> list[dict]:
    """Deterministic chunker. Same text in → same chunks, spans, hashes out.

    Document mode: paragraphs accumulate into ~chunk_chars chunks; a
    detected heading always starts a fresh chunk and becomes the section
    label carried by everything under it. List mode: every non-empty line
    is its own record (a registry row must be retrievable alone).
    """
    chunks: list[dict] = []

    def _push(body: str, section: str, start: int, end: int):
        body = body.strip()
        if not body:
            return
        chunks.append({
            "chunk_index": len(chunks), "section": section,
            "span_start": start, "span_end": end,
            "sha1": _sha1(body), "body": body,
        })

    if lines_mode:
        pos = 0
        section = ""
        for raw in text.splitlines(keepends=True):
            line = raw.strip()
            start, end = pos, pos + len(raw)
            pos = end
            if not line:
                continue
            head = _heading(line)
            if head is not None and len(line) < 100:
                section = head
                continue
            _push(line, section, start, end - 1)
        return chunks

    # document mode: split into blocks on blank lines, walk with spans
    section = ""
    buf: list[str] = []
    buf_start = 0
    pos = 0
    blocks: list[tuple[str, int, int]] = []
    for m in re.finditer(r"[^\n]*(?:\n|$)", text):
        line = m.group(0)
        if line == "":
            break
        blocks.append((line, m.start(), m.end()))

    def _flush(end_pos: int):
        nonlocal buf, buf_start
        if buf:
            _push("".join(buf), section, buf_start, end_pos)
            buf = []

    cur_len = 0
    for line, start, end in blocks:
        stripped = line.strip()
        head = _heading(stripped) if stripped else None
        if head is not None:
            _flush(start)
            section = head
            buf = [line]
            buf_start = start
            cur_len = len(line)
            continue
        if not buf:
            buf_start = start
        buf.append(line)
        cur_len += len(line)
        # flush at a paragraph boundary once past the target
        if not stripped and cur_len >= chunk_chars:
            _flush(end)
            cur_len = 0
    _flush(len(text))

    # Tiny fragments are not retrieval units. Merge them FORWARD into the
    # next chunk (a bare "## 4.2 Vessel Exclusion Periods" heading becomes
    # context atop its first subsection) — falling back to a backward merge
    # for a tiny tail chunk.
    merged: list[dict] = []
    pending: dict | None = None      # tiny chunk waiting to be prepended
    for ch in chunks:
        if pending is not None:
            ch = {**ch,
                  "body": pending["body"] + "\n\n" + ch["body"],
                  "span_start": pending["span_start"],
                  "section": pending["section"] or ch["section"]}
            ch["sha1"] = _sha1(ch["body"])
            pending = None
        if len(ch["body"]) < min_chunk_chars:
            pending = ch
            continue
        merged.append(ch)
    if pending is not None:          # tiny tail: merge backward if possible
        if merged:
            prev = merged[-1]
            prev["body"] = prev["body"] + "\n\n" + pending["body"]
            prev["span_end"] = pending["span_end"]
            prev["sha1"] = _sha1(prev["body"])
        else:
            merged.append(pending)
    for i, ch in enumerate(merged):
        ch["chunk_index"] = i
    return merged


# ── envelope ─────────────────────────────────────────────────
def build_envelope(path: Path, doc_id: str, chunks: list[dict],
                   full_text: str) -> dict:
    return {
        "source_type": "corpus",
        "doc_id": doc_id,
        "title": path.stem,
        "path": str(path),
        "sha1": _sha1(full_text),
        "generated_at": time.time(),
        "records": chunks,
    }


def digest_file(path: Path, out_dir: Path, doc_id: str | None,
                chunk_chars: int, lines_mode: bool, dry: bool,
                min_chunk_chars: int = DEFAULT_MIN_CHUNK_CHARS) -> dict:
    text = extract_text(path)
    did = doc_id or _slug(path.stem)
    chunks = chunk_text(text, chunk_chars=chunk_chars, lines_mode=lines_mode,
                        min_chunk_chars=min_chunk_chars)
    if not chunks:
        raise RuntimeError(f"{path.name}: produced no chunks")
    env = build_envelope(path, did, chunks, text)
    status = {"doc_id": did, "chunks": len(chunks),
              "chars": len(text),
              "sections": len({c["section"] for c in chunks if c["section"]})}
    if not dry:
        out_dir.mkdir(parents=True, exist_ok=True)
        out = out_dir / f"corpus_{did}.json"
        out.write_text(json.dumps(env, ensure_ascii=False),
                       encoding="utf-8")
        status["written"] = str(out)
    return status


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Chunk documents into a citable corpus for Courier.")
    ap.add_argument("inputs", nargs="+", help="document files or folders")
    ap.add_argument("--out", default=str(DEFAULT_OUT))
    ap.add_argument("--doc-id", default=None,
                    help="document id (single input file only)")
    ap.add_argument("--chunk-chars", type=int, default=DEFAULT_CHUNK_CHARS)
    ap.add_argument("--min-chunk-chars", type=int,
                    default=DEFAULT_MIN_CHUNK_CHARS,
                    help="fragments below this merge into a neighbor "
                         f"(default {DEFAULT_MIN_CHUNK_CHARS})")
    ap.add_argument("--lines", action="store_true",
                    help="one record per line (registries/watchlists)")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    files: list[Path] = []
    for inp in args.inputs:
        p = Path(inp)
        if p.is_dir():
            files.extend(sorted(q for q in p.rglob("*")
                                if q.suffix.lower() in
                                (".pdf", ".txt", ".md", ".text", ".markdown")))
        elif p.exists():
            files.append(p)
        else:
            print(f"  ✗ {inp}: not found")
    if not files:
        print("No input documents.")
        return 1
    if args.doc_id and len(files) > 1:
        print("--doc-id needs exactly one input file.")
        return 1

    failures = 0
    for f in files:
        try:
            st = digest_file(f, Path(args.out), args.doc_id,
                             args.chunk_chars, args.lines, args.dry_run,
                             min_chunk_chars=args.min_chunk_chars)
            dest = st.get("written", "(dry run)")
            print(f"  ✓ {f.name}: {st['chunks']} chunk(s), "
                  f"{st['sections']} section(s), {st['chars']} chars "
                  f"→ {dest}")
        except Exception as e:
            failures += 1
            print(f"  ✗ {f.name}: {e}")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
