#!/usr/bin/env python3
"""Cold probes for the digestor → corpus → retrieval chain.

No network, no torch, no Courier server: exercises the chunker's
determinism and shapes, the corpus envelope contract, Courier's ingest
routing (corpus envelopes index; the ledger stays untouched), the FTS5
store, query sanitization, and the corpus_search adapter end to end —
including the observation-derived query path (a hull ID seen in a cycle
record retrieving its registry entry).

Run:  python probe_digestor.py
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

GATOR = Path(__file__).resolve().parent
ROOT = GATOR.parent
sys.path.insert(0, str(GATOR))
sys.path.insert(0, str(ROOT / "courier" / "src"))

from digestor import chunk_text, digest_file, _heading  # noqa: E402

FAILS: list[str] = []


def check(name: str, cond: bool) -> bool:
    print(f"  {'PASS' if cond else 'FAIL'}  {name}")
    if not cond:
        FAILS.append(name)
    return bool(cond)


REGS = """# Marine Traffic Regulations

## 4.1 General Provisions
All vessels operating within the sanctuary boundary shall maintain
registration documents on board and respond to hails from wardens.

## 4.2 Vessel Exclusion Periods
### 4.2.1 Nesting Season
Between March 1 and June 30, motorized vessels are prohibited within
500 meters of the northern shoal. No-wake zone applies at all times.

## 4.3 Penalties
Violations carry fines up to $25,000 and vessel seizure under Schedule B.
"""

WATCHLIST = """KNOWN VESSELS OF INTEREST
Hull ID VX-7734 — 'Reina del Mar' — repeated 4.2.1 violations, night runs
Hull ID KQ-2210 — 'Sable' — suspected transshipment, permit NP-2 revoked
"""


def main() -> int:
    print("Digestor: heading detection")
    check("markdown heading", _heading("## 4.2 Vessel Exclusion") is not None)
    check("numbered heading", _heading("4.2.1 Nesting Season") is not None)
    check("section-word heading", _heading("Section 12 Prohibited Acts") is not None)
    check("all-caps heading", _heading("KNOWN VESSELS OF INTEREST") is not None)
    check("prose line is not a heading",
          _heading("the vessel shall maintain registration.") is None)

    print("Digestor: chunker")
    a = chunk_text(REGS)
    b = chunk_text(REGS)
    check("deterministic (same input, same chunks)", a == b)
    check("chunks produced", len(a) >= 1)
    check("no heading-only chunks",
          all(len(c["body"].splitlines()) > 1 or len(c["body"]) >= 60
              for c in a))
    check("sections carried", any("4.2" in (c["section"] or "") or
                                  "Penalties" in (c["section"] or "")
                                  for c in a))
    check("spans map back into source",
          all(REGS[c["span_start"]:c["span_end"] + 1].strip() != ""
              for c in a))
    check("hashes present", all(len(c["sha1"]) == 40 for c in a))
    idx = [c["chunk_index"] for c in a]
    check("indices contiguous", idx == list(range(len(a))))

    lines = chunk_text(WATCHLIST, lines_mode=True)
    check("lines mode: one record per entry", len(lines) == 2)
    check("lines mode: heading became section, not a record",
          all("KNOWN VESSELS" in (c["section"] or "") for c in lines))

    print("Digestor: envelope + Courier ingest routing")
    work = Path(tempfile.mkdtemp())
    regs = work / "marine_traffic_regs.md"
    regs.write_text(REGS, encoding="utf-8")
    wl = work / "watchlist.txt"
    wl.write_text(WATCHLIST, encoding="utf-8")
    imp = work / "import"
    st = digest_file(regs, imp, None, 1400, False, False)
    st2 = digest_file(wl, imp, "poacher_registry", 1400, True, False)
    check("envelope files written",
          len(list(imp.glob("corpus_*.json"))) == 2 and "written" in st)
    env = json.loads((imp / "corpus_marine_traffic_regs.json")
                     .read_text(encoding="utf-8"))
    check("envelope is corpus-typed", env.get("source_type") == "corpus")
    check("envelope carries doc identity",
          env.get("doc_id") == "marine_traffic_regs" and env.get("sha1"))

    from core.db import Database
    from data.ingest import ingest_json_file
    db = Database(work / "courier.db")
    n1 = ingest_json_file(db, imp / "corpus_marine_traffic_regs.json")
    n2 = ingest_json_file(db, imp / "corpus_poacher_registry.json")
    check("ingest indexed chunks", n1 >= 1 and n2 == 2)
    ledger = db._conn.execute("SELECT COUNT(*) FROM ingestion").fetchone()[0]
    check("ledger untouched by corpus envelopes", ledger == 0)
    check("corpus.db created beside ledger", (work / "corpus.db").exists())
    check("re-ingest replaces, not duplicates",
          ingest_json_file(db, imp / "corpus_poacher_registry.json") == 2)

    print("Corpus store + retrieval")
    from core.corpus import CorpusStore, sanitize_query
    check("query sanitization quotes terms",
          sanitize_query('vessel NEAR(“x”) OR *') .count('"') % 2 == 0)
    check("empty query is empty", sanitize_query("") == "")
    store = CorpusStore(work / "corpus.db")
    stats = store.stats()
    check("stats sees both documents", stats["documents"] == 2)
    hits = store.search(["VX-7734"], top_k=3)
    check("registry lookup by hull id",
          len(hits) >= 1 and "Reina del Mar" in hits[0]["body"])
    store.close()

    print("corpus_search adapter (observation-derived query)")
    from data.adapters.corpus_search import Adapter
    ad = Adapter()
    ad.connect({"path": str(work / "corpus.db"),
                "params": {"query": "vessel exclusion", "top_k": 4}})
    recs = [{"content": json.dumps({"event": "vessel_detected",
                                    "hull_id": "VX-7734",
                                    "camera": "north-shoal-2"})}]
    out = ad.render_records(recs, token_budget=400, params={})
    check("adapter renders citations", "chunk#" in out and "§" in out)
    check("observation pulled its registry entry", "VX-7734" in out)
    check("fixed query pulled regulation text",
          "Exclusion" in out or "prohibited" in out)
    check("fits budget", len(out) <= 400 * 4 + 200)
    ad2 = Adapter()
    ad2.connect({"path": str(work / "nonexistent.db"), "params": {}})
    check("missing corpus is loud, not fatal",
          "Corpus not found" in ad2.fetch(200, {"query": "x"}))
    ad3 = Adapter()
    ad3.connect({"path": str(work / "corpus.db"), "params": {}})
    check("no terms is loud, not fatal",
          "no query terms" in ad3.render_records([], 200,
                                                 {"from_records": False}))

    print()
    if FAILS:
        print(f"{len(FAILS)} probe(s) FAILED:")
        for f in FAILS:
            print(f"  - {f}")
        return 1
    print("All digestor/corpus probes passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
