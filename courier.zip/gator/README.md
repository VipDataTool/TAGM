# Datagator

The configurable conduit between instruments and Courier. One script.

Instruments speak their own native tongue. Courier only ever sees clean records
bound for its SQL ledger. Every awkward translation in between is quarantined in
Datagator. It reads `datagator.json`, runs each enabled source's adapter, caps
the result, and writes a self-describing envelope —
`{"source_type": "feed", "records": [...]}` — into Courier's import folder, the
spot Courier's auto-ingest watches. The `feed` marker carries the ledger
semantics a conduit needs: a record identity Courier has EVER seen (even one a
past cycle consumed) is not new work, so overlapping fetch windows don't
re-feed old readings to new cycles. Hand-uploaded plain arrays keep their
re-upload-re-feeds behavior. That's the whole job.

Datagator shares a root with Courier and nothing more: it never imports Courier
and never reaches across the root. It only writes JSON into the import folder.
The thing that talks to the open world has no path into the inference host.

## Adapters: the contained mess

An **adapter** owns whatever it takes to go from one instrument's reality to
clean records — fetch, handshake, demodulation, parsing, all of it. The contract
is one method:

```
produce() -> [records]
```

A trivial source is a few lines; the built-in adapters override only `parse()`
and lean on the base `produce()`, which fetches the source `url` as JSON. A
source that isn't a plain JSON GET — a device read, a non-JSON wire format, a
radio telescope — overrides `produce()` and does whatever it needs, as long as
it returns flat record dicts (each carrying a `timestamp` in epoch seconds).
Light adapters stay light; heavy ones carry their own weight. The mess lives in
the adapter, never in the instrument and never in Courier.

```python
class RadioTelescope(Adapter):
    def produce(self):
        raw = self._read_device(self.source["device"])
        samples = self._demodulate(raw)
        now = datetime.now(timezone.utc).timestamp()
        return [{"timestamp": now, "freq_mhz": s.freq, "power_db": s.power}
                for s in samples]
```

Register it under a shape name in `SHAPES`, reference that name from a source in
`datagator.json`. Shapes are code; sources are config. A source naming a shape
that doesn't exist is a **loud failure** — config can't smuggle in logic.

## Config (`datagator.json`)

```jsonc
{
  "out_dir": "../courier/import",
  "limit": 100,
  "sources": [
    { "source_id": "usgs_quakes", "shape": "usgs_geojson", "enabled": true, "limit": 50,
      "url": "https://earthquake.usgs.gov/.../all_hour.geojson",
      "label": "USGS earthquakes (past hour)" }
  ]
}
```

`datagator.json` beside the script is the config; if absent, a built-in default
runs so it works out of the box; a malformed file fails loudly; CLI flags win.

## Run

```bash
python datagator.py                      # all enabled sources -> courier/import
./run.sh                                 # same, one command
python datagator.py --feeds usgs_quakes,noaa_kindex
python datagator.py --limit 50           # force a cap across all sources
python datagator.py --config other.json  # different config
python datagator.py --list               # show resolved sources (with kind) and exit
```

## Poll a point source into a series

A *point* source returns one current value per fetch (the ISS position right
now). To turn that referent into a time-series, poll it on a fixed cadence for a
fixed duration — the samples accumulate into one file:

```bash
python datagator.py --poll iss_position --interval 5 --duration 60
# every 5s for 60s -> 12 samples -> iss_position.json
```

Sample count is `duration // interval`. The poller is meant for `kind == "point"`
sources; aimed at a `series` source it still runs but warns, since a series
already returns a window. `kind` is declared on each adapter (point vs series)
and shown in `--list`. (The script is just a script — an external scheduler can
also call it; `--poll` is the built-in fixed-duration mode.)

At runtime — e.g. Courier's fetch/refresh button — call the conduit directly:

```python
from datagator import Datagator
status = Datagator.run(Datagator.load_config("gator/datagator.json"))
# -> {"out_dir": ..., "ok": N, "records": M, "written": [...], "errors": [...]}
```

`run()` writes only into the import folder and returns a status dict for the
button to render. It never reaches back into Courier.

## Knobs

| Key | Scope | Meaning |
|---|---|---|
| `out_dir` | global | destination folder (default: sibling `../courier/import`) |
| `limit` | global | default cap per set; clamped to 100 (bounded by construction) |
| `sources[].source_id` | source | dataset id + output filename |
| `sources[].shape` | source | which `SHAPES` adapter handles it |
| `sources[].url` | source | where the shape is served (free to change) |
| `sources[].enabled` | source | include in a run (default: true) |
| `sources[].limit` | source | overrides the global cap for this source |
| `sources[].label` | source | human label for `--list` |

`--limit` on the CLI forces that cap on every source.


## Digestor: the durable-knowledge side

Datagator moves *perishable* observations; `digestor.py` prepares *durable*
knowledge — regulations, permits, registries, watchlists — for Courier's
retrieval index. It chunks textual PDFs / .txt / .md into citable passages
(each carrying doc id, section heading, char span, content hash) and writes a
`{"source_type": "corpus", ...}` envelope into the import folder. Courier
indexes it into `corpus.db` (SQLite FTS5) beside the ledger; templates then
retrieve relevant passages at render time with the `corpus_search` adapter —
including terms derived from the cycle's own records, so a hull ID seen by a
camera trap pulls its registry entry and the regulations that bear on it.

```bash
python digestor.py docs/marine_regs.pdf              # regulations: section-aware chunks
python digestor.py watchlist.txt --lines --doc-id poacher_registry
python digestor.py docs/ --dry-run                   # stats only
python probe_digestor.py                             # cold tests, no network
```

Chunking is tunable: `--chunk-chars` sets the target chunk size (default
1400 ≈ 350 tokens) and `--min-chunk-chars` the floor below which a fragment
merges into its neighbor instead of standing alone (default 200). Both knobs
are per-run, so a registry and a statute can be digested with different
granularity into the same corpus.

Same containment rules as Datagator: writes JSON into the import folder,
never imports Courier, never reaches across the root. Scanned/image PDFs
fail loudly (no text layer) — OCR first.

## Files

- `datagator.py` — the script: adapters, `SHAPES` registry, `resolve_sources`, `Datagator.run`
- `datagator.json` — sources and knobs
- `run.sh` — one-command wrapper
- `probe_datagator.py` — cold tests (adapters, cap, registry, resolver, the run conduit)
- `DATASETS.md` — verified catalog of keyless feeds
- `digestor.py` — document chunker: corpus envelopes for Courier's retrieval index
- `probe_digestor.py` — cold tests for the digestor → corpus → retrieval chain

## Note on testing

No network in the build environment, so live fetch runs in your Codespace. What
is verified cold: every adapter's parse, the cap, the `SHAPES` registry, the
`resolve_sources` contract (incl. unknown-shape raising), and `Datagator.run`
end-to-end with the network stubbed — including a source whose adapter fails.
