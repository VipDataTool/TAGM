# Gator — Free Public Realtime Datasets

A boiled-down catalog of the datasets Gator can assemble from free public
APIs. Every feed in the first table needs **no API key** (buildable today); ★ marks
the recommended starter set for a space + geophysical edge demo.

## Keyless datasets

| Dataset (`source_id`) | Source | What you get | Event or stream → dedup key | Update |
|---|---|---|---|---|
| ★ `usgs_quakes` | USGS | Earthquakes (mag bands × hour/day/week/month) | **Event** → feature `id` | ~1 min |
| ★ `noaa_kindex` | NOAA SWPC | Planetary K-index (geomagnetic storm level 0–9) | Stream → `time_tag` | ~1 min (3 h data) |
| ★ `noaa_xray` | NOAA SWPC | GOES X-ray flux → solar flare class (C/M/X) | Stream → `time_tag` + `energy` | 1 min |
| `noaa_protons` / `noaa_electrons` | NOAA SWPC | GOES particle flux → radiation-storm context | Stream → `time_tag` + `energy` | 5 min |
| `solar_wind_plasma` | NOAA SWPC | Solar wind density / speed / temp (DSCOVR/ACE) | Stream → `time_tag` | ~1 min |
| `solar_wind_mag` | NOAA SWPC | Interplanetary magnetic field (Bz — aurora driver) | Stream → `time_tag` | ~1 min |
| `noaa_scales` | NOAA SWPC | R/S/G space-weather scales (current conditions) | Snapshot → date + time | few min |
| `swpc_alerts` | NOAA SWPC | Space-weather alerts / watches / warnings | **Event** → serial number | as issued |
| `aurora_ovation` | NOAA SWPC | Aurora probability grid (heavy, ~900 KB) | Snapshot → forecast time | 5 min |
| ★ `iss_position` | wheretheiss.at | Live ISS lat / lon / alt / velocity | Stream → `timestamp` | ≤ every 5 s |
| `people_in_space` | open-notify † | Astronauts currently in orbit | Snapshot | slow |
| `nws_alerts` | NOAA NWS ‡ | Weather warnings / watches (US) | **Event** → alert `id` | ~1 min |
| `nws_obs` | NOAA NWS ‡ | Station weather observations | Stream → `timestamp` | ~hourly |
| `eonet_events` | NASA EONET | Natural events: wildfires, storms, volcanoes | **Event** → `id` | near-real-time |
| `usgs_water` | USGS Water § | Streamflow / gage height | Stream → site + param + `dateTime` | 15 min |

† open-notify is HTTP-only and community-run — use as a fallback.
‡ NWS needs no key but **requires a `User-Agent` header** (403 without it).
§ USGS legacy water host is keyless but decommissions Q1 2027; the replacement needs a key.

## Key-required datasets (optional module)

| Dataset | Source | What you get | Note |
|---|---|---|---|
| `nasa_donki` | NASA DONKI | Space-weather notifications (flares, CMEs, storms) | `DEMO_KEY` works for testing (30/hr, 50/day) |
| `nasa_neows` | NASA NeoWs | Near-Earth asteroid close approaches | same key limits |

## What you can assemble

A genuinely rich **space-weather + seismic + orbital** edge demo, entirely keyless:

- **Event feeds** with clean stable-ID dedup: earthquakes, SWPC alerts, EONET / NWS events.
- **Space-weather time-series**: K-index, GOES X-ray, GOES particles, solar wind (plasma + mag), R/S/G scales.
- **Live orbital track**: ISS position.

Four of these are already wired into Gator (`usgs_quakes`, `noaa_kindex`,
`noaa_xray`, `iss_position`); the rest are drop-in additions following the same
`normalize → key_fn` pattern.

## Timestamp formats (parse per feed, normalize to UTC epoch)

| Family | Feeds | Example |
|---|---|---|
| Epoch milliseconds | USGS quakes | `1716800000000` |
| Epoch seconds | wheretheiss.at, open-notify | `1716800000` |
| ISO-8601 (`Z`/offset) | SWPC `/json/`, EONET, NWS, USGS water | `2026-05-22T06:11:00Z` |
| SWPC `/products/` string | K-index, solar wind | `2024-09-19 21:00:00.000` |

**Shape gotcha:** SWPC `/products/` feeds are **array-of-arrays** (row 0 is a header row of
column-name strings); SWPC `/json/` feeds are **array-of-objects**.

## Attribution

Requested by the agencies (US public domain, not legally required):
Earthquakes — U.S. Geological Survey · Space weather — NOAA SWPC ·
Weather alerts — NOAA NWS · Natural events — NASA EONET.
