#!/usr/bin/env bash
# Datagator — one command. Args pass through to datagator.py.
#   ./run.sh                                  # all enabled sources -> ../courier/import
#   ./run.sh --feeds usgs_quakes              # subset by source_id
#   ./run.sh --limit 50                       # force a cap across all sources
#   ./run.sh --config /path/to/datagator.json # use a different config
#   ./run.sh --list                           # show resolved sources
#   ./run.sh --poll iss_position --interval 5 --duration 60   # point source -> series
cd "$(dirname "$0")" && exec python3 datagator.py "$@"
