"""
Core ASM Analyzer: single-pass computation of amplitude trajectories,
signed attribution, distribution metrics, behavioral divergence,
model response capture, and Lateral Tension Profile (LTP).
"""

import torch
import numpy as np
from dataclasses import dataclass, field
from typing import Optional, List, Tuple
import logging

logger = logging.getLogger("tasm")

from engine.ltp import (LTPResult, compute_ltp, ltp_result_to_dict,
                        precompute_svd_cache)
from engine.sfd import (SFDResult, SFDCache, precompute_sfd_cache,
                        compute_sfd_sequence, compute_rank_displacement)
from engine import engine_config


@dataclass
class PromptResult:
    """Complete analysis result for a single prompt."""
    prompt: str = ""
    category: str = ""
    tokens: list = field(default_factory=list)
    seq_len: int = 0

    # Stage 1: Full amplitude trajectory (all sublayers)
    amplitude_trajectory: list = field(default_factory=list)
    amplitude_normalized: list = field(default_factory=list)
    heatmap: Optional[np.ndarray] = None

    # Stage 2: Focused stress score (signal layers only)
    stress_score: float = 0.0
    per_token_stress: Optional[np.ndarray] = None

    # Stage 3: Signed attribution
    signed_attr: Optional[np.ndarray] = None
    net_correction: float = 0.0
    n_negative_tokens: int = 0
    has_negative_tokens: bool = False

    # Stage 3 per-layer detail (layer_idx -> np.array of per-token attr)
    per_layer_signed_attr: dict = field(default_factory=dict)

    # Stage 3b: Distribution metrics
    entropy: float = 0.0
    top2_share: float = 0.0
    middle_share: float = 0.0
    interior_cv: float = 0.0

    # Behavioral divergence
    kl_divergence: Optional[float] = None
    per_token_kl: Optional[np.ndarray] = None  # KL(instruct||base) at each position

    # Model responses (top-k next token predictions)
    instruct_topk: list = field(default_factory=list)  # [(token, prob), ...]
    base_topk: list = field(default_factory=list)

    # Base model per-token counterfactuals (for terrain map base bank)
    base_counterfactual_tokens: list = field(default_factory=list)  # [[("tok", prob), ...] per position]

    # Proof 1 exactness checks
    proof1_checks: list = field(default_factory=list)  # [{layer, head, sum, norm, error}]

    # Signal layer breakdown
    signal_layer_indices: list = field(default_factory=list)
    per_layer_amplitude: dict = field(default_factory=dict)

    # Full capture derived metrics (computed when full_capture=True)
    per_token_coherence: Optional[np.ndarray] = None   # Cross-layer direction agreement per token
    per_token_spectral_rank: Optional[list] = None      # Effective rank of correction per token
    attn_frac: Optional[np.ndarray] = None              # Fraction of correction from attention vs MLP per token
    token_similarity: Optional[np.ndarray] = None       # Token x token correction cosine similarity matrix
    full_capture_enabled: bool = False

    # Model-intrinsic normalization
    delta_scale: float = 0.0  # Mean fnorm across signal sublayers (set at analysis time)
    spectral_summary: dict = field(default_factory=dict)  # Delta spectral structure

    # LTP results
    ltp: Optional[LTPResult] = None

    # SFD results
    sfd: Optional[SFDResult] = None

    # Rank displacement (LTP companion: base vs instruct ordering)
    rank_displacement: Optional[dict] = None

    # Domain embedding (mean hidden state at middle layer, for domain surface module)
    domain_embedding: Optional[list] = None

    # Per-token domain embeddings (L2-normalized hidden states at domain layer)
    # Used by domain surface for per-token probe matching. Not serialized to JSON export.
    per_token_domain_emb: Optional[list] = None       # subject layer (domain_embedding_layer_frac)
    per_token_escalation_emb: Optional[list] = None   # escalation layer (domain_escalation_layer_frac)
    per_token_final_emb: Optional[list] = None         # final norm layer (model output)
    per_token_domain_offset: int = 1  # position offset (0 or 1) — how many leading tokens were skipped

    # ─── Field sets for from_dict reconstitution ──────────────────
    # Centralized here so every caller uses the same definitions.
    # "scalar" = what aggregate_batch and statistics need.
    # "plot"   = everything "scalar" provides, plus per-token arrays
    #            and trajectories needed to regenerate visualizations.

    _SCALAR_FIELDS = [
        "stress_score", "net_correction", "entropy",
        "top2_share", "middle_share", "interior_cv",
        "kl_divergence", "category", "seq_len",
        "has_negative_tokens", "n_negative_tokens",
    ]

    # SFD scalar fields (kept separate for clarity, merged into reconstitution)
    _SFD_SCALAR_FIELDS = [
        "sfd", "rank_displacement",
    ]

    _PLOT_EXTRA_FIELDS = [
        # Per-token arrays needed by plot functions
        "tokens", "signed_attr", "per_token_stress",
        # Trajectory and heatmap
        "amplitude_trajectory", "amplitude_normalized",
        "heatmap", "signal_layer_indices",
        # Domain surface module
        "domain_embedding",
    ]

    @classmethod
    def from_dict(cls, d: dict, mode: str = "scalar") -> "PromptResult":
        """Reconstitute a PromptResult from a stored result dict.

        Modes:
          "scalar" — scalar metrics only (for aggregate_batch, statistics).
          "plot"   — scalars + per-token arrays + trajectories + LTP profiles
                     (for deferred plot generation).

        This is the single point of truth for which fields each mode needs.
        All reconstitution in app.py calls this instead of hand-copying fields.
        """
        pr = cls()

        # Always copy scalar fields
        for key in cls._SCALAR_FIELDS:
            val = d.get(key)
            if val is not None:
                setattr(pr, key, val)

        # Plot mode adds per-token arrays and trajectories
        if mode == "plot":
            for key in cls._PLOT_EXTRA_FIELDS:
                val = d.get(key)
                if val is not None:
                    # heatmap must be ndarray (plot_heatmap uses .size, .shape)
                    if key == "heatmap" and not isinstance(val, np.ndarray):
                        val = np.array(val)
                    setattr(pr, key, val)

        # LTP reconstitution — summary stats for scalar, full profiles for plot
        ltp_data = d.get("ltp")
        if ltp_data:
            ltp_r = LTPResult()
            ltp_r.mean_M = ltp_data.get("mean_M", 0.0) or 0.0
            ltp_r.mean_V = ltp_data.get("mean_V", 0.0) or 0.0
            ltp_r.mean_L = ltp_data.get("mean_L", 0.0) or 0.0
            ltp_r.n_directional = ltp_data.get("n_directional", 0)
            ltp_r.max_prc = ltp_data.get("max_prc", 0.0) or 0.0

            if mode == "plot":
                ltp_r.profiles = [np.array(p) for p in ltp_data.get("profiles", [])]
                ltp_r.tension_magnitudes = ltp_data.get("tension_magnitudes", [])
                ltp_r.profile_shapes = ltp_data.get("profile_shapes", [])
                ltp_r.counterfactual_tokens = ltp_data.get("counterfactual_tokens", [])
                ltp_r.k = ltp_data.get("k", 8)
                ltp_r.offset_magnitude = {
                    int(k): v for k, v in ltp_data.get("offset_magnitude", {}).items()
                }
                sem = ltp_data.get("semantic_trajectory_2d", [])
                ten = ltp_data.get("tension_trajectory_2d", [])
                if sem:
                    ltp_r.semantic_trajectory = np.array(sem)
                if ten:
                    ltp_r.tension_trajectory = np.array(ten)

            pr.ltp = ltp_r

        # SFD reconstitution
        sfd_data = d.get("sfd")
        if sfd_data:
            pr.sfd = SFDResult.from_dict(sfd_data)

        # Rank displacement reconstitution
        rd_data = d.get("rank_displacement")
        if rd_data:
            pr.rank_displacement = rd_data

        return pr


class Analyzer:
    def __init__(self, model_manager):
        self.mm = model_manager
        # LTP enhancement caches (lazily initialized, persist for model lifetime)
        self._svd_caches = {}    # {rank: {layer_idx: tensor}}
        # SFD cache (lazily initialized)
        self._sfd_cache = None   # SFDCache or None

    def _get_svd_cache(self, rank: int):
        """Get or build SVD cache for the given rank."""
        if rank not in self._svd_caches:
            self._svd_caches[rank] = precompute_svd_cache(self.mm.state, rank=rank)
        return self._svd_caches[rank]


    def _get_sfd_cache(self, k: int = 16):
        """Get or build SFD cache for the QK delta subspace."""
        if self._sfd_cache is None:
            layer_indices = list(self.mm.state.signal_layers) if self.mm.state else None
            self._sfd_cache = precompute_sfd_cache(
                self.mm.state, layer_indices=layer_indices, k=k)
        return self._sfd_cache

    def clear_ltp_caches(self):
        """Clear LTP and SFD caches (e.g. on model reload)."""
        self._svd_caches.clear()
        self._sfd_cache = None

    def analyze_prompt(self, prompt: str, category: str = "",
                       compute_kl: bool = False,
                       compute_full_trajectory: bool = True,
                       capture_responses: bool = False,
                       full_capture: bool = False,
                       compute_ltp: bool = False,
                       compute_sfd: bool = False,
                       ltp_k: int = 8,
                       ltp_layer_strategy: str = "signal",
                       ltp_svd_rank: int = 0,

                       response_topk: int = None,
                       base_cache: dict = None) -> PromptResult:
        """Run the full analysis pipeline in a SINGLE forward pass.

        base_cache: optional dict from run_base_phase() containing pre-computed
            base model outputs. When provided, the base model is NOT loaded —
            enables sequential (non-concurrent) model loading for memory-
            constrained environments. Keys:
              per_position_base_alts: [[(token_id, prob), ...], ...] for LTP
              base_topk: [(token_str, prob), ...] for capture_responses
              base_counterfactual_tokens: [[(tok_str, prob), ...], ...] for RD
              base_log_softmax: np.ndarray [seq_len, vocab] for KL (optional)
        """
        if response_topk is None:
            response_topk = engine_config.get("response_topk")
        state = self.mm.state
        result = PromptResult(prompt=prompt, category=category)
        result.signal_layer_indices = list(state.signal_layers)
        result.full_capture_enabled = full_capture

        # Install all hooks, run one forward pass
        ltp_layers = None
        if compute_ltp and ltp_layer_strategy == "late":
            late_start = 2 * state.n_layers // 3
            ltp_layers = list(range(late_start, state.n_layers))
        domain_frac = max(0, min(1, engine_config.get("domain_embedding_layer_frac") or 0.50))
        domain_layer = max(0, min(state.n_layers - 1, int(domain_frac * state.n_layers)))
        esc_frac = max(0, min(1, engine_config.get("domain_escalation_layer_frac") or 0.75))
        escalation_layer = max(0, min(state.n_layers - 1, int(esc_frac * state.n_layers)))
        self.mm.install_analysis_hooks(full_trajectory=compute_full_trajectory or full_capture,
                                       ltp_layers=ltp_layers,
                                       domain_layer=domain_layer,
                                       escalation_layer=escalation_layer)
        _attn_pool = engine_config.get("attention_weighted_pool")
        tokens, inputs, model_out = self.mm.forward(
            prompt, output_attentions=full_capture or _attn_pool)

        result.tokens = [t.replace("\u0120", " ").replace("\u010a", "\\n") for t in tokens]
        result.seq_len = len(tokens)
        seq_len = result.seq_len

        # Capture instruct model top-k predictions from this forward pass
        if capture_responses or compute_kl:
            logits = model_out.logits[0, -1, :]
            probs = torch.softmax(logits, dim=-1)
            topk = torch.topk(probs, min(response_topk, probs.shape[0]))
            result.instruct_topk = [
                (state.tokenizer.decode(idx.item()).strip(), round(p.item(), engine_config.get("serialization_precision")))
                for idx, p in zip(topk.indices, topk.values)
            ]

        # Extract all metrics from cached activations
        self._extract_signed_attribution(result, seq_len, state)
        self._extract_stress_score(result, seq_len, state)

        # Model-intrinsic scale: mean fnorm across signal sublayers
        signal_norms = [v for k, v in state.delta_frob_norms.items()
                        if any(f"model.layers.{li}." in k for li in state.signal_layers)]
        result.delta_scale = float(np.mean(signal_norms)) if signal_norms else 1.0
        result.spectral_summary = getattr(state, 'spectral_summary', {})
        if compute_full_trajectory or full_capture:
            self._extract_amplitude_trajectory(result, seq_len, state)

        # Full capture: compute derived metrics from the heatmap
        if full_capture and result.heatmap is not None:
            self._compute_full_capture_metrics(result, seq_len, state)

        # LTP computation
        if compute_ltp:
            # Get base model logits for base bank probe directions
            base_logits = None
            precomputed_base_alts = None
            if base_cache is not None:
                # Sequential mode: use pre-computed base alternatives
                precomputed_base_alts = base_cache.get("per_position_base_alts")
            elif state.model_base is not None:
                # Concurrent mode: run base model live
                with torch.no_grad():
                    base_out = state.model_base(**inputs)
                    base_logits = base_out.logits
                    del base_out

            result.ltp = self._compute_ltp(
                model_out.logits, tokens, inputs["input_ids"],
                k=ltp_k, layer_strategy=ltp_layer_strategy,
                svd_rank=ltp_svd_rank,
                base_logits=base_logits,
                precomputed_base_alts=precomputed_base_alts)

        # SFD computation (uses same cached activations as ASM — no extra hooks)
        if compute_sfd:
            try:
                sfd_cache = self._get_sfd_cache()
                # Gather activations at signal layers (already captured by ASM hooks)
                layer_acts = {}
                for layer_idx in sfd_cache.layers:
                    act_key = f"layer_{layer_idx}_h"
                    act = self.mm.activations.get(act_key)
                    if act is not None:
                        layer_acts[layer_idx] = act[0, :seq_len].float().cpu().numpy()

                if layer_acts:
                    result.sfd = compute_sfd_sequence(layer_acts, sfd_cache)
                    logger.info(f"[SFD] density_mean={result.sfd.density_mean:.4f}")
            except Exception as e:
                logger.warning(f"[SFD] Computation failed: {e}")

        # Capture per-token domain embeddings at two depths:
        #   - Subject layer (domain_embedding_layer_frac): determines angular wedge
        #   - Escalation layer (domain_escalation_layer_frac): determines ring
        # Position 0 is skipped by default (positional artifact).
        skip_first = not engine_config.get("include_first_token")
        start_pos = 1 if skip_first else 0

        use_projection = engine_config.get("probe_projection_space")
        use_attn_pool = engine_config.get("attention_weighted_pool")

        def _project_and_normalize(raw_tok, layer_idx):
            """Optionally project through o_proj delta, then L2-normalize."""
            tok = raw_tok
            if use_projection:
                delta = state.o_delta(layer_idx)
                if delta is not None:
                    # h @ delta.T → correction-space projection
                    tok = torch.matmul(
                        torch.tensor(raw_tok, dtype=torch.float32),
                        delta.float().cpu().T
                    ).numpy()
            norms = np.linalg.norm(tok, axis=1, keepdims=True)
            norms[norms < 1e-12] = 1.0
            return tok / norms

        def _pool_embedding(raw_tok, layer_idx):
            """Pool per-token embeddings into prompt embedding."""
            if use_attn_pool:
                attn_key = f"layer_{layer_idx}_attn"
                attn = self.mm.attn_weights.get(attn_key)
                if attn is not None:
                    # Use last position's attention as pooling weights
                    # attn shape: [1, n_heads, seq_len, seq_len]
                    # Mean over heads, take last row, slice to match raw_tok
                    w = attn[0, :, -1, start_pos:seq_len].mean(dim=0).float().cpu().numpy()
                    w_sum = w.sum()
                    if w_sum > 1e-12 and len(w) == len(raw_tok):
                        return (raw_tok * w[:, None] / w_sum).sum(axis=0)
            # Fallback: uniform mean
            return raw_tok.mean(axis=0)

        de_key = f"layer_{domain_layer}_h"
        de_act = self.mm.activations.get(de_key)
        if de_act is not None and seq_len > 1:
            raw_tok = de_act[0, start_pos:seq_len].float().cpu().numpy()

            per_tok_normed = _project_and_normalize(raw_tok, domain_layer)
            result.per_token_domain_emb = per_tok_normed.tolist()
            result.per_token_domain_offset = start_pos

            # Prompt embedding (attention-weighted or mean-pooled)
            emb = _pool_embedding(raw_tok, domain_layer)
            norm = float(np.linalg.norm(emb))
            if norm > 1e-12:
                emb = emb / norm
            result.domain_embedding = [round(float(x), engine_config.get("serialization_precision")) for x in emb]

        # Escalation layer (may be same as domain layer)
        if escalation_layer != domain_layer:
            esc_key = f"layer_{escalation_layer}_h"
            esc_act = self.mm.activations.get(esc_key)
            if esc_act is not None and seq_len > 1:
                esc_raw = esc_act[0, start_pos:seq_len].float().cpu().numpy()
                result.per_token_escalation_emb = _project_and_normalize(esc_raw, escalation_layer).tolist()
        else:
            # Same depth for both — reuse subject embeddings for escalation
            result.per_token_escalation_emb = result.per_token_domain_emb

        # Final hidden state (from model's final norm layer)
        final_act = self.mm.activations.get("final_norm_h")
        if final_act is not None and seq_len > 1:
            final_raw = final_act[0, start_pos:seq_len].float().cpu().numpy()
            norms = np.linalg.norm(final_raw, axis=1, keepdims=True)
            norms[norms < 1e-12] = 1.0
            result.per_token_final_emb = (final_raw / norms).tolist()

        # Free activations and hooks before KL/response pass
        self.mm.clear_activations()
        self.mm._remove_hooks()

        # KL divergence + base model responses + base counterfactuals (separate base-model pass)
        needs_base = compute_kl or capture_responses or compute_ltp
        has_base = state.model_base is not None
        has_cache = base_cache is not None
        logger.info(f"[BASE PASS] needs={needs_base} (kl={compute_kl}, cap={capture_responses}, ltp={compute_ltp}), model_base loaded={has_base}, cached={has_cache}")

        if needs_base and has_cache:
            # Sequential mode: populate results from pre-computed cache
            if capture_responses and "base_topk" in base_cache:
                result.base_topk = base_cache["base_topk"]
            if "base_counterfactual_tokens" in base_cache:
                result.base_counterfactual_tokens = base_cache["base_counterfactual_tokens"]
            # KL from cached base log-softmax
            if compute_kl and "base_log_softmax" in base_cache:
                base_log_p = base_cache["base_log_softmax"]
                if base_log_p is not None:
                    logits_i = model_out.logits[0]
                    log_p_i = torch.log_softmax(logits_i, dim=-1)
                    p_i = torch.softmax(logits_i, dim=-1)
                    # base_log_p is numpy or tensor [seq_len, vocab]
                    if not isinstance(base_log_p, torch.Tensor):
                        base_log_p = torch.tensor(base_log_p, device=logits_i.device, dtype=logits_i.dtype)
                    per_tok_kl = (p_i * (log_p_i - base_log_p)).sum(dim=-1)
                    result.per_token_kl = per_tok_kl.float().cpu().numpy()
                    result.kl_divergence = float(per_tok_kl[-1].item())
                    del log_p_i, p_i, per_tok_kl
            logger.info(f"[BASE CACHE] Used cached base data (topk={len(result.base_topk)}, cf={len(result.base_counterfactual_tokens)}, kl={'yes' if result.kl_divergence is not None else 'no'})")
        elif needs_base and has_base:
            # Concurrent mode: run base model live (original path)
            self._compute_behavioral_comparison(
                result, state,
                instruct_logits=model_out.logits,
                compute_kl=compute_kl,
                capture_base=capture_responses,
                topk=response_topk)

        # Rank displacement: compare base vs instruct counterfactual orderings
        if (compute_sfd or compute_ltp) and result.ltp is not None:
            try:
                inst_cf = result.ltp.counterfactual_tokens if hasattr(result.ltp, 'counterfactual_tokens') else []
                base_cf = result.base_counterfactual_tokens
                if inst_cf and base_cf:
                    result.rank_displacement = compute_rank_displacement(inst_cf, base_cf)
                    rd = result.rank_displacement
                    if rd and rd.get('mean_tau') is not None:
                        logger.info(f"[RANK] tau={rd['mean_tau']:+.3f}, "
                                    f"overlap={rd['mean_overlap']:.3f}, "
                                    f"n={rd['n_comparable']}/{rd['n_positions']}")
            except Exception as e:
                logger.warning(f"[RANK] Displacement computation failed: {e}")

        return result

    def run_base_phase(self, prompts, ltp_k=8, compute_kl=False,
                       capture_responses=False, response_topk=10,
                       progress=None):
        """Phase 1 of sequential pipeline: run base model on all prompts.

        Loads the base model, runs each prompt through it, extracts and
        caches the outputs needed by LTP, RD, and KL, then unloads the
        base model to free memory for the instruct phase.

        Args:
            prompts: list of {"prompt": str, "category": str}
            ltp_k: number of counterfactual alternatives to cache
            compute_kl: if True, cache full log-softmax per position (large)
            capture_responses: if True, cache base top-k at last position
            response_topk: number of top-k to capture for base_topk
            progress: optional callback(stage, message)

        Returns:
            list of base_cache dicts, one per prompt, each containing:
              per_position_base_alts: [[(token_id, prob), ...], ...] for LTP
              base_topk: [(token_str, prob), ...] for capture_responses
              base_counterfactual_tokens: [[(tok_str, prob), ...], ...] for RD
              base_log_softmax: np.ndarray or None for KL
        """
        state = self.mm.state
        overfetch = engine_config.get("ltp_overfetch_second") or 5

        if progress:
            progress("base_phase", f"Loading base model for sequential phase...")

        # Load the base model
        self.mm.load_base_for_kl(callback=progress)

        if state.model_base is None:
            logger.error("[BASE PHASE] Failed to load base model")
            return [{}] * len(prompts)

        all_caches = []
        try:
            for pi, p in enumerate(prompts):
                prompt_text = p["prompt"]
                if progress and (pi + 1) % 5 == 0:
                    progress("base_phase", f"[Base phase {pi+1}/{len(prompts)}] {prompt_text[:40]}...")

                inputs = state.tokenizer(prompt_text, return_tensors="pt").to(state.device)
                token_ids = inputs["input_ids"][0]
                seq_len = token_ids.shape[0]

                with torch.no_grad():
                    out_base = state.model_base(**inputs)
                    base_logits = out_base.logits[0]  # [seq_len, vocab]

                cache = {}

                # Per-position base alternatives (for LTP + base bank)
                base_alts = []
                base_cf = []
                for i in range(seq_len):
                    chosen_id = token_ids[i].item()
                    topk_result = torch.topk(base_logits[i], ltp_k + overfetch)
                    probs = torch.softmax(topk_result.values, dim=-1)
                    alts_ids = []
                    alts_strs = []
                    for j, tid in enumerate(topk_result.indices.tolist()):
                        if tid != chosen_id and len(alts_ids) < ltp_k:
                            alts_ids.append((tid, probs[j].item()))
                            alts_strs.append((
                                state.tokenizer.decode(tid).strip(),
                                round(probs[j].item(), engine_config.get("serialization_precision"))
                            ))
                    base_alts.append(alts_ids)
                    base_cf.append(alts_strs)

                cache["per_position_base_alts"] = base_alts
                cache["base_counterfactual_tokens"] = base_cf

                # Base top-k at last position (for capture_responses)
                if capture_responses:
                    last_probs = torch.softmax(base_logits[-1], dim=-1)
                    tk = torch.topk(last_probs, min(response_topk, last_probs.shape[0]))
                    cache["base_topk"] = [
                        (state.tokenizer.decode(idx.item()).strip(),
                         round(p.item(), engine_config.get("serialization_precision")))
                        for idx, p in zip(tk.indices, tk.values)
                    ]
                    del last_probs

                # Full log-softmax for KL divergence (optional, large)
                if compute_kl:
                    cache["base_log_softmax"] = torch.log_softmax(
                        base_logits, dim=-1).float().cpu().numpy().astype(np.float16)

                del base_logits, out_base
                all_caches.append(cache)

                # Periodic memory cleanup
                if (pi + 1) % 20 == 0:
                    import gc as _gc
                    _gc.collect()

        finally:
            # Always unload base model, even on error
            if progress:
                progress("base_phase", "Unloading base model...")
            self.mm.unload_base()
            import gc as _gc
            _gc.collect()
            try:
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
            except Exception:
                pass

        logger.info(f"[BASE PHASE] Complete: {len(all_caches)} prompts cached, "
                    f"KL={'yes' if compute_kl else 'no'}")
        if progress:
            progress("base_phase", f"Base phase complete: {len(all_caches)} prompts cached")

        return all_caches

    def _compute_ltp(self, logits, tokens, input_ids,
                     k: int = 8, layer_strategy: str = "signal",
                     svd_rank: int = 0,
                     base_logits=None,
                     precomputed_base_alts=None) -> LTPResult:
        """Compute LTP using cached activations from the forward pass."""
        from engine.ltp import compute_ltp as _compute_ltp

        # Build caches on demand (lazy, persist for model lifetime)
        svd_cache = self._get_svd_cache(svd_rank) if svd_rank > 0 else None

        return _compute_ltp(
            self.mm, logits, tokens, input_ids,
            k=k, layer_strategy=layer_strategy,
            svd_cache=svd_cache, svd_rank=svd_rank,

            base_logits=base_logits,
            precomputed_base_alts=precomputed_base_alts)

    def _extract_signed_attribution(self, result, seq_len, state):
        """Extract signed attribution with per-layer detail and proof checks."""
        n_kv_heads = state.n_kv_heads
        head_dim = state.head_dim
        n_heads = state.n_heads
        heads_per_kv = n_heads // n_kv_heads

        layer_attrs = []

        for layer_idx in state.signal_layers:
            h_key = f"layer_{layer_idx}_h"
            a_key = f"layer_{layer_idx}_attn"

            if h_key not in self.mm.activations or a_key not in self.mm.attn_weights:
                continue

            h = self.mm.activations[h_key][0, :seq_len].float()
            alpha = self.mm.attn_weights[a_key][0, :, :seq_len, :seq_len].float()
            dw_v = state.v_delta(layer_idx)
            if dw_v is None:
                continue

            v = torch.matmul(h, dw_v.float().T)
            v_heads = v.view(seq_len, n_kv_heads, head_dim)

            alpha_grouped = alpha.view(n_kv_heads, heads_per_kv, seq_len, seq_len)
            alpha_kv = alpha_grouped.mean(dim=1)

            head_attrs = []
            layer_amp = 0.0
            for kv_head in range(n_kv_heads):
                v_h = v_heads[:, kv_head, :]
                a_h = alpha_kv[kv_head]
                delta = torch.matmul(a_h, v_h)
                d_norm = delta.norm(dim=-1, keepdim=True).clamp(min=1e-8)
                u_hat = delta / d_norm
                proj = torch.matmul(u_hat, v_h.T)
                signed = a_h * proj
                head_attrs.append(signed[-1, :])
                layer_amp += d_norm[-1].item()

                # Proof 1 exactness: sum of signed attr should equal ||delta||
                attr_sum = signed[-1, :].sum().item()
                delta_norm_val = d_norm[-1].item()
                error = abs(attr_sum - delta_norm_val)
                result.proof1_checks.append({
                    "layer": layer_idx, "head": kv_head,
                    "attr_sum": round(attr_sum, 8),
                    "delta_norm": round(delta_norm_val, 8),
                    "error": float(f"{error:.2e}"),
                    "exact": error < engine_config.get("proof1_threshold"),
                })

            layer_attr = torch.stack(head_attrs).mean(dim=0)
            layer_attrs.append(layer_attr)
            result.per_layer_amplitude[layer_idx] = layer_amp / n_kv_heads
            result.per_layer_signed_attr[layer_idx] = layer_attr.float().numpy().tolist()

        if not layer_attrs:
            return

        avg_attr = torch.stack(layer_attrs).mean(dim=0).float().numpy()
        result.signed_attr = avg_attr
        result.net_correction = float(avg_attr.sum())
        result.n_negative_tokens = int(sum(1 for a in avg_attr if a < 0))
        result.has_negative_tokens = result.n_negative_tokens > 0

        # Distribution metrics
        attr_abs = np.abs(avg_attr)
        total = attr_abs.sum()
        attr_dist = attr_abs / total if total > 0 else np.ones_like(attr_abs) / len(attr_abs)

        ent = -np.sum(attr_dist * np.log(attr_dist + 1e-10))
        max_ent = np.log(seq_len) if seq_len > 1 else 1.0
        result.entropy = float(ent / max_ent)

        # Bookend / interior split: proportional boundary (configurable,
        # minimum 1 token) instead of fixed first/last token.
        n = len(attr_dist)
        boundary = max(1, round(engine_config.get("boundary_fraction") * n))
        if n >= 2:
            result.top2_share = float(attr_dist[:boundary].sum() + attr_dist[-boundary:].sum())
            interior = attr_dist[boundary:-boundary] if n > 2 * boundary else np.array([])
            if len(interior) > 0:
                result.middle_share = float(interior.sum())
                imean = interior.mean()
                result.interior_cv = float(interior.std() / imean) if imean > 0 else 0.0
            else:
                result.middle_share = float(1.0 - result.top2_share)
                result.interior_cv = 0.0
        else:
            result.top2_share = 1.0
            result.middle_share = 0.0
            result.interior_cv = 0.0

    def _extract_stress_score(self, result, seq_len, state):
        per_token_total = torch.zeros(seq_len)
        n_layers = 0

        for layer_idx in state.signal_layers:
            key = f"layer_{layer_idx}_h"
            if key not in self.mm.activations:
                continue
            h = self.mm.activations[key]

            for p in ["q", "k", "v"]:
                dname = f"model.layers.{layer_idx}.self_attn.{p}_proj.weight"
                if dname in state.deltas:
                    dw = state.deltas[dname]
                    fnorm = state.delta_frob_norms[dname]
                    if dw.shape[1] == h.shape[2] and fnorm > 0:
                        projected = torch.matmul(h[0, :seq_len].float(), dw.float().T)
                        per_token_total += projected.norm(dim=-1) / fnorm
            n_layers += 1

        if n_layers > 0:
            per_token_total /= n_layers

        result.stress_score = float(per_token_total.mean().item())
        result.per_token_stress = per_token_total.numpy()

    def _extract_amplitude_trajectory(self, result, seq_len, state):
        raw_traj = []
        norm_traj = []
        heatmap_rows = []

        for layer_idx in range(state.n_layers):
            for sublayer_type in ["attn", "mlp"]:
                key = f"layer_{layer_idx}_traj_{sublayer_type}"
                if key not in self.mm.activations:
                    raw_traj.append(0.0)
                    norm_traj.append(0.0)
                    heatmap_rows.append(np.zeros(seq_len))
                    continue

                h = self.mm.activations[key]
                if sublayer_type == "attn":
                    dnames = [f"model.layers.{layer_idx}.self_attn.{p}_proj.weight"
                              for p in ["q", "k", "v"]]
                else:
                    dnames = [f"model.layers.{layer_idx}.mlp.{p}_proj.weight"
                              for p in ["gate", "up"]]

                raw_sum = 0.0
                norm_sum = 0.0
                per_tok = torch.zeros(seq_len)

                for dname in dnames:
                    if dname in state.deltas:
                        dw = state.deltas[dname]
                        fnorm = state.delta_frob_norms[dname]
                        if dw.shape[1] == h.shape[2] and fnorm > 0:
                            h_slice = h[0, :seq_len].float()  # upcast bfloat16 → float32
                            projected = torch.matmul(h_slice, dw.float().T)
                            pn = projected.norm(dim=-1)
                            raw_sum += pn.mean().item()
                            norm_sum += (pn / fnorm).mean().item()
                            per_tok += pn / fnorm

                raw_traj.append(raw_sum)
                norm_traj.append(norm_sum)
                heatmap_rows.append(per_tok.float().numpy())

        result.amplitude_trajectory = raw_traj
        result.amplitude_normalized = norm_traj
        result.heatmap = np.array(heatmap_rows)

    def _compute_full_capture_metrics(self, result, seq_len, state):
        """Derive coherence, spectral rank, attn/MLP split, and similarity from the heatmap.

        The heatmap is (n_sublayers x seq_len) where sublayers alternate attn/mlp.
        Each token gets a n_sublayer-dim profile of correction norms across the network.
        This is sufficient to compute all four derived metrics without storing raw vectors,
        since q/k/v/gate/up projections have different output dimensions (GQA) and
        cannot be meaningfully summed in a common vector space.
        """
        if result.heatmap is None or result.heatmap.size == 0:
            return

        hm = result.heatmap  # (n_sublayers, seq_len)
        n_sub, n_tok = hm.shape
        if n_tok != seq_len or n_sub < 2:
            return

        # ─── Attn vs MLP fraction per token ───
        attn_rows = hm[0::2]  # Even indices = attn sublayers
        mlp_rows = hm[1::2]   # Odd indices = mlp sublayers
        attn_sum = attn_rows.sum(axis=0)  # (seq_len,)
        mlp_sum = mlp_rows.sum(axis=0)
        total = attn_sum + mlp_sum
        result.attn_frac = np.where(total > 0, attn_sum / total, 0.5)

        # ─── Per-token coherence: consistency of correction profile across layers ───
        # For each token, measure how peaked vs uniform its sublayer profile is.
        # High coherence = correction concentrated in few sublayers (consistent strategy)
        # Low coherence = correction spread uniformly (no dominant strategy)
        profiles = hm.T  # (seq_len, n_sublayers) -- each row is a token's correction profile
        coherence = np.zeros(n_tok)
        for i in range(n_tok):
            p = profiles[i]
            total_p = p.sum()
            if total_p > 0:
                normed = p / total_p
                # Coherence = 1 - normalized entropy (1 = perfectly concentrated, 0 = uniform)
                ent = -np.sum(normed * np.log(normed + 1e-10))
                max_ent = np.log(n_sub) if n_sub > 1 else 1.0
                coherence[i] = 1.0 - (ent / max_ent)
        result.per_token_coherence = coherence

        # ─── Per-token spectral rank (effective dimensionality of correction pattern) ───
        # SVD of the heatmap reveals how many independent correction modes exist
        try:
            # Use the full heatmap transposed: (seq_len, n_sublayers)
            u, s, _ = np.linalg.svd(profiles, full_matrices=False)
            s = s[s > 1e-8]
            if len(s) > 0:
                p_s = s / s.sum()
                ent = -np.sum(p_s * np.log(p_s))
                global_spectral_rank = float(np.exp(ent))
            else:
                global_spectral_rank = 1.0
        except Exception:
            global_spectral_rank = 1.0

        # Per-token: how many sublayers contribute meaningfully to this token's correction
        spectral_ranks = []
        for i in range(n_tok):
            p = profiles[i]
            nonzero = p[p > 1e-8]
            if len(nonzero) > 1:
                normed = nonzero / nonzero.sum()
                ent = -np.sum(normed * np.log(normed))
                spectral_ranks.append(round(float(np.exp(ent)), engine_config.get("serialization_precision")))
            else:
                spectral_ranks.append(1.0)
        result.per_token_spectral_rank = spectral_ranks

        # ─── Token x token similarity matrix ───
        # Cosine similarity of sublayer correction profiles between all token pairs
        norms = np.linalg.norm(profiles, axis=1, keepdims=True)
        norms = np.where(norms > 1e-8, norms, 1.0)
        normed_profiles = profiles / norms
        sim = normed_profiles @ normed_profiles.T
        result.token_similarity = sim

    def _compute_behavioral_comparison(self, result, state,
                                        instruct_logits=None,
                                        compute_kl=False,
                                        capture_base=False,
                                        topk=10):
        """KL divergence, base model predictions, and base counterfactuals.
        Reuses instruct logits from the main forward pass — only runs base model."""
        inputs = state.tokenizer(result.prompt, return_tensors="pt").to(state.device)
        with torch.no_grad():
            # Reuse instruct logits from main analysis pass (no redundant forward)
            logits_i = instruct_logits[0] if instruct_logits is not None else None

            out_base = state.model_base(**inputs)

            if compute_kl and logits_i is not None:
                logits_b = out_base.logits[0]

                log_p_i = torch.log_softmax(logits_i, dim=-1)
                log_p_b = torch.log_softmax(logits_b, dim=-1)
                p_i = torch.softmax(logits_i, dim=-1)

                per_tok_kl = (p_i * (log_p_i - log_p_b)).sum(dim=-1)
                result.per_token_kl = per_tok_kl.float().cpu().numpy()
                result.kl_divergence = float(per_tok_kl[-1].item())
                del log_p_i, log_p_b, p_i, per_tok_kl

            if capture_base:
                logits_base = out_base.logits[0, -1, :]
                probs_base = torch.softmax(logits_base, dim=-1)
                tk = torch.topk(probs_base, min(topk, probs_base.shape[0]))
                result.base_topk = [
                    (state.tokenizer.decode(idx.item()).strip(), round(p.item(), engine_config.get("serialization_precision")))
                    for idx, p in zip(tk.indices, tk.values)
                ]
                del logits_base, probs_base

            # Per-token base counterfactuals for terrain map base bank
            base_logits_full = out_base.logits[0]  # [seq_len, vocab]
            token_ids = inputs["input_ids"][0]
            ltp_k = result.ltp.k if result.ltp else 8
            base_cf = []
            for i in range(base_logits_full.shape[0]):
                chosen_id = token_ids[i].item()
                topk_result = torch.topk(base_logits_full[i], ltp_k + 5)
                probs = torch.softmax(topk_result.values, dim=-1)
                alts = []
                for j, tid in enumerate(topk_result.indices.tolist()):
                    if tid != chosen_id and len(alts) < ltp_k:
                        alts.append((
                            state.tokenizer.decode(tid).strip(),
                            round(probs[j].item(), engine_config.get("serialization_precision"))
                        ))
                base_cf.append(alts)
            result.base_counterfactual_tokens = base_cf
            logger.info(f"[BASE CF] Generated {len(base_cf)} base counterfactual token sets (k={ltp_k})")
            del base_logits_full, out_base


def result_to_dict(r: PromptResult) -> dict:
    """Serialize a PromptResult for JSON transport."""
    def _native(v):
        if v is None:
            return None
        if isinstance(v, (np.integer,)):
            return int(v)
        if isinstance(v, (np.floating, np.float32, np.float64)):
            v = float(v)
            if np.isnan(v) or np.isinf(v):
                return None
            return v
        if isinstance(v, float):
            if np.isnan(v) or np.isinf(v):
                return None
            return v
        if isinstance(v, np.ndarray):
            return [None if (isinstance(x, float) and (np.isnan(x) or np.isinf(x))) else x
                    for x in v.tolist()]
        if hasattr(v, 'item'):
            val = v.item()
            if isinstance(val, float) and (np.isnan(val) or np.isinf(val)):
                return None
            return val
        return v

    d = {
        "prompt": r.prompt,
        "category": r.category,
        "tokens": r.tokens,
        "seq_len": r.seq_len,
        "stress_score": _native(r.stress_score),
        "per_token_stress": r.per_token_stress.tolist() if r.per_token_stress is not None else [],
        "signed_attr": r.signed_attr.tolist() if r.signed_attr is not None else [],
        "net_correction": _native(r.net_correction),
        "n_negative_tokens": _native(r.n_negative_tokens),
        "has_negative_tokens": r.has_negative_tokens,
        "entropy": _native(r.entropy),
        "top2_share": _native(r.top2_share),
        "middle_share": _native(r.middle_share),
        "interior_cv": _native(r.interior_cv),
        "kl_divergence": _native(r.kl_divergence),
        "per_token_kl": _native(r.per_token_kl) if r.per_token_kl is not None else None,
        "instruct_topk": r.instruct_topk,
        "base_topk": r.base_topk,
        "base_counterfactual_tokens": r.base_counterfactual_tokens,
        "proof1_checks": r.proof1_checks,
        "per_layer_signed_attr": {str(k): v for k, v in r.per_layer_signed_attr.items()},
        "amplitude_trajectory": [_native(v) for v in r.amplitude_trajectory],
        "amplitude_normalized": [_native(v) for v in r.amplitude_normalized],
        "heatmap": r.heatmap.tolist() if r.heatmap is not None else [],
        "signal_layer_indices": r.signal_layer_indices,
        "per_layer_amplitude": {str(k): _native(v) for k, v in r.per_layer_amplitude.items()},
        "full_capture_enabled": r.full_capture_enabled,
        "delta_scale": _native(r.delta_scale),
        "spectral_summary": r.spectral_summary,
    }

    # Full capture derived metrics
    if r.full_capture_enabled:
        d["per_token_coherence"] = r.per_token_coherence.tolist() if r.per_token_coherence is not None else []
        d["per_token_spectral_rank"] = r.per_token_spectral_rank or []
        d["attn_frac"] = r.attn_frac.tolist() if r.attn_frac is not None else []
        d["token_similarity"] = r.token_similarity.tolist() if r.token_similarity is not None else []

    # LTP data
    if r.ltp is not None:
        d["ltp"] = ltp_result_to_dict(r.ltp)
    else:
        d["ltp"] = None

    # SFD data
    if r.sfd is not None:
        d["sfd"] = r.sfd.to_dict()
    else:
        d["sfd"] = None

    # Rank displacement data
    d["rank_displacement"] = r.rank_displacement

    # Domain embedding (for domain surface module)
    d["domain_embedding"] = r.domain_embedding
    d["per_token_domain_emb"] = r.per_token_domain_emb
    d["per_token_escalation_emb"] = r.per_token_escalation_emb
    d["per_token_final_emb"] = r.per_token_final_emb
    d["per_token_domain_offset"] = r.per_token_domain_offset

    # Final recursive sanitization — the single authoritative point where
    # all NaN/Inf values are guaranteed replaced with None.  This ensures
    # the dict is safe for json.dump (Python writes NaN literally, which
    # is invalid JSON) and prevents NaN from leaking into session storage,
    # CSV export, or frontend rendering.
    d = _sanitize_all(d)

    return d


def _sanitize_all(obj):
    """Recursively replace NaN/Inf floats with None throughout a nested structure.
    Also coerces stray numpy scalars and arrays that may have been introduced
    by post-processing."""
    if isinstance(obj, float):
        if np.isnan(obj) or np.isinf(obj):
            return None
        return obj
    if isinstance(obj, (np.floating, np.float32, np.float64)):
        v = float(obj)
        return None if (np.isnan(v) or np.isinf(v)) else v
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, np.ndarray):
        return _sanitize_all(obj.tolist())
    if isinstance(obj, dict):
        return {k: _sanitize_all(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_sanitize_all(v) for v in obj]
    return obj
