# Changelog — Prompt Deconstruction + Analyze-Pipeline Unification

_2026-05-29_

## Summary

Adds an opt-in **Deconstruct** mode that expands each prompt into its
prefix ladder — `I` / `I like` / `I like cake` / `I like cake.` — and
analyzes every rung as its own record, so a prompt's contextual field
can be tracked one unit at a time against the fixed probe lattice.
Punctuation earns its own rung. Each rung record carries `family_index`
and `rung_index` so the ladder regroups in the data table and
downstream modules.

Along the way, the duplicated single-prompt and batch analyze paths were
collapsed onto one shared analysis core (a single prompt is now just a
one-element batch), which is what lets Deconstruct hook the pipeline in
exactly one place.

The toggle is runtime-only — it resets on reset/reboot and is not
persisted as configuration.

## Added

- **`src/engine/deconstruct.py`** (new) — pure prompt segmentation.
  - `segment_prompt(text)` returns the prefix ladder as literal prefixes
    of the original string (cut at unit boundaries), so the final rung
    is byte-identical to the input — the model never sees a re-spaced or
    re-tokenized variant.
  - Policy: a punctuation **run** is its own rung (`...` is one rung);
    intra-word apostrophes and hyphens stay attached (`don't`,
    `well-being` are single units).
  - `expand_prompts(prompts, enabled)` expands a prompt list into rung
    records (no-op when disabled); each rung gains `rung_index` and a
    provisional `family_local`.
- **Deconstruct checkbox** in the analyze control panel
  (`static/index.html`, `id="cfgDeconstruct"`). Applies to both single
  and batch since it flows through the shared form-data builder.
  Runtime-only (no `saveConfig`).
- **`family_index` / `rung_index`** persisted as indexed columns on the
  results table (not blob-only) so they surface in the data table
  without decompression.
- **`Fam·Rung` column** in the data table (`static/js/main.js`); shows
  `family.rung` for ladder rows, blank otherwise.
- **`Database.next_family_base(session_id)`** — assigns collision-free
  family ids (`MAX(family_index)+1`), robust against the idx reindexing
  that `remove_results` performs.
- Single-analyze response now includes **`n_rungs`** so the frontend
  knows when one prompt produced several records.

## Changed

- **Unified analyze pipeline** (`src/engine/app_core.py`). The
  duplicated analysis body in `api_analyze_handler` and
  `api_analyze_batch_handler` is replaced by one shared core,
  `_analyze_prompt_list(prompts, flags, *, deconstruct, progress)`, plus
  a shared `_read_analyze_flags(form, *, trajectory_default)`. The two
  endpoints remain as thin wrappers preserving their response contracts:
  single is synchronous and returns the result inline; batch is async
  and returns "started". Deconstruct + family/rung assignment happen
  once, in the core.
- **Single-prompt path, on deconstruct**: stores all rungs and returns
  the final rung (the complete prompt) as the inline result; the data
  table refreshes from the server (using `n_rungs`) so it shows the full
  ladder rather than just the inline result.
- **`db.py`** schema/IO updated for the two new columns: `CREATE TABLE`
  DDL, `_migrate_columns` (in-place `ALTER TABLE ADD COLUMN` on existing
  databases — upgrades automatically on boot), `_extract_scalars`,
  `ResultsList.append`, `Database.insert_result`, and
  `get_dashboard_rows`.

## Behavior preserved

- The console (`progressLog`) is **not** cleared on the analyze path;
  `clearLog()` remains limited to model load and explicit reset. A
  deconstructed run appends per-rung progress; an ordinary single run
  stays quiet, as before.
- Deconstruct OFF is a true no-op: prompts are analyzed exactly as
  before and `family_index`/`rung_index` are stored as `NULL`
  (NULL = "not part of a ladder").
- `ltp_svd_rank` is passed uniformly with default `0` — identical to the
  batch path's prior implicit behavior.

## Migration notes

- Existing `~/.tagm/tagm.db` files upgrade in place on first boot via
  `_migrate_columns`; no manual step. Pre-existing rows get `NULL` for
  the two new columns.

## Known item (deferred, by design)

- A decimal splits under the current punctuation rule
  (`3.5` → `3` / `3.` / `3.5`), because `.` is treated as punctuation
  regardless of context. Decoupled from everything else; gluing
  digit-period-digit is a one-line regex change in `deconstruct.py`.

## Notes / not yet verified

- All touched Python compiles; both result INSERTs balance at 26
  columns/placeholders/values; `main.js` parses. The new data path was
  integration-tested against a real SQLite DB (plain row → NULL; a
  deconstructed prompt → family 0, rungs 0–3 regrouping in order; a
  subsequent call → families 1, 2 with no collision).
- A live forward pass was **not** runnable in the dev environment
  (no torch). First thing to confirm on the Codespace: a single prompt
  with Deconstruct checked produces N rows sharing one family with
  sequential rungs, and the period lands on its own rung.

## Files touched

- `src/engine/deconstruct.py` (new)
- `src/core/db.py`
- `src/engine/app_core.py`
- `static/js/main.js`
- `static/index.html`
