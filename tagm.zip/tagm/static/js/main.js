const $=id=>document.getElementById(id);
let modelLoaded=false, sessionResults=[], dashResults=[], promptLibraryData=[], _busy=false;
var _promptTotal=0;

function setStatus(s,t){const p=$('statusPill');p.className='status-pill '+s;p.textContent=t||s.toUpperCase()}
function log(m,t=''){const el=$('progressLog'),d=document.createElement('div');d.className='entry '+t;d.textContent=m;el.appendChild(d);el.scrollTop=el.scrollHeight}
function clearLog(){$('progressLog').innerHTML=''}
function setLoading(b,l){b.disabled=l;if(l)b.dataset.orig=b.textContent;b.textContent=l?'Processing...':(b.dataset.orig||b.textContent)}
function pillClass(c){return({'benign':'pill-benign','baseline':'pill-benign','mild':'pill-mild','harmful':'pill-harmful','jailbreak':'pill-jailbreak','adversarial':'pill-adversarial','dual-use':'pill-dual-use'})[c]||''}
function toggleFeature(el){
  const f=el.closest('.feature');if(!f)return;
  const b=f.querySelector('.feature-body');if(!b)return;
  b.classList.toggle('collapsed');
  const ch=el.querySelector('.chevron');
  if(ch)ch.textContent=b.classList.contains('collapsed')?'\u25B6':'\u25BC';
}
function escHtml(s){const d=document.createElement('div');d.textContent=s;return d.innerHTML}
function fmtLN(v){if(v==null)return'';const s=v>0?'+':'',c=v>0.5?'positive':(v<-0.5?'negative':'neutral');return`<div class="metric-ln ${c}">${s}${v.toFixed(2)}sd</div>`}
function mc(l,v,ln,fmt,cls){const fv=fmt?fmt(v):(typeof v==='number'?v.toFixed(4):v);const extra=cls?` ${cls}`:'';return`<div class="metric-cell${extra}"><div class="metric-label">${l}</div><div class="metric-value">${fv}</div>${fmtLN(ln)}</div>`}
function switchMainTab(el,id){el.parentElement.querySelectorAll('.main-tab').forEach(t=>t.classList.remove('active'));el.classList.add('active');document.querySelectorAll('.tab-panel').forEach(p=>p.classList.remove('active'));$(id).classList.add('active')}
function showError(elId,msg){const el=$(elId);if(msg){el.innerHTML=`<div class="error-msg">${escHtml(msg)}</div>`;setTimeout(()=>el.innerHTML='',5000)}else el.innerHTML=''}

// ─── Card Collapse Defaults ─────────────────────────────────────
const CARD_COLLAPSE_DEFAULTS={prompt:'expanded',modules:'expanded',config:'expanded'};
const CARD_COLLAPSE_LABELS={prompt:'Prompt',modules:'Modules',config:'Configuration'};
function cardDefault(tab){return CARD_COLLAPSE_DEFAULTS[tab]==='collapsed'?' collapsed':''}
function applyCardDefaults(panelId,tab){
  const panel=$(panelId);if(!panel)return;
  const bodies=panel.querySelectorAll('.card-body');
  bodies.forEach(b=>{
    if(CARD_COLLAPSE_DEFAULTS[tab]==='collapsed')b.classList.add('collapsed');
    else b.classList.remove('collapsed');
  });
}

// ─── Export Defaults ────────────────────────────────────────────
const EXPORT_DEFAULTS={csv:true,pdf:false,json:false,charts:false,includeArrays:true,exportPath:''};
const DISPLAY_DEFAULTS={terrainCharLimit:50,terrainRecordLimit:100,terrainTokenLimit:20,terrainCategory:'all',terrainAutoRotate:false,terrainRotateSpeed:0.3};

// Global delegated click handler for all card headers
document.addEventListener('click',function(e){
  // Don't toggle if clicking a button inside the header (e.g. popout)
  if(e.target.closest('button'))return;
  const header=e.target.closest('.card-header');
  if(!header)return;
  const body=header.nextElementSibling;
  if(body&&body.classList.contains('card-body'))body.classList.toggle('collapsed');
});

// ─── Visualization Registry ──────────────────────────────────────
const VIZ_REGISTRY = {
  // ── Per-Prompt: ASM Core ──
  signed_attribution:  {cat:'ASM Core',   title:'Signed Attribution',         on:true,  scope:'prompt', order:20, type:'plot', desc:'Per-token contribution to alignment correction'},
  stress_per_token:    {cat:'ASM Core',   title:'Per-Token Stress',           on:true,  scope:'prompt', order:30, type:'plot', desc:'Correction pressure at discriminative middle layers'},
  heatmap:             {cat:'ASM Core',   title:'Token × Layer Heatmap',      on:true,  scope:'prompt', order:40, type:'plot', desc:'2D correction intensity by token and sublayer'},
  amplitude_trajectory:{cat:'ASM Detail', title:'Layer Trajectory (single)',   on:true, scope:'batch', order:10, type:'plot', desc:'Single-prompt correction through model depth'},

  // ── Per-Prompt: ASM Detail ──
  distribution_metrics:{cat:'ASM Detail', title:'Distribution Metrics',       on:true, scope:'prompt', order:50, type:'plot', desc:'Entropy, boundary/interior bars'},
  token_table:         {cat:'ASM Detail', title:'Attribution Table',          on:true,  scope:'prompt', order:60, type:'js',   desc:'Raw per-token values with inline bars'},
  model_predictions:   {cat:'ASM Detail', title:'Model Predictions',          on:true,  scope:'prompt', order:70, type:'js',   desc:'Instruct vs base top-k tokens'},

  // ── Per-Prompt: LTP ──
  ltp_tension_magnitudes:{cat:'LTP',      title:'Tension Magnitudes',         on:true,  scope:'prompt', order:80, type:'plot', needs:'ltp', desc:'Per-token lateral tension colored by profile shape'},
  ltp_profiles:        {cat:'LTP',        title:'Tension Profiles (Stacked)', on:true, scope:'prompt', order:90, type:'plot', needs:'ltp', desc:'Stacked bar of tension per counterfactual rank'},
  ltp_profile_heatmap: {cat:'LTP',        title:'Token × Rank Heatmap',       on:true, scope:'prompt', order:100, type:'plot', needs:'ltp', desc:'Dense heatmap: token vs rank'},
  ltp_summary_stats:   {cat:'LTP',        title:'LTP Summary Stats',          on:true, scope:'prompt', order:110, type:'plot', needs:'ltp', desc:'M, C, V scalar bars'},
  counterfactual_table:{cat:'LTP',        title:'Counterfactual Table',       on:true,  scope:'prompt', order:120, type:'js',   needs:'ltp', desc:'Alternative tokens at each position'},

  // ── Per-Prompt: SFD ──
  sfd_density:         {cat:'SFD',        title:'Per-Token QK Density',        on:true,  scope:'prompt', order:130, type:'plot',  needs:'sfd', desc:'How many dimensions of the QK routing subspace each token engages'},
  rank_displacement:   {cat:'SFD',        title:'Rank Displacement',           on:true,  scope:'prompt', order:160, type:'plot',  needs:'sfd', desc:'Kendall tau between base and instruct alternative orderings per position'},

  // ── Batch: Analysis tab ──
  separability:        {cat:'Batch Analysis',title:'Effect Sizes (Forest)',    on:true,  scope:'batch', order:20, type:'plot', desc:'Cohen\'s d with CIs for proven metrics'},
  batch_summary:       {cat:'Batch Analysis',title:'Category Distributions',  on:true,  scope:'batch', order:30, type:'plot', desc:'Strip plots with mean+CI for 4 key metrics'},
  key_scatters:        {cat:'Batch Analysis',title:'Separability Scatters',   on:true,  scope:'batch', order:40, type:'plot', desc:'2-panel scatter with confidence ellipses'},
  discriminative_sublayers:{cat:'Batch Analysis',title:'Discriminative Sublayers',on:true,scope:'batch', order:50,type:'plot',desc:'Sublayers ranked by adversarial-benign delta'},
  proof1_summary:      {cat:'Batch Analysis',title:'Proof 1 Verification',    on:true,  scope:'batch', order:60, type:'plot', desc:'Mathematical exactness of the decomposition'},

  // ── Batch: Extended ──
  exp_trajectory_overlay:{cat:'Batch Analysis',title:'Amplitude Trajectories',on:true,scope:'batch', order:70,type:'plot',desc:'All prompts overlaid across sublayer depth — category separation visible at middle layers'},
  exp_difference_from_benign:{cat:'Batch Analysis',title:'Difference from Benign',on:true,scope:'batch', order:80,type:'plot',desc:'Per-category trajectory minus benign mean'},
  exp_metric_scatters: {cat:'Batch Analysis',title:'Full Scatter Grid',   on:true, scope:'batch', order:90,type:'plot',desc:'All pairwise metric scatters including weak metrics'},
  exp_behavioral_comparison:{cat:'Batch Analysis',title:'Behavioral Divergence',on:true,scope:'batch', order:100,type:'plot',desc:'Instruct vs base probabilities and KL'},
  exp_ltp_category_comparison:{cat:'Batch Analysis',title:'LTP by Category',on:true,scope:'batch', order:110,type:'plot',desc:'LTP M,C,V box plots across categories'},
  exp_ltp_m_vs_stress: {cat:'Batch Analysis',title:'LTP M vs Stress',     on:true,  scope:'batch', order:120,type:'plot',desc:'Scatter showing Stress-M anticorrelation'},
  exp_ltp_profile_shapes:{cat:'Batch Analysis',title:'Profile Shapes',    on:true, scope:'batch', order:130,type:'plot',desc:'Shape distribution across categories'},

  // ── Batch: SFD ──
  exp_sfd_category_comparison:{cat:'Batch Analysis',title:'SFD by Category',on:true,scope:'batch', order:140,type:'plot',desc:'SFD density box plot across categories'},
  exp_sfd_vs_asm:      {cat:'Batch Analysis',title:'SFD vs ASM',           on:true, scope:'batch', order:150,type:'plot',desc:'Scatter: QK density vs ASM middle share'},
  exp_rank_displacement:{cat:'Batch Analysis',title:'Rank Displacement',   on:true, scope:'batch', order:160,type:'plot',desc:'Kendall tau by category — base vs instruct reordering'},
};

function vizIsEnabled(key){ return VIZ_REGISTRY[key] && VIZ_REGISTRY[key].on; }
function vizResetDefaults(){ for(const[k,v]of Object.entries(VIZ_REGISTRY)){v.on=v._default} vizRenderConfig();saveConfig(); }
function vizEnableAll(){ for(const v of Object.values(VIZ_REGISTRY)){v.on=true} vizRenderConfig();saveConfig(); }
function vizDisableAll(){ for(const v of Object.values(VIZ_REGISTRY)){v.on=false} vizRenderConfig();saveConfig(); }

function vizRenderConfig(){
  const panel=$('vizConfigPanel'); if(!panel) return;
  const groups={};
  for(const[k,v]of Object.entries(VIZ_REGISTRY)){
    if(!groups[v.cat]) groups[v.cat]=[];
    groups[v.cat].push({key:k,...v});
  }
  let h='';
  // Font size config
  h+=`<div style="margin-bottom:16px;padding-bottom:12px;border-bottom:1px solid var(--border)">
    <div style="font-size:var(--font-desc);font-family:var(--mono);color:var(--text-1);text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px">Font Sizes</div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:8px;max-width:540px">
      <div><label style="font-size:var(--font-desc);color:var(--text-1)">Card titles</label><select id="cfgFontCardTitle" onchange="applyFontConfig();saveConfig()"><option value="12">12px</option><option value="14">14px</option><option value="16">16px</option><option value="18">18px</option><option value="20">20px</option><option value="24" selected>24px</option><option value="28">28px</option><option value="32">32px</option><option value="36">36px</option></select></div>
      <div><label style="font-size:var(--font-desc);color:var(--text-1)">Descriptions</label><select id="cfgFontDesc" onchange="applyFontConfig();saveConfig()"><option value="10">10px</option><option value="11">11px</option><option value="12">12px</option><option value="13" selected>13px</option><option value="14">14px</option><option value="15">15px</option><option value="16">16px</option><option value="18">18px</option><option value="20">20px</option><option value="24">24px</option><option value="28">28px</option><option value="32">32px</option></select></div>
      <div><label style="font-size:var(--font-desc);color:var(--text-1)">Legends</label><select id="cfgFontLegend" onchange="applyFontConfig();saveConfig()"><option value="8">8px</option><option value="9">9px</option><option value="10">10px</option><option value="11" selected>11px</option><option value="12">12px</option><option value="13">13px</option><option value="14">14px</option><option value="16">16px</option><option value="18">18px</option><option value="20">20px</option><option value="24">24px</option></select></div>
      <div><label style="font-size:var(--font-desc);color:var(--text-1)">Data tables</label><select id="cfgFontTable" onchange="applyFontConfig();saveConfig()"><option value="8">8px</option><option value="9">9px</option><option value="10">10px</option><option value="11" selected>11px</option><option value="12">12px</option><option value="13">13px</option><option value="14">14px</option><option value="16">16px</option><option value="18">18px</option><option value="20">20px</option><option value="24">24px</option></select></div>
    </div>
  </div>`;
  // Card collapse defaults per tab
  h+=`<div style="margin-bottom:16px;padding-bottom:12px;border-bottom:1px solid var(--border)">
    <div style="font-size:var(--font-desc);font-family:var(--mono);color:var(--text-1);text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px">Card Default State</div>
    <div style="font-size:var(--font-legend);color:var(--text-0);margin-bottom:8px;line-height:1.5">Whether cards on each tab start expanded or collapsed.</div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:8px;max-width:540px">`;
  for(const[tab,label]of Object.entries(CARD_COLLAPSE_LABELS)){
    const cur=CARD_COLLAPSE_DEFAULTS[tab];
    h+=`<div><label style="font-size:var(--font-desc);color:var(--text-1)">${label}</label><select id="cfgCardDefault_${tab}" onchange="CARD_COLLAPSE_DEFAULTS['${tab}']=this.value;saveConfig()"><option value="expanded"${cur==='expanded'?' selected':''}>Expanded</option><option value="collapsed"${cur==='collapsed'?' selected':''}>Collapsed</option></select></div>`;
  }
  h+=`</div></div>`;
  // Export options
  h+=`<div style="margin-bottom:16px;padding-bottom:12px;border-bottom:1px solid var(--border)">
    <div style="font-size:var(--font-desc);font-family:var(--mono);color:var(--text-1);text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px">Export Options</div>
    <div style="font-size:var(--font-legend);color:var(--text-0);margin-bottom:8px;line-height:1.5">Select which formats to include when exporting. CSV is always generated.</div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:8px;max-width:540px;margin-bottom:10px">
      <div class="checkbox-row"><input type="checkbox" id="cfgExportCsv" checked disabled><label for="cfgExportCsv" style="color:var(--text-2)">CSV (always)</label></div>
      <div class="checkbox-row"><input type="checkbox" id="cfgExportPdf" ${EXPORT_DEFAULTS.pdf?'checked':''} onchange="EXPORT_DEFAULTS.pdf=this.checked;saveConfig()"><label for="cfgExportPdf">PDF report</label></div>
      <div class="checkbox-row"><input type="checkbox" id="cfgExportJson" ${EXPORT_DEFAULTS.json?'checked':''} onchange="EXPORT_DEFAULTS.json=this.checked;saveConfig()"><label for="cfgExportJson">JSON results</label></div>
      <div class="checkbox-row"><input type="checkbox" id="cfgExportCharts" ${EXPORT_DEFAULTS.charts?'checked':''} onchange="EXPORT_DEFAULTS.charts=this.checked;saveConfig()"><label for="cfgExportCharts">Charts &amp; plots</label></div>
    </div>
    <div style="max-width:540px;margin-bottom:10px">
      <div class="checkbox-row"><input type="checkbox" id="cfgExportArrays" ${EXPORT_DEFAULTS.includeArrays?'checked':''} onchange="EXPORT_DEFAULTS.includeArrays=this.checked;saveConfig()"><label for="cfgExportArrays">Include per-token arrays in JSON <span style="color:var(--text-3)">(signed attribution, per-position tau, LTP profiles, SFD per-token — larger file)</span></label></div>
    </div>
    <div style="max-width:540px">
      <label style="font-size:var(--font-desc);color:var(--text-1)">Export path <span style="color:var(--text-3)">(optional — leave blank to download via browser)</span></label>
      <input type="text" id="cfgExportPath" value="${EXPORT_DEFAULTS.exportPath}" placeholder="/path/to/export/directory" onchange="EXPORT_DEFAULTS.exportPath=this.value.trim();saveConfig()" style="margin-bottom:0">
    </div>
  </div>`;
  // Session management
  var sCount=_promptTotal||dashResults.length||sessionResults.length;
  var sessionInfo=sCount>0?(sCount+' results'):'No active session';
  h+=`<div style="margin-bottom:16px;padding-bottom:12px;border-bottom:1px solid var(--border)">
    <div style="font-size:var(--font-desc);font-family:var(--mono);color:var(--text-1);text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px">Session</div>
    <div style="font-size:var(--font-legend);color:var(--text-0);margin-bottom:8px;line-height:1.5">Current session: <strong>${sessionInfo}</strong>. Session data persists on disk across browser refreshes and crashes. Use Restore to recover a session after a page reload.</div>
    <div style="display:flex;gap:8px;max-width:540px">
      <button class="btn btn-sm btn-secondary" onclick="restoreSessionFromDisk()">Restore Session</button>
    </div>
  </div>`;
  // Cache management
  h+=`<div style="margin-bottom:16px;padding-bottom:12px;border-bottom:1px solid var(--border)">
    <div style="font-size:var(--font-desc);font-family:var(--mono);color:var(--text-1);text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px">Cache Management</div>
    <div style="font-size:var(--font-legend);color:var(--text-0);margin-bottom:8px;line-height:1.5">Session data cached on disk. Plots are the largest component. Cache is automatically cleared on server restart.</div>
    <div style="font-size:var(--font-desc);font-family:var(--mono);color:var(--text-0);margin-bottom:10px" id="cfgCacheSize">${_cacheBytes>0?fmtSize(_cacheBytes)+' total':'No data cached'}</div>
    <div style="display:flex;gap:8px;max-width:540px">
      <button class="btn btn-sm btn-secondary" onclick="clearPlotCache()">Clear Plot Cache</button>
      <button class="btn btn-sm btn-danger" onclick="clearAllSessionData()">Clear All Session Data</button>
    </div>
  </div>`;
  // Viz toggles by category
  for(const[cat,items]of Object.entries(groups)){
    const color=cat.includes('LTP')?'var(--cyan)':cat.includes('SFD')?'var(--orange)':cat.includes('Fusion')?'var(--green)':'var(--text-2)';
    const scope=items[0].scope;
    const scopeLabel=scope==='prompt'?'per-prompt':'analysis tab';
    h+=`<div style="margin-bottom:14px"><div style="font-size:var(--font-desc);font-family:var(--mono);color:${color};text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">${cat} <span style="color:var(--text-3);text-transform:none;letter-spacing:0">(${scopeLabel})</span></div>`;
    for(const item of items){
      h+=`<div class="viz-config-row">
        <input type="checkbox" id="viz_${item.key}" ${item.on?'checked':''} onchange="VIZ_REGISTRY['${item.key}'].on=this.checked;saveConfig()">
        <label for="viz_${item.key}" style="flex:1"><span style="color:var(--text-0)">${item.title}</span> <span style="color:var(--text-2);font-size:var(--font-legend)">— ${item.desc}</span></label>
        <span style="font-family:var(--mono);font-size:var(--font-legend);color:var(--text-3);padding:3px 6px;border:1px solid var(--border);border-radius:3px;min-width:48px;text-align:center">${item.scope}</span>
        <input type="number" value="${item.order}" min="1" max="999" style="width:42px;font-size:var(--font-table);padding:3px;text-align:center" onchange="VIZ_REGISTRY['${item.key}'].order=parseInt(this.value)||0;saveConfig()">
      </div>`;
    }
    h+=`</div>`;
  }
  panel.innerHTML=h;
}

function applyFontConfig(){
  const cardTitle=$('cfgFontCardTitle').value+'px';
  const desc=$('cfgFontDesc').value+'px';
  const legend=$('cfgFontLegend').value+'px';
  const table=$('cfgFontTable').value+'px';
  document.documentElement.style.setProperty('--font-card-title',cardTitle);
  document.documentElement.style.setProperty('--font-desc',desc);
  document.documentElement.style.setProperty('--font-legend',legend);
  document.documentElement.style.setProperty('--font-table',table);
}

// Store defaults for reset
(function(){ for(const[k,v]of Object.entries(VIZ_REGISTRY)){v._default=v.on} })();

// ─── Config Persistence ─────────────────────────────────────────
async function saveConfig(){
  try{
    const vizState={};
    for(const[k,v]of Object.entries(VIZ_REGISTRY)) vizState[k]={on:v.on,order:v.order};
    const config={
      viz: vizState,
      fonts:{
        cardTitle: $('cfgFontCardTitle')?$('cfgFontCardTitle').value:'24',
        desc: $('cfgFontDesc')?$('cfgFontDesc').value:'13',
        legend: $('cfgFontLegend')?$('cfgFontLegend').value:'11',
        table: $('cfgFontTable')?$('cfgFontTable').value:'11',
      },
      ltp:{
        layerStrategy: $('cfgLtpLayerStrategy')?$('cfgLtpLayerStrategy').value:'late',
        k: $('cfgLtpK')?$('cfgLtpK').value:'8',
      },
      analysis:{
        computeTraj: $('cfgComputeTraj')?$('cfgComputeTraj').checked:true,
        captureResponses: $('cfgCaptureResponses')?$('cfgCaptureResponses').checked:false,
        fullCapture: $('cfgFullCapture')?$('cfgFullCapture').checked:false,
      },
      cardCollapse:{...CARD_COLLAPSE_DEFAULTS},
      exportOpts:{...EXPORT_DEFAULTS},
      display:{...DISPLAY_DEFAULTS}
    };
    await fetch('/api/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(config)});
  }catch(e){}
}

async function loadConfig(){
  try{
    const resp=await fetch('/api/config');
    const data=await resp.json();
    if(!data.ok||!data.config||!Object.keys(data.config).length) return;
    const c=data.config;
    // Viz toggles
    if(c.viz){for(const[k,cfg]of Object.entries(c.viz)){if(VIZ_REGISTRY[k]){
      if(typeof cfg==='object'){VIZ_REGISTRY[k].on=!!cfg.on;if(cfg.order!=null)VIZ_REGISTRY[k].order=cfg.order}
      else{VIZ_REGISTRY[k].on=!!cfg} // backward compat: old format was just bool
    }}}
    // Font sizes
    if(c.fonts){
      if(c.fonts.cardTitle&&$('cfgFontCardTitle')){$('cfgFontCardTitle').value=c.fonts.cardTitle;document.documentElement.style.setProperty('--font-card-title',c.fonts.cardTitle+'px')}
      if(c.fonts.desc&&$('cfgFontDesc')){$('cfgFontDesc').value=c.fonts.desc;document.documentElement.style.setProperty('--font-desc',c.fonts.desc+'px')}
      if(c.fonts.legend&&$('cfgFontLegend')){$('cfgFontLegend').value=c.fonts.legend;document.documentElement.style.setProperty('--font-legend',c.fonts.legend+'px')}
      if(c.fonts.table&&$('cfgFontTable')){$('cfgFontTable').value=c.fonts.table;document.documentElement.style.setProperty('--font-table',c.fonts.table+'px')}
    }
    // LTP settings
    if(c.ltp){
      if(c.ltp.layerStrategy&&$('cfgLtpLayerStrategy'))$('cfgLtpLayerStrategy').value=c.ltp.layerStrategy;
      if(c.ltp.k&&$('cfgLtpK'))$('cfgLtpK').value=c.ltp.k;
    }
    // Analysis options
    if(c.analysis){
      if($('cfgComputeTraj'))$('cfgComputeTraj').checked=c.analysis.computeTraj!==false;
      if($('cfgCaptureResponses'))$('cfgCaptureResponses').checked=!!c.analysis.captureResponses;
      if($('cfgFullCapture'))$('cfgFullCapture').checked=!!c.analysis.fullCapture;
    }
    // Card collapse defaults
    if(c.cardCollapse){
      for(const[tab,val]of Object.entries(c.cardCollapse)){
        if(CARD_COLLAPSE_DEFAULTS.hasOwnProperty(tab))CARD_COLLAPSE_DEFAULTS[tab]=val;
      }
    }
    // Export options
    if(c.exportOpts){
      if(typeof c.exportOpts.pdf==='boolean')EXPORT_DEFAULTS.pdf=c.exportOpts.pdf;
      if(typeof c.exportOpts.json==='boolean')EXPORT_DEFAULTS.json=c.exportOpts.json;
      if(typeof c.exportOpts.charts==='boolean')EXPORT_DEFAULTS.charts=c.exportOpts.charts;
      if(typeof c.exportOpts.includeArrays==='boolean')EXPORT_DEFAULTS.includeArrays=c.exportOpts.includeArrays;
      if(typeof c.exportOpts.exportPath==='string')EXPORT_DEFAULTS.exportPath=c.exportOpts.exportPath;
    }
    // Display settings
    if(c.display){
      if(c.display.terrainCharLimit)DISPLAY_DEFAULTS.terrainCharLimit=parseInt(c.display.terrainCharLimit)||50;
      if(c.display.terrainRecordLimit)DISPLAY_DEFAULTS.terrainRecordLimit=parseInt(c.display.terrainRecordLimit)||100;
      if(c.display.terrainTokenLimit)DISPLAY_DEFAULTS.terrainTokenLimit=parseInt(c.display.terrainTokenLimit)||20;
      if(c.display.terrainCategory)DISPLAY_DEFAULTS.terrainCategory=c.display.terrainCategory;
      if(c.display.terrainAutoRotate!=null)DISPLAY_DEFAULTS.terrainAutoRotate=!!c.display.terrainAutoRotate;
      if(c.display.terrainRotateSpeed)DISPLAY_DEFAULTS.terrainRotateSpeed=parseFloat(c.display.terrainRotateSpeed)||0.3;
    }
    vizRenderConfig();
    // Apply config tab card defaults to the 3 static config cards
    applyCardDefaults('panel-config','config');
  }catch(e){}
}

function resetLtpConfig(){$('cfgLtpLayerStrategy').value='late';$('cfgLtpK').value='8';saveConfig();log('LTP config reset to defaults','done')}

async function restoreSessionFromDisk(){
  try{
    log('Restoring session from disk...','');
    const r=await(await fetch('/api/session/restore',{method:'POST'})).json();
    if(r.ok){
      _promptTotal=r.n_results;
      if(r.cache_size_bytes)_cacheBytes=r.cache_size_bytes;
      updateSessionBadge();
      renderDataTable();
      $('dashBtn').disabled=false;
      $('exportBtn').disabled=false;
      log('Session restored: '+r.n_results+' results'+(r.model?' ('+r.model+')':''),'done');
      vizRenderConfig(); // refresh config panel to update session info
    }else{
      log('Restore failed: '+(r.error||'unknown error'),'error');
    }
  }catch(e){log('Restore error: '+e.message,'error')}
}

async function clearPlotCache(){
  if(!confirm('Delete all cached plot images? Data (CSV, JSON, metrics) will be kept.')) return;
  try{
    const r=await(await fetch('/api/session/clear_plots',{method:'POST'})).json();
    if(r.ok){_cacheBytes=r.cache_size_bytes||0;updateSessionBadge();if($('cfgCacheSize'))$('cfgCacheSize').textContent=_cacheBytes>0?fmtSize(_cacheBytes)+' total':'No data cached';log(`Plot cache cleared: ${r.freed_mb}MB freed`,'done')}
    else{log('Clear failed: '+(r.error||''),'error')}
  }catch(e){log('Clear error: '+e.message,'error')}
}

async function clearAllSessionData(){
  if(!confirm('Delete ALL session data? This includes CSV, JSON, plots, and aggregate stats. Export first if needed.')) return;
  try{
    const r=await(await fetch('/api/session/clear_all',{method:'POST'})).json();
    if(r.ok){sessionResults=[];dashResults=[];_promptTotal=0;_cacheBytes=0;updateSessionBadge();$('dataTableContainer').innerHTML='<p style="color:var(--text-3);font-size:11px">No data yet.</p>';if($('cfgCacheSize'))$('cfgCacheSize').textContent='No data cached';log(`Session data cleared: ${r.freed_mb}MB freed`,'done')}
    else{log('Clear failed: '+(r.error||''),'error')}
  }catch(e){log('Clear error: '+e.message,'error')}
}

var _cacheBytes=0;
function fmtSize(b){if(b<1024)return b+'B';if(b<1048576)return(b/1024).toFixed(0)+'KB';return(b/1048576).toFixed(1)+'MB'}
function updateSessionBadge(){
  var n=_promptTotal||dashResults.length||sessionResults.length;
  var label=n?`Session: ${n} prompts`:'No session';
  if(n&&_cacheBytes>0) label+=` · ${fmtSize(_cacheBytes)} cached`;
  $('sessionBadge').textContent=label;
  $('dashBtn').disabled=n<1;
  $('exportBtn').disabled=n<1;
  var cs=$('cfgCacheSize');if(cs) cs.textContent=_cacheBytes>0?fmtSize(_cacheBytes)+' total':'No data cached';
}

// ─── User Info ──────────────────────────────────────────────────
async function saveUserInfo(){
  const fd=new FormData();fd.append('name',$('userName').value);fd.append('organization',$('userOrg').value);fd.append('project',$('userProject').value);
  try{await fetch('/api/user_info',{method:'POST',body:fd})}catch(e){}
}

// ─── Models ─────────────────────────────────────────────────────
async function loadModelList(){
  try{
    const r=await(await fetch('/api/models')).json();
    const sel=$('modelSelect');sel.innerHTML='<option value="">-- Select --</option>';
    (r.models||[]).forEach(m=>{const o=document.createElement('option');o.value=m.id;o.textContent=`${m.name}${m.notes?' - '+m.notes:''}`;sel.appendChild(o)});
    const custom=document.createElement('option');custom.value='custom';custom.textContent='Custom pair...';sel.appendChild(custom);
  }catch(e){}
}
function toggleAddModel(){$('addModelForm').classList.toggle('visible')}
async function addModel(){
  const fd=new FormData();
  fd.append('id',$('newModelId').value);fd.append('name',$('newModelName').value);
  fd.append('base',$('newModelBase').value);fd.append('instruct',$('newModelInstruct').value);
  try{
    const r=await(await fetch('/api/models',{method:'POST',body:fd})).json();
    if(r.ok){log('Model pair added','done');$('addModelForm').classList.remove('visible');loadModelList();
      ['newModelId','newModelName','newModelBase','newModelInstruct'].forEach(i=>$(i).value='');}
    else log('Error: '+(r.error||''),'error');
  }catch(e){log('Error: '+e.message,'error')}
}

// ─── Model Loading ──────────────────────────────────────────────
async function loadModel(){
  const sel=$('modelSelect');
  if(!sel.value){showError('promptError','Select a model pair first.');return}
  const btn=$('loadModelBtn');setLoading(btn,true);clearLog();log('Starting model load...');setStatus('loading','LOADING');
  const fd=new FormData();
  if(sel.value==='custom'){
    const b=prompt('Base model HF ID:');const i=prompt('Instruct model HF ID:');
    if(!b||!i){setLoading(btn,false);return}
    fd.append('base_id',b);fd.append('instruct_id',i);
  } else fd.append('pair_id',sel.value);
  try{await fetch('/api/load_model',{method:'POST',body:fd})}catch(e){}
  let lastLen=0;
  const poll=setInterval(async()=>{
    try{
      const prog=await(await fetch('/api/progress')).json();
      for(let i=lastLen;i<prog.log.length;i++){const e=prog.log[i];log(`[${e.stage}] ${e.message}`,e.stage==='error'?'error':(e.stage==='ready'?'done':''))}
      lastLen=prog.log.length;
      const st=await(await fetch('/api/status')).json();
      if(st.model_loaded){clearInterval(poll);modelLoaded=true;setStatus('ready','READY');$('analyzeBtn').disabled=false;$('batchBtn').disabled=false;setLoading(btn,false);sessionResults=[];dashResults=[];_promptTotal=0;updateSessionBadge();loadPromptLibrary();loadProbeFiles();if(st.user_info){$('userName').value=st.user_info.name||'';$('userOrg').value=st.user_info.organization||'';$('userProject').value=st.user_info.project||''}playChime();setInferenceModel($('inferenceModelSelect').value)}
      else if(st.loading_error){clearInterval(poll);setStatus('idle','ERROR');log('Failed: '+st.loading_error,'error');setLoading(btn,false)}
    }catch(e){}
  },2000);
}

async function setInferenceModel(cls){
  if(!modelLoaded)return;
  const sel=$('inferenceModelSelect');sel.disabled=true;
  log('Switching inference model to '+cls+'…','');
  const fd=new FormData();fd.append('model_class',cls);
  try{const r=await(await fetch('/api/set_inference_model',{method:'POST',body:fd})).json();
    if(!r.ok){showError('promptError',r.message||'Failed to switch inference model');sel.value=(cls==='base'?'instruct':'base')}
    else{log('Inference model: '+cls,'done')}
  }catch(e){log('Error switching model: '+e.message,'error');sel.value=(cls==='base'?'instruct':'base')}
  sel.disabled=false;
}

async function resetAll(){
  if(!confirm('Clear session and unload model?'))return;clearLog();setStatus('loading','RESETTING');
  try{const r=await(await fetch('/api/reset',{method:'POST'})).json();if(r.ok){modelLoaded=false;sessionResults=[];dashResults=[];_promptTotal=0;_cacheBytes=0;setStatus('idle','NO MODEL');$('analyzeBtn').disabled=true;$('batchBtn').disabled=true;$('dataTableContainer').innerHTML='<p style="color:var(--text-3);font-size:11px">No data yet.</p>';updateSessionBadge();log(r.message,'done')}}catch(e){log('Reset error: '+e.message,'error')}
}

// ─── Analysis ───────────────────────────────────────────────────
function _buildAnalysisFormData(){
  const fd=new FormData();
  fd.append('compute_kl',$('computeKL').checked);
  fd.append('compute_trajectory',$('cfgComputeTraj').checked);
  fd.append('full_capture',$('cfgFullCapture')?$('cfgFullCapture').checked:false);
  fd.append('capture_responses',$('cfgCaptureResponses').checked);
  fd.append('compute_ltp',$('computeLTP').checked);
  fd.append('compute_sfd',$('computeSFD').checked);
  fd.append('ltp_k',$('cfgLtpK').value);
  fd.append('ltp_layer_strategy',$('cfgLtpLayerStrategy').value);
  fd.append('ltp_svd_rank',0);
  return fd;
}

async function toggleBaselines(enabled){}

async function analyzePrompt(){
  const prompt=$('promptInput').value.trim();
  if(!prompt){showError('promptError','Enter a prompt to analyze.');return}
  if(prompt.length>5000){showError('promptError','Prompt too long (max 5000 chars).');return}
  showError('promptError','');
  const btn=$('analyzeBtn');setLoading(btn,true);log('Analyzing...');
  const fd=_buildAnalysisFormData();
  fd.append('prompt',prompt);fd.append('category',$('categorySelect').value);
  const prevN=_promptTotal;
  try{
    let resp,data;
    try{
      resp=await fetch('/api/analyze',{method:'POST',body:fd});
      data=await resp.json();
    }catch(fetchErr){
      // Browser timeout (Safari "Load failed") — poll for backend completion
      log('Connection interrupted, waiting for backend...','');
      let recovered=false;
      for(let attempt=0;attempt<15;attempt++){
        await new Promise(r=>setTimeout(r,4000));
        try{
          const chk=await(await fetch('/api/status')).json();
          const sn=chk.session?chk.session.n_results:0;
          if(sn>prevN){
            const allResp=await fetch(`/api/session/results?page=1&per_page=9999`);
            const allData=await allResp.json();
            if(allData.ok&&allData.results){
              sessionResults=allData.results;
              _promptTotal=allData.total;
              if(allData.cache_size_bytes!=null)_cacheBytes=allData.cache_size_bytes;
              updateSessionBadge();renderDataTable();
              dtGoPage(Math.ceil(allData.total/_dtPageSize)||1);
              log('Done (recovered after timeout)','done');
              playChime();
              recovered=true;break;
            }
          }
          log('Still waiting... ('+((attempt+1)*4)+'s)','');
        }catch(chkErr){}
      }
      if(recovered){setLoading(btn,false);return}
      throw fetchErr;
    }
    if(data.ok){log('Done','done');sessionResults.push(data.result);_promptTotal=data.session_n;if(data.cache_size_bytes!=null)_cacheBytes=data.cache_size_bytes;updateSessionBadge();renderDataTable();dtGoPage(Math.ceil(data.session_n/_dtPageSize)||1)}
    else{log('Error: '+(data.error||'Unknown'),'error');showError('promptError',data.error||'Analysis failed.')}
  }catch(e){log('Error: '+e.message,'error')}
  setLoading(btn,false);
}

async function analyzeBatch(){
  const file=$('csvFile').files[0];if(!file){log('No CSV selected','error');return}
  const btn=$('batchBtn');setLoading(btn,true);clearLog();log('Starting batch...');
  const fd=_buildAnalysisFormData();
  fd.append('file',file);fd.append('compute_trajectory',false);
  try{
    const resp=await fetch('/api/analyze_batch',{method:'POST',body:fd});const data=await resp.json();
    if(!data.ok){log('Error: '+(data.error||''),'error');setLoading(btn,false);return}
    log(`Batch started: ${data.n_prompts} prompts...`);
    // Start reading from current log length so we don't see
    // done messages from a previous batch.
    let lastLen=0;
    try{const p=await(await fetch('/api/progress')).json();lastLen=p.log.length}catch(e){}
    async function pollBatch(){
      try{
        const p=await(await fetch('/api/progress')).json();
        let done=false;
        for(let i=lastLen;i<p.log.length;i++){
          const e=p.log[i];
          log(`[${e.stage}] ${e.message}`,e.stage==='error'?'error':(e.stage==='done'?'done':(e.stage==='warning'?'error':'')));
          if(e.stage==='done'&&e.message.includes('Batch complete')){done=true;playChime()}
        }
        lastLen=p.log.length;
        if(done){
          setLoading(btn,false);
          log('Loading results...');
          try{
            const allResp=await fetch(`/api/session/results?page=1&per_page=9999`);
            const allData=await allResp.json();
            if(allData.ok&&allData.results){
              sessionResults=allData.results;
              _promptTotal=allData.total;
              if(allData.cache_size_bytes!=null)_cacheBytes=allData.cache_size_bytes;
              updateSessionBadge();
              renderDataTable();
            }
          }catch(re){log('Results load: '+re.message,'error')}
          try{await refreshSession()}catch(de){log('Session refresh: '+de.message,'error')}
          return;
        }
      }catch(pe){}
      setTimeout(pollBatch,2000);
    }
    setTimeout(pollBatch,2000);
  }catch(e){log('Error: '+e.message,'error');setLoading(btn,false)}
}

// ─── Session Refresh ────────────────────────────────────────────
async function refreshSession(){
  if(_busy){log('Another operation in progress, please wait.','error');return}
  _busy=true;
  log('Refreshing session data...');
  try{
    const resp=await fetch('/api/dashboard');
    if(!resp.ok){log('Session refresh HTTP error: '+resp.status,'error');return}
    const data=await resp.json();
    if(!data.ok){log('Session refresh: '+(data.error||'unknown error'),'error');return}

    dashResults=data.results||[];
    if(data.cache_size_bytes!=null)_cacheBytes=data.cache_size_bytes;
    if(data.session_info){
      _promptTotal=data.session_info.n_results||dashResults.length;
    }
    updateSessionBadge();
    renderDataTable();

    log('Session refreshed: '+dashResults.length+' prompts','done');
  }catch(e){
    log('Session refresh error: '+e.message,'error');
    console.error('Session refresh error:',e);
  }finally{
    _busy=false;
  }
}

function plotCard(key,title,desc,idx,collapsed){
  const chevron=collapsed?'▶':'▼';
  return `<div class="feature"><div class="feature-header" onclick="toggleFeature(this)"><div class="feature-title"><span class="chevron" style="color:var(--text-2);font-size:12px;margin-right:6px">${chevron}</span>${title}</div><p class="feature-desc">${desc}</p></div><div class="feature-body${collapsed?' collapsed':''}"><div class="plot-container"><img src="/api/plots/individual/${idx}/${key}" loading="lazy" onerror="this.parentElement.innerHTML='<p style=\\'color:var(--text-3);font-size:11px;padding:12px\\'>Plot not available</p>'"></div></div></div>`;
}
function plotCardUrl(key,title,desc,collapsed){
  const chevron=collapsed?'▶':'▼';
  return `<div class="feature"><div class="feature-header" onclick="toggleFeature(this)"><div class="feature-title"><span class="chevron" style="color:var(--text-2);font-size:12px;margin-right:6px">${chevron}</span>${title}</div><p class="feature-desc">${desc}</p></div><div class="feature-body${collapsed?' collapsed':''}"><div class="plot-container"><img src="/api/plots/${key}" loading="lazy" onerror="this.parentElement.innerHTML='<p style=\\'color:var(--text-3);font-size:11px;padding:12px\\'>Plot not available</p>'"></div></div></div>`;
}

async function exportSession(){
  if(_busy){log('Another operation in progress, please wait.','error');return}
  _busy=true;
  const opts={csv:true,pdf:EXPORT_DEFAULTS.pdf,json:EXPORT_DEFAULTS.json,charts:EXPORT_DEFAULTS.charts,includeArrays:EXPORT_DEFAULTS.includeArrays,exportPath:EXPORT_DEFAULTS.exportPath};
  const enabledFmts=['CSV',opts.pdf?'PDF':null,opts.json?'JSON':null,opts.charts?'Charts':null].filter(Boolean).join(', ');
  log(`Exporting (${enabledFmts})...`);
  try{
    // Get current progress length so we only see NEW entries
    const curProg=await(await fetch('/api/progress')).json();
    let lastLen=curProg.log.length;
    const r=await fetch('/api/export',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(opts)});const data=await r.json();
    if(!data.ok){log('Export error: '+(data.error||''),'error');_busy=false;return}
    log('Export started...');
    async function pollExport(){
      try{
        const p=await(await fetch('/api/progress')).json();
        let exportDone=false, exportFailed=false, doneMessage='';
        for(let i=lastLen;i<p.log.length;i++){
          const e=p.log[i];
          if(e.stage==='exporting'||e.stage==='done'||e.stage==='error'||e.stage==='warning'){
            log(`[${e.stage}] ${e.message}`,e.stage==='error'?'error':(e.stage==='done'?'done':''));
          }
          if(e.stage==='done'&&e.message.includes('Export ready')){exportDone=true;doneMessage=e.message;playChime()}
          if(e.stage==='error'&&e.message.includes('Export')){exportFailed=true}
        }
        lastLen=p.log.length;
        if(exportDone){
          // Check if a custom path was requested AND the backend confirmed it succeeded
          // (path failure messages contain "path failed" and fall back to "Click Download")
          const pathSucceeded=opts.exportPath && !doneMessage.includes('path failed');
          if(pathSucceeded){
            log('Export saved to: '+opts.exportPath,'done');
          } else {
            log('Downloading ZIP...');
            try{
              const dr=await fetch('/api/export/download');
              if(dr.ok){const b=await dr.blob();const u=URL.createObjectURL(b);const a=document.createElement('a');a.href=u;a.download='tagm_session.json.gz';a.click();URL.revokeObjectURL(u);log('Download complete','done')}
              else{log('Download failed: HTTP '+dr.status,'error')}
            }catch(de){log('Download error: '+de.message,'error')}
          }
          _busy=false;return;
        }
        if(exportFailed){_busy=false;return;}
      }catch(pe){}
      setTimeout(pollExport,2000);
    }
    setTimeout(pollExport,2000);
  }catch(e){log('Export error: '+e.message,'error');_busy=false}
}

// ─── Visualization Pop-out Store ─────────────────────────────────
const _vizStore={};
function _plotHtml(plotKey,title,desc){
  return`<div class="feature"><div class="feature-header"><div class="feature-title">${title}</div><p class="feature-desc">${desc||''}</p></div><div class="feature-body"><div class="plot-container" id="pc_${plotKey}"><div style="font-family:var(--mono);font-size:12px;color:var(--text-2);padding:20px;text-align:center" id="pl_${plotKey}">Loading ${plotKey}.png…</div><img src="/api/plots/${plotKey}" style="max-width:100%;height:auto;display:none" onload="this.style.display='';var pl=document.getElementById('pl_${plotKey}');if(pl)pl.style.display='none'" onerror="var pl=document.getElementById('pl_${plotKey}');if(pl){pl.textContent='Failed to generate ${plotKey}';pl.style.color='var(--red)'}"></div></div></div>`;
}
function storeViz(key,title,html,scripts){_vizStore[key]={title:title,html:html,scripts:scripts||null}}
function popoutViz(key){
  const entry=_vizStore[key];
  if(!entry){console.warn('No viz stored for',key);return}
  const pw=1060,ph=820;
  const left=Math.round((screen.width-pw)/2);
  const top=Math.round((screen.height-ph)/2);
  const w=window.open('','_blank',`width=${pw},height=${ph},left=${left},top=${top},scrollbars=yes`);
  if(!w) return;
  const styles=Array.from(document.querySelectorAll('style,link[rel="stylesheet"]'))
    .map(s=>s.outerHTML).join('\n');
  const scriptBlock=entry.scripts?`<script>${entry.scripts}<\/script>`:'';
  w.document.write(`<!DOCTYPE html><html><head><title>${entry.title} — TAGM</title>
    <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    ${styles}
    <style>body{background:var(--bg-0);color:var(--text-1);font-family:var(--sans);padding:20px;margin:0}
    .feature{max-width:960px;margin:0 auto 16px auto}
    .plot-container img{max-width:100%;height:auto}
    </style>
    </head><body>${entry.html}${scriptBlock}</body></html>`);
  w.document.close();
}
function vizLabel(storeKey,title,desc,borderColor){
  const bc=borderColor?`border-left:3px solid ${borderColor};`:'';
  return`<div class="viz-label" onclick="popoutViz('${storeKey}')" style="${bc}"><span class="vl-title">${title}</span><span class="vl-desc">${desc||''}</span><span class="vl-open">↗ Open</span></div>`;
}

// ─── Pop-out Record Window ──────────────────────────────────────
function popoutRecord(rid){
  const el=document.getElementById(rid);
  if(!el) return;
  const pw=1000,ph=800;
  const left=Math.round((screen.width-pw)/2);
  const top=Math.round((screen.height-ph)/2);
  const w=window.open('','_blank',`width=${pw},height=${ph},left=${left},top=${top},scrollbars=yes`);
  if(!w) return;
  // Grab stylesheets from parent
  const styles=Array.from(document.querySelectorAll('style,link[rel="stylesheet"]'))
    .map(s=>s.outerHTML).join('\n');
  w.document.write(`<!DOCTYPE html><html><head><title>TAGM Record</title>
    <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    ${styles}
    <style>body{background:var(--bg-0);color:var(--text-1);font-family:var(--sans);padding:20px;margin:0}
    .card{max-width:960px;margin:0 auto}</style>
    </head><body>${el.outerHTML}</body></html>`);
  w.document.close();
}

function renderTopK(r){
  if(!r.instruct_topk||!r.instruct_topk.length)return'';
  const n=Math.max(r.instruct_topk.length,(r.base_topk||[]).length);let rows='';
  for(let i=0;i<n;i++){const it=r.instruct_topk[i],bt=(r.base_topk||[])[i];rows+=`<tr><td>${i+1}</td><td class="tok-inst">${it?escHtml(it[0]):'--'}</td><td>${it?(it[1]*100).toFixed(1)+'%':'--'}</td><td class="tok-base">${bt?escHtml(bt[0]):'--'}</td><td>${bt?(bt[1]*100).toFixed(1)+'%':'--'}</td></tr>`}
  return`<div class="feature"><div class="feature-header"><div class="feature-title">Model Predictions</div><p class="feature-desc">What the instruct-tuned model and the base model each predict as the most likely next tokens.</p></div><div class="feature-body" style="padding:10px"><table class="topk-table" style="width:100%"><tr><th>#</th><th>Instruct</th><th>P</th><th>Base</th><th>P</th></tr>${rows}</table></div></div>`
}
function renderTokenTable(r){
  if(!r.tokens||!r.signed_attr||!r.signed_attr.length)return'';
  const mx=Math.max(...r.signed_attr.map(Math.abs)),ms=r.per_token_stress?Math.max(...r.per_token_stress):1;let rows='';
  for(let i=0;i<r.tokens.length;i++){const a=r.signed_attr[i],s=r.per_token_stress?r.per_token_stress[i]:0,ap=mx>0?(Math.abs(a)/mx*100):0,ac=a<0?'var(--red)':'var(--green)',sp=ms>0?(s/ms*100):0;rows+=`<tr><td>${escHtml(r.tokens[i])}</td><td style="color:${ac}">${a>=0?'+':''}${a.toFixed(4)}</td><td><span class="token-bar" style="width:${ap}%;background:${ac}"></span></td><td>${s.toFixed(4)}</td><td><span class="token-bar" style="width:${sp}%;background:var(--blue)"></span></td></tr>`}
  return`<div class="feature"><div class="feature-header" onclick="toggleFeature(this)"><div class="feature-title">Per-Token Attribution Table</div><p class="feature-desc">Raw numeric values for each token's signed attribution and focused stress score. The colored bars show relative magnitude within this prompt — useful for identifying exactly which tokens drive the model's alignment response. Sort mentally by bar length to find the dominant tokens.</p><div class="feature-legend">🔑 Attr = signed contribution (green = reinforces, red = opposes) · Stress = correction pressure at signal layers · Bar width = relative magnitude within this prompt</div></div><div class="feature-body" style="padding:10px"><table class="data-table"><tr><th>Token</th><th>Attr</th><th></th><th>Stress</th><th></th></tr>${rows}</table></div></div>`
}
var _dtPage=1,_dtPageSize=25,_dtSorted=[];
function renderDataTable(){
  var source=dashResults.length?dashResults:sessionResults;
  if(!source.length){$('dataTableContainer').innerHTML='<p style="color:var(--text-3);font-size:var(--font-table)">No data yet.</p>';return}

  _dtSorted=[...source].map((r,i)=>({...r,_srcIdx:r._index!=null?r._index:i})).sort((a,b)=>a._srcIdx-b._srcIdx);

  _dtPage=Math.min(_dtPage,Math.ceil(_dtSorted.length/_dtPageSize)||1);
  _renderDataTablePage();
}

function _renderDataTablePage(){
  const sorted=_dtSorted;
  const totalPages=Math.ceil(sorted.length/_dtPageSize)||1;
  const start=(_dtPage-1)*_dtPageSize;
  const pageData=sorted.slice(start,start+_dtPageSize);

  // Column definitions: [key, label, format, heatHue, defaultWidth]
  const cols=[
    ['_cb','','cb',null,32],
    ['_index','#',null,null,32],
    ['prompt','Prompt','s',null,400],
    ['category','Cat','cat',null,52],
    ['role','Role','s',null,42],
    ['seq_len','Tok','i',null,36],
    ['stress_score','Stress','f3',200,60],
    ['net_correction','Net','f5',160,72],
    ['entropy','Ent','f4',40,58],
    ['middle_share','Int%','pct',280,52],
    ['interior_cv','IntCV','f4',null,54],
    ['top2_share','Bnd%','pct',null,52],
    ['kl_divergence','KL','f4',null,52],
    ['n_negative_tokens','Neg','i',null,34],
    ['_inst_top1','InstTop1','s',null,70],
    ['_inst_prob','InstP','pct3',null,50],
    ['_base_top1','BaseTop1','s',null,70],
    ['_base_prob','BaseP','pct3',null,50],
    ['_ltp_max_prc','MaxPRC','pct_pp',null,56],
    ['_ltp_n_dir','N_dir','i',null,40],
    ['_ltp_M','M','f6',null,68],
    ['_sfd_density','Dens','f4',120,56],
    ['_rank_tau','Tau','f3',60,48],
    ['_rank_overlap','Ovlp','pct',null,48],
  ];

  // Compute ranges for heatmap columns (across ALL data, not just page)
  const ranges={};
  ['stress_score','net_correction','entropy','middle_share','_sfd_density','_rank_tau'].forEach(k=>{
    const vals=sorted.map(r=>getVal(r,k)).filter(v=>v!=null&&!isNaN(v));
    if(vals.length) ranges[k]={min:Math.min(...vals),max:Math.max(...vals)};
  });
  function heatBg(val,key,hue){
    if(!hue)return'';
    const r=ranges[key];if(!r||r.max===r.min)return'';
    const t=(val-r.min)/(r.max-r.min);
    return`background:hsla(${hue},60%,50%,${(t*0.25).toFixed(2)})`;
  }

  function fmt(val,format){
    if(val==null||val===''||val===undefined) return'<span style="color:var(--text-3)">--</span>';
    if(format==='s') return escHtml(String(val).substring(0,120));
    if(format==='i') return Math.round(val);
    if(format==='f2') return Number(val).toFixed(2);
    if(format==='f3') return Number(val).toFixed(3);
    if(format==='f4') return Number(val).toFixed(4);
    if(format==='f5') return Number(val).toFixed(5);
    if(format==='f6') return Number(val).toFixed(6);
    if(format==='pct') return (Number(val)*100).toFixed(1)+'%';
    if(format==='pct3') return (Number(val)*100).toFixed(1)+'%';
    if(format==='pct_pp') return (Number(val)*100).toFixed(1)+'pp';
    if(format==='cat') return val?`<span class="pill ${pillClass(val)}">${val.substring(0,4)}</span>`:'--';
    return val;
  }

  function getVal(r,key){
    if(key==='_cb') return r._srcIdx;
    if(key==='_index') return r._srcIdx+1;
    if(key==='_inst_top1') return r.instruct_topk&&r.instruct_topk[0]?r.instruct_topk[0][0]:null;
    if(key==='_inst_prob') return r.instruct_topk&&r.instruct_topk[0]?r.instruct_topk[0][1]:null;
    if(key==='_base_top1') return r.base_topk&&r.base_topk[0]?r.base_topk[0][0]:null;
    if(key==='_base_prob') return r.base_topk&&r.base_topk[0]?r.base_topk[0][1]:null;
    if(key==='_ltp_M') return r.ltp?r.ltp.mean_M:null;
    if(key==='_ltp_max_prc') return r.ltp?r.ltp.max_prc:null;
    if(key==='_ltp_n_dir') return r.ltp?r.ltp.n_directional:null;
    if(key==='_sfd_density') return r.sfd?r.sfd.density_mean:null;
    if(key==='_rank_tau') return r.rank_displacement?r.rank_displacement.mean_tau:null;
    if(key==='_rank_overlap') return r.rank_displacement?r.rank_displacement.mean_overlap:null;
    return r[key];
  }

  // ─── Toolbar ──────────────────────────────────────────────────
  let h=`<div class="dt-toolbar">
    <label style="margin:0;display:flex;align-items:center;gap:4px;cursor:pointer">
      <input type="checkbox" id="dtSelectAll" onchange="dtToggleAll(this.checked)"> <span style="font-size:11px">All</span>
    </label>
    <span class="dt-sel-count" id="dtSelCount">0 selected</span>
    <button class="btn btn-secondary btn-sm" id="dtViewBtn" onclick="dtViewSelected()" disabled>View Selected</button>
    <button class="btn btn-secondary btn-sm" id="dtRerunBtn" onclick="dtRerunSelected()" disabled>Rerun Selected</button>
    <button class="btn btn-danger btn-sm" id="dtRemoveBtn" onclick="dtRemoveSelected()" disabled>Remove Selected</button>
    <span style="margin-left:auto;color:var(--text-1);font-size:11px">${sorted.length} records · page ${_dtPage}/${totalPages}${_cacheBytes>0?' · '+fmtSize(_cacheBytes)+' cached':''}</span>
  </div>`;

  // ─── Table ────────────────────────────────────────────────────
  h+=`<div class="dt-wrap"><div class="dt-scroll" id="dtScroll"><table class="dt-grid" id="dtGridTable"><thead><tr>`;

  for(let ci=0;ci<cols.length;ci++){
    const[key,label,format,,w]=cols[ci];
    const isCheckbox = key==='_cb';
    const cls = isCheckbox ? ' class="dt-cb"' : '';
    const content = isCheckbox
      ? ''
      : `${label}<div class="dt-resize" data-col="${ci}" onmousedown="dtStartResize(event,${ci})"></div>`;
    h+=`<th${cls} style="min-width:${w}px;width:${w}px">${content}</th>`;
  }
  h+=`</tr></thead><tbody>`;

  for(const r of pageData){
    const srcIdx = r._srcIdx;
    h+=`<tr data-idx="${srcIdx}" id="dtRow_${srcIdx}">`;
    for(const[key,label,format,hue,w]of cols){
      const val=getVal(r,key);
      if(key==='_cb'){
        h+=`<td class="dt-cb"><input type="checkbox" data-idx="${srcIdx}" onchange="dtUpdateSelection()"></td>`;
      } else if(key==='prompt'){
        h+=`<td class="dt-cell-prompt" title="${escHtml(r.prompt)}">${fmt(val,format)}</td>`;
      } else {
        const style=heatBg(val||0,key,hue);
        h+=`<td style="${style}">${fmt(val,format)}</td>`;
      }
    }
    h+=`</tr>`;
  }
  h+=`</tbody></table></div></div>`;

  // ─── Pagination controls ──────────────────────────────────────
  if(totalPages>1){
    h+=`<div style="display:flex;align-items:center;justify-content:center;gap:8px;padding:8px 0;font-family:var(--mono);font-size:11px">`;
    h+=`<button class="btn btn-secondary btn-sm" onclick="dtGoPage(1)" ${_dtPage<=1?'disabled':''} style="width:auto">⟨⟨</button>`;
    h+=`<button class="btn btn-secondary btn-sm" onclick="dtGoPage(${_dtPage-1})" ${_dtPage<=1?'disabled':''} style="width:auto">⟨ Prev</button>`;
    // Page numbers
    var startP=Math.max(1,_dtPage-2),endP=Math.min(totalPages,_dtPage+2);
    for(var p=startP;p<=endP;p++){
      if(p===_dtPage) h+=`<span style="color:var(--blue);font-weight:600;padding:0 4px">${p}</span>`;
      else h+=`<button class="btn btn-secondary btn-sm" onclick="dtGoPage(${p})" style="width:auto;padding:2px 6px">${p}</button>`;
    }
    h+=`<button class="btn btn-secondary btn-sm" onclick="dtGoPage(${_dtPage+1})" ${_dtPage>=totalPages?'disabled':''} style="width:auto">Next ⟩</button>`;
    h+=`<button class="btn btn-secondary btn-sm" onclick="dtGoPage(${totalPages})" ${_dtPage>=totalPages?'disabled':''} style="width:auto">⟩⟩</button>`;
    h+=`<span style="color:var(--text-3);margin-left:8px">${sorted.length} rows · ${_dtPageSize}/page</span>`;
    h+=`</div>`;
  }

  $('dataTableContainer').innerHTML=h;
}
function dtGoPage(p){
  var totalPages=Math.ceil(_dtSorted.length/_dtPageSize)||1;
  _dtPage=Math.max(1,Math.min(totalPages,p));
  _renderDataTablePage();
}

// ─── Data Table: Selection ──────────────────────────────────────
function dtGetSelectedIndices(){
  const cbs=document.querySelectorAll('#dtGridTable tbody input[type="checkbox"]:checked');
  return Array.from(cbs).map(cb=>parseInt(cb.dataset.idx));
}
function dtUpdateSelection(){
  const sel=dtGetSelectedIndices();
  const count=sel.length;
  const el=$('dtSelCount'); if(el) el.textContent=count+' selected';
  const reBtn=$('dtRerunBtn'); if(reBtn) reBtn.disabled=count===0;
  const rmBtn=$('dtRemoveBtn'); if(rmBtn) rmBtn.disabled=count===0;
  const vwBtn=$('dtViewBtn'); if(vwBtn) vwBtn.disabled=count===0;
  // Update "select all" checkbox state
  const allCbs=document.querySelectorAll('#dtGridTable tbody input[type="checkbox"]');
  const allCheck=$('dtSelectAll');
  if(allCheck){
    allCheck.checked=allCbs.length>0&&count===allCbs.length;
    allCheck.indeterminate=count>0&&count<allCbs.length;
  }
  // Highlight selected rows
  document.querySelectorAll('#dtGridTable tbody tr').forEach(tr=>{
    const cb=tr.querySelector('input[type="checkbox"]');
    tr.classList.toggle('dt-selected',cb&&cb.checked);
  });
}
function dtToggleAll(checked){
  document.querySelectorAll('#dtGridTable tbody input[type="checkbox"]').forEach(cb=>{cb.checked=checked});
  dtUpdateSelection();
}

// ─── Data Table: Remove ─────────────────────────────────────────
async function dtRemoveSelected(){
  const indices=dtGetSelectedIndices();
  if(!indices.length) return;
  if(!confirm(`Remove ${indices.length} result(s) from the session? This cannot be undone.`)) return;
  try{
    const r=await(await fetch('/api/session/remove',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({indices})})).json();
    if(r.ok){
      log(`Removed ${r.removed} results (${r.remaining} remaining)`,'done');
      _promptTotal=r.remaining;
      dashResults=[];
      updateSessionBadge();renderDataTable();
    } else { log('Remove failed: '+(r.error||'unknown'),'error') }
  }catch(e){log('Remove error: '+e.message,'error')}
}

// ─── Data Table: Rerun ──────────────────────────────────────────
async function dtRerunSelected(){
  const indices=dtGetSelectedIndices();
  if(!indices.length) return;
  // Gather current analysis options from the sidebar checkboxes (same IDs as analyze_single)
  const options={
    compute_kl:$('computeKL')&&$('computeKL').checked,
    compute_trajectory:$('cfgComputeTraj')&&$('cfgComputeTraj').checked,
    capture_responses:$('cfgCaptureResponses')&&$('cfgCaptureResponses').checked,
    full_capture:$('cfgFullCapture')&&$('cfgFullCapture').checked,
    compute_ltp:$('computeLTP')&&$('computeLTP').checked,
    compute_sfd:$('computeSFD')&&$('computeSFD').checked,
    ltp_k:parseInt(($('cfgLtpK')&&$('cfgLtpK').value)||8),
    ltp_layer_strategy:($('cfgLtpLayerStrategy')&&$('cfgLtpLayerStrategy').value)||'signal',
    ltp_svd_rank:0,
  };
  log(`Rerunning ${indices.length} prompt(s)...`,'analyzing');
  try{
    const r=await(await fetch('/api/session/rerun',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({indices,options})})).json();
    if(r.ok){
      log(`Reran ${r.rerun} prompts (${r.total} total in session)`,'done');
      _promptTotal=r.total;
      dashResults=[];
      updateSessionBadge();dashResults=[];renderDataTable();
    } else { log('Rerun failed: '+(r.error||'unknown'),'error') }
  }catch(e){log('Rerun error: '+e.message,'error')}
}

// ─── Data Table: View Selected ─────────────────────────────────
async function dtViewSelected(){
  const indices=dtGetSelectedIndices();
  if(!indices.length) return;
  try{
    // Fetch full result data for each selected index (one page at a time)
    const results=[];
    for(const idx of indices){
      // Use page=1,per_page large enough, then find by _index
      // More efficient: fetch page containing this index
      const page=Math.floor(idx/50)+1;
      const resp=await fetch(`/api/session/results?page=${page}&per_page=50`);
      const data=await resp.json();
      if(data.ok&&data.results){
        const match=data.results.find(r=>r._index===idx);
        if(match) results.push(match);
      }
    }
    if(!results.length){log('No results found for selected indices','error');return}

    // Build card HTML for each selected result
    const styles=Array.from(document.querySelectorAll('style,link[rel="stylesheet"]'))
      .map(s=>s.outerHTML).join('\n');
    let cardsHtml='';
    for(const r of results){
      const plotKeys=r._plot_keys||[];
      const idx=r._index;
      cardsHtml+=_buildRecordCardHtml(r,plotKeys,idx);
    }

    // Open popout
    const pw=1060,ph=850;
    const left=Math.round((screen.width-pw)/2);
    const top=Math.round((screen.height-ph)/2);
    const w=window.open('','_blank',`width=${pw},height=${ph},left=${left},top=${top},scrollbars=yes`);
    if(!w) return;
    w.document.write(`<!DOCTYPE html><html><head><title>TAGM — ${results.length} Record${results.length>1?'s':''}</title>
      <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap" rel="stylesheet">
      ${styles}
      <style>body{background:var(--bg-0);color:var(--text-1);font-family:var(--sans);padding:20px;margin:0}
      .card{max-width:960px;margin:0 auto 16px auto}
      .plot-container img{max-width:100%;height:auto}
      </style></head><body>${cardsHtml}</body></html>`);
    w.document.close();
  }catch(e){log('View error: '+e.message,'error');console.error(e)}
}

function _buildRecordCardHtml(r,plotKeys,idx){
  // Build a self-contained record card for popout display
  let h=`<div class="card">
    <div class="card-header record-header">
      <h3>${escHtml(r.prompt)}</h3>
      <div class="record-meta">
        ${r.category?`<span class="pill ${pillClass(r.category)}">${r.category}</span>`:''}
        <span style="font-family:var(--mono);font-size:12px;color:var(--text-1)">#${idx} · ${r.seq_len} tokens</span>
        ${r.ltp?'<span class="ltp-badge">LTP</span>':''}
      </div>
    </div>
    <div class="card-body">`;

  // Metrics grid
  h+=`<div class="metrics-grid">${mc('Stress',r.stress_score,null)}${mc('Net Corr',r.net_correction,null)}${mc('Entropy',r.entropy,null)}${mc('Int%',r.middle_share,null,v=>(v*100).toFixed(1)+'%')}${mc('Bnd%',r.top2_share,null,v=>(v*100).toFixed(1)+'%')}${mc('IntCV',r.interior_cv,null)}${r.kl_divergence!=null?mc('KL',r.kl_divergence,null):''}`;
  if(r.ltp){h+=mc('MaxPRC',r.ltp.max_prc,null,v=>(v*100).toFixed(1)+'pp','ltp-metric');h+=mc('N_dir',r.ltp.n_directional,null,null,'ltp-metric');h+=mc('M',r.ltp.mean_M,null,null,'ltp-metric')}
  if(r.sfd){h+=mc('Density',r.sfd.density_mean,null,null,'sfd-metric')}
  if(r.rank_displacement&&r.rank_displacement.mean_tau!=null){h+=mc('Tau',r.rank_displacement.mean_tau,null,v=>v.toFixed(3),'sfd-metric');h+=mc('Overlap',r.rank_displacement.mean_overlap,null,v=>(v*100).toFixed(1)+'%','sfd-metric')}
  if(r.candidate_graph){h+=mc('Contest',r.candidate_graph.contested_frac,null,v=>(v*100).toFixed(0)+'%','ltp-metric');h+=mc('Sw/tok',r.candidate_graph.switch_rate,null,v=>v.toFixed(2),'ltp-metric')}
  h+=`</div>`;
  if(r.has_negative_tokens)h+=`<div style="margin-bottom:8px;font-size:11px;color:var(--purple)">⚠ ${r.n_negative_tokens} of ${r.seq_len} tokens push against the alignment correction</div>`;

  // Inline plots (these render in the popout since images load from server)
  const featureMeta={signed_attribution:'Signed Attribution',stress_per_token:'Per-Token Stress',distribution_metrics:'Correction Distribution',amplitude_trajectory:'Layer Trajectory',heatmap:'Token × Layer Heatmap',sfd_density:'QK Density',rank_displacement:'Rank Displacement'};
  const ltpPlotMeta={ltp_profiles:'Tension Profiles',ltp_tension_magnitudes:'Tension Magnitudes',ltp_summary_stats:'LTP Summary',ltp_profile_heatmap:'Token × Rank Heatmap'};

  for(const k of plotKeys){
    if(k.startsWith('ltp_'))continue;
    if(VIZ_REGISTRY[k]&&VIZ_REGISTRY[k].scope!=='prompt')continue;
    const title=featureMeta[k]||k;
    h+=`<div class="feature"><div class="feature-header"><div class="feature-title">${title}</div></div><div class="feature-body"><div class="plot-container"><img src="/api/plots/individual/${idx}/${k}" style="max-width:100%;height:auto"></div></div></div>`;
  }

  // LTP plots
  if(r.ltp){
    const ltpKeys=plotKeys.filter(k=>k.startsWith('ltp_')&&k!=='ltp_dual_trajectory');
    if(ltpKeys.length){
      h+=`<div style="margin-top:14px;padding-top:12px;border-top:2px solid var(--cyan)"><div style="font-family:var(--mono);font-size:13px;font-weight:600;color:var(--cyan);margin-bottom:8px">LTP</div>`;
      for(const k of ltpKeys){
        const title=ltpPlotMeta[k]||k;
        h+=`<div class="feature" style="border-color:var(--cyan)"><div class="feature-header"><div class="feature-title" style="color:var(--cyan)">${title}</div></div><div class="feature-body"><div class="plot-container"><img src="/api/plots/individual/${idx}/${k}" style="max-width:100%;height:auto"></div></div></div>`;
      }
      h+=`</div>`;
    }
  }

  // Model predictions
  if(r.instruct_topk&&r.instruct_topk.length) h+=renderTopK(r);

  // Token table
  if(r.tokens&&r.signed_attr&&r.signed_attr.length) h+=renderTokenTable(r);

  h+=`</div></div>`;
  return h;
}

// ─── Data Table: Column Resize ──────────────────────────────────
let _dtResizeState=null;
function dtStartResize(e,colIndex){
  e.preventDefault();
  const table=document.getElementById('dtGridTable');
  if(!table) return;
  const th=table.querySelectorAll('thead th')[colIndex];
  if(!th) return;
  const startX=e.clientX;
  const startW=th.offsetWidth;
  const handle=e.target;
  handle.classList.add('active');

  function onMove(ev){
    const delta=ev.clientX-startX;
    const newW=Math.max(28,startW+delta);
    th.style.width=newW+'px';
    th.style.minWidth=newW+'px';
    // Also resize corresponding body cells for consistency
    const rows=table.querySelectorAll('tbody tr');
    rows.forEach(tr=>{
      const td=tr.children[colIndex];
      if(td){td.style.width=newW+'px';td.style.minWidth=newW+'px'}
    });
  }
  function onUp(){
    handle.classList.remove('active');
    document.removeEventListener('mousemove',onMove);
    document.removeEventListener('mouseup',onUp);
  }
  document.addEventListener('mousemove',onMove);
  document.addEventListener('mouseup',onUp);
}

// ─── Prompt Library ─────────────────────────────────────────────
async function loadPromptLibrary(){
  try{const r=await(await fetch('/api/prompts')).json();promptLibraryData=r.prompts||[];renderPromptLibrary()}catch(e){}
}
function renderPromptLibrary(){
  const s=$('promptLibrary');s.innerHTML='<option value="">-- Presets --</option>';
  const g={};promptLibraryData.forEach((p,i)=>{if(p.baseline)return;const c=p.category||'other';if(!g[c])g[c]=[];g[c].push({...p,index:i})});
  for(const[c,ps]of Object.entries(g)){const og=document.createElement('optgroup');og.label=c[0].toUpperCase()+c.slice(1);ps.forEach(p=>{const o=document.createElement('option');o.value=p.index;o.textContent=p.prompt.length>55?p.prompt.substring(0,52)+'...':p.prompt;og.appendChild(o)});s.appendChild(og)}
}
function loadFromLibrary(){const s=$('promptLibrary');if(s.value==='')return;const p=promptLibraryData[parseInt(s.value)];if(p){$('promptInput').value=p.prompt;$('categorySelect').value=p.category||''}}
async function addCurrentToLibrary(){
  const p=$('promptInput').value.trim();if(!p){showError('promptError','No prompt to save.');return}
  const fd=new FormData();fd.append('prompt',p);fd.append('category',$('categorySelect').value||'benign');fd.append('baseline',false);
  try{const r=await(await fetch('/api/prompts',{method:'POST',body:fd})).json();if(r.ok){promptLibraryData=r.prompts;renderPromptLibrary();log('Saved to library','done')}else showError('promptError',r.error||'Failed')}catch(e){}
}

// ─── Keyboard Navigation ────────────────────────────────────────
// ─── Feature card collapse (delegated) ──────────────────────────
document.addEventListener('click',e=>{
  const header=e.target.closest('.feature-header');
  if(!header) return;
  const feature=header.closest('.feature');
  if(!feature) return;
  const body=feature.querySelector('.feature-body');
  if(!body) return;
  body.classList.toggle('collapsed');
  const chevron=header.querySelector('.chevron');
  if(chevron) chevron.textContent=body.classList.contains('collapsed')?'▶':'▼';
});

// ─── Alignment Terrain Viewer ──────────────────────────────────
let _terrainState = null;

function _terrainTransformData(results){
  const cats={};
  const diag={total:0,hasDispProfiles:0,hasLtpFallback:0,hasBaseCf:0,missingData:0};
  for(const r of results){
    const cat=r.category||'unknown';
    const ltp=r.ltp||{};
    const rd=r.rank_displacement||{};

    // Prefer displacement profiles; fall back to LTP tension profiles
    const useDisp=rd.instruct_disp_profiles&&rd.instruct_disp_profiles.length>0;
    const useLtp=!useDisp&&ltp.profiles&&ltp.profiles.length>0;
    if(!useDisp&&!useLtp) continue;

    if(!cats[cat]) cats[cat]=[];
    const toks=r.tokens||[];
    const cf=ltp.counterfactual_tokens||[];
    const baseCf=r.base_counterfactual_tokens||[];
    const kls=r.per_token_kl||[];
    const nT=toks.length;
    const perPos=rd.per_position||[];
    diag.total++;

    if(useDisp) diag.hasDispProfiles++;
    else if(useLtp) diag.hasLtpFallback++;
    if(baseCf.length>0&&baseCf[0]&&baseCf[0].length>=1) diag.hasBaseCf++;

    const rows=[];

    // ── Displacement normalization ──
    // The terrain renderer (HSCALE=180) was calibrated for LTP tension magnitudes
    // in the range ~0.002–0.008. Displacement profiles range 0–1.0.
    // Normalize per-prompt so the max displacement maps to ~0.008.
    const TERRAIN_TARGET_MAX=0.008;
    let dispMax=0;
    if(useDisp){
      const iProfs=rd.instruct_disp_profiles||[];
      const bProfs=rd.base_disp_profiles||[];
      for(let i=0;i<nT;i++){
        const ip=iProfs[i]||[];
        const bp=bProfs[i]||[];
        for(let j=0;j<8;j++){
          if(ip[j]>dispMax) dispMax=ip[j];
          if(bp[j]>dispMax) dispMax=bp[j];
        }
      }
    }
    const dispScale=dispMax>1e-10?TERRAIN_TARGET_MAX/dispMax:1;

    for(let i=0;i<nT;i++){
      const cands=cf[i]||[];
      const baseCands=baseCf[i]||[];
      const kl=(kls[i]!=null)?kls[i]:0;
      const posData=perPos[i]||{};
      const replRatio=posData.replacement_ratio||0;

      let im,bm;

      if(useDisp){
        // ── Displacement profiles: height = probability displacement per candidate ──
        // Scaled to match terrain renderer's expected magnitude range
        const iDisp=rd.instruct_disp_profiles[i]||[];
        im=[];
        for(let j=0;j<8;j++) im.push((iDisp[j]!=null?iDisp[j]:0)*dispScale);

        const bDisp=rd.base_disp_profiles[i]||[];
        bm=[];
        for(let j=7;j>=0;j--) bm.push((bDisp[j]!=null?bDisp[j]:0)*dispScale);
      }else{
        // ── Legacy fallback: LTP tension magnitudes ──
        const prof=ltp.profiles[i]||new Array(8).fill(0.01);
        im=[];
        for(let j=0;j<8;j++) im.push(prof[j]!=null?prof[j]:0.01);

        const baseProfiles=ltp.base_profiles||[];
        const bprof=baseProfiles[i];
        if(bprof&&bprof.length>=8){
          bm=[];
          for(let j=7;j>=0;j--) bm.push(bprof[j]!=null?bprof[j]:0.01);
        }else{
          bm=new Array(8).fill(0);
        }
      }

      // Instruct labels
      const ctoks=[];
      for(let j=0;j<8;j++){
        if(j<cands.length&&cands[j]){
          ctoks.push(Array.isArray(cands[j])?cands[j][0]||'':String(cands[j]));
        }else ctoks.push('');
      }
      // Base labels
      if(baseCands.length>0){
        for(let j=7;j>=0;j--){
          if(j<baseCands.length&&baseCands[j]){
            const nm=Array.isArray(baseCands[j])?baseCands[j][0]||'':String(baseCands[j]);
            ctoks.push('\u00B7'+nm);
          }else ctoks.push('\u00B7');
        }
      }else{
        for(let j=0;j<8;j++) ctoks.push('\u00B7?');
      }
      rows.push([bm,im,Math.round(kl*1e4)/1e4,Math.round(replRatio*1e4)/1e4,ctoks]);
    }
    cats[cat].push([r.prompt||'',toks,rows]);
  }
  // Diagnostic dump
  console.log('[Terrain] DATA DIAGNOSTIC:',JSON.stringify(diag));
  if(diag.hasDispProfiles>0) console.log('[Terrain] Using displacement profiles for '+diag.hasDispProfiles+'/'+diag.total+' prompts');
  if(diag.hasLtpFallback>0) console.log('[Terrain] Using LTP tension fallback for '+diag.hasLtpFallback+'/'+diag.total+' prompts');
  // Dump first prompt raw data to confirm what the terrain actually renders
  const firstCat=Object.keys(cats)[0];
  if(firstCat&&cats[firstCat][0]){
    const[prompt,toks,rows]=cats[firstCat][0];
    if(rows[0]){
      const[bm,im,kl,rr,ctoks]=rows[0];
      console.log('[Terrain] FIRST TOKEN "'+toks[0]+'":');
      console.log('  im (instruct disp):', JSON.stringify(im));
      console.log('  bm (base disp):    ', JSON.stringify(bm));
      console.log('  replacement_ratio:', rr);
      console.log('  instruct labels:', JSON.stringify(ctoks.slice(0,8)));
      console.log('  base labels:    ', JSON.stringify(ctoks.slice(8)));
    }
  }
  console.log('[Terrain] VERSION: v4.0 — displacement profiles');
  return cats;
}

function _terrainRendererCore(container, D, opts){
  // Self-contained terrain renderer — used by both the embedded viewer
  // and the popout window (via .toString() serialization).
  // Only external dependency: THREE.js must be loaded.
  var charLimit=(opts&&opts.charLimit)||50;

  // Color ramps — dual palette
  function stops(t,s){for(let i=0;i<s.length-1;i++){if(t<=s[i+1][0]){const f=(t-s[i][0])/(s[i+1][0]-s[i][0]);return s[i][1].map((v,j)=>v+(s[i+1][1][j]-v)*f)}}return s[s.length-1][1]}
  const BASES={
    dual:{label:'Dual (Base \u2194 Instruct)',
      base:function(t){return stops(t,[[0,[.01,.02,.12]],[.15,[.02,.08,.32]],[.30,[.04,.20,.52]],[.45,[.06,.38,.68]],[.58,[.10,.56,.78]],[.70,[.22,.72,.84]],[.82,[.48,.85,.88]],[.92,[.72,.94,.96]],[1,[.90,.98,.99]]])},
      inst:function(t){return stops(t,[[0,[.12,.02,.01]],[.15,[.32,.06,.02]],[.30,[.52,.12,.02]],[.45,[.72,.28,.04]],[.58,[.86,.44,.06]],[.70,[.94,.60,.08]],[.82,[.98,.76,.18]],[.92,[.99,.88,.42]],[1,[1,.96,.72]]])},
      spine:function(t){return stops(t,[[0,[.06,.05,.06]],[.30,[.20,.18,.16]],[.60,[.50,.46,.38]],[.80,[.78,.72,.60]],[1,[.96,.92,.80]]])}},
    vivid:{label:'Vivid (shared)',
      base:function(t){return stops(t,[[0,[.04,.02,.28]],[.08,[.10,.04,.48]],[.16,[.18,.06,.60]],[.24,[.06,.22,.72]],[.32,[.02,.42,.78]],[.40,[.02,.62,.68]],[.48,[.10,.75,.45]],[.56,[.38,.82,.22]],[.64,[.65,.86,.12]],[.72,[.88,.84,.08]],[.80,[.96,.68,.06]],[.88,[.98,.42,.06]],[.94,[.92,.18,.08]],[1,[.72,.04,.14]]])},
      inst:null,spine:null},
    ember:{label:'Heat (shared)',
      base:function(t){return stops(t,[[0,[.01,0,0]],[.28,[.20,.02,.01]],[.52,[.62,.10,0]],[.72,[.92,.44,0]],[.88,[.98,.78,.10]],[1,[1,.98,.80]]])},
      inst:null,spine:null}
  };

  const isPopout=!!(opts&&opts.isPopout);
  let curCat=opts.cat||(Object.keys(D).includes('benign')?'benign':Object.keys(D)[0]);
  let curIdx=opts.idx||0, curBase=opts.base||'dual', labelScale=opts.labelScale||2.0;
  let renderMode='surface', dataFilter='all';
  let slideshowPlaying=false, slideshowSpeed=4, slideshowTimer=null;
  const BG=[.047,.047,.07];
  const FY=-2.2, SCX=0.55, COLS=17, HSCALE=180, X_MAX=8*SCX;

  function _rampFor(colIdx){
    const profile=BASES[curBase];
    if(colIdx===8 && profile.spine) return profile.spine;
    if(colIdx>8 && profile.inst) return profile.inst;
    return profile.base;
  }

  // Build DOM
  container.innerHTML='<div class="terrain-wrap">'
    +'<canvas id="tCv"></canvas>'
    +'<div class="terrain-ui" id="tUI"></div>'
    +'<div class="terrain-inf" id="tInf"></div>'
    +'<div class="terrain-leg" id="tLeg">'
    +'<div style="display:flex;gap:4px;align-items:center"><span id="tLegMin">0</span><canvas id="tLegBase"></canvas><span id="tLegMax">0</span></div>'
    +'</div></div>';

  const cv=document.getElementById('tCv');
  const wrap=cv.parentElement;
  const sc=new THREE.Scene();
  const cam=new THREE.PerspectiveCamera(44,1,.1,200);
  const ren=new THREE.WebGLRenderer({canvas:cv,antialias:true});
  ren.setPixelRatio(Math.min(devicePixelRatio,2));
  ren.setClearColor(0x0c0c12,1);
  function onResize(){
    const w=wrap.clientWidth,h=wrap.clientHeight;
    if(w<10||h<10)return;
    ren.setSize(w,h);cam.aspect=w/h;cam.updateProjectionMatrix();
  }
  onResize();
  new ResizeObserver(onResize).observe(wrap);

  sc.add(new THREE.AmbientLight(0xaabbcc,1.0));
  const dl=new THREE.DirectionalLight(0xccddff,1.0);dl.position.set(3,10,6);sc.add(dl);
  const dl2=new THREE.DirectionalLight(0x667788,.5);dl2.position.set(-4,5,-3);sc.add(dl2);

  let msh=null,wir=null,flr=null,lbs=[];

  function mixColor(mag,mn,mx,klT,xAbs,colIdx){
    const t=Math.max(0,Math.min(1,(mag-mn)/(mx-mn||1)));
    const rampFn=_rampFor(colIdx);
    var rgb=rampFn(t);
    var r=rgb[0],g=rgb[1],b=rgb[2];
    const klBoost=1.0+klT*0.3;
    r=Math.min(1,r*klBoost);g=Math.min(1,g*klBoost);b=Math.min(1,b*klBoost);
    const fade=Math.pow(xAbs/X_MAX,1.6);
    r=r*(1-fade)+BG[0]*fade;g=g*(1-fade)+BG[1]*fade;b=b*(1-fade)+BG[2]*fade;
    return new THREE.Color(r,g,b);
  }

  function build(){
    [msh,wir,flr].forEach(function(m){if(!m)return;sc.remove(m);m.geometry.dispose();m.material.dispose()});
    lbs.forEach(function(s){sc.remove(s);if(s.geometry)s.geometry.dispose();if(s.material){if(s.material.map)s.material.map.dispose();s.material.dispose()}});
    msh=wir=flr=null;lbs=[];
    var entries=D[curCat];
    if(!entries||!entries[curIdx])return;
    var parts=entries[curIdx],prompt=parts[0],toks=parts[1],rows=parts[2];
    var nT=toks.length,scZ=SCX;
    var zDepth=(nT-1)*scZ;
    var zOffset=zDepth/2;
    var allMags=[];
    for(var ri=0;ri<rows.length;ri++){var rr=rows[ri];rr[0].forEach(function(v){allMags.push(v)});rr[1].forEach(function(v){allMags.push(v)})}
    var mn=Math.min.apply(null,allMags),mx=Math.max.apply(null,allMags);
    var klVals=rows.map(function(r){return r[2]});
    var klMin=Math.min.apply(null,klVals),klMax=Math.max.apply(null,klVals);

    // Surface
    var vsArr=[],csArr=[],ixArr=[],vtx=[];
    for(var t=0;t<nT;t++){
      vtx.push([]);
      var bm=rows[t][0],im=rows[t][1],kl=rows[t][2];
      var z=-t*scZ+zOffset,klT=(kl-klMin)/(klMax-klMin||1);
      var spineMag=(bm.reduce(function(a,v){return a+v},0)+im.reduce(function(a,v){return a+v},0))/(bm.length+im.length);
      for(var c=0;c<COLS;c++){
        var x,mag;
        if(c<8){x=(c-8)*SCX;mag=bm[c]}
        else if(c===8){x=0;mag=spineMag}
        else{x=(c-8)*SCX;mag=im[c-9]}
        var y=FY+(mag-mn)*HSCALE;
        vtx[t].push({x:x,y:y,z:z});
        vsArr.push(x,y,z);
        var col=mixColor(mag,mn,mx,klT,Math.abs(x),c);
        csArr.push(col.r,col.g,col.b);
      }
    }
    // Filter mask
    var klMean=klVals.reduce(function(a,v){return a+v},0)/klVals.length;
    var allMagsSorted=allMags.slice().sort(function(a,b){return a-b});
    var medianMag=allMagsSorted[Math.floor(allMagsSorted.length/2)];
    var tokenVisible=[];
    for(var t=0;t<nT;t++){
      if(dataFilter==='highkl') tokenVisible.push(rows[t][2]>klMean);
      else if(dataFilter==='hotspots'){
        var tmB=rows[t][0],tmI=rows[t][1];
        var tMean=(tmB.reduce(function(a,v){return a+v},0)+tmI.reduce(function(a,v){return a+v},0))/(tmB.length+tmI.length);
        tokenVisible.push(tMean>medianMag);
      }
      else tokenVisible.push(true);
    }
    var dimFactor=0.15;
    for(var t=0;t<nT;t++){
      if(!tokenVisible[t]){
        for(var c=0;c<COLS;c++){var i=(t*COLS+c)*3;csArr[i]*=dimFactor;csArr[i+1]*=dimFactor;csArr[i+2]*=dimFactor}
      }
    }

    // Render
    var geo=new THREE.BufferGeometry();
    geo.setAttribute('position',new THREE.Float32BufferAttribute(vsArr,3));
    geo.setAttribute('color',new THREE.Float32BufferAttribute(csArr,3));

    if(renderMode==='points'){
      var sizes=new Float32Array(nT*COLS);
      for(var t=0;t<nT;t++){var vis=tokenVisible[t];for(var c=0;c<COLS;c++){var ef=1-Math.pow(Math.abs(c-8)/8,0.8)*0.6;sizes[t*COLS+c]=vis?(0.06*ef):0.01}}
      geo.setAttribute('size',new THREE.Float32BufferAttribute(sizes,1));
      msh=new THREE.Points(geo,new THREE.PointsMaterial({vertexColors:true,size:0.08,sizeAttenuation:true,transparent:true,opacity:0.9}));
      sc.add(msh);
    }else{
      for(var t=0;t<nT-1;t++)for(var c=0;c<COLS-1;c++){var a=t*COLS+c,b=a+1,cc=a+COLS,dd=cc+1;ixArr.push(a,b,cc,b,dd,cc)}
      geo.setIndex(ixArr);geo.computeVertexNormals();
      msh=new THREE.Mesh(geo,new THREE.MeshPhongMaterial({vertexColors:true,side:THREE.DoubleSide,shininess:30,emissive:0x444444,emissiveIntensity:0.35}));
      sc.add(msh);
    }

    // Floor
    var fG=new THREE.PlaneGeometry(COLS*SCX+1.2,nT*scZ+2);fG.rotateX(-Math.PI/2);
    flr=new THREE.Mesh(fG,new THREE.MeshBasicMaterial({color:0x0c0c12,transparent:true,opacity:.25,side:THREE.DoubleSide}));
    flr.position.set(0,FY-.01,0);sc.add(flr);

    // Grid lines
    var OFF=0.032;
    if(renderMode==='surface'){
      var gridP=[],gridC=[];
      var pushSeg=function(ax,ay,az,bx,by,bz,r,g,b){gridP.push(ax,ay+OFF,az,bx,by+OFF,bz);gridC.push(r,g,b,r,g,b)};
      for(var t=0;t<nT;t++){for(var c=0;c<COLS-1;c++){var v0=vtx[t][c],v1=vtx[t][c+1];var near=(c===7||c===8)?.30:.14;pushSeg(v0.x,v0.y,v0.z,v1.x,v1.y,v1.z,near*.55,near*.65,near)}}
      for(var c=0;c<COLS;c++){var isSpine=(c===8);for(var t=0;t<nT-1;t++){var v0=vtx[t][c],v1=vtx[t+1][c];if(isSpine){pushSeg(v0.x,v0.y,v0.z,v1.x,v1.y,v1.z,.75,.72,.62)}else{var fade=1-Math.pow(Math.abs(c-8)/8,.7);pushSeg(v0.x,v0.y,v0.z,v1.x,v1.y,v1.z,fade*.22,fade*.26,fade*.38)}}}
      var gridGeo=new THREE.BufferGeometry();
      gridGeo.setAttribute('position',new THREE.Float32BufferAttribute(gridP,3));
      gridGeo.setAttribute('color',new THREE.Float32BufferAttribute(gridC,3));
      wir=new THREE.LineSegments(gridGeo,new THREE.LineBasicMaterial({vertexColors:true,transparent:true,opacity:.92}));
      sc.add(wir);
    }

    // Spine line + dots
    var spinePts=[];
    for(var t=0;t<nT;t++){var sv=vtx[t][8];spinePts.push(new THREE.Vector3(sv.x,sv.y+OFF+0.04,sv.z))}
    var spineGeo=new THREE.BufferGeometry().setFromPoints(spinePts);
    var spineLine=new THREE.Line(spineGeo,new THREE.LineBasicMaterial({color:0xf0ede4,linewidth:2,transparent:true,opacity:0.85}));
    sc.add(spineLine);lbs.push(spineLine);
    var dotGeo=new THREE.SphereGeometry(0.035,6,6);
    var dotMat=new THREE.MeshBasicMaterial({color:0xf0ede4,transparent:true,opacity:0.7});
    for(var t=0;t<nT;t++){var sv=vtx[t][8];var dot=new THREE.Mesh(dotGeo,dotMat);dot.position.set(sv.x,sv.y+OFF+0.04,sv.z);sc.add(dot);lbs.push(dot)}

    // Labels at every vertex
    var LW=Math.round(96*labelScale),LH=Math.round(24*labelScale);
    var LSX=SCX*0.90*labelScale,LSY=LSX*(LH/LW);
    var SPINE_BOOST=1.5;
    var SLW=Math.round(LW*SPINE_BOOST),SLH=Math.round(LH*SPINE_BOOST);
    var SLSX=LSX*SPINE_BOOST,SLSY=SLSX*(SLH/SLW);
    var labelFontPx=Math.round(12*labelScale);
    var spineFontPx=Math.round(12*labelScale*SPINE_BOOST);
    var texCache={};
    var getTexture=function(str,klT,isSpine,colIdx){
      var bucket=Math.round(klT*8),key=str+'|'+bucket+'|'+labelScale+'|'+(isSpine?'S':'C')+'|'+colIdx;
      if(texCache[key])return texCache[key];
      var w=isSpine?SLW:LW, h=isSpine?SLH:LH, fpx=isSpine?spineFontPx:labelFontPx;
      var S=2,lc=document.createElement('canvas');lc.width=w*S;lc.height=h*S;
      var lx=lc.getContext('2d');lx.scale(S,S);
      lx.font='700 '+fpx+'px system-ui,sans-serif';lx.textAlign='center';lx.textBaseline='middle';
      if(isSpine){lx.lineWidth=Math.max(3,labelScale*2.2);lx.strokeStyle='rgba(0,0,0,0.98)';lx.strokeText(str,w/2,h/2);lx.fillStyle='rgba(86,180,233,1.0)';lx.fillText(str,w/2,h/2)}
      else{lx.lineWidth=Math.max(2,labelScale*1.5);lx.strokeStyle='rgba(0,0,0,0.95)';lx.strokeText(str,w/2,h/2);lx.fillStyle='rgba(240,237,228,1.0)';lx.fillText(str,w/2,h/2)}
      var ulLen=Math.max(4,Math.round((w-10)*klT));
      if(!isSpine){var rgb2=_rampFor(colIdx)(Math.max(.15,klT*.75+.18));lx.globalAlpha=.7;lx.fillStyle='rgb('+Math.round(rgb2[0]*255)+','+Math.round(rgb2[1]*255)+','+Math.round(rgb2[2]*255)+')';lx.fillRect((w-ulLen)/2,h/2+Math.round(8*labelScale),ulLen,Math.max(2,Math.round(2*labelScale)))}
      else{lx.globalAlpha=.6;lx.fillStyle='rgba(86,180,233,0.8)';lx.fillRect((w-ulLen)/2,h/2+Math.round(10*labelScale*SPINE_BOOST),ulLen,Math.max(2,Math.round(2*labelScale)))}
      texCache[key]=new THREE.CanvasTexture(lc);return texCache[key];
    };
    for(var t=0;t<nT;t++){
      var ctoks=rows[t][4]||[];
      var klT2=(rows[t][2]-klMin)/(klMax-klMin||1);
      for(var c=0;c<COLS;c++){
        var vv=vtx[t][c];
        var isSpine=(c===8);
        var str;
        if(c<8)str=(ctoks[8+c]||'').replace(/^[\s\u0120\u00c2]/,'').trim().slice(0,12);
        else if(isSpine)str=toks[t].replace(/^[\s\u0120\u00c2]/,'').trim().slice(0,12);
        else str=(ctoks[16-c]||'').replace(/^[\s\u0120\u00c2]/,'').trim().slice(0,12);
        if(!str)str='\u00B7';
        var tex=getTexture(str,klT2,isSpine,c);
        var fd=isSpine?1.0:Math.max(.28,1-Math.pow(Math.abs(c-8)/8,1.2)*.68);
        var sx=isSpine?SLSX:LSX, sy=isSpine?SLSY:LSY;
        var sp=new THREE.Sprite(new THREE.SpriteMaterial({map:tex,transparent:true,depthTest:false,opacity:fd}));
        sp.position.set(vv.x,vv.y+OFF+(isSpine?.10:.06),vv.z);sp.scale.set(sx,sy,1);
        sc.add(sp);lbs.push(sp);
      }
    }

    // Axis labels
    var frontZ=vtx[0][8].z+scZ*.6;
    var makeAx=function(txt,xp,align){
      var ac=document.createElement('canvas');ac.width=160;ac.height=22;
      var ax=ac.getContext('2d');ax.font='500 10px system-ui,sans-serif';
      ax.fillStyle='rgba(110,110,130,0.55)';ax.textAlign=align||'center';
      ax.fillText(txt,align==='right'?155:align==='left'?5:80,14);
      var sp=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(ac),transparent:true,depthTest:false}));
      sp.position.set(xp,FY+.1,frontZ);sp.scale.set(1.3,.19,1);sc.add(sp);lbs.push(sp);
    };
    makeAx('\u2190 base',-2.2,'right');
    makeAx('instruct \u2192',2.2,'left');

    // Info
    var peakKl=Math.max.apply(null,klVals);
    var peakTok=toks[klVals.indexOf(peakKl)].replace(/^[\s\u0120\u00c2]/,'').trim().slice(0,14);
    var baseHasData=rows.some(function(r){return r[0].some(function(v){return v>0})});
    var infEl=document.getElementById('tInf');
    if(infEl) infEl.textContent=nT+' tokens \u00B7 tension '+(mn*1e3).toFixed(2)+'\u2013'+(mx*1e3).toFixed(2)+' \u00D710\u207B\u00B3 \u00B7 peak KL '+peakKl.toFixed(3)+' "'+peakTok+'" \u00B7 base: '+(baseHasData?'\u2705 data':'\u274C NO DATA');

    // Legend
    var legC=document.getElementById('tLegBase');
    if(legC){
      var profile=BASES[curBase];var hasDual=!!profile.inst;
      legC.width=hasDual?200:100;legC.height=hasDual?18:6;
      var ctx=legC.getContext('2d');ctx.clearRect(0,0,legC.width,legC.height);
      if(hasDual){
        var g1=ctx.createLinearGradient(0,0,legC.width,0);for(var i=0;i<=20;i++){var tt=i/20;var rgb=profile.base(tt);g1.addColorStop(tt,'rgb('+Math.round(rgb[0]*255)+','+Math.round(rgb[1]*255)+','+Math.round(rgb[2]*255)+')')}
        ctx.fillStyle=g1;ctx.fillRect(0,0,legC.width,7);ctx.fillStyle='#556';ctx.font='7px monospace';ctx.fillText('base',2,6);
        var g2=ctx.createLinearGradient(0,0,legC.width,0);for(var i=0;i<=20;i++){var tt=i/20;var rgb=profile.inst(tt);g2.addColorStop(tt,'rgb('+Math.round(rgb[0]*255)+','+Math.round(rgb[1]*255)+','+Math.round(rgb[2]*255)+')')}
        ctx.fillStyle=g2;ctx.fillRect(0,11,legC.width,7);ctx.fillStyle='#556';ctx.font='7px monospace';ctx.fillText('inst',2,17);
      }else{
        var g=ctx.createLinearGradient(0,0,100,0);for(var i=0;i<=20;i++){var tt=i/20;var rgb=profile.base(tt);g.addColorStop(tt,'rgb('+Math.round(rgb[0]*255)+','+Math.round(rgb[1]*255)+','+Math.round(rgb[2]*255)+')')}
        ctx.fillStyle=g;ctx.fillRect(0,0,100,6);
      }
    }
    var lMin=document.getElementById('tLegMin'),lMax=document.getElementById('tLegMax');
    if(lMin)lMin.textContent=(mn*1e3).toFixed(1);
    if(lMax)lMax.textContent=(mx*1e3).toFixed(1);

    // Center camera on terrain — frame based on larger dimension
    th=0.0;ph=0.08;
    var terrainW=COLS*SCX;
    rad=Math.max(10, Math.max(terrainW, zDepth)*0.8+4);
    target.set(0,FY+1.0,0);
    updateCam();
  }

  // UI controls
  function buildUI(){
    var ui=document.getElementById('tUI');
    if(!ui) return;
    var h='';
    h+='<select onchange="window._terrainSelectCat(this.value)" style="min-width:80px">';
    for(var c in D){if(D.hasOwnProperty(c))h+='<option value="'+c+'"'+(c===curCat?' selected':'')+'>'+c+'</option>'}
    h+='</select><span class="tsep">|</span>';
    h+='<select id="tPSel" onchange="window._terrainSelectPrompt(+this.value)">';
    var entries=D[curCat]||[];
    entries.forEach(function(e,i){h+='<option value="'+i+'"'+(i===curIdx?' selected':'')+'>'+e[0].slice(0,charLimit)+'</option>'});
    h+='</select>';
    h+='<button class="tb" onclick="window._terrainPrev()">Prev</button>';
    var playLabel=slideshowPlaying?'Stop':'Play';
    h+='<button class="tb'+(slideshowPlaying?' on':'')+'" id="tPlayBtn" onclick="window._terrainPlayPause()">'+playLabel+'</button>';
    h+='<button class="tb" onclick="window._terrainNext()">Next</button>';
    h+='<input type="range" min="1" max="10" value="'+slideshowSpeed+'" style="width:32px;vertical-align:middle" oninput="window._terrainSetSpeed(this.value)" title="Slideshow speed">';
    h+='<span class="tsep">|</span>';
    h+='<select onchange="window._terrainSetBase(this.value)" title="Color ramp">';
    for(var k in BASES){if(BASES.hasOwnProperty(k))h+='<option value="'+k+'"'+(k===curBase?' selected':'')+'>'+BASES[k].label+'</option>'}
    h+='</select>';
    if(!isPopout){
      h+='<select onchange="window._terrainSetMode(this.value)" title="Render mode">';
      h+='<option value="surface"'+(renderMode==='surface'?' selected':'')+'>Surface</option>';
      h+='<option value="points"'+(renderMode==='points'?' selected':'')+'>Points</option>';
      h+='</select>';
      h+='<select onchange="window._terrainSetFilter(this.value)" title="Data filter">';
      h+='<option value="all"'+(dataFilter==='all'?' selected':'')+'>All tokens</option>';
      h+='<option value="highkl"'+(dataFilter==='highkl'?' selected':'')+'>High KL</option>';
      h+='<option value="hotspots"'+(dataFilter==='hotspots'?' selected':'')+'>Hot spots</option>';
      h+='</select>';
    }
    h+='<span class="tsep">|</span>';
    h+='<span style="font-size:11px;color:#bbc">Aa</span><input type="range" min="5" max="40" value="'+Math.round(labelScale*10)+'" style="width:36px;vertical-align:middle" oninput="window._terrainSetLabelScale(this.value)" title="Label size">';
    h+='<span class="tsep">|</span>';
    h+='<button class="tb'+(autoRotate?' on':'')+'" onclick="window._terrainToggleRotate()">Rotate</button>';
    h+='<input type="range" min="1" max="20" value="'+Math.round(rotateSpeed*10)+'" style="width:32px;vertical-align:middle" oninput="window._terrainSetRotateSpeed(this.value)" title="Rotation speed (RPM)">';
    h+='<span class="tsep">|</span>';
    h+='<button class="tb" onclick="window._terrainResetView()">Reset</button>';
    if(!isPopout) h+='<button class="tb" onclick="window._terrainPopout()">Pop out</button>';
    ui.innerHTML=h;
  }

  function refreshPromptSelect(){
    var sel=document.getElementById('tPSel');if(!sel)return;sel.innerHTML='';
    (D[curCat]||[]).forEach(function(e,i){var o=document.createElement('option');o.value=i;o.textContent=e[0].slice(0,charLimit);if(i===curIdx)o.selected=true;sel.appendChild(o)});
  }

  window._terrainSelectCat=function(c){curCat=c;curIdx=0;if(slideshowPlaying){slideshowPlaying=false;if(slideshowTimer){clearTimeout(slideshowTimer);slideshowTimer=null}}buildUI();build()};
  window._terrainSelectPrompt=function(i){curIdx=parseInt(i)||0;if(slideshowPlaying){slideshowPlaying=false;if(slideshowTimer){clearTimeout(slideshowTimer);slideshowTimer=null}}buildUI();build()};
  window._terrainSetBase=function(k){curBase=k;build()};
  window._terrainSetMode=function(m){renderMode=m;build()};
  window._terrainSetFilter=function(f){dataFilter=f;build()};
  window._terrainSetLabelScale=function(v){labelScale=parseInt(v)/10;build()};
  window._terrainToggleRotate=function(){autoRotate=!autoRotate;buildUI()};
  window._terrainSetRotateSpeed=function(v){rotateSpeed=parseInt(v)/10};
  window._terrainNext=function(){var entries=D[curCat]||[];if(!entries.length)return;curIdx=(curIdx+1)%entries.length;buildUI();build()};
  window._terrainPrev=function(){var entries=D[curCat]||[];if(!entries.length)return;curIdx=(curIdx-1+entries.length)%entries.length;buildUI();build()};
  window._terrainPlayPause=function(){slideshowPlaying=!slideshowPlaying;buildUI();if(slideshowPlaying)_terrainAutoAdvance();else if(slideshowTimer){clearTimeout(slideshowTimer);slideshowTimer=null}};
  window._terrainSetSpeed=function(v){slideshowSpeed=parseInt(v)||4};
  window._terrainResetView=function(){th=0.0;ph=0.08;var entries=D[curCat]||[];var nT=entries[curIdx]?entries[curIdx][1].length:10;var terrainW=COLS*SCX;var zDepth=(nT-1)*SCX;rad=Math.max(10,Math.max(terrainW,zDepth)*0.8+4);target.set(0,FY+1.0,0);updateCam()};

  function _terrainAutoAdvance(){
    if(!slideshowPlaying)return;
    var entries=D[curCat]||[];
    if(!entries.length){slideshowPlaying=false;return}
    curIdx=(curIdx+1)%entries.length;
    if(curIdx===0){var cats=Object.keys(D);var ci=cats.indexOf(curCat);if(cats.length>1){curCat=cats[(ci+1)%cats.length];curIdx=0}}
    buildUI();build();
    var delay=Math.max(500,4000-slideshowSpeed*350);
    slideshowTimer=setTimeout(_terrainAutoAdvance,delay);
  }

  // Camera
  var th=0.0,ph=0.08,rad=14;
  var target=new THREE.Vector3(0,FY+1.0,0);
  var autoRotate=!!(opts&&opts.autoRotate);
  var rotateSpeed=(opts&&opts.rotateSpeed)||0.3; // RPM
  var dragging=false;
  function updateCam(){cam.position.set(target.x+rad*Math.sin(ph)*Math.cos(th),target.y+rad*Math.cos(ph),target.z+rad*Math.sin(ph)*Math.sin(th));cam.lookAt(target)}
  var ptrs={};
  cv.addEventListener('contextmenu',function(e){e.preventDefault()});
  cv.addEventListener('pointerdown',function(e){cv.setPointerCapture(e.pointerId);ptrs[e.pointerId]={btn:e.button,x:e.clientX,y:e.clientY};dragging=true});
  cv.addEventListener('pointerup',function(e){cv.releasePointerCapture(e.pointerId);delete ptrs[e.pointerId];if(Object.keys(ptrs).length===0)dragging=false});
  cv.addEventListener('pointermove',function(e){
    var p=ptrs[e.pointerId];if(!p)return;
    var dx=e.clientX-p.x,dy=e.clientY-p.y;p.x=e.clientX;p.y=e.clientY;
    if(p.btn===0){th+=dx*.008;ph=Math.max(.08,Math.min(1.55,ph-dy*.008))}
    else{
      var speed=rad*.0012;
      var right=new THREE.Vector3();
      right.crossVectors(new THREE.Vector3(0,1,0),new THREE.Vector3(Math.sin(ph)*Math.cos(th),Math.cos(ph),Math.sin(ph)*Math.sin(th))).normalize();
      var fwd=new THREE.Vector3(Math.sin(ph)*Math.cos(th),Math.cos(ph),Math.sin(ph)*Math.sin(th)).normalize();
      var up=new THREE.Vector3().crossVectors(right,fwd).normalize();
      target.addScaledVector(right,-dx*speed);target.addScaledVector(up,-dy*speed);
    }
    updateCam();
  });
  cv.addEventListener('wheel',function(e){e.preventDefault();rad=Math.max(4,Math.min(30,rad+e.deltaY*.012));updateCam()},{passive:false});

  // Start
  buildUI();
  updateCam();
  build();
  var running=true;
  var lastTime=performance.now();
  (function loop(){if(!running)return;requestAnimationFrame(loop);
    var now=performance.now();var dt=(now-lastTime)/1000;lastTime=now;
    if(autoRotate&&!dragging){th+=rotateSpeed*Math.PI*2/60*dt;updateCam()}
    ren.render(sc,cam)})();

  // Cleanup
  var observer=new MutationObserver(function(){
    if(!document.getElementById('tCv')){running=false;observer.disconnect();ren.dispose();if(slideshowTimer){clearTimeout(slideshowTimer);slideshowTimer=null;slideshowPlaying=false}}
  });
  observer.observe(document.body,{childList:true,subtree:true});
}


function _openTerrainWindow(D, charLimit, autoRotate, rotateSpeed){
    charLimit = charLimit || 50;
    autoRotate = !!autoRotate;
    rotateSpeed = rotateSpeed || 0.3;
    var pw=1200,ph=800;
    var left=Math.round((screen.width-pw)/2);
    var top=Math.round((screen.height-ph)/2);
    var w=window.open('','_blank','width='+pw+',height='+ph+',left='+left+',top='+top);
    if(!w)return;
    var dataJSON=JSON.stringify(D);
    w.document.write('<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Correction Field Topology</title>');
    w.document.write('<style>*{margin:0;padding:0;box-sizing:border-box}html,body{width:100%;height:100%;overflow:hidden;background:#0c0c12;color:#c2c0b6;font-family:system-ui,sans-serif}');
    w.document.write('.terrain-wrap{position:absolute;inset:0;background:#0c0c12}');
    w.document.write('.terrain-wrap canvas{position:absolute;inset:0;width:100%!important;height:100%!important;cursor:grab}.terrain-wrap canvas:active{cursor:grabbing}');
    w.document.write('.terrain-ui{position:absolute;bottom:8px;left:8px;display:flex;flex-wrap:wrap;gap:3px;align-items:center;background:rgba(8,8,18,.75);padding:3px 7px;border-radius:6px;max-width:calc(100% - 16px);z-index:5}');
    w.document.write('.terrain-ui .tb{font-size:11px;padding:2px 8px;background:transparent;border:.5px solid rgba(255,255,255,.16);border-radius:4px;color:#888;cursor:pointer;font-family:monospace}.terrain-ui .tb:hover{background:rgba(255,255,255,.05)}.terrain-ui .tb.on{border-color:#4A9EE0;color:#85B7EB}');
    w.document.write('.terrain-ui .tsep{color:rgba(255,255,255,.12);margin:0 2px;font-size:11px}');
    w.document.write('.terrain-ui select{background:rgba(255,255,255,.05);border:.5px solid rgba(255,255,255,.15);border-radius:3px;color:#ccc;font-size:11px;padding:2px 5px;cursor:pointer;max-width:200px;font-family:monospace}');
    w.document.write('.terrain-inf{position:absolute;top:6px;left:8px;font-size:11px;color:#bbc;background:rgba(8,8,18,.55);padding:2px 6px;border-radius:4px;z-index:5;font-family:monospace}');
    w.document.write('.terrain-leg{position:absolute;bottom:8px;right:8px;display:flex;flex-direction:column;gap:2px;background:rgba(8,8,18,.55);padding:3px 6px;border-radius:4px;z-index:5}.terrain-leg canvas{height:5px;width:100px;border-radius:2px}.terrain-leg span{font-size:11px;color:#bbc}');
    w.document.write('</style>');
    w.document.write('<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"><\/script>');
    w.document.write('</head><body>');
    w.document.write('<div id="terrainContainer" style="position:absolute;inset:0"></div>');
    w.document.write('<script>var D='+dataJSON+';<\/script>');
    w.document.write('<script>var _terrainRendererCore='+_terrainRendererCore.toString()+';<\/script>');
    w.document.write('<script>requestAnimationFrame(function(){_terrainRendererCore(document.getElementById("terrainContainer"),D,{isPopout:true,charLimit:'+charLimit+',autoRotate:'+autoRotate+',rotateSpeed:'+rotateSpeed+'})});<\/script>');
    w.document.write('</body></html>');
    w.document.close();
}

async function _lazyLoadTerrainPopout(totalCount, params){
  params = params || {};
  var catFilter = params.category || 'all';
  var recordLimit = params.recordLimit || DISPLAY_DEFAULTS.terrainRecordLimit || 100;
  var tokenLimit = params.tokenLimit || DISPLAY_DEFAULTS.terrainTokenLimit || 20;
  var charLimit = params.charLimit || DISPLAY_DEFAULTS.terrainCharLimit || 50;
  var autoRotate = params.autoRotate != null ? params.autoRotate : DISPLAY_DEFAULTS.terrainAutoRotate;
  var rotateSpeed = params.rotateSpeed || DISPLAY_DEFAULTS.terrainRotateSpeed || 0.3;

  var allResults=[];
  var CHUNK=25;
  // Estimate how many we need to fetch: if filtering by category, overshoot
  // since we don't know the distribution. Otherwise stop at recordLimit.
  var fetchLimit = (catFilter !== 'all') ? totalCount : recordLimit;
  try{
    for(var start=0;start<totalCount&&allResults.length<fetchLimit;start+=CHUNK){
      log('Loading terrain data... '+allResults.length+'/'+fetchLimit+(catFilter!=='all'?' (scanning for '+catFilter+')':''));
      var resp=await fetch('/api/results/detail?start='+start+'&count='+CHUNK);
      var data=await resp.json();
      if(!data.ok)break;
      if(catFilter !== 'all'){
        // Filter as we go so we can stop early
        var matching = data.results.filter(function(r){ return r.category === catFilter; });
        allResults = allResults.concat(matching);
        if(allResults.length >= recordLimit) break;
      } else {
        allResults=allResults.concat(data.results);
      }
    }
    // Apply record limit
    if(allResults.length > recordLimit){
      allResults = allResults.slice(0, recordLimit);
    }
    log('Loaded '+allResults.length+' records'+(catFilter!=='all'?' ('+catFilter+')':''));
    // Apply token limit — truncate per-prompt arrays
    allResults.forEach(function(r){
      if(r.tokens && r.tokens.length > tokenLimit){
        r.tokens = r.tokens.slice(0, tokenLimit);
        r.seq_len = tokenLimit;
        if(r.per_token_stress) r.per_token_stress = r.per_token_stress.slice(0, tokenLimit);
        if(r.per_token_kl) r.per_token_kl = r.per_token_kl.slice(0, tokenLimit);
        if(r.signed_attr) r.signed_attr = r.signed_attr.slice(0, tokenLimit);
        if(r.ltp){
          if(r.ltp.profiles) r.ltp.profiles = r.ltp.profiles.slice(0, tokenLimit);
          if(r.ltp.base_profiles) r.ltp.base_profiles = r.ltp.base_profiles.slice(0, tokenLimit);
          if(r.ltp.counterfactual_tokens) r.ltp.counterfactual_tokens = r.ltp.counterfactual_tokens.slice(0, tokenLimit);
          if(r.ltp.tension_magnitudes) r.ltp.tension_magnitudes = r.ltp.tension_magnitudes.slice(0, tokenLimit);
        }
        if(r.rank_displacement){
          if(r.rank_displacement.instruct_disp_profiles) r.rank_displacement.instruct_disp_profiles = r.rank_displacement.instruct_disp_profiles.slice(0, tokenLimit);
          if(r.rank_displacement.base_disp_profiles) r.rank_displacement.base_disp_profiles = r.rank_displacement.base_disp_profiles.slice(0, tokenLimit);
          if(r.rank_displacement.per_position) r.rank_displacement.per_position = r.rank_displacement.per_position.slice(0, tokenLimit);
        }
        if(r.base_counterfactual_tokens) r.base_counterfactual_tokens = r.base_counterfactual_tokens.slice(0, tokenLimit);
      }
    });

    var hasData=allResults.some(function(r){
      return(r.ltp&&r.ltp.profiles&&r.ltp.profiles.length>0)||
            (r.rank_displacement&&r.rank_displacement.instruct_disp_profiles&&r.rank_displacement.instruct_disp_profiles.length>0);
    });
    if(hasData){
      var D=_terrainTransformData(allResults);
      if(Object.keys(D).length) _openTerrainWindow(D, charLimit, autoRotate, rotateSpeed);
      else log('No terrain profile data available.','error');
    }else{
      log('No terrain profile data available for this session.','error');
    }
  }catch(e){
    console.error('Terrain lazy load error:',e);
    log('Terrain load failed: '+e.message,'error');
  }
}

// ─── Advanced Engine Parameters ────────────────────────────────

var _engineConfig = {};
var _engineDefaults = {};
var _enginePending = {};  // local edits not yet applied
var _advUnlocked = false;

// Parameter metadata for display
var ENGINE_PARAM_META = {
  signal_layer_fraction:  {group:'Signal Layers',   label:'Signal layer fraction',       desc:'Fraction of model depth for each third. 0.333 = middle third.', type:'float', step:0.01, min:0.1, max:0.5},
  sfd_use_signal_layers:  {group:'SFD',             label:'SFD uses signal layers',      desc:'If enabled, SFD uses the same layer range as ASM.', type:'bool'},
  sfd_layer_start:        {group:'SFD',             label:'SFD layer start',             desc:'First layer for SFD (when "uses signal layers" is off).', type:'int', min:0, max:30},
  sfd_layer_end:          {group:'SFD',             label:'SFD layer end (exclusive)',    desc:'Last layer (exclusive) for SFD.', type:'int', min:1, max:30},
  sfd_svd_k:              {group:'SFD',             label:'SFD SVD components',          desc:'Right singular vectors retained for per-token projection.', type:'int', min:4, max:64},
  sfd_svd_seed:           {group:'SFD',             label:'SFD SVD seed',                desc:'Random seed for deterministic SVD. Ensures reproducible SFD across sessions.', type:'int', min:0, max:99999},
  rd_min_shared:          {group:'Rank Displacement',label:'Min shared candidates',      desc:'Min shared candidates for Kendall tau. Below this, tau = 0.', type:'int', min:1, max:8},
  boundary_fraction:      {group:'ASM Attribution', label:'Boundary fraction',           desc:'Fraction of tokens at each end for interior/boundary split.', type:'float', step:0.01, min:0.01, max:0.4},
  response_topk:          {group:'ASM Attribution', label:'Response top-k',              desc:'Next-token predictions captured from each model.', type:'int', min:3, max:50},
  proof1_threshold:       {group:'ASM Attribution', label:'Proof-1 exactness',           desc:'Error threshold for exact attribution decomposition.', type:'float', step:0.0001, min:0.00001, max:0.01},
  delta_svd_k:            {group:'Weight Delta',    label:'Delta SVD rank',              desc:'Max singular values for weight delta spectral summary.', type:'int', min:16, max:128},
  serialization_precision:{group:'Serialization',   label:'Decimal precision',           desc:'Decimal places for measurement values in JSON. Higher = larger files, more precision.', type:'int', min:4, max:12},
  n_bootstrap:            {group:'Statistics',      label:'Bootstrap resamples',         desc:'Bootstrap iterations for CIs. Higher = slower, tighter.', type:'int', min:500, max:20000, step:500},
  ci_level:               {group:'Statistics',      label:'Confidence level',            desc:'CI width. 0.95 = 95% confidence intervals.', type:'float', step:0.01, min:0.80, max:0.99},
  threshold_steps:        {group:'Statistics',      label:'Threshold search steps',      desc:'Granularity of optimal classification threshold search.', type:'int', min:50, max:2000, step:50},
  min_valid_separability: {group:'Statistics',      label:'Min valid for separability',  desc:'Min non-null values per metric for separability analysis.', type:'int', min:2, max:20},
  min_samples_d:          {group:'Statistics',      label:'Min samples for Cohen\'s d',  desc:'Min per-group samples for effect size.', type:'int', min:2, max:10},
  ltp_overfetch_first:    {group:'LTP',             label:'LTP overfetch (first)',       desc:'Extra candidates on first pass for k non-chosen alternatives.', type:'int', min:1, max:10},
  ltp_overfetch_second:   {group:'LTP',             label:'LTP overfetch (fallback)',    desc:'Wider fetch if first pass insufficient.', type:'int', min:2, max:20},
  disc_sublayers_top_n:   {group:'Visualization',   label:'Discriminative sublayers N',  desc:'Sublayers shown in discriminative sublayers plot.', type:'int', min:5, max:30},
  persist_probe_caches:    {group:'Modules',         label:'Persist probe caches',        desc:'Keep probe embeddings across sessions. When off, caches clear on startup.', type:'bool'},
  domain_embedding_layer_frac:{group:'Modules',     label:'Angular probe depth',         desc:'Embedding depth for subject/topic identity (angular axis). Lower = better noun separation. 0.50=default.', type:'float', step:0.05, min:0.05, max:0.95},
  domain_escalation_layer_frac:{group:'Modules',    label:'Radial probe depth',          desc:'Embedding depth for escalation level (radial axis). Higher = better discourse framing. 0.75=default.', type:'float', step:0.05, min:0.05, max:0.95},
  include_first_token:     {group:'Token Processing', label:'Include first token',        desc:'Include position-0 token in per-token analysis. Usually excluded due to BOS/positional artifacts. Enable if tokenizer has no BOS prefix.', type:'bool'},
  probe_projection_space:  {group:'Modules',         label:'Delta-projected probes',      desc:'Project embeddings through the o_proj weight delta before probe matching. Matches in the correction field coordinate system instead of raw hidden-state space.', type:'bool'},
  attention_weighted_pool:  {group:'Modules',        label:'Attention-weighted pooling',   desc:'Weight each token by model attention at the domain layer instead of uniform mean-pool. De-emphasizes function words without external filtering.', type:'bool'},
  export_domain_embeddings: {group:'Serialization',  label:'Export domain embeddings',     desc:'Include per-token domain embeddings in session JSON export. Large but enables offline re-analysis with different probe sets.', type:'bool'},
  chat_temperature:        {group:'Chat Generation', label:'Temperature',                 desc:'Sampling temperature for chat responses. Lower = more deterministic.', type:'float', step:0.05, min:0.0, max:2.0},
  chat_top_p:              {group:'Chat Generation', label:'Top-p (nucleus)',              desc:'Nucleus sampling threshold. Lower = fewer candidate tokens.', type:'float', step:0.05, min:0.1, max:1.0},
  chat_max_tokens:         {group:'Chat Generation', label:'Max tokens',                  desc:'Maximum tokens generated per chat response.', type:'int', min:32, max:2048, step:32},
};

function _advToggleLock(unlocked){
  _advUnlocked = unlocked;
  var btns = $('advParamsButtons');
  if(unlocked){
    _enginePending = {};
    loadAdvancedParams();
    if(btns) btns.style.display = 'flex';
  } else {
    _enginePending = {};
    if(btns) btns.style.display = 'none';
    $('advancedParamsPanel').textContent = 'Locked.';
  }
}

async function loadAdvancedParams(){
  try{
    var r = await(await fetch('/api/engine_config')).json();
    if(!r.ok) return;
    _engineConfig = r.config;
    _engineDefaults = r.defaults;
    _enginePending = {};
    renderAdvancedParams();
    _advUpdateApplyBtn();
  }catch(e){
    $('advancedParamsPanel').textContent = 'Failed to load: '+e.message;
  }
}

function _advGetValue(key){
  return key in _enginePending ? _enginePending[key] : _engineConfig[key];
}

function renderAdvancedParams(){
  var panel = $('advancedParamsPanel');
  if(!panel || !_advUnlocked) return;
  var groups = {};
  for(var key in ENGINE_PARAM_META){
    var m = ENGINE_PARAM_META[key];
    if(!groups[m.group]) groups[m.group]=[];
    groups[m.group].push({key:key, meta:m});
  }
  var h = '';
  for(var group in groups){
    var items = groups[group];
    var color = group==='SFD'?'var(--orange)':group==='LTP'?'var(--cyan)':group==='Statistics'?'var(--green)':group==='Serialization'?'var(--purple)':'var(--text-2)';
    h += '<div style="margin-bottom:14px"><div style="font-size:var(--font-desc);font-family:var(--mono);color:'+color+';text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px">'+group+'</div>';
    h += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px 16px">';
    items.forEach(function(item){
      var m = item.meta;
      var val = _advGetValue(item.key);
      var def = _engineDefaults[item.key];
      var isPending = item.key in _enginePending;
      var isDefault = String(val) === String(def);
      var id = 'ep_'+item.key;
      h += '<div style="margin-bottom:4px">';
      h += '<label style="font-size:var(--font-desc);color:var(--text-1);font-family:var(--mono)">'+escHtml(m.label);
      if(isPending) h += ' <span style="color:var(--orange);font-size:10px" title="Pending change">●</span>';
      else if(!isDefault) h += ' <span style="color:var(--yellow);font-size:10px" title="Changed from default">◆</span>';
      h += '</label>';
      if(m.type === 'bool'){
        h += '<div class="checkbox-row" style="margin-top:2px"><input type="checkbox" id="'+id+'"'+(val?' checked':'')+' onchange="_advEdit(\''+item.key+'\',this.checked)"><label for="'+id+'">Enable</label></div>';
      } else if(m.type === 'float'){
        h += '<input type="number" id="'+id+'" value="'+val+'" step="'+(m.step||0.01)+'"'+(m.min!=null?' min="'+m.min+'"':'')+(m.max!=null?' max="'+m.max+'"':'')+(isPending?' style="width:100px;font-size:var(--font-table);border-color:var(--orange)"':' style="width:100px;font-size:var(--font-table)"')+' onchange="_advEdit(\''+item.key+'\',parseFloat(this.value))">';
      } else {
        h += '<input type="number" id="'+id+'" value="'+val+'" step="'+(m.step||1)+'"'+(m.min!=null?' min="'+m.min+'"':'')+(m.max!=null?' max="'+m.max+'"':'')+(isPending?' style="width:100px;font-size:var(--font-table);border-color:var(--orange)"':' style="width:100px;font-size:var(--font-table)"')+' onchange="_advEdit(\''+item.key+'\',parseInt(this.value))">';
      }
      h += '<div style="font-size:var(--font-legend);color:var(--text-3);margin-top:1px">'+escHtml(m.desc)+' Default: '+def+'</div>';
      h += '</div>';
    });
    h += '</div></div>';
  }
  panel.innerHTML = h;
}

function _advEdit(key, value){
  // Check if value matches current server value — if so, remove from pending
  if(String(value) === String(_engineConfig[key])){
    delete _enginePending[key];
  } else {
    _enginePending[key] = value;
  }
  renderAdvancedParams();
  _advUpdateApplyBtn();
}

function _advUpdateApplyBtn(){
  var btn = $('advApplyBtn');
  if(!btn) return;
  var n = Object.keys(_enginePending).length;
  btn.disabled = (n === 0);
  btn.textContent = n > 0
    ? 'Apply '+n+' Change'+(n>1?'s':'')+' & Reset Application'
    : 'Apply Changes & Reset Application';
}

async function _advApplyChanges(){
  var n = Object.keys(_enginePending).length;
  if(n === 0) return;
  var msg = 'Apply '+n+' parameter change'+(n>1?'s':'')+'?\n\nThis will:\n• Update engine configuration\n• Unload the model\n• Clear the current session\n• Invalidate all caches\n\nYou will need to reload the model and re-collect data.\n\nChanged parameters:\n';
  for(var k in _enginePending){
    var m = ENGINE_PARAM_META[k];
    msg += '  '+m.label+': '+_engineConfig[k]+' → '+_enginePending[k]+'\n';
  }
  if(!confirm(msg)) return;

  try{
    // 1. Apply config changes
    var r = await(await fetch('/api/engine_config',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify(_enginePending)
    })).json();
    if(!r.ok){ log('Config update failed','error'); return; }
    log('Engine config updated: '+Object.keys(_enginePending).join(', '),'done');

    // 2. Reset application
    var resetR = await(await fetch('/api/reset',{method:'POST'})).json();
    if(resetR.ok){
      log('Application reset. Reload model to continue.','done');
      modelLoaded = false;
      sessionResults = [];
      dashResults = [];
      _promptTotal = 0;
      setStatus('idle','IDLE');
      $('analyzeBtn').disabled = true;
      $('batchBtn').disabled = true;
      updateSessionBadge();
    }

    // 3. Refresh panel
    _enginePending = {};
    await loadAdvancedParams();
    _advUpdateApplyBtn();

  }catch(e){
    log('Apply failed: '+e.message,'error');
  }
}

async function resetAdvancedParams(){
  if(!confirm('Reset all advanced parameters to defaults?\n\nThis will reset the application (unload model, clear session).')) return;
  try{
    var r = await(await fetch('/api/engine_config/reset',{method:'POST'})).json();
    if(r.ok){
      _engineConfig = r.config;
      _enginePending = {};
      // Reset application
      await fetch('/api/reset',{method:'POST'});
      modelLoaded = false;
      sessionResults = [];
      dashResults = [];
      _promptTotal = 0;
      setStatus('idle','IDLE');
      $('analyzeBtn').disabled = true;
      $('batchBtn').disabled = true;
      updateSessionBadge();
      renderAdvancedParams();
      _advUpdateApplyBtn();
      log('Advanced parameters and application reset to defaults','done');
    }
  }catch(e){log('Reset failed: '+e.message,'error')}
}

var _probeFiles = [];

async function applyProbeSet(){
  var picker = $('probeFilePicker');
  var btn = $('probeApplyBtn');
  var status = $('probeStatus');
  if(!picker.files || picker.files.length === 0){
    status.textContent = 'No file selected.';
    status.style.color = 'var(--red)';
    return;
  }
  if(!modelLoaded){
    status.textContent = 'Load a model first.';
    status.style.color = 'var(--red)';
    return;
  }
  btn.disabled = true;
  btn.textContent = 'Applying...';
  status.textContent = 'Uploading...';
  status.style.color = 'var(--text-2)';
  try {
    var fd = new FormData();
    fd.append('file', picker.files[0]);
    var r = await(await fetch('/api/probe_set/apply', {method:'POST', body:fd})).json();
    if(!r.ok){
      status.textContent = 'Error: ' + (r.error||'Unknown');
      status.style.color = 'var(--red)';
      btn.disabled = false;
      btn.textContent = 'Apply';
      return;
    }
    status.textContent = 'Embedding probes...';
    // Poll for completion
    var poll = setInterval(async function(){
      try {
        var s = await(await fetch('/api/probe_set/apply_status')).json();
        if(s.progress) status.textContent = s.progress;
        if(!s.active){
          clearInterval(poll);
          btn.disabled = false;
          btn.textContent = 'Apply';
          if(s.error){
            status.textContent = 'Error: ' + s.error;
            status.style.color = 'var(--red)';
          } else if(s.result){
            var res = s.result;
            status.innerHTML = '<span style="color:var(--green)">✓ ' + escHtml(res.filename) + '</span>'
              + ' — ' + res.n_probes + ' probes, ' + res.n_subjects + ' subjects, ' + res.n_levels + ' subclasses'
              + ' — embedded at L' + res.layer_L50 + ' and L' + res.layer_L75;
            status.style.color = 'var(--text-1)';
            log('Probe set applied: ' + res.filename + ' (' + res.n_probes + ' probes)', 'done');
            playChime();
          }
        }
      } catch(e){}
    }, 1000);
  } catch(e) {
    status.textContent = 'Failed: ' + e.message;
    status.style.color = 'var(--red)';
    btn.disabled = false;
    btn.textContent = 'Apply';
  }
}

async function loadProbeFiles(){
  // Show current active probe if any
  var status = $('probeStatus');
  if(!status) return;
  try {
    var r = await(await fetch('/api/probe_set/status')).json();
    if(r.ok && r.active){
      status.innerHTML = '<span style="color:var(--green)">✓ ' + escHtml(r.filename) + '</span>'
        + ' — ' + r.n_probes + ' probes, ' + r.n_subjects + ' subjects'
        + (r.cached ? ' — <span style="color:var(--green)">cached</span>' : ' — <span style="color:var(--text-3)">not cached</span>');
    } else {
      status.innerHTML = '<span style="color:var(--text-3)">No probe set active.</span>';
    }
  } catch(e) {}
}

async function clearProbeCaches(){
  var status = $('probeStatus');
  try {
    var r = await(await fetch('/api/probe_set/clear_caches', {method:'POST'})).json();
    if(r.ok){
      status.textContent = 'Cleared ' + r.deleted + ' cache file(s).';
      status.style.color = 'var(--text-2)';
      log('Probe caches cleared: ' + r.deleted + ' files', 'done');
    } else {
      status.textContent = 'Error: ' + (r.error||'Unknown');
      status.style.color = 'var(--red)';
    }
  } catch(e) {
    status.textContent = 'Failed: ' + e.message;
    status.style.color = 'var(--red)';
  }
}

// ─── Notification Chime ─────────────────────────────────────────
function playChime() {
  if (!$('chimeToggle') || !$('chimeToggle').checked) return;
  try {
    var ctx = new (window.AudioContext || window.webkitAudioContext)();
    var now = ctx.currentTime;

    function tone(freq, start, dur, gain) {
      var osc = ctx.createOscillator();
      var g = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      g.gain.setValueAtTime(0, now + start);
      g.gain.linearRampToValueAtTime(gain, now + start + 0.02);
      g.gain.exponentialRampToValueAtTime(0.001, now + start + dur);
      osc.connect(g);
      g.connect(ctx.destination);
      osc.start(now + start);
      osc.stop(now + start + dur);
    }

    // Two-note major third: E5 → G5, soft and brief
    tone(659, 0.0, 0.4, 0.12);
    tone(784, 0.15, 0.5, 0.10);

    setTimeout(function() { ctx.close(); }, 1000);
  } catch(e) {}
}

// ─── Init ───────────────────────────────────────────────────────
(async function(){
  try{
    loadModelList();loadPromptLibrary();await loadConfig();vizRenderConfig();loadAdvancedParams();loadProbeFiles();
    if($('chimeToggle'))$('chimeToggle').checked=localStorage.getItem('tagm_chime')==='1';
    const st=await(await fetch('/api/status')).json();
    if(st.user_info){$('userName').value=st.user_info.name||'';$('userOrg').value=st.user_info.organization||'';$('userProject').value=st.user_info.project||''}
    if(st.model_loaded){modelLoaded=true;setStatus('ready','READY');$('analyzeBtn').disabled=false;$('batchBtn').disabled=false}
    else if(st.loading){setStatus('loading','LOADING');$('loadModelBtn').disabled=true;$('loadModelBtn').textContent='Processing...';
      let ll=0;const poll=setInterval(async()=>{try{const p=await(await fetch('/api/progress')).json();for(let i=ll;i<p.log.length;i++){const e=p.log[i];log(`[${e.stage}] ${e.message}`,e.stage==='error'?'error':(e.stage==='ready'?'done':''))}ll=p.log.length;const s=await(await fetch('/api/status')).json();if(s.model_loaded){clearInterval(poll);modelLoaded=true;setStatus('ready','READY');$('analyzeBtn').disabled=false;$('batchBtn').disabled=false;$('loadModelBtn').disabled=false;$('loadModelBtn').textContent='Load Model';loadPromptLibrary()}else if(s.loading_error){clearInterval(poll);setStatus('idle','ERROR');$('loadModelBtn').disabled=false;$('loadModelBtn').textContent='Load Model'}}catch(e){}},2000)}
    // Restored session: populate data table and enable dashboard
    if(st.session&&st.session.n_results>0){
      _promptTotal=st.session.n_results;
      if(st.session.cache_size_bytes)_cacheBytes=st.session.cache_size_bytes;
      updateSessionBadge();
      renderDataTable();
      $('dashBtn').disabled=false;
      $('exportBtn').disabled=false;
      log('Session restored: '+st.session.n_results+' results'+(st.session.model?' ('+st.session.model+')':''),'done');
    }
  }catch(e){}
})();

// ─── Candidate Graph Topology ──────────────────────────────────
function computeCandidateGraph(r){
  const tokens=r.tokens||[];const instCf=(r.ltp&&r.ltp.counterfactual_tokens)||[];const baseCf=r.base_counterfactual_tokens||[];
  const nPos=Math.min(instCf.length,baseCf.length,tokens.length);if(nPos===0)return null;
  const candidates={};const posStats=[];
  function ec(t){if(!candidates[t])candidates[t]={inst:[],base:[],promoted:[],demoted:[],matched:[]};return candidates[t]}
  for(let pos=0;pos<nPos;pos++){
    const iAlts=instCf[pos]||[];const bAlts=baseCf[pos]||[];const instSet={};const baseSet={};
    for(let j=0;j<iAlts.length;j++){const t=Array.isArray(iAlts[j])?iAlts[j][0]:iAlts[j];const p=Array.isArray(iAlts[j])?iAlts[j][1]:0;instSet[t]={rank:j,prob:p}}
    for(let j=0;j<bAlts.length;j++){const t=Array.isArray(bAlts[j])?bAlts[j][0]:bAlts[j];const p=Array.isArray(bAlts[j])?bAlts[j][1]:0;baseSet[t]={rank:j,prob:p}}
    let nP=0,nD=0,nM=0;const prom=[],demo=[],match=[];
    for(const t in instSet){const c=ec(t);c.inst.push({pos,rank:instSet[t].rank,prob:instSet[t].prob});if(baseSet[t]!==undefined){c.matched.push(pos);match.push(t);nM++}else{c.promoted.push(pos);prom.push(t);nP++}}
    for(const t in baseSet){const c=ec(t);c.base.push({pos,rank:baseSet[t].rank,prob:baseSet[t].prob});if(instSet[t]===undefined){c.demoted.push(pos);demo.push(t);nD++}}
    posStats.push({pos,token:tokens[pos],nPromoted:nP,nDemoted:nD,nMatched:nM,contested:nP>0&&nD>0,intensity:nP+nD,promoted:prom,demoted:demo,matched:match})
  }
  const dualRole=[];for(const t in candidates){const c=candidates[t];if(c.promoted.length>0&&c.demoted.length>0)dualRole.push({token:t,promotedAt:c.promoted.map(p=>({pos:p,tok:tokens[p]})),demotedAt:c.demoted.map(p=>({pos:p,tok:tokens[p]})),matchedAt:c.matched.map(p=>({pos:p,tok:tokens[p]}))})}
  const roleSwitches=[];for(const t in candidates){const c=candidates[t];const ap=[...new Set([...c.inst.map(x=>x.pos),...c.base.map(x=>x.pos)])].sort((a,b)=>a-b);if(ap.length<2)continue;for(let i=0;i<ap.length-1;i++){if(ap[i+1]-ap[i]>2)continue;const p1=ap[i],p2=ap[i+1];const r1=c.promoted.includes(p1)?'promoted':(c.demoted.includes(p1)?'demoted':'matched');const r2=c.promoted.includes(p2)?'promoted':(c.demoted.includes(p2)?'demoted':'matched');if(r1!==r2)roleSwitches.push({candidate:t,fromPos:p1,fromTok:tokens[p1]||'?',fromRole:r1,toPos:p2,toTok:tokens[p2]||'?',toRole:r2})}}
  const trajectories=[];for(const t in candidates){const c=candidates[t];const aps=new Set([...c.inst.map(x=>x.pos),...c.base.map(x=>x.pos)]);if(aps.size<2)continue;const im={};c.inst.forEach(x=>im[x.pos]=x);const bm={};c.base.forEach(x=>bm[x.pos]=x);const positions=[...aps].sort((a,b)=>a-b).map(pos=>({pos,tok:tokens[pos]||'?',role:c.promoted.includes(pos)?'promoted':(c.demoted.includes(pos)?'demoted':'matched'),inst:im[pos]||null,base:bm[pos]||null}));trajectories.push({candidate:t,nAppearances:aps.size,positions,isDualRole:c.promoted.length>0&&c.demoted.length>0})}
  trajectories.sort((a,b)=>b.nAppearances-a.nAppearances);
  const nContested=posStats.filter(p=>p.contested).length;
  return{nPositions:nPos,tokens,posStats,candidates,dualRole,roleSwitches,trajectories:trajectories.slice(0,20),nContested,contestedFrac:nContested/nPos,nDualRole:dualRole.length,nRoleSwitches:roleSwitches.length,switchRate:roleSwitches.length/nPos,nUniqueCandidates:Object.keys(candidates).length,nMultiPosition:trajectories.length}
}
function renderCandidateGraphSection(r){
  const g=computeCandidateGraph(r);if(!g)return'';
  const uid='cg_'+Date.now()+'_'+Math.random().toString(36).substr(2,5);
  let mapH='<div style="font-family:var(--mono);font-size:12px;letter-spacing:1px;line-height:1.8;margin:8px 0">';
  for(let i=0;i<g.posStats.length;i++){const ps=g.posStats[i];let ch,col,title;if(!ps.contested){ch='·';col='var(--text-3)';title=ps.token+': stable ('+ps.nMatched+' matched)'}else if(ps.intensity>=6){ch='▓';col='var(--red)';title=ps.token+': heavy (+'+ps.nPromoted+' -'+ps.nDemoted+')'}else if(ps.intensity>=3){ch='▒';col='var(--orange)';title=ps.token+': moderate (+'+ps.nPromoted+' -'+ps.nDemoted+')'}else{ch='░';col='#e3b341';title=ps.token+': light (+'+ps.nPromoted+' -'+ps.nDemoted+')'}mapH+='<span style="color:'+col+';cursor:help" title="'+escHtml(title)+'">'+ch+'</span>'}
  mapH+='</div><div style="display:flex;flex-wrap:wrap;gap:2px;margin-bottom:12px">';
  for(let i=0;i<g.tokens.length;i++){const ps=g.posStats[i];const bg=ps.contested?(ps.intensity>=6?'rgba(248,81,73,0.15)':(ps.intensity>=3?'rgba(210,153,34,0.15)':'rgba(227,179,65,0.08)')):'transparent';mapH+='<span style="font-family:var(--mono);font-size:12px;padding:2px 5px;background:'+bg+';border-radius:3px;color:var(--text-0)">'+escHtml(g.tokens[i])+'</span>'}
  mapH+='</div>';
  const cp=(g.contestedFrac*100).toFixed(0),bw=Math.round(g.contestedFrac*100),bc=g.contestedFrac>0.85?'var(--red)':(g.contestedFrac>0.7?'var(--orange)':'var(--green)');
  let mH=`<div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:10px;margin-bottom:14px"><div><div style="font-size:11px;color:var(--text-2);margin-bottom:3px">CONTESTED</div><div style="font-family:var(--mono);font-size:16px;font-weight:600;color:${bc}">${cp}%</div><div style="width:100%;height:3px;background:var(--bg-3);border-radius:2px;margin-top:3px"><div style="width:${bw}%;height:100%;background:${bc};border-radius:2px"></div></div></div><div><div style="font-size:11px;color:var(--text-2);margin-bottom:3px">DUAL-ROLE</div><div style="font-family:var(--mono);font-size:16px;font-weight:600;color:var(--text-0)">${g.nDualRole}</div><div style="font-size:11px;color:var(--text-2)">candidates</div></div><div><div style="font-size:11px;color:var(--text-2);margin-bottom:3px">SWITCHES</div><div style="font-family:var(--mono);font-size:16px;font-weight:600;color:var(--text-0)">${g.nRoleSwitches}</div><div style="font-size:11px;color:var(--text-2)">${g.switchRate.toFixed(2)}/token</div></div><div><div style="font-size:11px;color:var(--text-2);margin-bottom:3px">TRAJECTORIES</div><div style="font-family:var(--mono);font-size:16px;font-weight:600;color:var(--text-0)">${g.nMultiPosition}</div><div style="font-size:11px;color:var(--text-2)">of ${g.nUniqueCandidates} unique</div></div></div>`;
  let ptH='<div style="max-height:200px;overflow-y:auto;margin-bottom:14px"><table class="data-table"><tr><th>Pos</th><th>Token</th><th>Match</th><th>+Prom</th><th>-Demo</th><th>Status</th></tr>';
  for(const ps of g.posStats){const st=ps.contested?'<span style="color:var(--red)">contested</span>':'<span style="color:var(--green)">stable</span>';ptH+=`<tr><td>${ps.pos}</td><td>${escHtml(ps.token)}</td><td>${ps.nMatched}</td><td>${ps.nPromoted}</td><td>${ps.nDemoted}</td><td>${st}</td></tr>`}
  ptH+='</table></div>';
  let dH='';if(g.dualRole.length>0){dH='<div style="margin-bottom:14px"><div style="font-size:12px;font-weight:600;color:var(--purple);margin-bottom:8px">DUAL-ROLE CANDIDATES</div>';for(const dr of g.dualRole){if(dr.token.trim()==='')continue;const pc=dr.promotedAt.map(x=>'<span style="color:var(--green)">pos '+x.pos+'</span> <span style="color:var(--text-3)">('+escHtml(x.tok)+')</span>').join(', ');const dc=dr.demotedAt.map(x=>'<span style="color:var(--red)">pos '+x.pos+'</span> <span style="color:var(--text-3)">('+escHtml(x.tok)+')</span>').join(', ');dH+=`<div style="margin-bottom:8px;padding:6px 8px;background:var(--bg-2);border-radius:4px;border-left:3px solid var(--purple)"><div style="font-family:var(--mono);font-size:11px;font-weight:600;color:var(--text-0)">"${escHtml(dr.token)}"</div><div style="font-size:11px;margin-top:4px">↑ promoted: ${pc}</div><div style="font-size:11px;margin-top:3px">↓ demoted: ${dc}</div>${dr.matchedAt.length?'<div style="font-size:11px;margin-top:3px;color:var(--text-3)">= matched: '+dr.matchedAt.length+' positions</div>':''}</div>`}dH+='</div>'}
  let sH='';if(g.roleSwitches.length>0){sH='<div style="margin-bottom:14px"><div style="font-size:12px;font-weight:600;color:var(--orange);margin-bottom:8px">ROLE SWITCHES</div><div style="max-height:180px;overflow-y:auto"><table class="data-table"><tr><th>Candidate</th><th>From</th><th>→</th><th>To</th></tr>';for(const sw of g.roleSwitches.slice(0,20)){const fc=sw.fromRole==='promoted'?'var(--green)':(sw.fromRole==='demoted'?'var(--red)':'var(--text-2)');const tc=sw.toRole==='promoted'?'var(--green)':(sw.toRole==='demoted'?'var(--red)':'var(--text-2)');sH+=`<tr><td style="font-family:var(--mono)">"${escHtml(sw.candidate)}"</td><td><span style="color:${fc}">${sw.fromRole}</span> <span style="color:var(--text-3)">at ${sw.fromPos} (${escHtml(sw.fromTok)})</span></td><td style="color:var(--text-3)">→</td><td><span style="color:${tc}">${sw.toRole}</span> <span style="color:var(--text-3)">at ${sw.toPos} (${escHtml(sw.toTok)})</span></td></tr>`}sH+='</table></div></div>'}
  let tH='';const topT=g.trajectories.filter(t=>t.nAppearances>=2).slice(0,8);if(topT.length>0){tH='<div style="margin-bottom:14px"><div style="font-size:12px;font-weight:600;color:var(--cyan);margin-bottom:8px">CANDIDATE TRAJECTORIES</div>';for(const tr of topT){const lb=tr.isDualRole?' <span style="color:var(--purple);font-size:11px;font-weight:600">DUAL</span>':'';tH+=`<div style="margin-bottom:8px;padding:6px 8px;background:var(--bg-2);border-radius:4px"><div style="font-family:var(--mono);font-size:12px;font-weight:600;color:var(--text-0)">"${escHtml(tr.candidate)}" <span style="color:var(--text-3);font-weight:400">${tr.nAppearances} pos</span>${lb}</div><div style="display:flex;flex-wrap:wrap;gap:4px;margin-top:4px">`;for(const p of tr.positions){const rc=p.role==='promoted'?'var(--green)':(p.role==='demoted'?'var(--red)':'var(--text-2)');const rs=p.role==='promoted'?'↑':(p.role==='demoted'?'↓':'=');const ip=p.inst?(p.inst.prob*100).toFixed(1)+'%':'—';const bp=p.base?(p.base.prob*100).toFixed(1)+'%':'—';tH+=`<span style="font-size:11px;padding:3px 6px;background:var(--bg-1);border-radius:3px;border:1px solid var(--border)" title="inst:${ip} base:${bp}"><span style="color:${rc}">${rs}</span> <span style="color:var(--text-1)">${p.pos}:${escHtml(p.tok)}</span></span>`}tH+='</div></div>'}tH+='</div>'}
  return`<div style="margin-top:16px;padding-top:14px;border-top:2px solid var(--purple)"><div style="display:flex;align-items:center;gap:8px;margin-bottom:12px"><div style="font-family:var(--mono);font-size:14px;font-weight:600;color:var(--purple)">Candidate Graph</div><button class="btn-popout" onclick="popoutCandidateGraph('${uid}')" title="Full graph in new window">↗ Pop out</button></div><div id="${uid}">${mapH}${mH}<div class="feature" style="border-color:var(--purple)"><div class="feature-header" onclick="toggleFeature(this)"><div class="feature-title" style="color:var(--purple)">Position Detail</div><p class="feature-desc">Per-token contested status. Contested = both models swapping candidates at this position.</p></div><div class="feature-body collapsed" style="padding:10px">${ptH}</div></div>${dH}${sH}${tH}</div></div>`
}
function popoutCandidateGraph(uid){
  const el=document.getElementById(uid);if(!el)return;
  const pw=1000,ph=850,left=Math.round((screen.width-pw)/2),top=Math.round((screen.height-ph)/2);
  const w=window.open('','_blank',`width=${pw},height=${ph},left=${left},top=${top},scrollbars=yes`);if(!w)return;
  const styles=Array.from(document.querySelectorAll('style,link[rel="stylesheet"]')).map(s=>s.outerHTML).join('\n');
  w.document.write(`<!DOCTYPE html><html><head><title>TAGM — Candidate Graph</title><link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap" rel="stylesheet">${styles}<style>body{background:var(--bg-0);color:var(--text-1);font-family:var(--sans);padding:20px;margin:0}.feature-body.collapsed{display:block!important}</style></head><body><div style="max-width:960px;margin:0 auto">${el.outerHTML}</div></body></html>`);
  w.document.close();
}

function _computeGraphsChunked(results){
  // Build graph objects from server pre-computed candidate_graph summaries
  var graphs=[];
  for(var i=0;i<results.length;i++){
    var r=results[i];
    var cg=r.candidate_graph;
    if(!cg)continue;
    cg.category=r.category||'unknown';
    cg.prompt=r.prompt||'';
    cg.contestedFrac=cg.contested_frac||0;
    cg.nDualRole=cg.n_dual_role||0;
    cg.nRoleSwitches=cg.n_role_switches||0;
    cg.switchRate=cg.switch_rate||0;
    cg.nMultiPosition=cg.n_multi_position||0;
    cg.nUniqueCandidates=cg.n_unique_candidates||0;
    cg.nPositions=cg.n_positions||0;
    cg.posStats=[];
    var cmap=cg.contest_map||'';
    for(var j=0;j<cmap.length;j++){
      var ch=cmap[j];
      cg.posStats.push({contested:ch!=='.',intensity:ch==='H'?6:(ch==='M'?3:1)});
    }
    graphs.push(cg);
  }
  return _buildCandidateGraphAggregateFromGraphs(graphs);
}

function _buildCandidateGraphAggregateFromGraphs(graphs){
  if(graphs.length<2)return'';

  // Group by category
  var catOrder=['benign','dual-use','mild','harmful','adversarial','jailbreak'];
  var catGraphs={};catOrder.forEach(function(c){catGraphs[c]=[]});
  graphs.forEach(function(g){if(catGraphs[g.category])catGraphs[g.category].push(g);else{if(!catGraphs['unknown'])catGraphs['unknown']=[];catGraphs['unknown'].push(g)}});

  // Helper: mean and std
  function stats(arr){
    if(!arr.length)return{mean:0,std:0,n:0};
    var m=arr.reduce(function(a,v){return a+v},0)/arr.length;
    var v=arr.reduce(function(a,v){return a+(v-m)*(v-m)},0)/arr.length;
    return{mean:m,std:Math.sqrt(v),n:arr.length};
  }

  // Cohen's d
  function cohend(a,b){
    var sa=stats(a),sb=stats(b);
    if(sa.n<2||sb.n<2)return 0;
    var pooled=Math.sqrt((sa.std*sa.std+sb.std*sb.std)/2);
    return pooled>0?Math.abs(sa.mean-sb.mean)/pooled:0;
  }

  // ── Category summary table ──
  var tblS='';
  tblS+='<table style="width:100%;border-collapse:collapse;font-family:var(--mono);font-size:11px">';
  tblS+='<tr style="border-bottom:1px solid rgba(255,255,255,0.12)">';
  tblS+='<th style="text-align:left;padding:8px 10px;color:#e6edf3">Category</th>';
  tblS+='<th style="text-align:right;padding:8px 6px;color:#e6edf3">N</th>';
  tblS+='<th style="text-align:right;padding:8px 6px;color:#e6edf3">Contested %</th>';
  tblS+='<th style="text-align:right;padding:8px 6px;color:#e6edf3">Dual-Role</th>';
  tblS+='<th style="text-align:right;padding:8px 6px;color:#e6edf3">Switches</th>';
  tblS+='<th style="text-align:right;padding:8px 6px;color:#e6edf3">Sw/token</th>';
  tblS+='<th style="text-align:right;padding:8px 6px;color:#e6edf3">Unique Cands</th>';
  tblS+='</tr>';

  var catColors={benign:'#3fb950','dual-use':'#009E73',mild:'#58a6ff',harmful:'#d29a22',adversarial:'#882255',jailbreak:'#f85149'};

  catOrder.forEach(function(cat){
    var gs=catGraphs[cat];if(!gs.length)return;
    var cf=stats(gs.map(function(g){return g.contestedFrac}));
    var dr=stats(gs.map(function(g){return g.nDualRole}));
    var sw=stats(gs.map(function(g){return g.nRoleSwitches}));
    var sr=stats(gs.map(function(g){return g.switchRate}));
    var uc=stats(gs.map(function(g){return g.nUniqueCandidates}));
    var cc=catColors[cat]||'#b1bac4';

    tblS+='<tr style="border-bottom:1px solid rgba(255,255,255,0.06)">';
    tblS+='<td style="padding:6px 10px"><span style="color:'+cc+';font-weight:600">'+cat+'</span></td>';
    tblS+='<td style="text-align:right;padding:6px;color:#b1bac4">'+gs.length+'</td>';
    tblS+='<td style="text-align:right;padding:6px;color:#e6edf3;font-weight:600">'+(cf.mean*100).toFixed(1)+'%<span style="color:var(--text-1);font-weight:400"> ±'+(cf.std*100).toFixed(1)+'</span></td>';
    tblS+='<td style="text-align:right;padding:6px;color:#e6edf3">'+dr.mean.toFixed(1)+'<span style="color:var(--text-1)"> ±'+dr.std.toFixed(1)+'</span></td>';
    tblS+='<td style="text-align:right;padding:6px;color:#e6edf3">'+sw.mean.toFixed(1)+'<span style="color:var(--text-1)"> ±'+sw.std.toFixed(1)+'</span></td>';
    tblS+='<td style="text-align:right;padding:6px;color:#e6edf3">'+sr.mean.toFixed(3)+'</td>';
    tblS+='<td style="text-align:right;padding:6px;color:#b1bac4">'+uc.mean.toFixed(0)+'</td>';
    tblS+='</tr>';
  });
  tblS+='</table>';

  // ── Effect sizes ──
  var benignGraphs=catGraphs['benign']||[];
  var jailGraphs=catGraphs['jailbreak']||[];
  var effH='';
  if(benignGraphs.length>=2&&jailGraphs.length>=2){
    var metrics=[
      {name:'Contested %',fn:function(g){return g.contestedFrac}},
      {name:'Switch rate',fn:function(g){return g.switchRate}},
      {name:'Dual-role count',fn:function(g){return g.nDualRole}},
      {name:'Role switches',fn:function(g){return g.nRoleSwitches}},
      {name:'Multi-pos cands',fn:function(g){return g.nMultiPosition}},
    ];
    var effRows='';
    metrics.forEach(function(m){
      var bVals=benignGraphs.map(m.fn),jVals=jailGraphs.map(m.fn);
      var d=cohend(bVals,jVals);
      var bm=stats(bVals),jm=stats(jVals);
      var dir=jm.mean>bm.mean?'↑':'↓';
      var barW=Math.min(d/3*100,100);
      var barCol=d>1.5?'#3fb950':(d>0.8?'#58a6ff':(d>0.5?'#d29a22':'#8b949e'));

      effRows+='<tr style="border-bottom:1px solid rgba(255,255,255,0.06)">';
      effRows+='<td style="padding:5px 10px;color:#e6edf3">'+m.name+'</td>';
      effRows+='<td style="padding:5px 6px;text-align:right;color:#b1bac4">'+bm.mean.toFixed(3)+'</td>';
      effRows+='<td style="padding:5px 6px;text-align:right;color:#b1bac4">'+jm.mean.toFixed(3)+'</td>';
      effRows+='<td style="padding:5px 6px;text-align:right;font-weight:600;color:'+barCol+'">'+d.toFixed(2)+' '+dir+'</td>';
      effRows+='<td style="padding:5px 6px;width:120px"><div style="width:100%;height:8px;background:rgba(255,255,255,0.06);border-radius:4px"><div style="width:'+barW+'%;height:100%;background:'+barCol+';border-radius:4px"></div></div></td>';
      effRows+='</tr>';
    });

    effH='<div style="margin-top:16px"><div style="font-size:11px;font-weight:600;color:#e6edf3;margin-bottom:8px">Separation Power (benign vs jailbreak)</div>';
    effH+='<table style="width:100%;border-collapse:collapse;font-family:var(--mono);font-size:11px">';
    effH+='<tr style="border-bottom:1px solid rgba(255,255,255,0.12)"><th style="text-align:left;padding:5px 10px;color:var(--text-1)">Metric</th><th style="text-align:right;padding:5px 6px;color:#3fb950">Benign</th><th style="text-align:right;padding:5px 6px;color:#f85149">Jailbreak</th><th style="text-align:right;padding:5px 6px;color:var(--text-1)">Cohen\'s d</th><th style="padding:5px 6px;color:var(--text-1)"></th></tr>';
    effH+=effRows+'</table></div>';
  }

  // ── Cross-prompt candidate frequency (requires raw data — skip for server summaries) ──
  var hasRawData=graphs.some(function(g){return g.candidates&&typeof g.candidates==='object'&&Object.keys(g.candidates).length>0});
  var candH='';
  if(hasRawData){
    var candFreq={};
    graphs.forEach(function(g){
      if(!g.candidates)return;
      for(var t in g.candidates){
        var c=g.candidates[t];
        if(!candFreq[t])candFreq[t]={promoted:0,demoted:0,matched:0,dual:0,prompts:0,categories:{}};
        var cf=candFreq[t];
        cf.prompts++;
        cf.promoted+=c.promoted.length;
        cf.demoted+=c.demoted.length;
        cf.matched+=c.matched.length;
        if(c.promoted.length>0&&c.demoted.length>0)cf.dual++;
        cf.categories[g.category]=(cf.categories[g.category]||0)+1;
      }
    });

  // Most contested: highest (promoted+demoted) / total appearances
  var candList=[];
  for(var t in candFreq){
    var cf=candFreq[t];
    if(cf.prompts<2)continue;// skip single-prompt
    var contestRatio=(cf.promoted+cf.demoted)/(cf.promoted+cf.demoted+cf.matched+0.001);
    candList.push({token:t,label:t.trim()||'⎵',freq:cf,contestRatio:contestRatio});
  }
  candList.sort(function(a,b){return b.freq.dual-a.freq.dual||(b.contestRatio-a.contestRatio)});

  var candH='';
  if(candList.length>0){
    candH='<div style="margin-top:16px"><div style="font-size:11px;font-weight:600;color:#e6edf3;margin-bottom:8px">Most Contested Candidates (across all prompts)</div>';
    candH+='<table style="width:100%;border-collapse:collapse;font-family:var(--mono);font-size:11px">';
    candH+='<tr style="border-bottom:1px solid rgba(255,255,255,0.12)"><th style="text-align:left;padding:5px 10px;color:var(--text-1)">Token</th><th style="text-align:right;padding:5px 6px;color:var(--text-1)">Prompts</th><th style="text-align:right;padding:5px 6px;color:#3fb950">+Prom</th><th style="text-align:right;padding:5px 6px;color:#f85149">-Demo</th><th style="text-align:right;padding:5px 6px;color:#58a6ff">=Match</th><th style="text-align:right;padding:5px 6px;color:#bc8cff">Dual</th><th style="text-align:left;padding:5px 6px;color:var(--text-1)">Categories</th></tr>';
    var shown=0;
    for(var ci=0;ci<candList.length&&shown<15;ci++){
      var cl=candList[ci];
      if(cl.label==='⎵')continue;// skip EOS
      var catStr=catOrder.filter(function(c){return cl.freq.categories[c]}).map(function(c){
        return '<span style="color:'+catColors[c]+'">'+c.substr(0,3)+':'+cl.freq.categories[c]+'</span>';
      }).join(' ');
      candH+='<tr style="border-bottom:1px solid rgba(255,255,255,0.04)">';
      candH+='<td style="padding:4px 10px;color:#e6edf3;font-weight:600">"'+escHtml(cl.label)+'"</td>';
      candH+='<td style="text-align:right;padding:4px 6px;color:#b1bac4">'+cl.freq.prompts+'</td>';
      candH+='<td style="text-align:right;padding:4px 6px;color:#3fb950">'+cl.freq.promoted+'</td>';
      candH+='<td style="text-align:right;padding:4px 6px;color:#f85149">'+cl.freq.demoted+'</td>';
      candH+='<td style="text-align:right;padding:4px 6px;color:#58a6ff">'+cl.freq.matched+'</td>';
      candH+='<td style="text-align:right;padding:4px 6px;color:'+(cl.freq.dual>0?'#bc8cff':'#8b949e')+'">'+cl.freq.dual+'</td>';
      candH+='<td style="padding:5px 8px;font-size:11px">'+catStr+'</td>';
      candH+='</tr>';
      shown++;
    }
    candH+='</table></div>';
  }
  } // end hasRawData

  // ── Per-prompt breakdown ──
  var promptH='<div style="margin-top:16px"><div style="font-size:11px;font-weight:600;color:#e6edf3;margin-bottom:8px">Per-Prompt Candidate Graph Metrics</div>';
  promptH+='<div style="max-height:300px;overflow-y:auto">';
  promptH+='<table style="width:100%;border-collapse:collapse;font-family:var(--mono);font-size:11px">';
  promptH+='<tr style="border-bottom:1px solid rgba(255,255,255,0.12);position:sticky;top:0;background:var(--bg-1)"><th style="text-align:left;padding:4px 8px;color:var(--text-1)">Prompt</th><th style="text-align:left;padding:4px 4px;color:var(--text-1)">Cat</th><th style="text-align:right;padding:4px 4px;color:var(--text-1)">Contest</th><th style="text-align:right;padding:4px 4px;color:var(--text-1)">Dual</th><th style="text-align:right;padding:4px 4px;color:var(--text-1)">Sw/tok</th><th style="padding:4px 4px;color:var(--text-1);width:80px">Map</th></tr>';

  // Sort by contested fraction descending
  var sorted=graphs.slice().sort(function(a,b){return b.contestedFrac-a.contestedFrac});
  sorted.forEach(function(g){
    var cc=catColors[g.category]||'#b1bac4';
    var cfCol=g.contestedFrac>0.85?'#f85149':(g.contestedFrac>0.7?'#d29a22':'#3fb950');
    // Build mini contestation map
    var miniMap='';
    for(var i=0;i<g.posStats.length;i++){
      var ps=g.posStats[i];
      if(!ps.contested)miniMap+='<span style="color:#333">·</span>';
      else if(ps.intensity>=6)miniMap+='<span style="color:#f85149">▓</span>';
      else if(ps.intensity>=3)miniMap+='<span style="color:#d29a22">▒</span>';
      else miniMap+='<span style="color:var(--text-1)">░</span>';
    }
    promptH+='<tr style="border-bottom:1px solid rgba(255,255,255,0.03)">';
    promptH+='<td style="padding:3px 8px;color:#b1bac4;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="'+escHtml(g.prompt)+'">'+escHtml(g.prompt.substr(0,40))+'</td>';
    promptH+='<td style="padding:3px 4px;color:'+cc+'">'+g.category.substr(0,4)+'</td>';
    promptH+='<td style="text-align:right;padding:3px 4px;color:'+cfCol+';font-weight:600">'+(g.contestedFrac*100).toFixed(0)+'%</td>';
    promptH+='<td style="text-align:right;padding:3px 4px;color:#b1bac4">'+g.nDualRole+'</td>';
    promptH+='<td style="text-align:right;padding:3px 4px;color:#b1bac4">'+g.switchRate.toFixed(2)+'</td>';
    promptH+='<td style="padding:3px 4px;font-family:var(--mono);font-size:11px;letter-spacing:0.5px">'+miniMap+'</td>';
    promptH+='</tr>';
  });
  promptH+='</table></div></div>';

  // ── Assemble ──
  var h='<div class="feature" style="border-color:var(--purple);margin-top:16px">';
  h+='<div class="feature-header" onclick="toggleFeature(this)">';
  h+='<div class="feature-title" style="color:#bc8cff">Candidate Graph Topology</div>';
  h+='<p class="feature-desc" style="color:#b1bac4">Cross-prompt analysis of alignment decision stability. Contested = both models swapping candidates at that position. Dual-role = same token promoted at some positions, demoted at others. Switch rate = role changes per token.</p>';
  h+='</div>';
  h+='<div class="feature-body" style="padding:16px">';
  h+=tblS+effH+candH+promptH;
  h+='</div></div>';
  return h;
}

// ─── Module Framework ──────────────────────────────────────────

var _moduleData = {};  // cached module metadata
var _modulePollers = {};  // active polling intervals

async function loadModules() {
  try {
    const r = await fetch('/api/modules');
    const d = await r.json();
    if (!d.ok) { $('modulesContainer').innerHTML = '<div class="error-msg">Failed to load modules</div>'; return; }
    $('modulesLoading').style.display = 'none';
    renderModules(d.modules);
  } catch(e) {
    $('modulesLoading').textContent = 'Failed to load modules: ' + e.message;
  }
}

function renderModules(modules) {
  if (!modules.length) {
    $('modulesContainer').innerHTML = '<div style="padding:20px;color:var(--text-3);font-family:var(--mono);font-size:12px">No modules discovered. Place module files in engine/modules/</div>';
    return;
  }
  var h = '';
  modules.forEach(function(m) {
    _moduleData[m.name] = m;
    h += renderModuleCard(m);
  });
  $('modulesContainer').innerHTML = h;

  // Resume polling for any running modules
  modules.forEach(function(m) {
    if (m.status === 'running') startModulePoll(m.name);
    if (m.has_results) fetchModuleResults(m.name);
  });
}

function renderModuleCard(m) {
  var h = '<div class="mod-card" id="mod-' + m.name + '">';

  var modCollapsed = CARD_COLLAPSE_DEFAULTS.modules === 'collapsed';
  var chevSymbol = modCollapsed ? '▶' : '▼';
  var bodyStyle = modCollapsed ? ' style="display:none"' : '';

  // Collapsible header - click to toggle body
  h += '<div class="mod-header" onclick="toggleModCard(\'' + m.name + '\')" style="cursor:pointer">';
  h += '<div class="mod-info">';
  h += '<div class="mod-title"><span class="mod-chevron" id="mod-chev-' + m.name + '" style="font-size:11px;color:var(--text-2);flex-shrink:0">' + chevSymbol + '</span> ' + escHtml(m.display_name) + ' <span class="mod-ver">v' + m.version + '</span></div>';
  h += '<div class="mod-desc">' + escHtml(m.description) + '</div>';
  h += '</div>';
  h += '<div class="mod-status ' + m.status + '" id="mod-status-' + m.name + '">' + m.status + '</div>';
  h += '</div>';

  // Collapsible body
  h += '<div class="mod-body" id="mod-body-' + m.name + '"' + bodyStyle + '>';

  // Requirements
  var reqs = [];
  if (m.requires_sfd) reqs.push('SFD');
  if (m.requires_ltp) reqs.push('LTP');
  if (m.requires_rd) reqs.push('RD');
  if (reqs.length || m.min_results > 1) {
    h += '<div style="padding:6px 16px 0;display:flex;gap:6px;flex-wrap:wrap">';
    if (m.min_results > 1) h += '<span class="mod-req">' + m.min_results + '+ results</span>';
    reqs.forEach(function(r) { h += '<span class="mod-req">' + r + '</span>'; });
    h += '</div>';
  }

  // Parameters
  if (m.parameters && m.parameters.length) {
    h += '<div class="mod-params">';
    m.parameters.forEach(function(p) {
      h += '<div class="mod-param">';
      h += '<label>' + escHtml(p.display_name) + '</label>';
      h += renderParamControl(m.name, p);
      if (p.description) h += '<div class="param-desc">' + escHtml(p.description) + '</div>';
      h += '</div>';
    });
    h += '</div>';
  }

  // Actions
  h += '<div class="mod-actions">';
  h += '<button class="btn btn-primary btn-sm" id="mod-run-' + m.name + '" onclick="event.stopPropagation();runModule(\'' + m.name + '\')">Run</button>';
  h += '<button class="btn btn-sm" style="border:1px solid var(--border);color:var(--text-2);background:transparent" title="Clear results and restore all parameters to defaults" onclick="event.stopPropagation();resetModule(\'' + m.name + '\')">Reset Defaults</button>';
  h += '<div class="mod-progress" id="mod-progress-' + m.name + '"></div>';
  h += '</div>';

  // Results placeholder
  h += '<div id="mod-results-' + m.name + '"></div>';

  h += '</div>'; // end mod-body
  h += '</div>'; // end mod-card
  return h;
}

function toggleModCard(name) {
  var body = $('mod-body-' + name);
  var chev = $('mod-chev-' + name);
  if (!body) return;
  if (body.style.display === 'none') {
    body.style.display = '';
    if (chev) chev.textContent = '▼';
  } else {
    body.style.display = 'none';
    if (chev) chev.textContent = '▶';
  }
}

function renderParamControl(modName, p) {
  var id = 'modp-' + modName + '-' + p.name;
  if (p.type === 'bool') {
    var checked = p.default ? ' checked' : '';
    return '<div class="checkbox-row" style="margin-top:3px"><input type="checkbox" id="' + id + '"' + checked + '><label for="' + id + '">Enable</label></div>';
  }
  if (p.type === 'select') {
    var s = '<select id="' + id + '">';
    p.options.forEach(function(o) {
      var sel = o === p.default ? ' selected' : '';
      s += '<option value="' + o + '"' + sel + '>' + o + '</option>';
    });
    s += '</select>';
    return s;
  }
  if (p.type === 'int' || p.type === 'float') {
    var step = p.type === 'float' ? '0.01' : '1';
    var minA = p.min_val != null ? ' min="' + p.min_val + '"' : '';
    var maxA = p.max_val != null ? ' max="' + p.max_val + '"' : '';
    return '<input type="number" id="' + id + '" value="' + p.default + '" step="' + step + '"' + minA + maxA + ' style="width:80px">';
  }
  if (p.type === 'file') {
    return '<div class="file-input-wrapper"><input type="file" id="' + id + '" accept=".csv" data-param-type="file"></div>';
  }
  if (p.type === 'textarea') {
    var val = (p.default || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    return '<textarea id="' + id + '" rows="4" style="width:100%;resize:vertical;font-size:11px;line-height:1.5">' + val + '</textarea>';
  }
  return '<input type="text" id="' + id + '" value="' + (p.default || '') + '">';
}

function getModuleParams(modName) {
  var m = _moduleData[modName];
  if (!m || !m.parameters) return {};
  var params = {};
  m.parameters.forEach(function(p) {
    var el = $('modp-' + modName + '-' + p.name);
    if (!el) { params[p.name] = p.default; return; }
    if (p.type === 'bool') params[p.name] = el.checked;
    else if (p.type === 'file') params[p.name] = '';  // resolved by upload in runModule
    else if (p.type === 'int') { var v = parseInt(el.value); params[p.name] = isNaN(v) ? p.default : v; }
    else if (p.type === 'float') { var v = parseFloat(el.value); params[p.name] = isNaN(v) ? p.default : v; }
    else params[p.name] = el.value;
  });
  return params;
}

async function resetModule(name) {
  try {
    var r = await fetch('/api/modules/' + name + '/reset', {method: 'POST'});
    var d = await r.json();
    if (d.ok) {
      var st = $('mod-status-' + name);
      if (st) { st.className = 'mod-status idle'; st.textContent = 'idle'; }
      var pr = $('mod-progress-' + name);
      if (pr) pr.textContent = '';
      var res = $('mod-results-' + name);
      if (res) res.innerHTML = '';
      var btn = $('mod-run-' + name);
      if (btn) btn.disabled = false;
      // Remove download log button
      var logBtn = $('mod-log-' + name);
      if (logBtn) logBtn.remove();
      // Reset params to defaults
      var m = _moduleData[name];
      if (m && m.parameters) {
        m.parameters.forEach(function(p) {
          var el = $('modp-' + name + '-' + p.name);
          if (!el) return;
          if (p.type === 'bool') el.checked = !!p.default;
          else if (p.type === 'file') el.value = '';
          else if (p.type === 'textarea') el.value = p.default || '';
          else el.value = p.default != null ? p.default : '';
        });
      }
    }
  } catch(e) {
    console.error('Reset failed:', e);
  }
}

async function runModule(name) {
  var btn = $('mod-run-' + name);
  var prog = $('mod-progress-' + name);
  btn.disabled = true;
  btn.textContent = 'Running...';
  prog.textContent = 'Starting...';
  // Remove stale download log button
  var oldLog = $('mod-log-' + name);
  if (oldLog) oldLog.remove();

  var params = getModuleParams(name);

  // Upload any file params first
  try {
    var fileInputs = document.querySelectorAll('[data-param-type="file"]');
    for (var i = 0; i < fileInputs.length; i++) {
      var fi = fileInputs[i];
      if (fi.id.startsWith('modp-' + name + '-') && fi.files && fi.files.length > 0) {
        var paramName = fi.id.replace('modp-' + name + '-', '');
        prog.textContent = 'Uploading ' + fi.files[0].name + '...';
        var fd = new FormData();
        fd.append('file', fi.files[0]);
        var ur = await fetch('/api/modules/upload_template', {method:'POST', body:fd});
        var ud = await ur.json();
        if (!ud.ok) { throw new Error(ud.error || 'Upload failed'); }
        params[paramName] = ud.filename;
      }
    }
  } catch(e) {
    prog.textContent = '';
    btn.disabled = false;
    btn.textContent = 'Run';
    alert('Upload error: ' + e.message);
    return;
  }

  try {
    const r = await fetch('/api/modules/' + name + '/run', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({params: params})
    });
    const d = await r.json();
    if (!d.ok) {
      prog.textContent = '';
      btn.disabled = false;
      btn.textContent = 'Run';
      updateModuleStatus(name, 'error');
      alert(d.error || 'Module failed to start');
      return;
    }
    updateModuleStatus(name, 'running');
    startModulePoll(name);
  } catch(e) {
    prog.textContent = '';
    btn.disabled = false;
    btn.textContent = 'Run';
    alert('Error: ' + e.message);
  }
}

function startModulePoll(name) {
  if (_modulePollers[name]) clearInterval(_modulePollers[name]);
  _modulePollers[name] = setInterval(function() { pollModule(name); }, 500);
}

async function pollModule(name) {
  try {
    const r = await fetch('/api/modules/' + name + '/status');
    const d = await r.json();
    var prog = $('mod-progress-' + name);
    if (prog) prog.textContent = d.progress || '';

    if (d.status === 'completed') {
      clearInterval(_modulePollers[name]);
      delete _modulePollers[name];
      updateModuleStatus(name, 'completed');
      playChime();
      var btn = $('mod-run-' + name);
      if (btn) { btn.disabled = false; btn.textContent = 'Re-run'; }
      if (prog) {
        var elapsed = d.completed_at && d.started_at ? (d.completed_at - d.started_at).toFixed(1) : '?';
        prog.textContent = 'Completed in ' + elapsed + 's';
      }
      // Show download log button
      if (d.has_log) {
        var existing = $('mod-log-' + name);
        if (!existing) {
          var logBtn = document.createElement('button');
          logBtn.id = 'mod-log-' + name;
          logBtn.className = 'btn btn-sm';
          logBtn.style.cssText = 'border:1px solid var(--border);color:var(--text-2);background:transparent;cursor:pointer';
          logBtn.textContent = 'Download Log';
          logBtn.onclick = function(e) { e.stopPropagation(); window.open('/api/modules/' + name + '/download_log', '_blank'); };
          if (btn && btn.parentNode) btn.parentNode.insertBefore(logBtn, btn.nextSibling);
        }
      }
      fetchModuleResults(name);
    } else if (d.status === 'error') {
      clearInterval(_modulePollers[name]);
      delete _modulePollers[name];
      updateModuleStatus(name, 'error');
      var btn2 = $('mod-run-' + name);
      if (btn2) { btn2.disabled = false; btn2.textContent = 'Retry'; }
      if (prog) prog.textContent = 'Error: ' + (d.error || 'unknown');
    }
  } catch(e) { /* silent retry */ }
}

function updateModuleStatus(name, status) {
  var el = $('mod-status-' + name);
  if (!el) return;
  el.className = 'mod-status ' + status;
  el.textContent = status;
}

async function fetchModuleResults(name) {
  try {
    const r = await fetch('/api/modules/' + name + '/results');
    const d = await r.json();
    if (!d.ok) return;
    renderModuleResults(name, d.results);
  } catch(e) { /* silent */ }
}

function renderModuleResults(name, results) {
  var container = $('mod-results-' + name);
  if (!container) return;

  // Route to module-specific renderer
  if (name === 'token_variance') {
    container.innerHTML = renderTokenVarianceResults(results);
  } else if (name === 'domain_surface') {
    _dsSurfaceData = results;
    container.innerHTML = renderDomainSurfaceResults(results);
  } else if (name === 'correction_manifold') {
    container.innerHTML = renderCorrectionManifoldResults(results);
  } else if (name === 'probe_generator') {
    container.innerHTML = renderProbeGeneratorResults(results);
  } else if (name === 'correction_heatmap') {
    container.innerHTML = renderCorrectionHeatmapResults(results);
  } else if (name === 'correction_backscatter') {
    container.innerHTML = renderCorrectionBackscatterResults(results);
  } else if (name === 'mechanistic_interpretability') {
    container.innerHTML = renderMIResults(results);
  } else if (name === 'correction_field_topology') {
    container.innerHTML = renderCFTResults(results);
  } else if (name === 'comparative_analysis') {
    container.innerHTML = renderComparativeResults(results);
  } else if (name === 'mi_instrumentation') {
    container.innerHTML = renderMIInstrumentationResults(results);
  } else if (name === 'model_dialogue') {
    container.innerHTML = renderModelDialogueResults(results);
    // Auto-open chat window when Run completes
    if (results && results.chat_url) popoutChat();
  } else {
    // Generic JSON dump fallback
    container.innerHTML = '<div class="mod-results"><div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Results</div><div class="mod-results-body"><pre style="padding:12px;font-size:11px;color:var(--text-1);overflow:auto;max-height:400px">' + escHtml(JSON.stringify(results, null, 2).substring(0, 5000)) + '</pre></div></div>';
  }
}

// ─── Model Dialogue Results Renderer ────────────────────────────

function renderModelDialogueResults(r) {
  var cfg = r.config || {};
  var h = '<div class="mod-results">';
  h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">';
  h += 'Chat Configuration';
  h += '<button class="btn-popout" style="margin-left:auto" onclick="event.stopPropagation();popoutChat()">↗ Open Chat</button>';
  h += '</div>';
  h += '<div class="mod-results-body">';
  h += '<table style="font-size:12px;border-collapse:collapse;width:100%">';
  h += '<tr><td style="padding:4px 12px;color:var(--text-2)">Temperature</td><td style="padding:4px 12px;font-weight:600">' + (cfg.temperature || 0.7) + '</td>';
  h += '<td style="padding:4px 12px;color:var(--text-2)">Top-P</td><td style="padding:4px 12px;font-weight:600">' + (cfg.top_p || 0.9) + '</td>';
  h += '<td style="padding:4px 12px;color:var(--text-2)">Max Tokens</td><td style="padding:4px 12px;font-weight:600">' + (cfg.max_tokens || 256) + '</td></tr>';
  h += '<tr><td style="padding:4px 12px;color:var(--text-2)">Analyze Prompts</td><td style="padding:4px 12px;font-weight:600">' + (cfg.analyze_prompts ? '✓' : '—') + '</td>';
  h += '<td style="padding:4px 12px;color:var(--text-2)">Analyze Responses</td><td style="padding:4px 12px;font-weight:600">' + (cfg.analyze_responses ? '✓' : '—') + '</td>';
  h += '<td style="padding:4px 12px;color:var(--text-2)">LTP / SFD</td><td style="padding:4px 12px;font-weight:600">' + (cfg.compute_ltp ? 'LTP' : '') + (cfg.compute_ltp && cfg.compute_sfd ? ' + ' : '') + (cfg.compute_sfd ? 'SFD' : '') + '</td></tr>';
  h += '</table>';
  h += '<div style="margin-top:10px;padding:8px;background:var(--bg-0);border-radius:4px;font-size:11px;color:var(--text-2)">';
  h += 'Click <strong>Open Chat</strong> to launch the dialogue window. ';
  h += 'Each conversation turn is analyzed under the current configuration and recorded into the session. ';
  h += 'Switch between instruct and base models using the toggle in the chat window.';
  h += '</div>';
  h += '</div></div>';
  return h;
}

function popoutChat() {
  var pw = 640, ph = 720;
  var left = Math.round((screen.width - pw) / 2);
  var top = Math.round((screen.height - ph) / 2);
  window.open('/chat', '_blank', 'width=' + pw + ',height=' + ph + ',left=' + left + ',top=' + top + ',scrollbars=yes');
}

// ─── Token Variance Results Renderer ───────────────────────────

function renderTokenVarianceResults(r) {
  var s = r.summary;
  var h = '<div class="mod-results">';

  // Summary stats
  h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Summary</div>';
  h += '<div class="mod-results-body">';
  h += '<div class="mod-summary">';
  h += tvStat('Prompts', s.n_prompts, s.n_skipped + ' skipped');
  h += tvStat('Tokens Analyzed', s.n_tokens_analyzed, s.n_qualified + ' qualified (n≥' + (s.qualified_threshold||3) + ')');
  h += tvStat('Categories', s.categories ? s.categories.length : 0, s.categories ? s.categories.join(', ') : '');
  if (s.density_cv) {
    h += tvStat('Density CV (p50)', s.density_cv.p50.toFixed(4), 'p25=' + s.density_cv.p25.toFixed(4) + ' p75=' + s.density_cv.p75.toFixed(4));
    h += tvStat('Density η²', s.density_cv.eta_sq_mean.toFixed(4), 'median ' + s.density_cv.eta_sq_median.toFixed(4));
  }
  if (s.context_stable) {
    h += tvStat('Context-Stable', s.context_stable.count, 'CV ≤ ' + s.context_stable.threshold.toFixed(4));
    h += tvStat('Context-Dependent', s.context_dependent.count, 'CV ≥ ' + s.context_dependent.threshold.toFixed(4));
  }
  h += '</div></div>';

  // Highest CV tokens
  if (r.highest_cv && r.highest_cv.length) {
    h += tvTokenTable('Highest Density CV — Most Context-Dependent', r.highest_cv);
  }

  // Lowest CV tokens
  if (r.lowest_cv && r.lowest_cv.length) {
    h += tvTokenTable('Lowest Density CV — Most Context-Stable', r.lowest_cv);
  }

  // Eta-squared
  if (r.high_eta && r.high_eta.length) {
    h += tvTokenTable('Highest η² — Most Category-Driven Variance', r.high_eta);
  }

  // Pairwise comparisons
  if (r.pairwise) {
    Object.keys(r.pairwise).forEach(function(key) {
      var pair = r.pairwise[key];
      if (!pair.length) return;
      h += tvPairwiseTable(key.replace(/_/g, ' ').toUpperCase(), pair);
    });
  }

  h += '</div>';
  return h;
}

function tvStat(label, value, detail) {
  return '<div class="mod-stat"><div class="stat-label">' + escHtml(label) + '</div><div class="stat-value">' + value + '</div>' + (detail ? '<div class="stat-detail">' + escHtml(String(detail)) + '</div>' : '') + '</div>';
}

function tvTokenTable(title, tokens) {
  var h = '<div class="mod-section-title">' + escHtml(title) + '</div>';
  h += '<div class="mod-results-body" style="max-height:350px">';
  h += '<table class="mod-tbl"><thead><tr>';
  h += '<th>Token</th><th class="num">n</th><th class="num">cats</th>';
  h += '<th class="num">den_cv</th><th class="num">str_cv</th>';
  h += '<th class="num">den_mean</th><th class="num">str_mean</th>';
  h += '<th class="num">η²_den</th>';
  h += '</tr></thead><tbody>';
  tokens.forEach(function(t) {
    var cv = t.density_cv || 0;
    var cvCol = cv > 0.05 ? 'var(--orange)' : (cv < 0.01 ? 'var(--green)' : 'var(--text-0)');
    h += '<tr>';
    h += '<td style="color:var(--cyan);font-weight:500">' + escHtml(t.token) + '</td>';
    h += '<td class="num">' + t.n + '</td>';
    h += '<td class="num">' + t.n_cats + '</td>';
    h += '<td class="num" style="color:' + cvCol + '">' + (t.density_cv || 0).toFixed(4) + '</td>';
    h += '<td class="num">' + (t.stress_cv || 0).toFixed(4) + '</td>';
    h += '<td class="num">' + (t.density_mean || 0).toFixed(4) + '</td>';
    h += '<td class="num">' + (t.stress_mean || 0).toFixed(3) + '</td>';
    h += '<td class="num">' + (t.eta_sq_density || 0).toFixed(4) + '</td>';
    h += '</tr>';
  });
  h += '</tbody></table></div>';
  return h;
}

function tvPairwiseTable(title, pairs) {
  var h = '<div class="mod-section-title">' + escHtml(title) + '</div>';
  h += '<div class="mod-results-body" style="max-height:300px">';
  h += '<table class="mod-tbl"><thead><tr>';
  h += '<th>Token</th><th class="num">Mean A</th><th class="num">n</th><th class="num">Mean B</th><th class="num">n</th><th class="num">Δ</th>';
  h += '</tr></thead><tbody>';
  pairs.forEach(function(p) {
    var dc = p.diff > 0 ? 'var(--red)' : (p.diff < 0 ? 'var(--green)' : 'var(--text-0)');
    h += '<tr>';
    h += '<td style="color:var(--cyan)">' + escHtml(p.token) + '</td>';
    h += '<td class="num">' + p.mean_a.toFixed(4) + '</td>';
    h += '<td class="num" style="color:var(--text-3)">' + p.n_a + '</td>';
    h += '<td class="num">' + p.mean_b.toFixed(4) + '</td>';
    h += '<td class="num" style="color:var(--text-3)">' + p.n_b + '</td>';
    h += '<td class="num" style="color:' + dc + ';font-weight:600">' + (p.diff > 0 ? '+' : '') + p.diff.toFixed(4) + '</td>';
    h += '</tr>';
  });
  h += '</tbody></table></div>';
  return h;
}

// ─── Domain Surface Results Renderer ──────────────────────────

var _dsSurfaceData = null;

function renderDomainSurfaceResults(r) {
  var h = '<div class="mod-results">';
  var ln = r.level_names || ['nouns','phrase','question','instruct','meta'];
  var cats = ['b','m','h','j'];
  var catNames = {b:'benign',m:'mild',h:'harmful',j:'jailbreak'};
  var catCols = {b:'var(--cat-benign)',m:'var(--cat-mild)',h:'var(--cat-harmful)',j:'var(--cat-jailbreak)'};

  // Summary
  h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Summary';
  if (r.observations && r.observations.length > 0) {
    h += '<button class="btn-popout" style="margin-left:auto" onclick="event.stopPropagation();popoutDomainSurface()">↗ Scatter Plot</button>';
  }
  h += '</div>';
  h += '<div class="mod-results-body"><div class="mod-summary">';
  h += tvStat('Prompts', r.n_prompts_used, r.n_prompts_total > r.n_prompts_used ? (r.n_prompts_total - r.n_prompts_used) + ' without embeddings' : 'all with embeddings');
  h += tvStat('Observations', r.observations ? r.observations.length : 0, r.tokens ? r.tokens.length + ' tokens tracked' : '');
  h += tvStat('Subjects', r.subjects ? r.subjects.length : 0, r.anchors ? r.anchors.length + ' probe anchors' : '');
  h += tvStat('PCA Variance', r.pca ? r.pca[0] + '% + ' + r.pca[1] + '%' : '?', 'PC1 + PC2');
  h += tvStat('Probe File', r.probe_file || '?', '');
  h += '</div></div>';

  // Stratification by discourse level
  if (r.stratification && r.stratification.by_level) {
    h += '<div class="mod-section-title">Stratification by Discourse Level</div>';
    h += '<div class="mod-results-body">';
    h += '<table class="mod-tbl"><thead><tr>';
    h += '<th>Level</th>';
    cats.forEach(function(c) { h += '<th class="num" style="color:' + catCols[c] + '">' + catNames[c] + '</th>'; });
    h += '<th class="num">total</th><th class="num">% jailbreak</th>';
    h += '</tr></thead><tbody>';
    for (var li = 0; li < 5; li++) {
      var lk = String(li);
      var lv = r.stratification.by_level[lk] || {};
      var total = 0;
      cats.forEach(function(c) { total += (lv[c] || 0); });
      var jPct = total > 0 ? ((lv.j || 0) / total * 100) : 0;
      var isMeta = (li === 4);
      h += '<tr' + (isMeta ? ' style="background:rgba(204,121,167,0.06)"' : '') + '>';
      h += '<td style="color:var(--cyan);font-weight:500">' + (ln[li] || li) + '</td>';
      cats.forEach(function(c) {
        var n = lv[c] || 0;
        h += '<td class="num"' + (n > 0 ? ' style="color:' + catCols[c] + '"' : '') + '>' + n + '</td>';
      });
      h += '<td class="num" style="color:var(--text-2)">' + total + '</td>';
      h += '<td class="num" style="color:' + (jPct > 30 ? 'var(--cat-jailbreak)' : 'var(--text-2)') + ';font-weight:' + (jPct > 30 ? '600' : '400') + '">' + jPct.toFixed(1) + '%</td>';
      h += '</tr>';
    }
    h += '</tbody></table></div>';
  }

  // Stratification by subject
  if (r.stratification && r.stratification.by_subject) {
    h += '<div class="mod-section-title">Stratification by Subject</div>';
    h += '<div class="mod-results-body" style="max-height:350px">';
    h += '<table class="mod-tbl"><thead><tr>';
    h += '<th>Subject</th>';
    cats.forEach(function(c) { h += '<th class="num" style="color:' + catCols[c] + '">' + catNames[c] + '</th>'; });
    h += '<th class="num">total</th>';
    h += '</tr></thead><tbody>';
    var subjects = Object.keys(r.stratification.by_subject).sort();
    subjects.forEach(function(s) {
      var sv = r.stratification.by_subject[s];
      var total = 0;
      cats.forEach(function(c) { total += (sv[c] || 0); });
      h += '<tr><td style="color:var(--cyan)">' + escHtml(s.replace(/_/g, ' ')) + '</td>';
      cats.forEach(function(c) {
        var n = sv[c] || 0;
        h += '<td class="num"' + (n > 0 ? ' style="color:' + catCols[c] + '"' : '') + '>' + n + '</td>';
      });
      h += '<td class="num" style="color:var(--text-2)">' + total + '</td></tr>';
    });
    h += '</tbody></table></div>';
  }

  // Token table
  if (r.tokens && r.tokens.length && r.observations) {
    h += '<div class="mod-section-title">Tokens by Coefficient of Variation</div>';
    h += '<div class="mod-results-body" style="max-height:400px">';
    h += '<table class="mod-tbl"><thead><tr>';
    h += '<th>Token</th><th class="num">CV</th><th class="num">n</th>';
    h += '<th class="num">disp μ</th><th class="num">ASM μ</th>';
    h += '<th class="num">SFD-e μ</th><th class="num">SFD-d μ</th>';
    h += '</tr></thead><tbody>';
    r.tokens.forEach(function(tok) {
      var cv = (r.token_cv || {})[tok] || 0;
      var obs = r.observations.filter(function(o) { return o[0] === tok; });
      var n = obs.length;
      var mDisp = n ? obs.reduce(function(s, o) { return s + o[3]; }, 0) / n : 0;
      var mAsm = n ? obs.reduce(function(s, o) { return s + o[6]; }, 0) / n : 0;
      var mSfdE = n ? obs.reduce(function(s, o) { return s + o[7]; }, 0) / n : 0;
      var mSfdD = n ? obs.reduce(function(s, o) { return s + o[8]; }, 0) / n : 0;
      var cvCol = cv < 0.35 ? 'var(--green)' : (cv < 0.6 ? 'var(--orange)' : 'var(--red)');
      h += '<tr>';
      h += '<td style="color:var(--cyan);font-weight:500">' + escHtml(tok) + '</td>';
      h += '<td class="num" style="color:' + cvCol + '">' + cv.toFixed(3) + '</td>';
      h += '<td class="num">' + n + '</td>';
      h += '<td class="num">' + mDisp.toFixed(3) + '</td>';
      h += '<td class="num">' + mAsm.toFixed(2) + '</td>';
      h += '<td class="num">' + mSfdE.toFixed(3) + '</td>';
      h += '<td class="num">' + mSfdD.toFixed(3) + '</td>';
      h += '</tr>';
    });
    h += '</tbody></table></div>';
  }

  h += '</div>';
  return h;
}

// Load modules when the tab is first shown

function popoutDomainSurface(){
  if(!_dsSurfaceData||!_dsSurfaceData.observations||!_dsSurfaceData.observations.length)return;
  var pw=1100,ph=780,left=Math.round((screen.width-pw)/2),top=Math.round((screen.height-ph)/2);
  window.open('/domain_surface_viz','_blank','width='+pw+',height='+ph+',left='+left+',top='+top+',scrollbars=yes');
}

// ─── Correction Manifold Results Renderer ────────────────────
function renderCorrectionManifoldResults(r) {
  var h = '<div class="mod-results">';

  // Summary
  h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Classification Results</div>';
  h += '<div class="mod-results-body">';
  h += '<div class="mod-summary">';

  var cls = r.classification || {};
  var bin = cls.binary || {};
  var pca = r.pca_explained || [0,0];
  h += tvStat('Prompts', r.n_prompts || 0);
  h += tvStat('Clusters', r.n_clusters || 0);
  h += tvStat('Silhouette', (r.silhouette_score || 0).toFixed(3));
  h += tvStat('Cluster Accuracy', cls.overall_accuracy ? (cls.overall_accuracy * 100).toFixed(1) + '%' : '--');
  h += tvStat('Binary Accuracy', bin.best_accuracy ? (bin.best_accuracy * 100).toFixed(1) + '%' : '--', 'safe=' + (bin.n_safe||0) + ' risk=' + (bin.n_risk||0));
  h += tvStat('PCA Variance', ((pca[0]+pca[1])*100).toFixed(1) + '%', 'PC1=' + (pca[0]*100).toFixed(1) + '% PC2=' + (pca[1]*100).toFixed(1) + '%');
  h += tvStat('Fingerprint Dim', r.n_cells || 0, (r.classes||[]).length + ' classes × ' + (r.subclasses||[]).length + ' subclasses');

  h += '</div>';

  // Cluster-to-category mapping
  var mapping = r.cluster_mapping || [];
  if (mapping.length > 0) {
    h += '<div style="margin-top:8px"><table class="data-table" style="font-size:11px"><tr><th>Cluster</th><th>Best Match</th><th>Overlap</th></tr>';
    for (var i = 0; i < mapping.length; i++) {
      var m = mapping[i];
      var catName = m.category === 'b' ? 'benign' : m.category === 'm' ? 'mild' : m.category === 'd' ? 'dual-use' : m.category === 'h' ? 'harmful' : m.category === 'j' ? 'jailbreak' : m.category;
      h += '<tr><td>K' + m.cluster + '</td><td><span class="pill ' + pillClass(catName) + '">' + catName + '</span></td><td>' + m.overlap + '</td></tr>';
    }
    h += '</table></div>';
  }

  // Cluster detail
  var clusters = r.clusters || [];
  if (clusters.length > 0) {
    h += '<div style="margin-top:8px"><table class="data-table" style="font-size:11px"><tr><th>Cluster</th><th>Size</th><th>Distribution</th></tr>';
    for (var i = 0; i < clusters.length; i++) {
      var cl = clusters[i];
      var dist = cl.category_distribution || {};
      var distStr = Object.keys(dist).map(function(k){ return k + ':' + dist[k] }).join(' ');
      h += '<tr><td>K' + cl.id + '</td><td>' + cl.size + '</td><td style="font-size:10px;color:var(--text-2)">' + escHtml(distStr) + '</td></tr>';
    }
    h += '</table></div>';
  }

  h += '</div>';

  // Popout button
  h += '<div style="margin-top:8px;text-align:center">';
  h += '<button class="btn-popout" onclick="popoutCorrectionManifold()" style="font-size:12px;padding:6px 16px">↗ Open Manifold Visualization</button>';
  h += '</div>';

  h += '</div>';
  return h;
}

// ─── Correction Heatmap Results Renderer ───────────────────────

function renderCorrectionHeatmapResults(r) {
  var h = '<div class="mod-results">';
  var subjects = r.subjects || [];
  var levels = r.levels || [];
  var agg = r.aggregate || [];
  var variance = r.variance || [];

  // Find symmetric range for diverging color scale (centered on zero)
  var absMax = 0;
  for (var si = 0; si < agg.length; si++)
    for (var li = 0; li < (agg[si]||[]).length; li++) {
      var av = Math.abs(agg[si][li] || 0);
      if (av > absMax) absMax = av;
    }
  if (absMax < 1e-8) absMax = 1;

  // Diverging color: blue (negative) → neutral (zero) → red (positive)
  function heatColor(val) {
    var t = Math.max(-1, Math.min(1, val / absMax)); // -1 to +1
    var r, g, b;
    if (t >= 0) {
      // zero → red: rgb(42,42,52) → rgb(220,50,47)
      r = Math.round(42 + t * (220 - 42));
      g = Math.round(42 - t * (42 - 50) * (t > 0.5 ? 0 : 1));
      b = Math.round(52 - t * (52 - 47));
      // desaturate near zero, saturate at extremes
      r = Math.round(42 + t * 178);
      g = Math.round(42 - t * 12);
      b = Math.round(52 - t * 15);
    } else {
      var s = -t; // 0 to 1
      // zero → blue: rgb(42,42,52) → rgb(38,139,210)
      r = Math.round(42 - s * 4);
      g = Math.round(42 + s * 97);
      b = Math.round(52 + s * 158);
    }
    return 'rgb(' + r + ',' + g + ',' + b + ')';
  }
  function heatTextColor(val) {
    return Math.abs(val / absMax) > 0.35 ? '#fff' : 'var(--text-2)';
  }

  // Summary stats
  h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">';
  h += 'Aggregate Heatmap';
  h += '<button class="btn-popout" style="margin-left:auto" onclick="event.stopPropagation();popoutCorrectionHeatmap()">↗ Interactive Explorer</button>';
  h += '</div>';
  h += '<div class="mod-results-body">';
  h += '<div style="padding:10px;overflow-x:auto">';

  // Color legend
  h += '<div style="display:flex;align-items:center;gap:6px;margin-bottom:8px;font-size:10px;color:var(--text-2)">';
  h += '<span>−' + absMax.toFixed(3) + '</span>';
  h += '<div style="display:flex;height:10px;width:120px;border-radius:2px;overflow:hidden">';
  for (var ci = 0; ci < 20; ci++) {
    var cv = -absMax + (ci / 19) * 2 * absMax;
    h += '<div style="flex:1;background:' + heatColor(cv) + '"></div>';
  }
  h += '</div>';
  h += '<span>+' + absMax.toFixed(3) + '</span>';
  h += '<span style="margin-left:8px;color:var(--text-3)">blue = suppressed · red = activated</span>';
  h += '</div>';

  // Heatmap table
  h += '<table style="border-collapse:collapse;font-size:10px;font-family:var(--mono)">';
  h += '<tr><th style="padding:4px 8px;text-align:left;color:var(--text-2)"></th>';
  for (var li = 0; li < levels.length; li++) {
    h += '<th style="padding:4px 6px;color:var(--text-2);font-weight:500;text-align:center">' + escHtml(levels[li]) + '</th>';
  }
  h += '</tr>';

  for (var si = 0; si < subjects.length; si++) {
    h += '<tr>';
    h += '<td style="padding:4px 8px;color:var(--text-1);font-weight:600;text-align:left;white-space:nowrap">' + escHtml((r.subj_short||subjects)[si]) + '</td>';
    for (var li = 0; li < levels.length; li++) {
      var val = (agg[si] && agg[si][li] != null) ? agg[si][li] : 0;
      var vari = (variance[si] && variance[si][li]) ? variance[si][li] : 0;
      var bg = heatColor(val);
      var textCol = heatTextColor(val);
      var sign = val > 0 ? '+' : '';
      var title = subjects[si] + ' \u00d7 ' + levels[li] + ': activation=' + sign + val.toFixed(4) + ' variance=' + vari.toFixed(4);
      h += '<td style="padding:4px 6px;text-align:center;background:' + bg + ';color:' + textCol + '" title="' + escHtml(title) + '">';
      h += sign + val.toFixed(3);
      h += '</td>';
    }
    h += '</tr>';
  }
  h += '</table>';
  h += '</div></div>';

  // Per-subject summary
  h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Per Subject Summary</div>';
  h += '<div class="mod-results-body">';
  h += '<table class="data-table" style="width:100%;font-size:11px">';
  h += '<tr><th style="text-align:left">Subject</th><th>Mean</th><th>Max</th><th>Variance</th></tr>';
  var ps = r.per_subject || {};
  subjects.forEach(function(subj) {
    var s = ps[subj] || {};
    h += '<tr>';
    h += '<td style="text-align:left;font-weight:600;color:var(--text-0)">' + escHtml(subj.replace('_',' ')) + '</td>';
    h += '<td>' + (s.mean_activation || 0).toFixed(4) + '</td>';
    h += '<td>' + (s.max_activation || 0).toFixed(4) + '</td>';
    h += '<td>' + (s.mean_variance || 0).toFixed(6) + '</td>';
    h += '</tr>';
  });
  h += '</table></div>';

  h += '</div>';
  return h;
}

// ─── Probe Generator Results Renderer ──────────────────────────

function renderProbeGeneratorResults(r) {
  var h = '<div class="mod-results">';

  // Summary
  h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Summary</div>';
  h += '<div class="mod-results-body"><div class="mod-summary">';
  h += '<div class="mod-stat"><span class="mod-stat-val">' + r.total_raw_tokens + '</span><span class="mod-stat-label">Raw Tokens</span></div>';
  h += '<div class="mod-stat"><span class="mod-stat-val">' + r.total_shared_removed + '</span><span class="mod-stat-label">Shared (removed)</span></div>';
  h += '<div class="mod-stat"><span class="mod-stat-val">' + r.total_discriminative + '</span><span class="mod-stat-label">Discriminative</span></div>';
  h += '<div class="mod-stat"><span class="mod-stat-val">' + r.queries_per_subject + '</span><span class="mod-stat-label">Queries/Subject</span></div>';
  h += '<div class="mod-stat"><span class="mod-stat-val">' + r.sampling_seconds + 's</span><span class="mod-stat-label">Sampling Time</span></div>';
  h += '<div class="mod-stat"><span class="mod-stat-val">' + escHtml(r.output_file) + '</span><span class="mod-stat-label">Output File</span></div>';
  if (r.catalog_file) h += '<div class="mod-stat"><span class="mod-stat-val">' + escHtml(r.catalog_file) + '</span><span class="mod-stat-label">Catalog File</span></div>';
  h += '</div></div>';

  // Per-subject table
  h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Per Subject Breakdown</div>';
  h += '<div class="mod-results-body" style="max-height:500px">';
  h += '<table class="data-table" style="width:100%;font-size:11px">';
  h += '<tr><th style="text-align:left">Subject</th><th>Raw</th><th>Discriminative</th><th style="text-align:left">Top Words</th></tr>';

  var subjects = r.subjects || [];
  var ps = r.per_subject || {};
  subjects.forEach(function(subj) {
    var s = ps[subj] || {};
    var top = (s.top_20 || []).slice(0, 10).join(', ');
    var pct = s.raw_tokens > 0 ? Math.round(100 * s.discriminative_tokens / s.raw_tokens) : 0;
    h += '<tr>';
    h += '<td style="text-align:left;font-weight:600;color:var(--text-0)">' + escHtml(subj.replace('_', ' ')) + '</td>';
    h += '<td>' + (s.raw_tokens || 0) + '</td>';
    h += '<td><span style="color:var(--green)">' + (s.discriminative_tokens || 0) + '</span> <span style="color:var(--text-3);font-size:10px">(' + pct + '%)</span></td>';
    h += '<td style="text-align:left;color:var(--text-2);font-size:10px">' + escHtml(top) + '</td>';
    h += '</tr>';
  });

  h += '</table></div>';

  // Shared tokens list
  var shared = r.shared_tokens || [];
  if (shared.length > 0) {
    h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Shared Tokens Removed (' + shared.length + ')</div>';
    h += '<div class="mod-results-body collapsed" style="max-height:300px">';
    h += '<div style="padding:10px 16px;font-size:10px;color:var(--text-2);font-family:var(--mono);line-height:1.8;word-break:break-all">';
    h += escHtml(shared.join(', '));
    h += '</div></div>';
  }

  // Inference catalog
  var catalog = r.catalog || {};
  var catalogKeys = Object.keys(catalog);
  if (catalogKeys.length > 0) {
    h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Inference Catalog (' + (r.total_queries||0) + ' queries' + (r.catalog_file ? ' — ' + escHtml(r.catalog_file) : '') + ')</div>';
    h += '<div class="mod-results-body collapsed" style="max-height:600px">';
    catalogKeys.forEach(function(key) {
      var parts = key.split('|');
      var cls = parts[0] || '?';
      var sub = parts[1] || '?';
      var entries = catalog[key] || [];
      h += '<div style="border-bottom:1px solid var(--border);padding:8px 12px">';
      h += '<div style="cursor:pointer;font-weight:600;color:var(--text-0);font-size:11px" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">';
      h += escHtml(cls.replace('_',' ')) + ' × ' + escHtml(sub.replace('_',' '));
      h += ' <span style="color:var(--text-3);font-weight:400">(' + entries.length + ' queries)</span></div>';
      h += '<div class="collapsed" style="max-height:400px;overflow-y:auto">';
      entries.forEach(function(e) {
        var nTok = (e.tokens_extracted && e.tokens_extracted.length) || e.n_tokens || 0;
        var respFull = e.response || '';
        var respPrev = respFull.length > 300 ? respFull.slice(0,300) + '…' : respFull;
        h += '<div style="padding:6px 0;border-top:1px solid var(--border);font-size:10px">';
        h += '<span style="color:var(--cyan);font-weight:600">Q' + e.q + '</span> ';
        h += '<span style="color:var(--text-3)">(' + nTok + ' tokens)</span>';
        h += '<div style="color:var(--text-2);margin-top:3px;line-height:1.5;white-space:pre-wrap;word-break:break-word">' + escHtml(respPrev) + '</div>';
        h += '</div>';
      });
      h += '</div></div>';
    });
    h += '</div>';
  }

  h += '</div>';
  return h;
}

function popoutCorrectionManifold(){
  var pw=960,ph=960,left=Math.round((screen.width-pw)/2),top=Math.round((screen.height-ph)/2);
  window.open('/correction_manifold_viz','_blank','width='+pw+',height='+ph+',left='+left+',top='+top+',scrollbars=yes');
}

function popoutCorrectionHeatmap(){
  var pw=1100,ph=800,left=Math.round((screen.width-pw)/2),top=Math.round((screen.height-ph)/2);
  window.open('/correction_heatmap_viz','_blank','width='+pw+',height='+ph+',left='+left+',top='+top+',scrollbars=yes');
}

function popoutCorrectionBackscatter(){
  var pw=1100,ph=800,left=Math.round((screen.width-pw)/2),top=Math.round((screen.height-ph)/2);
  window.open('/correction_backscatter_viz','_blank','width='+pw+',height='+ph+',left='+left+',top='+top+',scrollbars=yes');
}

function renderCorrectionBackscatterResults(r) {
  var h = '<div class="mod-results">';
  var subjects = r.subjects || [];
  var levels = r.levels || [];
  var agg = r.aggregate || [];
  var variance = r.variance || [];
  var probeEnergy = r.probe_energy_grid || [];
  var cfg = r.config || {};
  var decomp = r.decomposition || {};
  var projOrder = r.projection_order || [];
  var projLabels = r.projection_labels || {};

  // Warm color scale helper (positive energies)
  function warmScale(grid) {
    var mn = Infinity, mx = 0;
    for (var si = 0; si < grid.length; si++)
      for (var li = 0; li < (grid[si]||[]).length; li++) {
        var v = grid[si][li] || 0;
        if (v > 0 && v < mn) mn = v;
        if (v > mx) mx = v;
      }
    if (mx < 1e-10) mx = 1;
    if (mn === Infinity) mn = 0;
    return {min: mn, max: mx};
  }
  function warmColor(val, sc) {
    if (val <= 0) return 'rgb(30,30,36)';
    var t = Math.max(0, Math.min(1, (val - sc.min) / (sc.max - sc.min)));
    return 'rgb(' + Math.round(30 + t * 200) + ',' + Math.round(30 + t * 120) + ',' + Math.round(36 + t * 10) + ')';
  }
  function warmText(val, sc) {
    var t = (sc.max > sc.min) ? (val - sc.min) / (sc.max - sc.min) : 0;
    return t > 0.4 ? '#fff' : 'var(--text-2)';
  }
  function peColor(val, sc) {
    if (val <= 0) return 'rgb(30,30,36)';
    var t = Math.max(0, Math.min(1, (val - sc.min) / (sc.max - sc.min)));
    return 'rgb(' + Math.round(30 + t * 50) + ',' + Math.round(60 + t * 140) + ',' + Math.round(100 + t * 130) + ')';
  }

  function renderHeatmapTable(grid, colorFn, sc, digits) {
    var th = '<table style="border-collapse:collapse;font-size:10px;font-family:var(--mono)">';
    th += '<tr><th style="padding:3px 6px;text-align:left;color:var(--text-2)"></th>';
    for (var li = 0; li < levels.length; li++)
      th += '<th style="padding:3px 5px;color:var(--text-2);font-weight:500;text-align:center;font-size:9px">' + escHtml(levels[li]) + '</th>';
    th += '</tr>';
    for (var si = 0; si < subjects.length; si++) {
      th += '<tr>';
      th += '<td style="padding:3px 6px;color:var(--text-1);font-weight:600;text-align:left;font-size:9px;white-space:nowrap">' + escHtml((r.subj_short||subjects)[si]) + '</td>';
      for (var li = 0; li < levels.length; li++) {
        var val = (grid[si] && grid[si][li] != null) ? grid[si][li] : 0;
        var bg = colorFn(val, sc);
        var tc = warmText(val, sc);
        th += '<td style="padding:3px 5px;text-align:center;background:' + bg + ';color:' + tc + ';font-size:9px">' + val.toFixed(digits) + '</td>';
      }
      th += '</tr>';
    }
    th += '</table>';
    return th;
  }

  // ── Delta Decomposition: all projections side by side ──
  var aggSc = warmScale(agg);  // retained for any per-subject scale use below
  if (projOrder.length > 1) {
    h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">';
    h += 'Delta Decomposition (' + projOrder.length + ' projections)';
    h += '<button class="btn-popout" style="margin-left:auto" onclick="event.stopPropagation();popoutCorrectionBackscatter()">↗ Interactive Explorer</button>';
    h += '</div>';
    h += '<div class="mod-results-body">';
    h += '<div style="padding:10px;display:flex;flex-wrap:wrap;gap:16px">';
    projOrder.forEach(function(pk) {
      var d = decomp[pk];
      if (!d) return;
      var dAgg = d.aggregate || [];
      var dPe = d.probe_energy || [];
      var sc = warmScale(dAgg);
      var label = projLabels[pk] || pk.toUpperCase();
      h += '<div style="min-width:200px">';
      h += '<div style="font-size:11px;font-weight:600;color:var(--cyan);margin-bottom:4px">' + escHtml(label) + '</div>';
      h += renderHeatmapTable(dAgg, warmColor, sc, 4);
      h += '</div>';
    });
    h += '</div></div>';

    // Probe energy decomposition
    h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Probe Energy Decomposition</div>';
    h += '<div class="mod-results-body">';
    h += '<div style="padding:10px;display:flex;flex-wrap:wrap;gap:16px">';
    projOrder.forEach(function(pk) {
      var d = decomp[pk];
      if (!d) return;
      var dPe = d.probe_energy || [];
      var sc = warmScale(dPe);
      var label = projLabels[pk] || pk.toUpperCase();
      h += '<div style="min-width:200px">';
      h += '<div style="font-size:11px;font-weight:600;color:var(--cyan);margin-bottom:4px">' + escHtml(label) + '</div>';
      h += renderHeatmapTable(dPe, peColor, sc, 4);
      h += '</div>';
    });
    h += '</div></div>';
  }

  // ── Per-subject summary ──
  h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Per Subject Summary</div>';
  h += '<div class="mod-results-body">';
  h += '<table class="data-table" style="width:100%;font-size:11px">';
  h += '<tr><th style="text-align:left">Subject</th><th>Mean</th><th>Max</th><th>Probe Energy</th><th>Variance</th></tr>';
  var ps = r.per_subject || {};
  subjects.forEach(function(subj) {
    var s = ps[subj] || {};
    h += '<tr>';
    h += '<td style="text-align:left;font-weight:600;color:var(--text-0)">' + escHtml(subj.replace(/_/g,' ')) + '</td>';
    h += '<td>' + (s.mean_backscatter || 0).toFixed(6) + '</td>';
    h += '<td>' + (s.max_backscatter || 0).toFixed(6) + '</td>';
    h += '<td style="color:var(--cyan)">' + (s.mean_probe_energy || 0).toFixed(6) + '</td>';
    h += '<td>' + (s.mean_variance || 0).toFixed(8) + '</td>';
    h += '</tr>';
  });
  h += '</table></div>';

  // ── Config ──
  h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Configuration</div>';
  h += '<div class="mod-results-body collapsed">';
  h += '<div style="padding:10px;font-size:10px;color:var(--text-2);line-height:1.8">';
  h += 'Primary: <span style="color:var(--text-1)">' + escHtml(cfg.primary_projection || 'qkv') + '</span> · ';
  h += 'Aggregation: <span style="color:var(--text-1)">' + escHtml(cfg.aggregation || 'mean') + '</span> · ';
  h += 'Signal layers: <span style="color:var(--text-1)">' + (cfg.n_signal_layers || 0) + '</span> · ';
  h += 'Projections: <span style="color:var(--text-1)">' + (cfg.projections_computed || []).join(', ') + '</span>';
  h += '</div></div>';

  h += '</div>';
  return h;
}

// ─── Comparative Analysis Results Renderer ──────────────────────

function renderComparativeResults(r) {
  if (r.error) {
    return '<div class="mod-results"><div class="mod-results-body" style="padding:16px;color:var(--orange)">' + escHtml(r.error) + '</div></div>';
  }

  var h = '<div class="mod-results">';
  var agg = r.aggregate || {};
  var cats = agg.categories || {};
  var plotKeys = r.plot_keys || [];

  // Session summary badges
  h += '<div style="padding:10px 16px;border-bottom:1px solid var(--border)">';
  h += '<div class="metrics-grid">';
  h += mc('Prompts', r.n_prompts || 0, null, function(v){return v});
  (r.categories || []).forEach(function(cat) {
    var ci = cats[cat];
    h += mc(cat, ci ? ci.n : '?', null, function(v){return v});
  });
  h += '</div></div>';

  // Category summary table
  if (Object.keys(cats).length) {
    h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Category Summary</div>';
    h += '<div class="mod-results-body">';
    h += '<div style="font-size:11px;color:var(--text-2);margin-bottom:8px;line-height:1.5">Bootstrapped estimates (5000 resamples, 95% CI). ASM (disruption), LTP (selectivity), SFD (subspace).</div>';
    h += '<table class="mod-tbl"><thead><tr><th>Category</th><th class="num">N</th><th class="num">Stress</th><th class="num">Entropy</th><th class="num">Int%</th><th class="num">Net Corr</th><th class="num">Int CV</th><th class="num" style="color:var(--orange)">Density</th><th class="num" style="color:var(--orange)">Tau</th></tr></thead><tbody>';
    for (var catName in cats) {
      var s = cats[catName];
      var m = s.metrics || {};
      h += '<tr>';
      h += '<td><span class="pill ' + pillClass(catName) + '">' + catName + '</span></td>';
      h += '<td class="num">' + s.n + '</td>';
      h += '<td class="num">' + (m.stress_score ? m.stress_score.estimate.toFixed(4) : '--') + '</td>';
      h += '<td class="num">' + (m.entropy ? m.entropy.estimate.toFixed(4) : '--') + '</td>';
      h += '<td class="num">' + (m.middle_share ? (m.middle_share.estimate * 100).toFixed(1) + '%' : '--') + '</td>';
      h += '<td class="num">' + (m.net_correction ? m.net_correction.estimate.toFixed(5) : '--') + '</td>';
      h += '<td class="num">' + (m.interior_cv ? m.interior_cv.estimate.toFixed(4) : '--') + '</td>';
      h += '<td class="num">' + (m.sfd_density_mean ? m.sfd_density_mean.estimate.toFixed(4) : '--') + '</td>';
      h += '<td class="num">' + (m.rank_displacement_tau ? m.rank_displacement_tau.estimate.toFixed(3) : '--') + '</td>';
      h += '</tr>';
    }
    h += '</tbody></table></div>';
  }

  // Batch visualizations — popout labels
  var plotKeySet = {};
  plotKeys.forEach(function(k) { plotKeySet[k] = true; });
  var batchItems = Object.entries(VIZ_REGISTRY).filter(function(e) {
    return e[1].scope === 'batch' && e[1].on && plotKeySet[e[0]];
  }).sort(function(a, b) { return a[1].order - b[1].order; });

  if (batchItems.length) {
    h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Visualizations (' + batchItems.length + ')</div>';
    h += '<div class="mod-results-body">';
    h += '<div style="font-size:11px;color:var(--text-2);margin-bottom:8px">Click any item to open in a new window.</div>';
    batchItems.forEach(function(e) {
      var key = e[0], v = e[1];
      var sk = 'comp_' + key;
      storeViz(sk, v.title, _plotHtml(key, v.title, v.desc || ''));
      h += vizLabel(sk, v.title, v.desc || '');
    });

    // Candidate graph aggregate
    if (dashResults.length > 1) {
      try {
        var cgAgg = _computeGraphsChunked(dashResults);
        if (cgAgg) {
          var sk2 = 'comp_candgraph';
          storeViz(sk2, 'Candidate Graph Aggregate', cgAgg);
          h += vizLabel(sk2, 'Candidate Graph Aggregate', 'Contested positions and role switches across batch', 'var(--purple)');
        }
      } catch(e) { console.error('Candidate graph aggregate:', e); }
    }

    // Disabled batch vizs
    var disabledBatch = Object.entries(VIZ_REGISTRY).filter(function(e) {
      return e[1].scope === 'batch' && !e[1].on && plotKeySet[e[0]];
    }).sort(function(a, b) { return a[1].order - b[1].order; });
    if (disabledBatch.length) {
      h += '<div style="margin-top:12px;padding-top:10px;border-top:1px solid var(--border)"><div style="font-size:11px;color:var(--text-3);margin-bottom:6px">Disabled (enable in Configuration tab):</div>';
      disabledBatch.forEach(function(e) {
        var key = e[0], v = e[1];
        var sk3 = 'comp_dis_' + key;
        storeViz(sk3, v.title, _plotHtml(key, v.title, v.desc || ''));
        h += vizLabel(sk3, v.title + ' (disabled)', v.desc || '');
      });
      h += '</div>';
    }
    h += '</div>';
  }

  // Separability details (if available)
  var sep = agg.separability || {};
  if (Object.keys(sep).length) {
    h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Separability (Cohen\'s d)</div>';
    h += '<div class="mod-results-body collapsed">';
    h += '<table class="mod-tbl"><thead><tr><th>Metric</th><th class="num">d</th><th class="num">CI Low</th><th class="num">CI High</th><th class="num">Accuracy</th></tr></thead><tbody>';
    var sepKeys = Object.keys(sep).sort(function(a, b) {
      return (sep[b].effect_size ? sep[b].effect_size.estimate : 0) - (sep[a].effect_size ? sep[a].effect_size.estimate : 0);
    });
    sepKeys.forEach(function(k) {
      var s = sep[k];
      var es = s.effect_size || {};
      var ci = es.ci || [];
      var th = s.threshold || {};
      var col = Math.abs(es.estimate || 0) >= 0.8 ? 'var(--green)' : Math.abs(es.estimate || 0) >= 0.5 ? 'var(--cyan)' : 'var(--text-2)';
      h += '<tr><td style="color:var(--cyan)">' + escHtml(k) + '</td>';
      h += '<td class="num" style="color:' + col + '">' + (es.estimate || 0).toFixed(3) + '</td>';
      h += '<td class="num">' + (ci[0] != null ? ci[0].toFixed(3) : '--') + '</td>';
      h += '<td class="num">' + (ci[1] != null ? ci[1].toFixed(3) : '--') + '</td>';
      h += '<td class="num">' + (th.accuracy ? (th.accuracy * 100).toFixed(1) + '%' : '--') + '</td>';
      h += '</tr>';
    });
    h += '</tbody></table></div>';
  }

  h += '</div>';
  return h;
}

// ─── Correction Field Topology Results Renderer ─────────────────

function renderCFTResults(r) {
  if (r.error) {
    return '<div class="mod-results"><div class="mod-results-body" style="padding:16px;color:var(--orange)">' + escHtml(r.error) + '</div></div>';
  }

  var h = '<div class="mod-results">';

  // Launch button
  var nUsable = (r.n_with_displacement || 0) + (r.n_with_ltp_fallback || 0);
  var lp = r.launch_params || {};
  h += '<div style="padding:12px 16px;display:flex;align-items:center;gap:12px;border-bottom:1px solid var(--border)">';
  h += '<button class="btn btn-primary btn-sm" onclick="_cftLaunchFromModule()" style="white-space:nowrap">↗ Launch Visualization</button>';
  h += '<span style="font-size:11px;color:var(--text-2)">' + nUsable + ' prompts ready';
  if (r.n_with_displacement > 0) h += ' · ' + r.n_with_displacement + ' displacement';
  if (r.n_with_ltp_fallback > 0) h += ' · ' + r.n_with_ltp_fallback + ' LTP fallback';
  h += '</span></div>';

  // Summary stats
  h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Topology Summary</div>';
  h += '<div class="mod-results-body"><div class="mod-summary">';
  h += tvStat('Usable Prompts', nUsable, r.n_skipped + ' skipped (no profiles)');
  h += tvStat('Base Candidates', r.n_with_base_candidates || 0, 'prompts with dual-bank data');
  var ts = r.token_stats || {};
  h += tvStat('Total Tokens', ts.total_tokens || 0, 'mean ' + (ts.mean_tokens_per_prompt || 0) + '/prompt, max ' + (ts.max_tokens || 0));
  h += '</div></div>';

  // Category breakdown
  if (r.by_category && Object.keys(r.by_category).length > 1) {
    h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Category Breakdown</div>';
    h += '<div class="mod-results-body collapsed">';
    h += '<table class="mod-tbl"><thead><tr><th>Category</th><th class="num">Prompts</th><th class="num">Mean Tokens</th></tr></thead><tbody>';
    Object.keys(r.by_category).sort().forEach(function(cat) {
      var ci = r.by_category[cat];
      h += '<tr><td style="color:var(--cyan)">' + escHtml(cat) + '</td>';
      h += '<td class="num">' + ci.count + '</td>';
      h += '<td class="num">' + ci.mean_tokens + '</td></tr>';
    });
    h += '</tbody></table></div>';
  }

  // Displacement stats
  if (r.displacement_stats) {
    var ds = r.displacement_stats;
    h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Displacement Magnitude</div>';
    h += '<div class="mod-results-body collapsed"><div class="mod-summary">';
    var ov = ds.overall || {};
    h += tvStat('Overall Mean', (ov.mean || 0).toFixed(6), 'std ' + (ov.std || 0).toFixed(6) + ', median ' + (ov.median || 0).toFixed(6));
    if (ds.by_category) {
      Object.keys(ds.by_category).sort().forEach(function(cat) {
        var cs = ds.by_category[cat];
        h += tvStat(cat, cs.mean.toFixed(6), 'std ' + cs.std.toFixed(6) + ', max ' + cs.max.toFixed(6));
      });
    }
    h += '</div></div>';
  }

  // Asymmetry stats
  if (r.asymmetry_stats) {
    var as = r.asymmetry_stats;
    h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Bank Asymmetry</div>';
    h += '<div class="mod-results-body collapsed"><div class="mod-summary">';
    var ao = as.overall || {};
    var biasLabel = ao.mean > 0.05 ? 'instruct-dominant' : ao.mean < -0.05 ? 'base-dominant' : 'balanced';
    h += tvStat('Overall Bias', biasLabel, 'mean asymmetry ' + (ao.mean || 0).toFixed(4) + ', ' + Math.round((ao.instruct_dominant_frac || 0) * 100) + '% instruct-dominant positions');
    if (as.by_category) {
      Object.keys(as.by_category).sort().forEach(function(cat) {
        var cs = as.by_category[cat];
        var catBias = cs.mean > 0.05 ? '↑ instruct' : cs.mean < -0.05 ? '↓ base' : '≈ balanced';
        h += tvStat(cat, catBias, 'mean ' + cs.mean.toFixed(4) + ', ' + Math.round(cs.instruct_dominant_frac * 100) + '% instruct-dominant');
      });
    }
    h += '</div></div>';
  }

  h += '</div>';
  return h;
}

// Store latest CFT launch params from module results
var _cftLaunchParams = null;

// Override fetchModuleResults to capture CFT params
var _origFetchModuleResults = fetchModuleResults;
fetchModuleResults = async function(name) {
  await _origFetchModuleResults(name);
  if (name === 'correction_field_topology') {
    try {
      var r = await fetch('/api/modules/correction_field_topology/results');
      var d = await r.json();
      if (d.ok && d.results && d.results.launch_params) {
        _cftLaunchParams = d.results.launch_params;
      }
    } catch(e) { /* silent */ }
  }
};

function _cftLaunchFromModule() {
  var p = _cftLaunchParams || {};
  // Fall back to module card param controls if no cached results
  if (!_cftLaunchParams) {
    var m = _moduleData['correction_field_topology'];
    if (m) p = getModuleParams('correction_field_topology');
  }
  var totalCount = sessionResults ? sessionResults.length : (dashResults ? dashResults.length : 0);
  if (!totalCount) {
    // Try from session info
    try { totalCount = parseInt(document.querySelector('#sessCount')?.textContent) || 0; } catch(e) {}
  }
  // Use dashboard info if available
  if (_promptTotal > 0) totalCount = _promptTotal;
  _lazyLoadTerrainPopout(totalCount, {
    category: p.category || 'all',
    recordLimit: p.record_limit || 100,
    tokenLimit: p.token_limit || 20,
    charLimit: p.char_limit || 50,
    autoRotate: !!p.auto_rotate,
    rotateSpeed: p.rotate_speed || 0.3,
  });
}

// ─── MI Instrumentation Results Renderer ────────────────────────

function renderMIInstrumentationResults(r) {
  if (r.error) {
    return '<div class="mod-results"><div class="mod-results-body" style="padding:16px;color:var(--orange)">' + escHtml(r.error) + '</div></div>';
  }

  var h = '<div class="mod-results">';
  var sm = r.summary || {};

  // ── Summary banner ──
  var rCol = sm.refusal_separates ? 'var(--green)' : 'var(--orange)';
  var sCol = sm.stress_separates ? 'var(--green)' : 'var(--orange)';
  h += '<div style="padding:12px 16px;border-bottom:1px solid var(--border)">';
  h += '<div class="metrics-grid">';
  h += mc('Prompts', r.n_prompts, null, function(v){return v});
  h += mc('Safe', r.n_safe, null, function(v){return v});
  h += mc('Risk', r.n_risk, null, function(v){return v});
  h += mc('Hidden Dim', r.hidden_dim, null, function(v){return v});
  h += '</div></div>';

  // ═══ 1. REFUSAL DIRECTION ═══
  var rd = r.refusal_direction || {};
  h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Refusal Direction</div>';
  h += '<div class="mod-results-body">';
  h += '<div style="font-size:11px;color:var(--text-2);margin-bottom:8px;line-height:1.5">';
  h += 'Empirical refusal direction extracted from mean hidden states (risk − safe). ';
  h += 'Cosine similarity of each prompt against this direction produces a continuous alignment score.</div>';
  h += '<div class="metrics-grid">';
  h += mc('Refusal AUROC', rd.auroc, null, function(v){return '<span style="color:'+rCol+'">'+v.toFixed(4)+'</span>'});
  h += mc('Stress AUROC', rd.stress_auroc, null, function(v){return '<span style="color:'+sCol+'">'+v.toFixed(4)+'</span>'});
  h += mc('Separation', rd.separation, null, function(v){var c=v>0?'var(--green)':'var(--orange)';return '<span style="color:'+c+'">'+v.toFixed(4)+'</span>'});
  h += mc('‖dir‖', rd.refusal_norm, null, function(v){return v.toFixed(4)});
  h += '</div>';

  // Cosine stats
  h += '<table class="mod-tbl" style="margin-top:8px"><thead><tr><th>Group</th><th class="num">Mean cos</th><th class="num">Std</th></tr></thead><tbody>';
  h += '<tr><td style="color:var(--green)">Safe</td><td class="num">' + (rd.mean_cosine_safe||0).toFixed(4) + '</td><td class="num">' + (rd.std_cosine_safe||0).toFixed(4) + '</td></tr>';
  h += '<tr><td style="color:var(--red)">Risk</td><td class="num">' + (rd.mean_cosine_risk||0).toFixed(4) + '</td><td class="num">' + (rd.std_cosine_risk||0).toFixed(4) + '</td></tr>';
  h += '</tbody></table>';

  // Per-category breakdown
  var pcats = rd.per_category || {};
  if (Object.keys(pcats).length > 2) {
    h += '<table class="mod-tbl" style="margin-top:8px"><thead><tr><th>Category</th><th class="num">Mean cos</th><th class="num">Std</th><th class="num">n</th></tr></thead><tbody>';
    for (var cat in pcats) {
      var pc = pcats[cat];
      h += '<tr><td><span class="pill ' + pillClass(cat) + '">' + cat + '</span></td>';
      h += '<td class="num">' + pc.mean.toFixed(4) + '</td>';
      h += '<td class="num">' + pc.std.toFixed(4) + '</td>';
      h += '<td class="num">' + pc.n + '</td></tr>';
    }
    h += '</tbody></table>';
  }
  h += '</div>';

  // ═══ 2. PER-LAYER AUROC ═══
  var pla = r.per_layer_auroc || {};
  var layers = pla.layers || [];
  if (layers.length) {
    h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Per-Layer AUROC (' + layers.length + ' layers)</div>';
    h += '<div class="mod-results-body">';
    h += '<div style="font-size:11px;color:var(--text-2);margin-bottom:8px;line-height:1.5">';
    h += 'Discrimination power of the weight-delta projection at each model layer. ';
    h += 'Shows where in the network the correction signal concentrates.</div>';

    // Visual bar chart
    h += '<div style="margin-bottom:8px">';
    layers.forEach(function(la) {
      var w = Math.max(2, (la.auroc - 0.4) / 0.6 * 100);
      var col = la.auroc > 0.8 ? 'var(--green)' : la.auroc > 0.65 ? 'var(--cyan)' : la.auroc > 0.55 ? 'var(--orange)' : 'var(--text-3)';
      h += '<div style="display:flex;align-items:center;gap:6px;margin-bottom:2px">';
      h += '<span style="width:32px;text-align:right;font-size:10px;color:var(--text-2)">L' + la.layer + '</span>';
      h += '<div style="flex:1;height:12px;background:var(--bg-3);border-radius:2px;overflow:hidden">';
      h += '<div style="width:' + w + '%;height:100%;background:' + col + ';border-radius:2px"></div></div>';
      h += '<span style="width:40px;font-size:10px;color:' + col + '">' + la.auroc.toFixed(3) + '</span>';
      h += '</div>';
    });
    h += '</div>';

    // Table
    h += '<table class="mod-tbl"><thead><tr><th>Layer</th><th class="num">AUROC</th><th class="num">Safe μ</th><th class="num">Risk μ</th><th class="num">Ratio</th></tr></thead><tbody>';
    layers.forEach(function(la) {
      var col = la.auroc > 0.8 ? 'var(--green)' : la.auroc > 0.65 ? 'var(--cyan)' : 'var(--text-2)';
      h += '<tr><td>L' + la.layer + '</td>';
      h += '<td class="num" style="color:' + col + '">' + la.auroc.toFixed(4) + '</td>';
      h += '<td class="num">' + la.mean_safe.toFixed(6) + '</td>';
      h += '<td class="num">' + la.mean_risk.toFixed(6) + '</td>';
      h += '<td class="num">' + la.ratio.toFixed(2) + 'x</td></tr>';
    });
    h += '</tbody></table>';
    h += '</div>';
  }

  // ═══ 3. PATCHING PRIORITY MAP ═══
  var pp = r.patching_priority || {};
  var topPts = pp.top_points || [];
  if (topPts.length) {
    h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Activation Patching Priority</div>';
    h += '<div class="mod-results-body">';
    h += '<div style="font-size:11px;color:var(--text-2);margin-bottom:8px;line-height:1.5">';
    h += 'Highest-value intervention points for activation patching experiments. ';
    h += 'Intensity = attribution × stress, aggregated across all prompts.</div>';

    // Layer marginal summary
    var lm = pp.layer_marginal || [];
    if (lm.length) {
      h += '<div style="margin-bottom:8px">';
      var maxInt = Math.max.apply(null, lm.map(function(x){return x.max_intensity})) || 1;
      lm.forEach(function(la) {
        var w = Math.max(2, la.max_intensity / maxInt * 100);
        h += '<div style="display:flex;align-items:center;gap:6px;margin-bottom:2px">';
        h += '<span style="width:32px;text-align:right;font-size:10px;color:var(--text-2)">L' + la.layer + '</span>';
        h += '<div style="flex:1;height:10px;background:var(--bg-3);border-radius:2px;overflow:hidden">';
        h += '<div style="width:' + w + '%;height:100%;background:var(--orange);border-radius:2px"></div></div>';
        h += '<span style="width:52px;font-size:10px;color:var(--orange)">' + la.max_intensity.toFixed(5) + '</span>';
        h += '</div>';
      });
      h += '</div>';
    }

    // Top points table
    h += '<table class="mod-tbl"><thead><tr><th>Rank</th><th>Layer</th><th>Position</th><th class="num">Intensity</th><th class="num">Obs</th></tr></thead><tbody>';
    topPts.slice(0, 15).forEach(function(pt, i) {
      h += '<tr><td>' + (i+1) + '</td><td>L' + pt.layer + '</td><td>P' + pt.position + '</td>';
      h += '<td class="num" style="color:var(--orange)">' + pt.intensity.toFixed(6) + '</td>';
      h += '<td class="num">' + pt.n_observations + '</td></tr>';
    });
    h += '</tbody></table>';
    h += '</div>';
  }

  // ═══ 4. RANDOM PROJECTION CONTROL ═══
  var rp = r.random_projection || {};
  h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Random Projection Control</div>';
  h += '<div class="mod-results-body">';
  h += '<div style="font-size:11px;color:var(--text-2);margin-bottom:8px;line-height:1.5">';
  h += 'Validates that the refusal direction and TAGM stress outperform random projections of the same hidden states. ';
  h += rp.n_trials + ' random unit vectors tested. p-value = fraction of random trials that match or exceed the real AUROC.</div>';

  h += '<div class="metrics-grid">';
  h += mc('Random μ', rp.random_mean_auroc, null, function(v){return v.toFixed(4)});
  h += mc('Random σ', rp.random_std_auroc, null, function(v){return v.toFixed(4)});
  h += mc('Random max', rp.random_max_auroc, null, function(v){return v.toFixed(4)});
  h += mc('Random p95', rp.random_p95_auroc, null, function(v){return v.toFixed(4)});
  h += '</div>';

  // Comparison table
  var rpRef = rp.refusal_direction || {};
  var rpStr = rp.tagm_stress || {};
  h += '<table class="mod-tbl" style="margin-top:8px"><thead><tr><th>Method</th><th class="num">AUROC</th><th class="num">Δ over random</th><th class="num">p-value</th><th>Significant</th></tr></thead><tbody>';

  var refSig = rpRef.empirical_p < 0.05;
  var strSig = rpStr.empirical_p < 0.05;
  h += '<tr><td style="color:var(--cyan)">Refusal Direction</td>';
  h += '<td class="num">' + (rpRef.auroc||0).toFixed(4) + '</td>';
  h += '<td class="num" style="color:var(--green)">+' + (rpRef.delta_over_random||0).toFixed(4) + '</td>';
  h += '<td class="num">' + (rpRef.empirical_p||1).toFixed(3) + '</td>';
  h += '<td style="color:' + (refSig?'var(--green)':'var(--orange)') + '">' + (refSig?'✓ yes':'✗ no') + '</td></tr>';

  h += '<tr><td style="color:var(--orange)">TAGM Stress</td>';
  h += '<td class="num">' + (rpStr.auroc||0).toFixed(4) + '</td>';
  h += '<td class="num" style="color:var(--green)">+' + (rpStr.delta_over_random||0).toFixed(4) + '</td>';
  h += '<td class="num">' + (rpStr.empirical_p||1).toFixed(3) + '</td>';
  h += '<td style="color:' + (strSig?'var(--green)':'var(--orange)') + '">' + (strSig?'✓ yes':'✗ no') + '</td></tr>';

  h += '</tbody></table>';

  // Histogram text summary
  var hist = rp.histogram || [];
  if (hist.length) {
    var below60 = hist.filter(function(v){return v<0.6}).length;
    var above70 = hist.filter(function(v){return v>0.7}).length;
    h += '<div style="font-size:10px;color:var(--text-3);margin-top:6px">';
    h += 'Distribution: ' + below60 + '/' + hist.length + ' trials below 0.6, ';
    h += above70 + '/' + hist.length + ' above 0.7';
    h += '</div>';
  }
  h += '</div>';

  h += '</div>';
  return h;
}

// ─── MI Readiness Results Renderer ──────────────────────────────

function renderMIResults(r) {
  if (r.error) {
    return '<div class="mod-results"><div class="mod-results-body" style="padding:16px;color:var(--orange)">' + escHtml(r.error) + '</div></div>';
  }

  var h = '<div class="mod-results">';

  // ── Readiness Banner ──
  var readyCol = r.overall_readiness === 'ready' ? 'var(--green)' : r.overall_readiness === 'gaps' ? 'var(--red)' : 'var(--orange)';
  var readyLabel = r.overall_readiness === 'ready' ? 'MI READY' : r.overall_readiness === 'gaps' ? 'GAPS IDENTIFIED' : 'NEAR READY';
  h += '<div style="padding:12px 16px;background:color-mix(in srgb,' + readyCol + ' 12%,transparent);border-left:3px solid ' + readyCol + ';margin:8px 0;font-family:var(--mono);font-size:12px">';
  h += '<span style="color:' + readyCol + ';font-weight:700">' + readyLabel + '</span>';
  h += '<span style="color:var(--text-1);margin-left:8px">' + escHtml(r.readiness_summary) + '</span>';
  h += '</div>';

  // ── Scorecard ──
  h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">MI Scorecard</div>';
  h += '<div class="mod-results-body"><div class="mod-summary">';
  if (r.scorecard) {
    r.scorecard.forEach(function(s) {
      var col = s.status === 'strong' ? 'var(--green)' : s.status === 'weak' ? 'var(--red)' : 'var(--orange)';
      var icon = s.status === 'strong' ? '●' : s.status === 'weak' ? '○' : '◐';
      h += '<div class="mod-stat"><div class="stat-label"><span style="color:' + col + '">' + icon + '</span> ' + escHtml(s.item) + '</div>';
      h += '<div class="stat-value" style="color:' + col + '">' + s.status + '</div>';
      h += '<div class="stat-detail">' + escHtml(s.detail) + '</div></div>';
    });
  }
  h += '</div></div>';

  // ── AUROC Comparison ──
  h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Discrimination Power (AUROC)</div>';
  h += '<div class="mod-results-body">';
  h += '<table class="mod-tbl"><thead><tr>';
  h += '<th>Method</th><th class="num">AUC</th><th class="num">± std</th><th>Notes</th>';
  h += '</tr></thead><tbody>';

  if (r.auroc_length_only) {
    h += '<tr><td>Sequence length only</td><td class="num">' + r.auroc_length_only.auc.toFixed(4) + '</td>';
    h += '<td class="num" style="color:var(--text-3)">' + r.auroc_length_only.std.toFixed(4) + '</td>';
    h += '<td style="color:var(--text-2);font-size:10px">Safe mean ' + r.mean_seq_len_safe + ' tok, risk mean ' + r.mean_seq_len_risk + ' tok</td></tr>';
  }
  if (r.auroc_full) {
    var aucCol = r.auroc_full.auc >= 0.95 ? 'var(--green)' : r.auroc_full.auc >= 0.80 ? 'var(--cyan)' : 'var(--orange)';
    h += '<tr><td style="font-weight:600">TAGM features (' + r.n_features + ' metrics)</td>';
    h += '<td class="num" style="color:' + aucCol + ';font-weight:700">' + r.auroc_full.auc.toFixed(4) + '</td>';
    h += '<td class="num" style="color:var(--text-3)">' + r.auroc_full.std.toFixed(4) + '</td>';
    h += '<td style="color:var(--text-2);font-size:10px">' + r.auroc_full.n_folds + '-fold CV</td></tr>';
  }
  if (r.auroc_residualized) {
    h += '<tr><td>TAGM features, length-residualized</td>';
    h += '<td class="num" style="font-weight:600">' + r.auroc_residualized.auc.toFixed(4) + '</td>';
    h += '<td class="num" style="color:var(--text-3)">' + r.auroc_residualized.std.toFixed(4) + '</td>';
    h += '<td style="color:var(--text-2);font-size:10px">Signal after removing length</td></tr>';
  }
  if (r.random_baseline) {
    h += '<tr><td>Random projection baseline</td>';
    h += '<td class="num" style="color:var(--text-3)">' + r.random_baseline.mean_auc.toFixed(4) + '</td>';
    h += '<td class="num" style="color:var(--text-3)">' + r.random_baseline.std_auc.toFixed(4) + '</td>';
    h += '<td style="color:var(--text-2);font-size:10px">' + r.random_baseline.n_trials + ' trials, Δ = +' + r.random_baseline.delta_above_random.toFixed(4) + '</td></tr>';
  }
  h += '</tbody></table></div>';

  // ── Per-Metric AUROC ──
  if (r.per_metric_auroc && r.per_metric_auroc.length) {
    h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Per-Metric AUROC</div>';
    h += '<div class="mod-results-body collapsed" style="max-height:350px">';
    h += '<table class="mod-tbl"><thead><tr><th>Metric</th><th class="num">AUROC</th><th>Direction</th></tr></thead><tbody>';
    r.per_metric_auroc.forEach(function(m) {
      var col = m.auroc >= 0.80 ? 'var(--green)' : m.auroc >= 0.65 ? 'var(--cyan)' : 'var(--text-2)';
      h += '<tr><td style="color:var(--cyan)">' + escHtml(m.metric) + '</td>';
      h += '<td class="num" style="color:' + col + '">' + m.auroc.toFixed(4) + '</td>';
      h += '<td style="color:var(--text-3);font-size:10px">' + m.direction + '</td></tr>';
    });
    h += '</tbody></table></div>';
  }

  // ── PCA ──
  if (r.pca && r.pca.components) {
    var pcaTarget = (r.config && r.config.pca_variance_target) ? Math.round(r.config.pca_variance_target * 100) : 95;
    h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">PCA: Effective Dimensionality (' + pcaTarget + '% target)</div>';
    h += '<div class="mod-results-body">';
    h += '<div style="padding:8px 0;font-size:11px;color:var(--text-1)">';
    h += '<span style="color:var(--cyan);font-weight:600">' + r.pca.effective_dimensionality + '</span> components explain ' + (r.pca.variance_target ? Math.round(r.pca.variance_target * 100) : 95) + '% variance ';
    h += '(from ' + r.pca.n_features_original + ' features)</div>';
    h += '<table class="mod-tbl"><thead><tr><th>Component</th><th>Axis Name</th><th class="num">Var %</th><th class="num">Cumul %</th><th>Top Loadings</th></tr></thead><tbody>';
    r.pca.components.forEach(function(c) {
      var bar = '<span style="display:inline-block;width:' + Math.round(c.variance_explained) + 'px;height:8px;background:var(--cyan);border-radius:2px;vertical-align:middle;margin-right:4px"></span>';
      var loads = (c.top_loadings || []).slice(0, 3).map(function(l) {
        return '<span style="color:var(--text-2)">' + l.metric + '</span> <span style="color:var(--text-3)">(' + l.loading.toFixed(2) + ')</span>';
      }).join(', ');
      h += '<tr><td>PC' + c.index + '</td><td style="color:var(--text-1)">' + escHtml(c.name) + '</td>';
      h += '<td class="num">' + bar + c.variance_explained + '%</td>';
      h += '<td class="num">' + c.cumulative + '%</td>';
      h += '<td style="font-size:10px">' + loads + '</td></tr>';
    });
    h += '</tbody></table></div>';
  }

  // ── Length Confounds ──
  if (r.length_confounds && r.length_confounds.length) {
    h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Length Confound Analysis</div>';
    h += '<div class="mod-results-body collapsed" style="max-height:350px">';
    h += '<table class="mod-tbl"><thead><tr><th>Metric</th><th class="num">r</th><th class="num">r²</th><th>Severity</th></tr></thead><tbody>';
    r.length_confounds.forEach(function(c) {
      var sCol = c.severity === 'heavily confounded' ? 'var(--red)' : c.severity === 'moderately confounded' ? 'var(--orange)' : c.severity === 'mildly confounded' ? 'var(--yellow, var(--orange))' : 'var(--green)';
      h += '<tr><td style="color:var(--cyan)">' + escHtml(c.metric) + '</td>';
      h += '<td class="num">' + c.r.toFixed(4) + '</td>';
      h += '<td class="num">' + c.r_squared.toFixed(4) + '</td>';
      h += '<td style="color:' + sCol + '">' + c.severity + '</td></tr>';
    });
    h += '</tbody></table></div>';
  }

  // ── Redundancy ──
  if (r.redundancy && r.redundancy.pairs && r.redundancy.pairs.length) {
    h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Metric Redundancy (|r| ≥ ' + r.redundancy.threshold + ')</div>';
    h += '<div class="mod-results-body collapsed">';
    h += '<table class="mod-tbl"><thead><tr><th>Metric A</th><th>Metric B</th><th class="num">r</th><th>Assessment</th></tr></thead><tbody>';
    r.redundancy.pairs.forEach(function(p) {
      var iCol = p.implication === 'functionally identical' ? 'var(--red)' : 'var(--orange)';
      h += '<tr><td style="color:var(--cyan)">' + escHtml(p.metric_a) + '</td>';
      h += '<td style="color:var(--cyan)">' + escHtml(p.metric_b) + '</td>';
      h += '<td class="num">' + p.r.toFixed(4) + '</td>';
      h += '<td style="color:' + iCol + '">' + p.implication + '</td></tr>';
    });
    h += '</tbody></table></div>';
  }

  // ── Category Stress ──
  if (r.category_stress) {
    h += '<div class="mod-results-header" onclick="this.nextElementSibling.classList.toggle(\'collapsed\')">Category Stress Distribution</div>';
    h += '<div class="mod-results-body collapsed"><div class="mod-summary">';
    var sep = r.category_stress._separation;
    if (sep) {
      h += tvStat('Safe Mean Stress', sep.safe_mean.toFixed(4), sep.n_safe + ' prompts');
      h += tvStat('Risk Mean Stress', sep.risk_mean.toFixed(4), sep.n_risk + ' prompts');
      h += tvStat("Cohen's d", sep.cohens_d.toFixed(3), 'supplementary metric');
    }
    Object.keys(r.category_stress).forEach(function(cat) {
      if (cat === '_separation') return;
      var cs = r.category_stress[cat];
      h += tvStat(cat, cs.mean_stress.toFixed(4) + ' ± ' + cs.std_stress.toFixed(4), 'n=' + cs.n);
    });
    h += '</div></div>';
  }

  // ── Data summary footer ──
  h += '<div style="padding:8px 16px;font-size:10px;color:var(--text-3);border-top:1px solid var(--border);margin-top:8px">';
  h += r.n_prompts + ' prompts (' + r.n_safe + ' safe, ' + r.n_risk + ' risk) · ';
  h += r.n_features + ' features · ';
  h += 'Categories: ' + (r.categories || []).join(', ');
  if (r.safe_categories) {
    h += ' · Safe=' + r.safe_categories.join(',');
  }
  if (r.config) {
    h += '<br>seed=' + r.config.random_seed + ' · ' + r.config.n_folds + '-fold CV · ';
    h += 'LR(lr=' + r.config.lr_learning_rate + ', iter=' + r.config.lr_iterations + ', λ=' + r.config.lr_regularization + ') · ';
    h += 'PCA@' + Math.round(r.config.pca_variance_target * 100) + '%';
  }
  h += '</div>';

  h += '</div>';
  return h;
}

(function() {
  var origSwitch = switchMainTab;
  var modulesLoaded = false;
  switchMainTab = function(el, id) {
    origSwitch(el, id);
    if (id === 'panel-modules' && !modulesLoaded) {
      modulesLoaded = true;
      loadModules();
    }
  };
})();

