"""Domain Surface: polar-projected per-token embeddings onto probe axes.

Ported from TASM's engine/modules/domain_surface.py. Co-fits PCA on
prompt + probe embeddings, builds per-token observations with metric
data, computes stratification. Output shape matches TASM renderer.
"""
from __future__ import annotations

import logging
import math
from collections import defaultdict
from typing import Optional

import numpy as np

from tagm.analysis.base import AnalysisModule
from tagm.analysis.registry import register_analysis
from tagm.analysis.statistics import extract_scalar
from tagm.measurement.parameters import ModuleParameter

logger = logging.getLogger("tagm")

NORM_EPS = 1e-12
PROBE_TEXT_DISPLAY_LEN = 40
PROMPT_TEXT_DISPLAY_LEN = 200


def _get_measurement_flat(prompt, meas_name):
    ms = (prompt.get("measurements") or {}).get(meas_name)
    if not ms:
        return {}
    flat = {}
    flat.update(ms.get("scalars") or {})
    flat.update(ms.get("per_token") or {})
    flat.update(ms.get("per_layer") or {})
    flat.update(ms.get("objects") or {})
    return flat


def _get_per_token_embs(prompt, depth="final"):
    pte = ((prompt.get("measurements") or {}).get("per_token_embedding") or {})
    embs = (pte.get("objects") or {}).get("per_token_embeddings") or {}
    return embs.get(depth)


def _cofit_pca(prompt_embs, probe_embs, n_components=2):
    """Numpy-only PCA on concatenated prompt + probe embeddings."""
    all_embs = np.vstack([prompt_embs, probe_embs])
    mu = all_embs.mean(axis=0)
    centered = all_embs - mu
    C = np.cov(centered.T)
    if C.ndim == 0:
        C = np.array([[C]])
    eigvals, eigvecs = np.linalg.eigh(C)
    idx = np.argsort(eigvals)[::-1]
    eigvals = eigvals[idx]
    eigvecs = eigvecs[:, idx]

    total = eigvals.sum()
    variance = [round(float(eigvals[i] / total) * 100, 1) if total > 0 else 0
                for i in range(min(n_components, len(eigvals)))]

    proj = centered @ eigvecs[:, :n_components]
    n_p = len(prompt_embs)
    return proj[:n_p], proj[n_p:], variance


def _nearest_probe(dx, dy, anchor_pts):
    best_dist = float("inf")
    best_idx = 0
    for i, a in enumerate(anchor_pts):
        d = math.sqrt((dx - a["x"]) ** 2 + (dy - a["y"]) ** 2)
        if d < best_dist:
            best_dist = d
            best_idx = i
    return best_idx, best_dist


def _build_observations(prompts, prompt_coords, anchor_pts, subjects,
                        top_n=20, min_appearances=2):
    """Build per-token observations from TAGM measurement data."""
    token_freq = defaultdict(int)
    raw_obs = []
    subj_to_idx = {s: i for i, s in enumerate(subjects)}

    for pi, sr in enumerate(prompts):
        dx = float(prompt_coords[pi, 0])
        dy = float(prompt_coords[pi, 1])
        cat = ((sr.get("category") or "?")[:1]).lower()
        toks = sr.get("tokens") or []

        rd = _get_measurement_flat(sr, "rank_displacement")
        per_pos = rd.get("per_position") or []
        stress_arr = ((sr.get("measurements") or {}).get("stress_score") or {}).get("per_token", {}).get("stress") or []
        sfd_arr = ((sr.get("measurements") or {}).get("spectral_field_density") or {}).get("per_token", {}).get("density") or []

        for pos in range(min(len(toks), len(per_pos) if per_pos else len(toks))):
            tok = toks[pos].strip()
            if not tok:
                continue
            token_freq[tok] += 1

            pd = per_pos[pos] if pos < len(per_pos) else {}
            disp = float(pd.get("total_disp", 0)) if isinstance(pd, dict) else 0
            repl = float(pd.get("replacement_ratio", 0)) if isinstance(pd, dict) else 0
            asm = float(stress_arr[pos]) if pos < len(stress_arr) else 0
            sfd_d = float(sfd_arr[pos]) if pos < len(sfd_arr) else 0

            raw_obs.append({
                "tok": tok, "cat": cat, "dx": dx, "dy": dy,
                "disp": disp, "repl": repl, "asm": asm, "sfd_d": sfd_d,
                "pi": pi, "pos": pos,
            })

    qualified = {t: n for t, n in token_freq.items() if n >= min_appearances}
    top = sorted(qualified.keys(), key=lambda t: -qualified[t])[:top_n]

    token_cv = {}
    for tok in top:
        disps = [o["disp"] for o in raw_obs if o["tok"] == tok]
        if len(disps) >= 2:
            m = np.mean(disps)
            token_cv[tok] = round(float(np.std(disps) / max(abs(m), NORM_EPS)), 3)
        else:
            token_cv[tok] = 0
    ordered = sorted(top, key=lambda t: token_cv.get(t, 0))

    top_set = set(ordered)
    obs_export = []

    for o in raw_obs:
        if o["tok"] not in top_set:
            continue
        # Find nearest probe
        near_idx, near_dist = _nearest_probe(o["dx"], o["dy"], anchor_pts)
        near_a = anchor_pts[near_idx]
        near_level = near_a.get("level", 0)
        near_subj = near_a.get("subject", "")
        near_subj_idx = subj_to_idx.get(near_subj, 0)
        near_angle = math.atan2(o["dy"] - near_a["y"],
                                o["dx"] - near_a["x"])

        obs_export.append([
            o["tok"], o["cat"], round(o["dy"], 4), round(o["disp"], 4),
            round(o["repl"], 4), round(o["dx"], 4),
            round(o["asm"], 4), round(o["sfd_d"], 4),
            o["pi"], o["pos"],
            round(near_dist, 4), int(near_level), int(near_subj_idx),
            round(near_angle, 4),
        ])

    return obs_export, ordered, token_cv


def _stratification(obs, subjects):
    by_level = defaultdict(lambda: defaultdict(int))
    by_subject = defaultdict(lambda: defaultdict(int))
    for o in obs:
        cat = o[1]
        by_level[int(round(o[11]))][cat] += 1
        if o[12] < len(subjects):
            by_subject[subjects[o[12]]][cat] += 1
    return {
        "by_level": {str(k): dict(v) for k, v in sorted(by_level.items())},
        "by_subject": {k: dict(v) for k, v in sorted(by_subject.items())},
    }


@register_analysis
class DomainSurface(AnalysisModule):
    name = "domain_surface"
    display_name = "Domain Surface"
    description = (
        "Polar-projected per-token embedding scatter. Co-fits PCA on "
        "prompt + probe embeddings, builds per-token observations with "
        "correction metrics, computes stratification by discourse level."
    )
    version = "1.0.0"
    min_results = 5

    depends_on_measurements = ()

    parameters = [
        ModuleParameter(name="top_tokens", display_name="Top Tokens",
                        description="Maximum unique tokens to track.",
                        kind="int", default=30, min_value=5, max_value=100),
        ModuleParameter(name="min_appearances", display_name="Min Appearances",
                        description="Minimum token occurrences to include.",
                        kind="int", default=2, min_value=1, max_value=20),
        ModuleParameter(name="pca_components", display_name="PCA Components",
                        description="Number of PCA dimensions.",
                        kind="int", default=2, min_value=2, max_value=5),
    ]

    def __init__(self):
        self._pipeline = None
        self._probe_store = None

    def set_pipeline(self, pipeline):
        self._pipeline = pipeline

    def set_probe_store(self, probe_store):
        self._probe_store = probe_store

    def check_dependencies(self, session: dict) -> list[str]:
        if self._probe_store is None:
            return ["Domain Surface requires a probe store."]
        return []

    def run(self, session: dict, params: dict,
            probes: Optional[dict] = None) -> dict:
        prompts = session.get("prompts") or []
        top_tokens = int(params.get("top_tokens", 30))
        min_appearances = int(params.get("min_appearances", 2))
        pca_components = int(params.get("pca_components", 2))

        probe_set = self._get_active_probe_set()
        if probe_set is None:
            return {"error": "No active probe set."}

        subjects = list(dict.fromkeys(p.row for p in probe_set.probes))
        subclasses = list(dict.fromkeys(p.column for p in probe_set.probes))
        level_names = [l.replace("_", " ") for l in subclasses]
        level_idx = {l: i for i, l in enumerate(subclasses)}

        # Get probe embeddings at subject depth
        subj_mat, subj_labels = probe_set.embeddings_matrix(probe_set.depth_labels[0])
        if subj_mat.shape[0] == 0:
            return {"error": "No probe embeddings at subject depth."}

        probe_embs = subj_mat.astype(np.float64)

        # Build prompt embeddings: mean-pool per-token final embeddings
        prompt_embs_list = []
        valid_indices = []
        for pi, r in enumerate(prompts):
            fe = _get_per_token_embs(r, "final")
            if fe is None:
                # Try subject depth
                if probe_set.depth_labels:
                    fe = _get_per_token_embs(r, probe_set.depth_labels[0])
            if fe is not None and len(fe) > 0:
                arr = np.array(fe, dtype=np.float64)
                mean_emb = arr.mean(axis=0)
                norm = np.linalg.norm(mean_emb)
                if norm > NORM_EPS:
                    mean_emb /= norm
                prompt_embs_list.append(mean_emb)
                valid_indices.append(pi)

        if len(prompt_embs_list) < 3:
            return {"error": f"Need at least 3 prompts with embeddings. Have {len(prompt_embs_list)}."}

        prompt_embs = np.array(prompt_embs_list, dtype=np.float64)

        # Ensure dimensions match
        if prompt_embs.shape[1] != probe_embs.shape[1]:
            return {"error": f"Dimension mismatch: prompts={prompt_embs.shape[1]}, probes={probe_embs.shape[1]}"}

        session_subset = [prompts[i] for i in valid_indices]

        # Co-fit PCA
        prompt_coords, probe_coords, variance = _cofit_pca(
            prompt_embs, probe_embs, n_components=pca_components)

        # Build anchor points from probes
        anchor_pts = []
        for i, p in enumerate(probe_set.probes):
            li = level_idx.get(p.column, 0)
            anchor_pts.append({
                "subject": p.row,
                "level": li,
                "text": p.label[:PROBE_TEXT_DISPLAY_LEN],
                "x": float(probe_coords[i, 0]),
                "y": float(probe_coords[i, 1]),
            })

        # Build observations
        obs, ordered_tokens, token_cv = _build_observations(
            session_subset, prompt_coords, anchor_pts,
            subjects, top_tokens, min_appearances)

        strat = _stratification(obs, subjects)

        # Compact anchors
        subj_idx = {s: i for i, s in enumerate(subjects)}
        anchors_compact = [{
            "s": subj_idx.get(a["subject"], 0),
            "l": a["level"],
            "t": a["text"],
            "x": round(a["x"], 4),
            "y": round(a["y"], 4),
        } for a in anchor_pts]

        prompt_texts = [(r.get("prompt") or "")[:PROMPT_TEXT_DISPLAY_LEN]
                        for r in session_subset]

        return {
            "pca": variance,
            "pca_components": pca_components,
            "layer": "middle",
            "n_prompts_used": len(prompt_embs),
            "n_prompts_total": len(prompts),
            "min_appearances": min_appearances,
            "subjects": subjects,
            "tokens": ordered_tokens,
            "token_cv": token_cv,
            "anchors": anchors_compact,
            "observations": obs,
            "prompts": prompt_texts,
            "fields": [
                "tok", "cat", "dy", "disp", "repl", "dx",
                "asm", "sfd_d", "pi", "pos",
                "near_dist", "near_level", "near_subj_idx",
                "near_angle",
            ],
            "stratification": strat,
            "probe_file": probe_set.template_name,
            "level_names": level_names,
        }

    def _get_active_probe_set(self):
        if self._probe_store is None:
            return None
        sets = self._probe_store.list()
        if not sets:
            return None
        return self._probe_store.get_by_id(sets[-1]["set_id"])
